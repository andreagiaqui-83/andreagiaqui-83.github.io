ag_main : dialog {
  label = "AG CAD Tools 2.0";
  : column {
    : text {
      label = "Suite CAD indipendente - 198 strumenti - Core, Web e personali";
      alignment = centered;
    }
    : list_box {
      key = "lst";
      width = 82;
      height = 16;
    }
    : text {
      key = "categoria";
      label = "Categoria:";
      width = 82;
    }
    : row {
      : button { key = "run"; label = "Avvia"; is_default = true; width = 18; }
      : button { key = "diag"; label = "Diagnostica"; width = 18; }
      : button { key = "cancel"; label = "Chiudi"; is_cancel = true; width = 18; }
    }
  }
}
