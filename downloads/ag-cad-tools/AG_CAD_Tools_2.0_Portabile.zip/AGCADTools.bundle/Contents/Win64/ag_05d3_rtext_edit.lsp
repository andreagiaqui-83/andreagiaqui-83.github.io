; AG CAD Tools 1.9 - modulo isolato clean-room 0.5d3
; Testo remoto: aggiornamento, modifica sorgente e apertura editor.
(defun cti:modificatestoremoto-core (/ sel e src opt p diesel-src editor)
  (setq sel (entsel "\nSelezionare un testo remoto AG CAD Tools: "))
  (if sel
    (progn
      (setq e (car sel))
      (setq src (cti:rtext-source e))
      (if (null src)
        (princ "\nL'oggetto selezionato non e' un testo remoto AG CAD Tools.")
        (progn
          (initget "Aggiorna Sorgente Apri")
          (setq opt (getkword "\nOperazione [Aggiorna/Sorgente/Apri] <Aggiorna>: "))
          (if (null opt) (setq opt "Aggiorna"))
          (if (= opt "Aggiorna")
            (progn
              (cti:rtext-refresh-one e)
              (princ "\nTesto remoto aggiornato."))
            (if (= opt "Sorgente")
              (progn
                (if (wcmatch src "FILE|*")
                  (progn
                    (setq p (getfiled "Nuovo file di testo" (substr src 6) "txt" 0))
                    (if p (setq src (strcat "FILE|" p))))
                  (progn
                    (setq diesel-src (getstring T (strcat "\nNuova espressione DIESEL <" (substr src 8) ">: ")))
                    (if (/= diesel-src "") (setq src (strcat "DIESEL|" diesel-src)))))
                (cti:xdata-set-data e "CTI_REMOTE_TEXT" (list (cons 1000 src)))
                (cti:rtext-refresh-one e))
              (if (= opt "Apri")
                (if (wcmatch src "FILE|*")
                  (progn
                    (setq p (substr src 6))
                    (setq editor (cti:rtext-editor))
                    (if (= editor ".")
                      (startapp "notepad.exe" p)
                      (startapp editor p))
                    (princ "\nEditor avviato. Dopo il salvataggio usare MODIFICATESTOREMOTO > Aggiorna."))
                  (princ "\nLa sorgente DIESEL si modifica con l'opzione Sorgente."))))))))
  (princ)))

(defun c:AG_MODIFICATESTOREMOTO () (cti2:esegui-comando "AG_MODIFICATESTOREMOTO" 'cti:modificatestoremoto-core))
(defun c:MODIFICATESTOREMOTO () (c:AG_MODIFICATESTOREMOTO))
(princ)
