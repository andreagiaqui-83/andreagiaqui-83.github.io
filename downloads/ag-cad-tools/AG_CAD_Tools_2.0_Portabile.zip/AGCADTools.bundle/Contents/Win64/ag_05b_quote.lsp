; AG CAD Tools 1.9 - modulo isolato clean-room 0.5
; Caricato dal bootstrap principale con gestione errori.
; --- RIASSOCIAQUOTE / equivalente funzionale DIMREASSOC ---
(defun cti:riassociaquote-core (/ ss i o n)
  (setq ss (ssget '((0 . "DIMENSION"))))
  (if ss
    (progn
      (setq i 0 n 0)
      (repeat (sslength ss)
        (setq o (vlax-ename->vla-object (ssname ss i)))
        (if (vlax-property-available-p o 'TextOverride T)
          (progn (vla-put-TextOverride o "") (vla-Update o) (setq n (1+ n))))
        (setq i (1+ i)))
      (princ (strcat "\n" (itoa n) " quote riportate al valore misurato."))))
  (princ))
(defun c:AG_RIASSOCIAQUOTE () (cti2:esegui-comando "AG_RIASSOCIAQUOTE" 'cti:riassociaquote-core))
(defun c:RIASSOCIAQUOTE () (c:AG_RIASSOCIAQUOTE))

; --- SCALATESTOCARTA / equivalente funzionale PSTSCALE ---
(defun cti:vp-custom-scale (/ doc vp r)
  (if (and (= (getvar "TILEMODE") 0) (> (getvar "CVPORT") 1))
    (progn
      (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
            r (vl-catch-all-apply 'vla-get-ActivePViewport (list doc)))
      (if (not (vl-catch-all-error-p r))
        (progn (setq vp r r (vl-catch-all-apply 'vla-get-CustomScale (list vp)))
               (if (and (not (vl-catch-all-error-p r)) (> r 1e-12)) r nil))))))
(defun cti:pstscale-record (e / d ph key)
  (setq d (cti:xdata-data e "CTI_PSTSCALE"))
  (if d
    (progn
      (setq ph (cdr (assoc 1040 d)) key (cdr (assoc 1000 d)))
      (if ph (list ph (if key key "Esistente")) nil))))
(defun cti:scalatestocarta-core (/ sc ss opt ph just i e o rec base cur target fac n)
  (setq sc (cti:vp-custom-scale))
  (if (null sc)
    (princ "\nAttivare una finestra di layout (spazio modello nella finestra) e riprovare.")
    (progn
      (setq ss (ssget '((0 . "TEXT,MTEXT"))))
      (if ss
        (progn
          (initget "Imposta Aggiorna")
          (setq opt (getkword "\nScala testo carta [Imposta/Aggiorna] <Aggiorna>: "))
          (if (null opt) (setq opt "Aggiorna"))
          (if (= opt "Imposta")
            (progn
              (initget 6)
              (setq ph (getdist "\nAltezza desiderata in spazio carta <2.5>: "))
              (if (null ph) (setq ph 2.5))
              (initget "Esistente Inizio Centro Medio Destra AS AC AD MS MC MD BS BC BD")
              (setq just (getkword "\nPunto base [Esistente/Inizio/Centro/Medio/Destra/AS/AC/AD/MS/MC/MD/BS/BC/BD] <Esistente>: "))
              (if (null just) (setq just "Esistente"))))
          (setq i 0 n 0)
          (repeat (sslength ss)
            (setq e (ssname ss i)
                  o (vlax-ename->vla-object e)
                  rec (if (= opt "Aggiorna") (cti:pstscale-record e) (list ph just)))
            (if rec
              (progn
                (setq ph (car rec)
                      just (cadr rec)
                      base (if (= just "Esistente") (cti:existing-anchor o) (cti:anchor-from-bbox o (if (= just "Inizio") "MS" just)))
                      cur (cti:text-height-value o)
                      target (/ ph sc))
                (if (and base (> cur 1e-12) (> target 0.0) (vlax-method-applicable-p o 'ScaleEntity))
                  (progn
                    (setq fac (/ target cur))
                    (vla-ScaleEntity o (vlax-3d-point base) fac)
                    (cti:xdata-set-data e "CTI_PSTSCALE" (list (cons 1040 ph) (cons 1000 just)))
                    (setq n (1+ n))))))
            (setq i (1+ i)))
          (princ (strcat "\n" (itoa n) " oggetti aggiornati alla scala carta (scala finestra " (rtos sc 2 6) ")."))))))
  (princ))
(defun c:AG_SCALATESTOCARTA () (cti2:esegui-comando "AG_SCALATESTOCARTA" 'cti:scalatestocarta-core))
(defun c:SCALATESTOCARTA () (c:AG_SCALATESTOCARTA))
(princ)
