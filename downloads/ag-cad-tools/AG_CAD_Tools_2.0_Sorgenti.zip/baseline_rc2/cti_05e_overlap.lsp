; CAD Tools Italiano 1.9 - modulo isolato clean-room 0.5
; Caricato dal bootstrap principale con gestione errori.
; --- SEPARATESTI / equivalente funzionale TSPACEINVADERS ---
(defun cti:bbox-overlap-selection (e / o mn mx a b ss i x found mh)
  (setq o (vlax-ename->vla-object e))
  (if (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'mn 'mx))) nil
    (progn
      (setq a (vlax-safearray->list mn) b (vlax-safearray->list mx)
            ss (ssget "_C" (trans a 0 1) (trans b 0 1)) i 0 found nil)
      (if ss
        (while (and (< i (sslength ss)) (not found))
          (setq x (ssname ss i))
          (if (/= x e)
            (progn
              (setq mh (cti:textmask-handle e))
              (if (or (null mh) (/= x (handent mh))) (setq found T))))
          (setq i (1+ i)))) found)))
(defun cti:separatesti-core (/ r ss ask i e out inc n)
  (princ "\nSelezionare testi da controllare oppure premere Invio per tutto il disegno...")
  (setq r (vl-catch-all-apply 'ssget (list '((0 . "TEXT,MTEXT,ATTRIB,ATTDEF")))))
  (if (vl-catch-all-error-p r) (setq ss nil) (setq ss r))
  (if (null ss) (setq ss (ssget "_X" '((0 . "TEXT,MTEXT,ATTRIB,ATTDEF")))))
  (if ss
    (progn
      (initget "Si No") (setq ask (getkword "\nVerificare singolarmente ogni testo sovrapposto? [Si/No] <No>: ")) (if (null ask) (setq ask "No"))
      (setq out (ssadd) i 0 n 0)
      (while (< i (sslength ss))
        (setq e (ssname ss i))
        (if (cti:bbox-overlap-selection e)
          (progn
            (setq inc T)
            (if (= ask "Si")
              (progn (redraw e 3) (initget "Si No Esci") (setq r (getkword "\nIncludere questo testo? [Si/No/Esci] <Si>: ")) (redraw e 4)
                     (if (null r) (setq r "Si"))
                     (cond ((= r "No") (setq inc nil)) ((= r "Esci") (setq inc nil i (sslength ss))))))
            (if inc (progn (ssadd e out) (setq n (1+ n))))))
        (setq i (1+ i)))
      (sssetfirst nil out)
      (princ (strcat "\nTesti con possibile sovrapposizione: " (itoa n) ". La selezione resta attiva."))))
  (princ))
(defun c:CTI_SEPARATESTI () (cti2:esegui-comando "CTI_SEPARATESTI" 'cti:separatesti-core))
(defun c:SEPARATESTI () (c:CTI_SEPARATESTI))
(defun c:CTI_TROVASOVRAPPOSIZIONI () (c:CTI_SEPARATESTI))
(defun c:TROVASOVRAPPOSIZIONI () (c:CTI_SEPARATESTI))
(princ)
