; CAD Tools Italiano 1.9 - modulo isolato clean-room 0.5d2
; Testo remoto: creazione e scelta editor.
(defun cti:rtext-editor ()
  (cti:registry-string "RemoteTextEditor" "."))

(defun cti:testoremoto-core (/ opt p diesel-src src pt h rot e)
  (initget "File Diesel")
  (setq opt (getkword "\nSorgente testo remoto [File/Diesel] <File>: "))
  (if (null opt) (setq opt "File"))
  (setq src nil)
  (if (= opt "File")
    (progn
      (setq p (getfiled "Selezionare file di testo" "" "txt" 0))
      (if p (setq src (strcat "FILE|" p))))
    (progn
      (setq diesel-src (getstring T "\nEspressione DIESEL: "))
      (if (/= diesel-src "") (setq src (strcat "DIESEL|" diesel-src)))))
  (if src
    (progn
      (setq pt (getpoint "\nPunto di inserimento: "))
      (if pt
        (progn
          (initget 6)
          (setq h (getdist pt (strcat "\nAltezza testo <" (rtos (getvar "TEXTSIZE") 2 2) ">: ")))
          (if (null h) (setq h (getvar "TEXTSIZE")))
          (setq rot (getangle pt "\nAngolo di rotazione <0>: "))
          (if (null rot) (setq rot 0.0))
          (setq e (cti:rtext-create pt h rot src))
          (if e (princ "\nTesto remoto CTI creato."))))))
  (princ))

(defun c:CTI_TESTOREMOTO () (cti2:esegui-comando "CTI_TESTOREMOTO" 'cti:testoremoto-core))
(defun c:TESTOREMOTO () (c:CTI_TESTOREMOTO))

(defun cti:apptestoremoto-core (/ cur p)
  (setq cur (cti:rtext-editor))
  (setq p (getstring T (strcat "\nEditor testo remoto o . per predefinito <" cur ">: ")))
  (if (= p "") (setq p cur))
  (vl-registry-write "HKEY_CURRENT_USER\\Software\\CADToolsItaliano" "RemoteTextEditor" p)
  (princ (strcat "\nEditor memorizzato: " p))
  (princ))

(defun c:CTI_APPTESTOREMOTO () (cti2:esegui-comando "CTI_APPTESTOREMOTO" 'cti:apptestoremoto-core))
(defun c:APPTESTOREMOTO () (c:CTI_APPTESTOREMOTO))
(princ)
