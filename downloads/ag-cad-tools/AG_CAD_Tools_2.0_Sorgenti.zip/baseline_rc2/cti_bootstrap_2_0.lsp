; CAD Tools Italiano 2.0 RC2 - unico punto di caricamento per documento.
(vl-load-com)
(setq *CTI2-LOAD-COMPLETE* nil *CTI2-LOAD-ERRORS* nil *CTI2-RUNTIME-OK* nil
      *CTI-WEB-2-0-LOADED* nil *CTI-ANDREA-LOADED* nil *CTI-UI-2-0-COUNT* nil
      *CTI2-DIAGNOSTICA-OK* nil)
(setq *CTI2-DIRECTORY*
  (strcat (vl-filename-directory (findfile "cti_bootstrap_2_0.lsp")) "\\"))
(defun cti2:carica-modulo (nome / p r)
  (setq p (strcat *CTI2-DIRECTORY* nome))
  (if (findfile p)
    (progn
      (setq r (vl-catch-all-apply 'load (list p)))
      (if (vl-catch-all-error-p r)
        (setq *CTI2-LOAD-ERRORS* (cons (strcat nome ": " (vl-catch-all-error-message r)) *CTI2-LOAD-ERRORS*))))
    (setq *CTI2-LOAD-ERRORS* (cons (strcat nome ": file mancante") *CTI2-LOAD-ERRORS*)))
  (princ))
(progn
  (cti2:carica-modulo "cti_runtime_2_0.lsp")
  (cti2:carica-modulo "cad_tools_italiano.lsp")
  (cti2:carica-modulo "cti_web_2_0.lsp")
  (cti2:carica-modulo "cti_andrea_2_0.lsp")
  (cti2:carica-modulo "cti_catalogo_2_0.lsp")
  (cti2:carica-modulo "cti_diagnostica_2_0.lsp"))
(setq *CTI2-LOAD-COMPLETE*
  (and (null *CTI2-LOAD-ERRORS*) *CTI2-RUNTIME-OK* *CTI-LOAD-COMPLETE*
       *CTI-WEB-2-0-LOADED* *CTI-ANDREA-LOADED* *CTI2-DIAGNOSTICA-OK*
       (= *CTI-UI-2-0-COUNT* 200)
       (null (cti2:comandi-mancanti *CTI2-COMANDI-PUBBLICI*))))
(if *CTI2-LOAD-COMPLETE*
  (princ "\nCAD Tools Italiano 2.0 RC2 caricato: 93 core + 100 Web + 5 personali. Digita CTI.")
  (princ "\nCAD Tools Italiano: caricamento incompleto. Digita CTI_DIAGNOSTICA."))
(princ)
