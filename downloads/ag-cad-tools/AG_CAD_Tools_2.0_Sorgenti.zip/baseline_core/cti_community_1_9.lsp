; CAD Tools Italiano 1.9 - modulo Community MIT
; 12 strumenti adattati e localizzati per CAD Tools Italiano.
;
; Basati su routine del progetto BGol CAD Lisps:
; https://github.com/thevijayparmar/bgol-cad-lisps
; Revisione di riferimento: 3acbe32f71b489f4c81dcd9372f989591a9be858
; Copyright (c) 2026 BGol Community (https://bgol.in/)
; Licenza MIT. Vedere LICENZE_TERZE_PARTI.txt distribuito con il plugin.
;
; Adattamenti CTI: namespace, prompt italiani, gestione errori, controlli input,
; integrazione AutoCAD 2027 Italiano e correzioni conservative senza cambiare
; l'obiettivo funzionale originario delle routine.

(vl-load-com)
(setq *CTI-COMMUNITY-VERSION* "1.9")
(setq *CTI-COMMUNITY-COUNT* 12)
(setq *CTI-COMMUNITY-LOADED* nil)

(defun cti19:assicura-layer (lname color /)
  (if (not (tblsearch "LAYER" lname))
    (entmake
      (list '(0 . "LAYER")
            '(100 . "AcDbSymbolTableRecord")
            '(100 . "AcDbLayerTableRecord")
            (cons 2 lname)
            '(70 . 0)
            (cons 62 color)
            '(6 . "Continuous"))))
  lname)

(defun cti19:in-lista (value / v r)
  (setq v value)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond
    ((listp v) v)
    (T
     (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
     (if (vl-catch-all-error-p r) nil r))))

(defun cti19:punti-unici (pts tol / out p q found)
  (setq out nil)
  (foreach p pts
    (setq found nil)
    (foreach q out
      (if (< (distance p q) tol) (setq found T)))
    (if (not found) (setq out (cons p out))))
  (reverse out))

(defun cti19:intersezioni (o1 o2 / r vals out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list o1 'IntersectWith o2 acExtendNone)))
  (if (vl-catch-all-error-p r)
    nil
    (progn
      (setq vals (cti19:in-lista r) out nil)
      (while (and vals (>= (length vals) 3))
        (setq out (cons (list (car vals) (cadr vals) (caddr vals)) out)
              vals (cdddr vals)))
      (reverse out))))

(defun cti19:vertici-entita (ename / ed typ obj coords elev n i out vent vd pt)
  (setq ed (entget ename) typ (cdr (assoc 0 ed)) out nil)
  (cond
    ((= typ "LWPOLYLINE")
     (setq obj (vlax-ename->vla-object ename)
           coords (cti19:in-lista (vlax-get obj 'Coordinates))
           elev (vl-catch-all-apply 'vlax-get (list obj 'Elevation)))
     (if (vl-catch-all-error-p elev) (setq elev 0.0))
     (setq n (/ (length coords) 2) i 0)
     (while (< i n)
       (setq out (cons (list (nth (* 2 i) coords)
                             (nth (1+ (* 2 i)) coords)
                             elev) out)
             i (1+ i)))
     (reverse out))
    ((= typ "POLYLINE")
     (setq vent (entnext ename))
     (while (and vent (= (cdr (assoc 0 (entget vent))) "VERTEX"))
       (setq vd (entget vent) pt (cdr (assoc 10 vd)))
       (setq out (cons pt out) vent (entnext vent)))
     (reverse out))
    (T nil)))

(defun cti19:crea-testo (pt txt ht layer /)
  (entmakex
    (list '(0 . "TEXT") '(100 . "AcDbEntity") (cons 8 layer)
          '(100 . "AcDbText") (cons 10 pt) (cons 40 ht) (cons 1 txt))))

(defun cti19:crea-cerchio (pt rad layer /)
  (entmakex
    (list '(0 . "CIRCLE") '(100 . "AcDbEntity") (cons 8 layer)
          '(100 . "AcDbCircle") (cons 10 pt) (cons 40 rad))))

(defun cti19:crea-lwpoly (pts layer closed / data p)
  (setq data
    (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 layer)
          '(100 . "AcDbPolyline") (cons 90 (length pts))
          (cons 70 (if closed 1 0))))
  (foreach p pts
    (setq data (append data (list (cons 10 (list (car p) (cadr p)))))))
  (entmakex data))

(defun cti19:intero-rigoroso (s / t0 n)
  (setq t0 (vl-string-trim " \t" s))
  (if (= t0 "")
    nil
    (progn
      (setq n (distof t0 2))
      (if (and n (= n (fix n))) (fix n) nil))))

(defun cti19:lista-stringa (lst / out x)
  (setq out "")
  (foreach x lst
    (setq out (strcat out (if (= out "") "" ", ") (itoa x))))
  out)

(defun cti19:separatore-csv (line / i quoted ch commas semis)
  (setq i 1 quoted nil commas 0 semis 0)
  (while (<= i (strlen line))
    (setq ch (substr line i 1))
    (cond
      ((= ch "\"")
       (if (and quoted (< i (strlen line)) (= (substr line (1+ i) 1) "\""))
         (setq i (1+ i))
         (setq quoted (not quoted))))
      ((and (not quoted) (= ch ",")) (setq commas (1+ commas)))
      ((and (not quoted) (= ch ";")) (setq semis (1+ semis))))
    (setq i (1+ i)))
  (if (> semis commas) ";" ","))

(defun cti19:dividi-csv (line sep / i quoted ch field out)
  (setq i 1 quoted nil field "" out nil)
  (while (<= i (strlen line))
    (setq ch (substr line i 1))
    (cond
      ((= ch "\"")
       (if (and quoted (< i (strlen line)) (= (substr line (1+ i) 1) "\""))
         (progn (setq field (strcat field "\"")) (setq i (1+ i)))
         (setq quoted (not quoted))))
      ((and (not quoted) (= ch sep))
       (setq out (cons field out) field ""))
      (T (setq field (strcat field ch))))
    (setq i (1+ i)))
  (reverse (cons field out)))


; ---------------------- GESTIONE SICURA ESC / ERRORI ----------------------
; Tutti i comandi Community vengono eseguiti attraverso questo wrapper.
; ESC/Annulla viene assorbito senza lasciare "; errore:" in riga di comando.
; Gli errori reali restano invece visibili, con prefisso Community MIT.

(defun cti19:annullamento-p (msg / u)
  (setq u (strcase (if msg msg "")))
  (or (wcmatch u "*ANNULL*")
      (wcmatch u "*CANCEL*")
      (wcmatch u "*QUIT*")
      (wcmatch u "*EXIT*")
      (wcmatch u "*ABORT*")
      (wcmatch u "*BREAK*")))

(defun cti19:esegui-comando (fn / *error* r msg)
  (defun *error* (m)
    (if (not (cti19:annullamento-p m))
      (princ (strcat "\nErrore Community MIT: " m)))
    (princ))
  (setq r (vl-catch-all-apply fn '()))
  (if (vl-catch-all-error-p r)
    (progn
      (setq msg (vl-catch-all-error-message r))
      (if (not (cti19:annullamento-p msg))
        (princ (strcat "\nErrore Community MIT: " msg)))))
  (princ))

; ---------------------- 1. SPEZZAINCROCI ----------------------
; Adattato da PBRKALL-bgol.lsp (PBRK). Il risultato sono segmenti LINE
; esatti per polilinee composte da segmenti rettilinei; le polilinee con
; archi/bulge vengono ignorate per evitare deformazioni geometriche.

(defun cti19:prodotto-vettoriale-2d (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun cti19:sottrai-vettori-2d (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))
(defun cti19:somma-vettori-2d (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))
(defun cti19:scala-vettore-2d (a s) (list (* (car a) s) (* (cadr a) s)))

(defun cti19:parametri-intersezione-segmenti (p p2 q q2 / r s qp den tv u)
  (setq r (cti19:sottrai-vettori-2d p2 p) s (cti19:sottrai-vettori-2d q2 q)
        qp (cti19:sottrai-vettori-2d q p) den (cti19:prodotto-vettoriale-2d r s))
  (if (< (abs den) 1e-12)
    nil
    (progn
      (setq tv (/ (cti19:prodotto-vettoriale-2d qp s) den)
            u (/ (cti19:prodotto-vettoriale-2d qp r) den))
      (if (and (>= tv -1e-9) (<= tv (+ 1.0 1e-9))
               (>= u -1e-9) (<= u (+ 1.0 1e-9)))
        (list tv u)
        nil))))

(defun cti19:polilinea-rettilinea-p (ename / ed ok x)
  (setq ed (entget ename) ok T)
  (foreach x ed
    (if (and (= (car x) 42) (> (abs (cdr x)) 1e-12)) (setq ok nil)))
  ok)

(defun cti19:segmenti-polilinea (ename / verts ed closed layer color ltype lw out i n p1 p2)
  (setq verts (cti19:vertici-entita ename)
        ed (entget ename)
        closed (= 1 (logand 1 (cdr (assoc 70 ed))))
        layer (cdr (assoc 8 ed))
        color (assoc 62 ed) ltype (assoc 6 ed) lw (assoc 370 ed)
        out nil n (length verts) i 0)
  (while (< i (1- n))
    (setq p1 (nth i verts) p2 (nth (1+ i) verts)
          out (cons (list ename p1 p2 layer color ltype lw '(0.0 1.0)) out)
          i (1+ i)))
  (if (and closed (> n 2))
    (setq out (cons (list ename (nth (1- n) verts) (car verts) layer color ltype lw '(0.0 1.0)) out)))
  (reverse out))

(defun cti19:aggiungi-parametro (seg tval / ts)
  (setq ts (nth 7 seg))
  (if (not (vl-some '(lambda (x) (< (abs (- x tval)) 1e-8)) ts))
    (setq ts (cons tval ts)))
  (subst ts (nth 7 seg) seg))

(defun cti19:crea-linea-da-segmento (seg ta tb / p1 p2 a b data c lt lw)
  (setq p1 (nth 1 seg) p2 (nth 2 seg)
        a (cti19:somma-vettori-2d p1 (cti19:scala-vettore-2d (cti19:sottrai-vettori-2d p2 p1) ta))
        b (cti19:somma-vettori-2d p1 (cti19:scala-vettore-2d (cti19:sottrai-vettori-2d p2 p1) tb))
        data (list '(0 . "LINE") '(100 . "AcDbEntity") (cons 8 (nth 3 seg))
                   '(100 . "AcDbLine") (cons 10 (list (car a) (cadr a) (caddr p1)))
                   (cons 11 (list (car b) (cadr b) (caddr p2))))
        c (nth 4 seg) lt (nth 5 seg) lw (nth 6 seg))
  (if c (setq data (append data (list c))))
  (if lt (setq data (append data (list lt))))
  (if lw (setq data (append data (list lw))))
  (entmakex data))

(defun cti19:cmd-spezzaincroci (/ ss i en polys skipped segs s1 s2 ti a b allents nmade ts k)
  (princ "\nSeleziona almeno due polilinee rettilinee da spezzare alle intersezioni: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if (and ss (>= (sslength ss) 2))
    (progn
      (setq i 0 polys nil skipped 0 allents nil)
      (repeat (sslength ss)
        (setq en (ssname ss i))
        (if (cti19:polilinea-rettilinea-p en)
          (progn (setq polys (cons en polys) allents (cons en allents)))
          (setq skipped (1+ skipped)))
        (setq i (1+ i)))
      (setq segs nil)
      (foreach en (reverse polys) (setq segs (append segs (cti19:segmenti-polilinea en))))
      (setq i 0)
      (while (< i (length segs))
        (setq s1 (nth i segs) k (1+ i))
        (while (< k (length segs))
          (setq s2 (nth k segs))
          (if (/= (car s1) (car s2))
            (progn
              (setq ti (cti19:parametri-intersezione-segmenti (nth 1 s1) (nth 2 s1) (nth 1 s2) (nth 2 s2)))
              (if ti
                (progn
                  (setq s1 (cti19:aggiungi-parametro s1 (car ti))
                        s2 (cti19:aggiungi-parametro s2 (cadr ti))
                        segs (cti19:imposta-elemento-lista segs i s1)
                        segs (cti19:imposta-elemento-lista segs k s2))))))
          (setq k (1+ k)))
        (setq i (1+ i)))
      (setq nmade 0)
      (foreach s1 segs
        (setq ts (vl-sort (nth 7 s1) '<) k 0)
        (while (< k (1- (length ts)))
          (setq a (nth k ts) b (nth (1+ k) ts))
          (if (> (- b a) 1e-9)
            (progn (cti19:crea-linea-da-segmento s1 a b) (setq nmade (1+ nmade))))
          (setq k (1+ k))))
      (foreach en allents (entdel en))
      (princ (strcat "\nCreati " (itoa nmade) " segmenti LINE spezzati alle intersezioni."
                     (if (> skipped 0) (strcat " Ignorate " (itoa skipped) " polilinee con archi.") ""))))
    (princ "\nServono almeno due polilinee."))
  (princ))

(defun cti19:imposta-elemento-lista (lst idx val / i out x)
  (setq i 0 out nil)
  (foreach x lst
    (setq out (cons (if (= i idx) val x) out) i (1+ i)))
  (reverse out))
(defun c:CTI_SPEZZAINCROCI () (cti19:esegui-comando 'cti19:cmd-spezzaincroci))
(defun c:SPEZZAINCROCI () (c:CTI_SPEZZAINCROCI))

; ---------------------- 2. TABELLA_VERTICI ----------------------
(defun cti19:cmd-tabella-vertici (/ en verts ins rowh colw doc space tab r p)
  (setq en (car (entsel "\nSeleziona una polilinea 2D o 3D: ")))
  (if en
    (progn
      (setq verts (cti19:vertici-entita en))
      (if verts
        (progn
          (setq ins (getpoint "\nIndica il punto di inserimento della tabella: "))
          (if ins
            (progn
              (setq rowh (getdist "\nAltezza riga <8.0>: "))
              (if (or (null rowh) (<= rowh 0.0)) (setq rowh 8.0))
              (setq colw (getdist "\nLarghezza colonna <28.0>: "))
              (if (or (null colw) (<= colw 0.0)) (setq colw 28.0))
              (cti19:assicura-layer "CTI-COMMUNITY-TABELLE" 5)
              (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
                    space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
                    tab (vla-AddTable space (vlax-3d-point ins) (+ 2 (length verts)) 4 rowh colw))
              (vla-put-Layer tab "CTI-COMMUNITY-TABELLE")
              (vla-put-RegenerateTableSuppressed tab :vlax-true)
              (vla-SetText tab 0 0 "TABELLA COORDINATE VERTICI")
              (vla-MergeCells tab 0 0 0 3)
              (vla-SetText tab 1 0 "N.")
              (vla-SetText tab 1 1 "X")
              (vla-SetText tab 1 2 "Y")
              (vla-SetText tab 1 3 "Z")
              (setq r 2)
              (foreach p verts
                (vla-SetText tab r 0 (itoa (1- r)))
                (vla-SetText tab r 1 (rtos (car p) 2 4))
                (vla-SetText tab r 2 (rtos (cadr p) 2 4))
                (vla-SetText tab r 3 (rtos (if (caddr p) (caddr p) 0.0) 2 4))
                (setq r (1+ r)))
              (vla-put-RegenerateTableSuppressed tab :vlax-false)
              (princ (strcat "\nTabella creata con " (itoa (length verts)) " vertici."))))
          )
        (princ "\nL'oggetto selezionato non contiene vertici leggibili.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))
(defun c:CTI_TABELLA_VERTICI () (cti19:esegui-comando 'cti19:cmd-tabella-vertici))
(defun c:TABELLA_VERTICI () (c:CTI_TABELLA_VERTICI))

; ---------------------- 3. ESPORTA_VERTICI_CSV ----------------------
(defun cti19:cmd-esporta-vertici-csv (/ en verts path f i p)
  (setq en (car (entsel "\nSeleziona una polilinea 2D o 3D da esportare: ")))
  (cond
    ((null en)
     (princ "\nNessun oggetto selezionato."))
    ((null (setq verts (cti19:vertici-entita en)))
     (princ "\nL'oggetto selezionato non contiene vertici leggibili."))
    ((null (setq path (getfiled "Salva coordinate vertici" "vertici" "csv" 1)))
     (princ "\nEsportazione annullata."))
    ((null (setq f (open path "w")))
     (princ "\nImpossibile creare il file CSV."))
    (T
     (write-line "Numero;X;Y;Z" f)
     (setq i 1)
     (foreach p verts
       (write-line
         (strcat (itoa i) ";" (rtos (car p) 2 4) ";"
                 (rtos (cadr p) 2 4) ";"
                 (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
       (setq i (1+ i)))
     (close f)
     (princ (strcat "\nEsportati " (itoa (length verts)) " vertici in: " path))))
  (princ))
(defun c:CTI_ESPORTA_VERTICI_CSV () (cti19:esegui-comando 'cti19:cmd-esporta-vertici-csv))
(defun c:ESPORTA_VERTICI_CSV () (c:CTI_ESPORTA_VERTICI_CSV))

; ---------------------- 4. NUMERA_VERTICI ----------------------
(defun cti19:cmd-numera-vertici (/ ss path f ht i en verts p count layer)
  (princ "\nSeleziona le polilinee di cui numerare i vertici: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "LWPOLYLINE") (0 . "POLYLINE") (-4 . "OR>"))))
  (cond
    ((null ss)
     (princ "\nNessuna polilinea selezionata."))
    ((null (setq path (getfiled "Salva elenco numerato vertici" "vertici_numerati" "csv" 1)))
     (princ "\nEsportazione annullata."))
    (T
     (setq ht (getdist "\nAltezza testo numerazione <2.5>: "))
     (if (or (null ht) (<= ht 0.0)) (setq ht 2.5))
     (setq layer (cti19:assicura-layer "CTI-COMMUNITY-VERTICI" 2)
           f (open path "w") count 1 i 0)
     (if f
       (progn
         (write-line "Numero;X;Y;Z" f)
         (repeat (sslength ss)
           (setq en (ssname ss i) verts (cti19:vertici-entita en))
           (foreach p verts
             (cti19:crea-testo p (itoa count) ht layer)
             (write-line
               (strcat (itoa count) ";" (rtos (car p) 2 4) ";"
                       (rtos (cadr p) 2 4) ";"
                       (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
             (setq count (1+ count)))
           (setq i (1+ i)))
         (close f)
         (princ (strcat "\nNumerati ed esportati " (itoa (1- count)) " vertici.")))
       (princ "\nImpossibile creare il file CSV."))))
  (princ))
(defun c:CTI_NUMERA_VERTICI () (cti19:esegui-comando 'cti19:cmd-numera-vertici))
(defun c:NUMERA_VERTICI () (c:CTI_NUMERA_VERTICI))

; ---------------------- 5. INTERSEZIONI ----------------------
(defun cti19:cmd-intersezioni (/ ss rad i j o1 o2 pts all p layer)
  (setq rad (getdist "\nRaggio dei marcatori <1.5>: "))
  (if (or (null rad) (<= rad 0.0)) (setq rad 1.5))
  (princ "\nSeleziona LINEE, ARCHI e POLILINEE da controllare: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "LINE") (0 . "ARC") (0 . "LWPOLYLINE") (-4 . "OR>"))))
  (if (and ss (>= (sslength ss) 2))
    (progn
      (setq all nil i 0 layer (cti19:assicura-layer "CTI-COMMUNITY-INTERSEZIONI" 6))
      (while (< i (sslength ss))
        (setq o1 (vlax-ename->vla-object (ssname ss i)) j (1+ i))
        (while (< j (sslength ss))
          (setq o2 (vlax-ename->vla-object (ssname ss j))
                pts (cti19:intersezioni o1 o2))
          (foreach p pts (setq all (cons p all)))
          (setq j (1+ j)))
        (setq i (1+ i)))
      (setq all (cti19:punti-unici all 1e-5))
      (foreach p all (cti19:crea-cerchio p rad layer))
      (princ (strcat "\nIndividuate e marcate " (itoa (length all)) " intersezioni.")))
    (princ "\nServono almeno due oggetti compatibili."))
  (princ))
(defun c:CTI_INTERSEZIONI () (cti19:esegui-comando 'cti19:cmd-intersezioni))
(defun c:INTERSEZIONI () (c:CTI_INTERSEZIONI))

; ---------------------- 6. POLILINEE_APERTE ----------------------
(defun cti19:cmd-polilinee-aperte (/ ss rad i en ed closed verts layer count p1 p2)
  (setq rad (getdist "\nRaggio dei marcatori <1.5>: "))
  (if (or (null rad) (<= rad 0.0)) (setq rad 1.5))
  (princ "\nSeleziona le LWPOLYLINE da controllare: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq i 0 count 0 layer (cti19:assicura-layer "CTI-COMMUNITY-APERTURE" 1))
      (repeat (sslength ss)
        (setq en (ssname ss i) ed (entget en)
              closed (= 1 (logand 1 (cdr (assoc 70 ed)))))
        (if (not closed)
          (progn
            (setq verts (cti19:vertici-entita en))
            (if verts
              (progn
                (setq p1 (car verts) p2 (car (last verts)))
                (cti19:crea-cerchio p1 rad layer)
                (if (> (distance p1 p2) 1e-8) (cti19:crea-cerchio p2 rad layer))
                (setq count (1+ count))))))
        (setq i (1+ i)))
      (princ (strcat "\nPolilinee aperte trovate: " (itoa count) ". Estremi marcati sul layer " layer ".")))
    (princ "\nNessuna polilinea selezionata."))
  (princ))
(defun c:CTI_POLILINEE_APERTE () (cti19:esegui-comando 'cti19:cmd-polilinee-aperte))
(defun c:POLILINEE_APERTE () (c:CTI_POLILINEE_APERTE))

; ---------------------- 7. RIDUCI_VERTICI ----------------------
; Adattato da VXTHIN-bgol.lsp. Per sicurezza CTI 1.9 opera solo su
; LWPOLYLINE 2D senza archi/bulge: il risultato e' una nuova copia
; alleggerita composta da segmenti retti e l'originale resta intatto.
(defun cti19:cmd-riduci-vertici (/ d en obj typ len dist pts p layer original)
  (setq d (getdist "\nDistanza di campionamento <30.0>: "))
  (if (or (null d) (<= d 0.0)) (setq d 30.0))
  (setq en (car (entsel "\nSeleziona una polilinea 2D rettilinea da alleggerire: ")))
  (if en
    (progn
      (setq typ (cdr (assoc 0 (entget en))))
      (cond
        ((/= typ "LWPOLYLINE")
         (princ "\nSelezionare una LWPOLYLINE 2D."))
        ((not (cti19:polilinea-rettilinea-p en))
         (princ "\nLa polilinea contiene archi/bulge: operazione annullata per non alterare la geometria."))
        (T
         (setq obj (vlax-ename->vla-object en)
               original (length (cti19:vertici-entita en))
               len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
               dist 0.0 pts nil)
         (while (< dist len)
           (setq p (vlax-curve-getPointAtDist obj dist))
           (if p (setq pts (cons p pts)))
           (setq dist (+ dist d)))
         (setq p (vlax-curve-getEndPoint obj))
         (if p (setq pts (reverse (cons p pts))))
         (setq layer (cti19:assicura-layer "CTI-COMMUNITY-RIDOTTE" 3))
         (if (> (length pts) 1)
           (progn
             (cti19:crea-lwpoly pts layer nil)
             (princ (strcat "\nCreata copia alleggerita 2D: " (itoa original) " -> " (itoa (length pts)) " vertici. L'originale e' stato conservato.")))
           (princ "\nCampionamento insufficiente per creare la nuova polilinea.")))))
    (princ "\nNessun oggetto selezionato."))
  (princ))
(defun c:CTI_RIDUCI_VERTICI () (cti19:esegui-comando 'cti19:cmd-riduci-vertici))
(defun c:RIDUCI_VERTICI () (c:CTI_RIDUCI_VERTICI))

; ---------------------- 8. BLOCCHI_SU_NODI ----------------------
(defun cti19:aggiungi-punto-unico (pt pts tol)
  (if (vl-some '(lambda (q) (< (distance pt q) tol)) pts) pts (cons pt pts)))

(defun cti19:cmd-blocchi-su-nodi (/ mode ss blk scale rot i j o1 o2 pts p all layer en)
  (initget "Intersezioni Estremi Entrambi")
  (setq mode (getkword "\nPosizioni [Intersezioni/Estremi/Entrambi] <Entrambi>: "))
  (if (null mode) (setq mode "Entrambi"))
  (setq ss (ssget '((-4 . "<OR") (0 . "LINE") (0 . "ARC") (0 . "LWPOLYLINE") (-4 . "OR>"))))
  (if ss
    (progn
      (setq blk (getstring T "\nNome del blocco gia' definito nel disegno: "))
      (if (tblsearch "BLOCK" blk)
        (progn
          (setq scale (getreal "\nScala blocco <1.0>: "))
          (if (or (null scale) (<= scale 0.0)) (setq scale 1.0))
          (setq rot (getangle "\nRotazione <0>: "))
          (if (null rot) (setq rot 0.0))
          (setq all nil i 0)
          (if (or (= mode "Estremi") (= mode "Entrambi"))
            (repeat (sslength ss)
              (setq o1 (vlax-ename->vla-object (ssname ss i)))
              (setq all (cti19:aggiungi-punto-unico (vlax-curve-getStartPoint o1) all 1e-4))
              (setq all (cti19:aggiungi-punto-unico (vlax-curve-getEndPoint o1) all 1e-4))
              (setq i (1+ i))))
          (if (or (= mode "Intersezioni") (= mode "Entrambi"))
            (progn
              (setq i 0)
              (while (< i (sslength ss))
                (setq o1 (vlax-ename->vla-object (ssname ss i)) j (1+ i))
                (while (< j (sslength ss))
                  (setq o2 (vlax-ename->vla-object (ssname ss j)) pts (cti19:intersezioni o1 o2))
                  (foreach p pts (setq all (cti19:aggiungi-punto-unico p all 1e-4)))
                  (setq j (1+ j)))
                (setq i (1+ i)))))
          (setq layer (cti19:assicura-layer "CTI-COMMUNITY-NODI" 1))
          (foreach p all
            (entmakex (list '(0 . "INSERT") '(100 . "AcDbEntity") (cons 8 layer)
                            '(100 . "AcDbBlockReference") (cons 2 blk) (cons 10 p)
                            (cons 41 scale) (cons 42 scale) (cons 43 scale) (cons 50 rot))))
          (princ (strcat "\nInseriti " (itoa (length all)) " blocchi sui nodi.")))
        (princ "\nIl blocco indicato non e' definito nel disegno.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))
(defun c:CTI_BLOCCHI_SU_NODI () (cti19:esegui-comando 'cti19:cmd-blocchi-su-nodi))
(defun c:BLOCCHI_SU_NODI () (c:CTI_BLOCCHI_SU_NODI))

; ---------------------- 9. PREFISSO_SUFFISSO ----------------------
(defun cti19:cmd-prefisso-suffisso (/ pre suf ss i obj old count)
  (setq pre (getstring T "\nPrefisso <nessuno>: ")
        suf (getstring T "\nSuffisso <nessuno>: "))
  (if (and (= pre "") (= suf ""))
    (princ "\nPrefisso e suffisso vuoti: nessuna modifica.")
    (progn
      (princ "\nSeleziona TESTO e TESTOM da modificare: ")
      (setq ss (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
      (if ss
        (progn
          (setq i 0 count 0)
          (repeat (sslength ss)
            (setq obj (vlax-ename->vla-object (ssname ss i))
                  old (vla-get-TextString obj))
            (vla-put-TextString obj (strcat pre old suf))
            (setq count (1+ count) i (1+ i)))
          (princ (strcat "\nAggiornati " (itoa count) " testi.")))
        (princ "\nNessun testo selezionato."))))
  (princ))
(defun c:CTI_PREFISSO_SUFFISSO () (cti19:esegui-comando 'cti19:cmd-prefisso-suffisso))
(defun c:PREFISSO_SUFFISSO () (c:CTI_PREFISSO_SUFFISSO))

; ---------------------- 10. CONTROLLA_NUMERAZIONE ----------------------
(defun cti19:cmd-controlla-numerazione (/ ss i en obj s n vals valid invalid minv maxv k missing seen dupes p layer)
  (princ "\nSeleziona TESTO/TESTOM contenenti numeri interi: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
  (if ss
    (progn
      (setq i 0 vals nil valid nil invalid 0)
      (repeat (sslength ss)
        (setq en (ssname ss i) obj (vlax-ename->vla-object en)
              s (vla-get-TextString obj) n (cti19:intero-rigoroso s))
        (if n
          (progn (setq vals (cons n vals)) (setq valid (cons (cons n en) valid)))
          (setq invalid (1+ invalid)))
        (setq i (1+ i)))
      (if vals
        (progn
          (setq minv (apply 'min vals) maxv (apply 'max vals) k minv missing nil seen nil dupes nil)
          (while (<= k maxv)
            (if (not (member k vals)) (setq missing (cons k missing)))
            (setq k (1+ k)))
          (foreach n vals
            (if (member n seen)
              (if (not (member n dupes)) (setq dupes (cons n dupes)))
              (setq seen (cons n seen))))
          (setq missing (vl-sort missing '<) dupes (vl-sort dupes '<)
                layer (cti19:assicura-layer "CTI-COMMUNITY-NUMERAZIONE" 1))
          (foreach p valid
            (if (member (car p) dupes)
              (cti19:crea-cerchio (vlax-get (vlax-ename->vla-object (cdr p)) 'InsertionPoint) 1.0 layer)))
          (princ (strcat "\nIntervallo: " (itoa minv) " - " (itoa maxv)))
          (princ (strcat "\nMancanti (" (itoa (length missing)) "): " (cti19:lista-stringa missing)))
          (princ (strcat "\nDuplicati (" (itoa (length dupes)) "): " (cti19:lista-stringa dupes)))
          (if (> invalid 0) (princ (strcat "\nIgnorati " (itoa invalid) " testi non numerici/non interi."))))
        (princ "\nNessun testo numerico intero valido nella selezione.")))
    (princ "\nNessun testo selezionato."))
  (princ))
(defun c:CTI_CONTROLLA_NUMERAZIONE () (cti19:esegui-comando 'cti19:cmd-controlla-numerazione))
(defun c:CONTROLLA_NUMERAZIONE () (c:CTI_CONTROLLA_NUMERAZIONE))

; ---------------------- 11. COPIA_SU_LAYOUT ----------------------
(defun cti19:cmd-copia-su-layout (/ ss doc layouts arr i lay blk res count)
  (princ "\nSeleziona gli oggetti da copiare in tutti i layout di spazio carta: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
            layouts (vla-get-Layouts doc)
            arr (vlax-make-safearray vlax-vbObject (cons 0 (1- (sslength ss))))
            i 0)
      (repeat (sslength ss)
        (vlax-safearray-put-element arr i (vlax-ename->vla-object (ssname ss i)))
        (setq i (1+ i)))
      (setq count 0)
      (vlax-for lay layouts
        (if (/= (strcase (vla-get-Name lay)) "MODEL")
          (progn
            (setq blk (vla-get-Block lay)
                  res (vl-catch-all-apply 'vla-CopyObjects (list doc arr blk)))
            (if (not (vl-catch-all-error-p res)) (setq count (1+ count))))))
      (princ (strcat "\nCopiati " (itoa (sslength ss)) " oggetti in " (itoa count) " layout.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))
(defun c:CTI_COPIA_SU_LAYOUT () (cti19:esegui-comando 'cti19:cmd-copia-su-layout))
(defun c:COPIA_SU_LAYOUT () (c:CTI_COPIA_SU_LAYOUT))

; ---------------------- 12. CSV_IN_TABELLA ----------------------
(defun cti19:cmd-csv-in-tabella (/ path f line sep rows row maxcols ins colw rowh doc space tab r c value)
  (setq path (getfiled "Seleziona un file CSV" "" "csv" 0))
  (cond
    ((null path)
     (princ "\nNessun file selezionato."))
    ((null (setq f (open path "r")))
     (princ "\nImpossibile aprire il file CSV."))
    (T
     (setq rows nil sep nil maxcols 0)
     (while (setq line (read-line f))
       (if (> (strlen (vl-string-trim " \t" line)) 0)
         (progn
           (if (null sep) (setq sep (cti19:separatore-csv line)))
           (setq row (cti19:dividi-csv line sep)
                 rows (append rows (list row))
                 maxcols (max maxcols (length row))))))
     (close f)
     (if (null rows)
       (princ "\nIl file CSV non contiene righe utilizzabili.")
       (progn
         (setq ins (getpoint "\nIndica il punto di inserimento della tabella: "))
         (if ins
           (progn
             (setq colw (getdist "\nLarghezza colonna <25.0>: "))
             (if (or (null colw) (<= colw 0.0)) (setq colw 25.0))
             (setq rowh (getdist "\nAltezza riga <8.0>: "))
             (if (or (null rowh) (<= rowh 0.0)) (setq rowh 8.0))
             (cti19:assicura-layer "CTI-COMMUNITY-TABELLE" 5)
             (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
                   space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
                   tab (vla-AddTable space (vlax-3d-point ins) (length rows) maxcols rowh colw))
             (vla-put-Layer tab "CTI-COMMUNITY-TABELLE")
             (vla-put-RegenerateTableSuppressed tab :vlax-true)
             (setq r 0)
             (foreach row rows
               (setq c 0)
               (while (< c maxcols)
                 (setq value (if (< c (length row)) (nth c row) ""))
                 (vla-SetText tab r c value)
                 (setq c (1+ c)))
               (setq r (1+ r)))
             (vla-put-RegenerateTableSuppressed tab :vlax-false)
             (princ (strcat "\nCSV importato come tabella nativa: " (itoa (length rows)) " righe x " (itoa maxcols) " colonne.")))
           (princ "\nInserimento tabella annullato."))))))
  (princ))
(defun c:CTI_CSV_IN_TABELLA () (cti19:esegui-comando 'cti19:cmd-csv-in-tabella))
(defun c:CSV_IN_TABELLA () (c:CTI_CSV_IN_TABELLA))

(setq *CTI-COMMUNITY-LOADED* T)
(princ "\nCAD Tools Italiano 1.9 - modulo Community MIT caricato: 12 strumenti disponibili.")
(princ)
