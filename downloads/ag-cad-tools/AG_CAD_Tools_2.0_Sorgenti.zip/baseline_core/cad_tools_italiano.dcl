cti_main : dialog {
  label = "CAD Tools Italiano 1.9";
  : column {
    : text {
      label = "Suite CAD indipendente - 93 comandi / 100 riferimenti clean-room";
      alignment = centered;
    }
    : list_box {
      key = "lst";
      width = 58;
      height = 16;
    }
    : row {
      : button { key = "run"; label = "Avvia"; is_default = true; width = 18; }
      : button { key = "diag"; label = "Diagnostica"; width = 18; }
      : button { key = "cancel"; label = "Chiudi"; is_cancel = true; width = 18; }
    }
  }
}
