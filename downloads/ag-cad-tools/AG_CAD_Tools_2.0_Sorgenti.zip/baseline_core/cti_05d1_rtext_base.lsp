; CAD Tools Italiano 1.9 - modulo isolato clean-room 0.5d1
; Testo remoto: funzioni base, lettura, XDATA e aggiornamento.
(defun cti:rtext-read-file (p / f line out)
  (setq out "")
  (if (and p (= (type p) 'STR) (setq f (open p "r")))
    (progn
      (while (setq line (read-line f))
        (if (= out "")
          (setq out line)
          (setq out (strcat out "\\P" line))))
      (close f)
      out)
    nil))

(defun cti:rtext-diesel (s / r)
  (if (and s (= (type s) 'STR))
    (progn
      (setq r (vl-catch-all-apply 'menucmd (list (strcat "M=" s))))
      (if (vl-catch-all-error-p r)
        (strcat "[Errore DIESEL: " (vl-catch-all-error-message r) "]")
        r))
    ""))

(defun cti:rtext-source (e / d p)
  (setq d (cti:xdata-data e "CTI_REMOTE_TEXT"))
  (if d
    (progn
      (setq p (assoc 1000 d))
      (if p (cdr p) nil))
    nil))

(defun cti:rtext-content (src / p)
  (if (not (= (type src) 'STR))
    ""
    (if (wcmatch src "FILE|*")
      (progn
        (setq p (substr src 6))
        (or (cti:rtext-read-file p) (strcat "[File non disponibile: " p "]")))
      (if (wcmatch src "DIESEL|*")
        (cti:rtext-diesel (substr src 8))
        ""))))

(defun cti:rtext-put-content (e src / ed old txt)
  (setq ed (entget e))
  (setq old (assoc 1 ed))
  (setq txt (cti:rtext-content src))
  (if old (entmod (subst (cons 1 txt) old ed)))
  (entupd e)
  e)

(defun cti:rtext-create (pt h rot src / e data)
  (setq data
        (list '(0 . "MTEXT")
              '(100 . "AcDbEntity")
              (cons 8 (getvar "CLAYER"))
              '(100 . "AcDbMText")
              (cons 10 (trans pt 1 0))
              (cons 40 h)
              (cons 41 (* h 50.0))
              (cons 71 1)
              (cons 50 rot)
              (cons 1 (cti:rtext-content src))))
  (setq e (entmakex data))
  (if e (cti:xdata-set-data e "CTI_REMOTE_TEXT" (list (cons 1000 src))))
  e)

(defun cti:rtext-refresh-one (e / src)
  (setq src (cti:rtext-source e))
  (if src (cti:rtext-put-content e src)))

(defun cti:rtext-refresh-all (/ ss i e n)
  (setq ss (ssget "_X" '((0 . "MTEXT"))))
  (setq i 0 n 0)
  (if ss
    (repeat (sslength ss)
      (setq e (ssname ss i))
      (if (cti:rtext-source e)
        (progn
          (cti:rtext-refresh-one e)
          (setq n (1+ n))))
      (setq i (1+ i))))
  n)
(princ)
