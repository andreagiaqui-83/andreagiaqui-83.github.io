module cadtoolsitaliano/installer

go 1.22
