package main

import (
	"os"
	"path/filepath"
	"testing"
)

func requiredFiles() []string {
	return []string{
		"PackageContents.xml",
		filepath.Join("Contents", "Win64", "cad_tools_italiano.lsp"),
		filepath.Join("Contents", "Win64", "CADToolsItaliano.cuix"),
		filepath.Join("Contents", "Win64", "cad_tools_italiano.dcl"),
		filepath.Join("Contents", "Win64", "CAD_Tools_Italiano_Help.html"),
		filepath.Join("Contents", "Win64", "CAD_Tools_Italiano_Sostieni.html"),
	}
}

func TestInstallUpdateUninstall(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "CADToolsItaliano.bundle")
	dataRoot := filepath.Join(root, "localdata")

	var last int
	_, err := installWithProgress(target, dataRoot, func(_ string, p int) {
		if p < last {
			t.Fatalf("progress regressed: %d -> %d", last, p)
		}
		last = p
	})
	if err != nil {
		t.Fatalf("install: %v", err)
	}
	if last != 100 {
		t.Fatalf("final progress = %d", last)
	}
	for _, rel := range requiredFiles() {
		if _, err := os.Stat(filepath.Join(target, rel)); err != nil {
			t.Fatalf("missing %s: %v", rel, err)
		}
	}

	// Add a marker that must survive only in the preserved previous-version backup.
	marker := filepath.Join(target, "previous_marker.txt")
	if err := os.WriteFile(marker, []byte("previous"), 0644); err != nil {
		t.Fatal(err)
	}
	res, err := installWithProgress(target, dataRoot, nil)
	if err != nil {
		t.Fatalf("update: %v", err)
	}
	if !res.Updated {
		t.Fatal("update not detected")
	}
	if res.BackupPath == "" {
		t.Fatal("backup path empty")
	}
	if b, err := os.ReadFile(filepath.Join(res.BackupPath, "previous_marker.txt")); err != nil || string(b) != "previous" {
		t.Fatalf("previous version backup missing or invalid: %v %q", err, string(b))
	}
	if _, err := os.Stat(marker); !os.IsNotExist(err) {
		t.Fatalf("stale marker remained in active bundle")
	}

	if got := installedVersion(target); got != version {
		t.Fatalf("installed version = %q, want %q", got, version)
	}

	if err := uninstall(target); err != nil {
		t.Fatalf("uninstall: %v", err)
	}
	if _, err := os.Stat(target); !os.IsNotExist(err) {
		t.Fatalf("target still exists after uninstall")
	}
}

func TestEmbeddedPayloadHasFiles(t *testing.T) {
	entries, err := embeddedEntries()
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) < 10 {
		t.Fatalf("unexpectedly small embedded payload: %d", len(entries))
	}
}
