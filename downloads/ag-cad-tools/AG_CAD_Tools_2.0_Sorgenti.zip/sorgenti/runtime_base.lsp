; Runtime comune Web 2.0, Fase 2D. Nessuna modifica al core golden.
(defun cti2:annullamento-p (msg / u)
  (setq u (strcase (if msg (vl-princ-to-string msg) "")))
  (or (wcmatch u "*FUNCTION CANCELLED*,*FUNCTION CANCELED*")
      (wcmatch u "*FUNZIONE*ANNULL*,*OPERAZIONE*ANNULL*")
      (wcmatch u "*QUIT / EXIT ABORT*,*CONSOLE BREAK*,*USER BREAK*")))

(defun cti2:interrompi (msg)
  (princ (strcat "\n" msg))
  (quit))

(defun cti2:registra-cleanup (fn args)
  (setq *CTI2-CLEANUP* (cons (list fn args) *CTI2-CLEANUP*))
  T)

(defun cti2:avviso-cleanup (msg)
  (setq *CTI2-AVVISI* (cons msg *CTI2-AVVISI*))
  (princ))

(defun cti2:proteggi-variabile (nome / old)
  (setq nome (strcase nome))
  (if (not (assoc nome *CTI2-VARIABILI*))
    (progn
      (setq old (getvar nome))
      (setq *CTI2-VARIABILI* (cons (cons nome old) *CTI2-VARIABILI*))))
  nome)

(defun cti2:setvar-temporanea (nome valore)
  (cti2:proteggi-variabile nome)
  (setvar nome valore))

(defun cti2:setvar-finale (nome valore)
  ; Il risultato intenzionale resta solo se il comando termina correttamente.
  (cti2:proteggi-variabile nome)
  (setvar nome valore)
  (setq *CTI2-VARIABILI-FINALI* (cons (strcase nome) *CTI2-VARIABILI-FINALI*))
  valore)

(defun cti2:apri-file (percorso modo / tmp f)
  ; Le esportazioni vengono pubblicate solo alla conclusione riuscita.
  (setq tmp (if (= modo "w")
              (vl-filename-mktemp "CTI_" (vl-filename-directory percorso) ".tmp")
              nil))
  (if tmp (setq *CTI2-TEMPORANEI* (cons tmp *CTI2-TEMPORANEI*)))
  (setq f (open (if tmp tmp percorso) modo))
  (if f
    (progn
      (setq *CTI2-FILE-APERTI* (cons f *CTI2-FILE-APERTI*))
      (if tmp (setq *CTI2-ESPORTAZIONI* (cons (list tmp percorso) *CTI2-ESPORTAZIONI*)))))
  f)

(defun cti2:chiudi-file (f)
  (close f)
  (setq *CTI2-FILE-APERTI* (vl-remove f *CTI2-FILE-APERTI*))
  nil)

(defun cti2:pubblica-file (record / tmp dst backup)
  (setq tmp (car record) dst (cadr record) backup nil)
  (if (findfile dst)
    (progn
      (setq backup (vl-filename-mktemp "CTI_PRECEDENTE_" (vl-filename-directory dst) ".bak"))
      (if (findfile backup) (vl-file-delete backup))
      (if (not (vl-file-rename dst backup))
        (cti2:interrompi (strcat "Impossibile sostituire il file; originale preservato: " dst)))))
  (if (vl-file-rename tmp dst)
    (if backup
      (if (not (vl-file-delete backup))
        (cti2:avviso-cleanup (strcat "Esportazione completata; copia precedente conservata in " backup))))
    (progn
      (if backup
        (if (not (vl-file-rename backup dst))
          (princ (strcat "\nCopia precedente da recuperare: " backup))))
      (cti2:interrompi (strcat "Pubblicazione del file non riuscita: " dst))))
  T)

(defun cti2:completa-file (/ f record)
  (foreach f *CTI2-FILE-APERTI* (cti2:chiudi-file f))
  (foreach record (reverse *CTI2-ESPORTAZIONI*) (cti2:pubblica-file record))
  T)

(defun cti2:cleanup (riuscito / f item r)
  (if (not *CTI2-CONCLUSO*)
    (progn
      (setq *CTI2-CONCLUSO* T)
      (foreach f *CTI2-FILE-APERTI*
        (setq r (vl-catch-all-apply 'close (list f)))
        (if (vl-catch-all-error-p r) (cti2:avviso-cleanup "Chiusura file non riuscita.")))
      (setq *CTI2-FILE-APERTI* nil)
      (foreach item *CTI2-CLEANUP*
        (setq r (vl-catch-all-apply (car item) (cadr item)))
        (if (vl-catch-all-error-p r)
          (cti2:avviso-cleanup (vl-catch-all-error-message r))))
      (foreach item *CTI2-VARIABILI*
        (if (not (and riuscito (member (car item) *CTI2-VARIABILI-FINALI*)))
          (progn
            (setq r (vl-catch-all-apply 'setvar (list (car item) (cdr item))))
            (if (vl-catch-all-error-p r)
              (cti2:avviso-cleanup (strcat "Ripristino variabile " (car item) " non riuscito."))))))
      (foreach item *CTI2-TEMPORANEI*
        (if (findfile item)
          (if (not (vl-file-delete item))
            (cti2:avviso-cleanup (strcat "File temporaneo da rimuovere: " item)))))
      (if *CTI2-UNDO-APERTO*
        (progn
          (setq r (vl-catch-all-apply 'vla-EndUndoMark (list *CTI2-DOCUMENTO*)))
          (if (vl-catch-all-error-p r)
            (cti2:avviso-cleanup "Chiusura del gruppo UNDO non riuscita."))))
      (foreach item (reverse *CTI2-AVVISI*)
        (princ (strcat "\nAvviso " *CTI2-NOME* ": " item)))))
  (princ))

(defun cti2:corpo-protetto (fn / nome r ctl)
  (setq *CTI2-DOCUMENTO* (vla-get-ActiveDocument (vlax-get-acad-object)))
  (foreach nome '("CMDECHO" "OSMODE" "CLAYER" "PDMODE" "DIMTXT" "FILEDIA"
                 "ORTHOMODE" "SNAPMODE" "MIRRTEXT" "TEXTFILL" "PEDITACCEPT"
                 "FILLETRAD" "BACKGROUNDPLOT" "DIMZIN" "HPBOUND")
    (cti2:proteggi-variabile nome))
  (setq ctl (getvar "UNDOCTL"))
  ; Non chiude un gruppo aperto da AutoCAD o da un altro comando.
  (if (and (= 1 (logand 1 ctl)) (= 0 (logand 8 ctl)))
    (progn
      (vla-StartUndoMark *CTI2-DOCUMENTO*)
      (setq *CTI2-UNDO-APERTO* T)))
  (setq r (apply fn nil))
  (cti2:completa-file)
  r)

(defun cti2:esegui-comando (nome fn / *error* r msg
    *CTI2-NOME* *CTI2-DOCUMENTO* *CTI2-UNDO-APERTO* *CTI2-CONCLUSO*
    *CTI2-VARIABILI* *CTI2-VARIABILI-FINALI* *CTI2-CLEANUP*
    *CTI2-FILE-APERTI* *CTI2-TEMPORANEI* *CTI2-ESPORTAZIONI* *CTI2-AVVISI*)
  (setq *CTI2-NOME* nome)
  (defun *error* (m)
    (cti2:cleanup nil)
    (if (not (cti2:annullamento-p m))
      (princ (strcat "\nErrore " *CTI2-NOME* ": " (if m m "errore sconosciuto"))))
    (princ))
  (setq r (vl-catch-all-apply 'cti2:corpo-protetto (list fn)))
  (cti2:cleanup (not (vl-catch-all-error-p r)))
  (if (vl-catch-all-error-p r)
    (progn
      (setq msg (vl-catch-all-error-message r))
      (if (not (cti2:annullamento-p msg))
        (princ (strcat "\nErrore " nome ": " msg)))))
  (princ))

(defun cti2:scheda-attiva ()
  (if (= (getvar "CVPORT") 1) (getvar "CTAB") "Model"))

(defun cti2:crea-entita (dati / prima dopo)
  ; ENTMAKE assegna la proprieta nello spazio corrente.
  (setq prima (entlast))
  (if (entmake dati)
    (progn
      (setq dopo (entlast))
      (if (and dopo (not (eq prima dopo))) dopo
        (cti2:interrompi "Creazione entità non completata.")))
    (cti2:interrompi "AutoCAD ha rifiutato la nuova entità; operazione interrotta.")))

(defun cti2:punto-wcs (p) (if p (trans p 1 0) nil))
(defun cti2:punto-ucs (p) (if p (trans p 0 1) nil))
(defun cti2:angolo-xy (a b / ang)
  (setq ang (atan (- (cadr b) (cadr a)) (- (car b) (car a))))
  (if (< ang 0.0) (+ ang (* 2.0 pi)) ang))
(defun cti2:angolo-wcs (ang)
  (if ang (cti2:angolo-xy '(0.0 0.0 0.0) (trans (list (cos ang) (sin ang) 0.0) 1 0 T)) nil))
(defun cti2:polare-xy (p ang d)
  (list (+ (car p) (* d (cos ang))) (+ (cadr p) (* d (sin ang)))
        (if (caddr p) (caddr p) 0.0)))

(defun cti2:orizzontale-p (pts / z ok p)
  (setq ok (and pts (>= (length pts) 2)) z (if pts (caddr (car pts)) nil))
  (foreach p pts (if (not (equal (caddr p) z 1e-8)) (setq ok nil)))
  ok)

(defun cti2:rtos-stabile (v prec)
  (cti2:setvar-temporanea "DIMZIN" 0)
  (rtos v 2 prec))

(defun cti2:sospendi-tabella (tab)
  (cti2:registra-cleanup 'vla-put-RegenerateTableSuppressed (list tab :vlax-false))
  (vla-put-RegenerateTableSuppressed tab :vlax-true))
