; Un menu parziale caricato non viene necessariamente inserito nella barra.
; Usa solo il menu principale del nostro gruppo, senza salvare il CUI Autodesk.
(defun ag:assicura-menu-barra (/ gruppi gruppo menus menu principale)
  (if (menugroup "AGCADTOOLS")
    (progn
      (setq gruppi (vla-get-MenuGroups (vlax-get-acad-object))
            gruppo (vla-Item gruppi "AGCADTOOLS")
            menus (vla-get-Menus gruppo))
      (vlax-for menu menus
        (if (= (strcase (vla-get-NameNoMnemonic menu)) "AG CAD TOOLS")
          (setq principale menu)))
      (if principale
        (if (= (vla-get-OnMenuBar principale) :vlax-false)
          (vla-InsertMenuInMenuBar menus (vla-get-Name principale) ""))
        (princ "\nAG CAD Tools: menu principale non trovato nel CUIX."))))
  (princ))
