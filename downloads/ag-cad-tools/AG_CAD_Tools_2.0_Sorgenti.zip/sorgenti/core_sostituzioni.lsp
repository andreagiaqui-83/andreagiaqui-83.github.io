; Definizioni integrate dal generatore: non viene caricato come modulo autonomo.
(defun cti:run (fn)
  (if (and (boundp '*CTI2-ATTIVO*) *CTI2-ATTIVO*)
    (apply fn nil)
    (cti2:esegui-comando "CAD Tools Italiano" fn)))

(defun cti:chiudiveloce-core ()
  (princ "\nChiusura di AutoCAD: verrà richiesto di salvare i disegni modificati.")
  (cti2:differisci 'cti2:chiudi-autocad nil))

(defun cti:ripristinadisegno-core (/ path mod ans scr f)
  (setq path (strcat (getvar "DWGPREFIX") (getvar "DWGNAME")))
  (if (or (= (getvar "DWGPREFIX") "") (= (getvar "DWGNAME") ""))
    (princ "\nIl disegno deve essere stato salvato almeno una volta.")
    (progn
      (setq mod (/= (getvar "DBMOD") 0) ans "Si")
      (if mod
        (progn
          (initget "Si No")
          (setq ans (getkword "\nAbbandonare le modifiche e riaprire l'ultima versione salvata? [Si/No] <No>: "))
          (if (null ans) (setq ans "No"))))
      (if (= ans "Si")
        (progn
          (setq scr (cti2:file-temporaneo "cti_revert_" (getvar "TEMPPREFIX") ".scr")
                f (cti2:apri-core scr "w"))
          (write-line "_.CLOSE" f)
          (if mod (write-line "_N" f))
          (write-line "_.OPEN" f)
          (write-line (strcat "\"" path "\"") f)
          ; Dopo OPEN il nuovo documento non deve aver caricato il plugin.
          (write-line "(vl-load-com)" f)
          (write-line
            (strcat "(if (and (findfile " (vl-prin1-to-string scr)
                    ") (not (vl-file-delete " (vl-prin1-to-string scr)
                    "))) (princ "
                    (vl-prin1-to-string (strcat "\nFile temporaneo da rimuovere: " scr)) "))") f)
          (cti2:chiudi-core f)
          (setq *CTI2-TEMPORANEI-PASSATI* (cons scr *CTI2-TEMPORANEI-PASSATI*))
          (cti2:differisci 'cti2:avvia-script (list scr)))
        (princ "\nOperazione annullata."))))
  (princ))

(defun cti:launcher-core (/ p id idx res pair)
  (setq p (cti:dcl-path))
  (if (or (null p) (not (findfile p)))
    (princ "\nInterfaccia non trovata. Usa i comandi CTI_ dalla riga di comando.")
    (progn
      (setq id (load_dialog p))
      (if (and id (> id 0))
        (progn
          (cti2:registra-cleanup 'unload_dialog (list id))
          (if (new_dialog "cti_main" id)
            (progn
              (start_list "lst")
              (foreach pair *CTI-LAUNCHER* (add_list (cti:launcher-voce pair)))
              (end_list)
              (set_tile "lst" "0")
              (setq idx 0)
              (cti:launcher-categoria idx)
              (action_tile "lst" "(setq idx (atoi $value)) (cti:launcher-categoria idx)")
              (action_tile "run" "(done_dialog 1)")
              (action_tile "diag" "(done_dialog 2)")
              (action_tile "cancel" "(done_dialog 0)")
              (setq res (start_dialog))
              (cond
                ((= res 1)
                  (setq pair (nth idx *CTI-LAUNCHER*))
                  (if pair (cti2:differisci (read (strcat "C:" (car pair))) nil)))
                ((= res 2) (cti2:differisci 'c:CTI_DIAGNOSTICA nil))))
            (princ "\nImpossibile aprire l'interfaccia DCL.")))
        (princ "\nImpossibile caricare l'interfaccia DCL."))))
  (princ))

(defun cti:launcher-voce (pair / testo pos)
  (setq testo (cdr pair) pos (vl-string-search " - " testo))
  (strcat (if pos (substr testo (+ pos 4)) testo) " [" (car pair) "]"))

(defun cti:launcher-categoria (idx / pair testo pos)
  (setq pair (nth idx *CTI-LAUNCHER*))
  (if pair
    (progn
      (setq testo (cdr pair) pos (vl-string-search " - " testo))
      (set_tile "categoria" (strcat "Categoria: " (if pos (substr testo 1 pos) "Guida e supporto"))))))

(defun cti:dwglog-write (action)
  (cti2:esegui-risorse "LOGDISEGNO" 'cti:dwglog-write-risorse (list action)))
(defun cti:dwglog-write-risorse (action / p f u m stamp)
  (if (and (cti:dwglog-enabled-p) (setq p (cti:dwglog-path)))
    (progn
      (setq u (getenv "USERNAME") m (getenv "COMPUTERNAME"))
      (if (null u) (setq u "utente"))
      (if (null m) (setq m "computer"))
      (setq stamp (rtos (getvar "CDATE") 2 6) f (cti2:apri-core p "a"))
      (write-line (strcat action " by " u " on " m " at " stamp) f)
      (cti2:chiudi-core f))))

(defun cti:rtext-read-file (p)
  (cti2:esegui-risorse "TESTOREMOTO" 'cti:rtext-read-risorse (list p)))
(defun cti:rtext-read-risorse (p / f line out)
  (setq out "")
  (if (and p (eq (type p) 'STR) (findfile p))
    (progn
      (setq f (cti2:apri-core p "r"))
      (while (setq line (read-line f))
        (if (= out "") (setq out line) (setq out (strcat out "\\P" line))))
      (cti2:chiudi-core f)
      out)
    nil))

(defun cti:rtext-content (src / p contenuto)
  (if (not (eq (type src) 'STR)) ""
    (if (wcmatch src "FILE|*")
      (progn
        (setq p (substr src 6) contenuto (cti:rtext-read-file p))
        (if contenuto contenuto (strcat "[File non disponibile: " p "]")))
      (if (wcmatch src "DIESEL|*") (cti:rtext-diesel (substr src 8)) ""))))

(defun cti:copy-vla-vector (o v / n r)
  (setq r (vl-catch-all-apply 'vla-Copy (list o)))
  (if (vl-catch-all-error-p r)
    (progn (cti:report-error r) nil)
    (progn
      (setq n r)
      (cti2:oggetto-provvisorio n)
      (setq r (vl-catch-all-apply 'vla-Move
                (list n (vlax-3d-point '(0.0 0.0 0.0)) (vlax-3d-point v))))
      (if (vl-catch-all-error-p r)
        (progn (cti2:elimina-oggetto n) (cti:report-error r) nil)
        (progn
          (setq *CTI2-CLEANUP* (vl-remove (list 'cti2:elimina-oggetto (list n)) *CTI2-CLEANUP*))
          n)))))
(princ)
