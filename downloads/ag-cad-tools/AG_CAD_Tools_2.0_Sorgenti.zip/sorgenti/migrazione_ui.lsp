; Migrazione del gruppo parziale precedente; nessun file Autodesk viene modificato.
(defun ag:aggiorna-interfaccia (/ gruppi vecchio nuovo percorso)
  (setq gruppi (vla-get-MenuGroups (vlax-get-acad-object)))
  ; Rimuove il vecchio gruppo solo dopo avere disponibile il nuovo.
  (if (not (menugroup "AGCADTOOLS"))
    (progn
      (setq percorso (findfile (strcat *CTI2-DIRECTORY* "AGCADTools.cuix")))
      (if percorso (vla-Load gruppi percorso))))
  (ag:assicura-menu-barra)
  (if (and (menugroup "AGCADTOOLS") (menugroup "CADTOOLSITALIANO"))
    (progn
      (setq vecchio (vla-Item gruppi "CADTOOLSITALIANO"))
      (vla-Unload vecchio)))
  (princ))
