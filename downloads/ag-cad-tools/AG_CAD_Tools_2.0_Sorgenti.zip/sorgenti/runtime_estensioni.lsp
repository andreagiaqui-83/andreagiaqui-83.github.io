; Risorse del core e passaggi di controllo, candidata 2.0 RC2.
(defun cti2:apri-core (percorso modo / tmp f)
  ; Il core pubblica alla chiusura: LIN/SHP/PGP/SCR devono essere già leggibili.
  (if (member modo '("w" "a"))
    (progn
      (setq tmp (vl-filename-mktemp "CTI_CORE_" (vl-filename-directory percorso) ".tmp"))
      (setq *CTI2-TEMPORANEI* (cons tmp *CTI2-TEMPORANEI*))
      (if (and (= modo "a") (findfile percorso))
        (progn
          (if (findfile tmp) (vl-file-delete tmp))
          (if (not (vl-file-copy percorso tmp))
            (cti2:interrompi (strcat "Impossibile preparare il file: " percorso)))))
      (setq f (open tmp modo)))
    (setq f (open percorso modo)))
  (if f
    (progn
      (setq *CTI2-FILE-APERTI* (cons f *CTI2-FILE-APERTI*))
      (if tmp (setq *CTI2-FILE-CORE* (cons (list f tmp percorso) *CTI2-FILE-CORE*))))
    (cti2:interrompi (strcat "Impossibile aprire il file: " percorso)))
  f)

(defun cti2:chiudi-core (f / record)
  (setq record (assoc f *CTI2-FILE-CORE*))
  (cti2:chiudi-file f)
  (if record
    (progn
      (cti2:pubblica-file (cdr record))
      (setq *CTI2-FILE-CORE* (vl-remove record *CTI2-FILE-CORE*))))
  nil)

(defun cti2:esegui-risorse (nome fn args / r *CTI2-NOME* *CTI2-CONCLUSO*
    *CTI2-DOCUMENTO* *CTI2-UNDO-APERTO* *CTI2-VARIABILI* *CTI2-VARIABILI-FINALI*
    *CTI2-FILE-APERTI* *CTI2-FILE-CORE* *CTI2-CLEANUP* *CTI2-TEMPORANEI*
    *CTI2-TEMPORANEI-PASSATI* *CTI2-AVVISI*)
  ; Anche letture e log avviati dai reactor chiudono i propri file. Nessun UNDO.
  (setq *CTI2-NOME* nome r (vl-catch-all-apply fn args))
  (cti2:cleanup (not (vl-catch-all-error-p r)))
  (if (vl-catch-all-error-p r)
    (progn
      (princ (strcat "\nAvviso " nome ": " (vl-catch-all-error-message r)))
      nil)
    r))

(defun cti2:file-temporaneo (prefisso cartella estensione / p)
  (setq p (vl-filename-mktemp prefisso cartella estensione))
  (setq *CTI2-TEMPORANEI* (cons p *CTI2-TEMPORANEI*))
  p)

(defun cti2:elimina-oggetto (o)
  (if (and o (not (vlax-erased-p o))) (vla-Delete o))
  (princ))
(defun cti2:oggetto-provvisorio (o)
  (if o (cti2:registra-cleanup 'cti2:elimina-oggetto (list o)))
  o)
(defun cti2:oggetti-provvisori (oggetti / o)
  (foreach o oggetti (cti2:oggetto-provvisorio o))
  oggetti)
(defun cti2:elimina-entita (e)
  (if (and e (entget e)) (entdel e))
  (princ))
(defun cti2:entita-provvisoria (e)
  (if e (cti2:registra-cleanup 'cti2:elimina-entita (list e)))
  e)
(defun cti2:differisci (fn args)
  (setq *CTI2-AZIONE-DOPO* (list fn args)))
(defun cti2:esegui-differita (azione)
  ; Il wrapper è già uscito: file, dialoghi, variabili e UNDO sono chiusi.
  (if azione (apply (car azione) (cadr azione)) (princ)))
(defun cti2:chiudi-autocad () (command "_.QUIT"))
(defun cti2:avvia-script (p) (command "_.SCRIPT" p))

(defun cti2:comando-definito-p (nome / r)
  ; Non invoca il comando. Un simbolo internato ma senza funzione non basta.
  (setq r (vl-catch-all-apply 'eval (list (read (strcat "C:" nome)))))
  (and (not (vl-catch-all-error-p r))
       (member (type r) '(SUBR USUBR EXRXSUBR))))
(princ)
