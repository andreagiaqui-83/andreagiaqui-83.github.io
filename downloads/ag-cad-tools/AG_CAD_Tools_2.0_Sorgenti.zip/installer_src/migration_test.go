package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func oldFixture(t *testing.T, target string) string {
	t.Helper()
	legacy := legacyTarget(target)
	if err := os.MkdirAll(legacy, 0755); err != nil {
		t.Fatal(err)
	}
	xml := `<ApplicationPackage Name="CAD Tools Italiano" AppVersion="2.0.0.2" UpgradeCode="{0D9E7026-A9CF-4E2B-9C91-54D2416CFE8D}"/>`
	for name, data := range map[string]string{"PackageContents.xml": xml, "personale.txt": "precedente"} {
		if err := os.WriteFile(filepath.Join(legacy, name), []byte(data), 0644); err != nil {
			t.Fatal(err)
		}
	}
	return legacy
}
func assertOld(t *testing.T, p string) {
	t.Helper()
	b, e := os.ReadFile(filepath.Join(p, "personale.txt"))
	if e != nil || string(b) != "precedente" {
		t.Fatalf("old data changed at %s: %v", p, e)
	}
}
func TestMigrationFromRC2(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	legacy := oldFixture(t, target)
	data := filepath.Join(root, "data")
	res, err := installWithMigration(target, data, nil)
	if err != nil {
		t.Fatal(err)
	}
	if !res.Updated || !existsDir(target) || existsDir(legacy) || existsDir(legacy+".ag-migrazione") {
		t.Fatal("wrong final layout")
	}
	assertOld(t, filepath.Join(data, "BackupCADToolsItaliano.bundle"))
	b, e := os.ReadFile(filepath.Join(target, "PackageContents.xml"))
	if e != nil || !strings.Contains(string(b), `Name="AG CAD Tools"`) {
		t.Fatal("wrong active identity")
	}
}
func TestMigrationRollback(t *testing.T) {
	for _, phase := range []int{45, 84} {
		for _, both := range []bool{false, true} {
			t.Run(strings.Join([]string{string(rune('A' + phase)), map[bool]string{false: "only-old", true: "both"}[both]}, "/"), func(t *testing.T) {
				root := t.TempDir()
				target := filepath.Join(root, "AGCADTools.bundle")
				legacy := oldFixture(t, target)
				data := filepath.Join(root, "data")
				if both {
					if _, e := installWithProgress(target, data, nil); e != nil {
						t.Fatal(e)
					}
					if e := os.WriteFile(filepath.Join(target, "new-marker"), []byte("AG-before"), 0644); e != nil {
						t.Fatal(e)
					}
				}
				once := false
				_, err := installWithMigration(target, data, func(_ string, p int) {
					if p == phase && !once {
						once = true
						dir := target
						if phase == 45 {
							dir += ".staging"
						}
						if e := os.WriteFile(filepath.Join(dir, "PackageContents.xml"), []byte("damaged"), 0644); e != nil {
							t.Fatal(e)
						}
					}
				})
				if err == nil || !once {
					t.Fatal("expected controlled failure")
				}
				assertOld(t, legacy)
				if existsDir(legacy + ".ag-migrazione") {
					t.Fatal("old folder not restored")
				}
				if both {
					b, e := os.ReadFile(filepath.Join(target, "new-marker"))
					if e != nil || string(b) != "AG-before" {
						t.Fatal("AG pre-state not restored")
					}
				} else if existsDir(target) {
					t.Fatal("new bundle survived failed install")
				}
			})
		}
	}
}
func TestMigrationBackupFailure(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	legacy := oldFixture(t, target)
	data := filepath.Join(root, "blocked")
	os.WriteFile(data, []byte("file"), 0644)
	if _, err := installWithMigration(target, data, nil); err == nil {
		t.Fatal("backup should fail")
	}
	assertOld(t, legacy)
	if existsDir(target) {
		t.Fatal("new bundle should not exist")
	}
}
func TestMigrationRefusesUnrelatedFolder(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	legacy := oldFixture(t, target)
	os.WriteFile(filepath.Join(legacy, "PackageContents.xml"), []byte(`<ApplicationPackage Name="Unrelated"/>`), 0644)
	if _, err := installWithMigration(target, filepath.Join(root, "data"), nil); err == nil {
		t.Fatal("unrelated folder accepted")
	}
	assertOld(t, legacy)
}
func TestMigrationInterruptedRecovery(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	legacy := oldFixture(t, target)
	if e := os.Rename(legacy, legacy+".ag-migrazione"); e != nil {
		t.Fatal(e)
	}
	if _, err := installWithMigration(target, filepath.Join(root, "data"), nil); err != nil {
		t.Fatal(err)
	}
	assertOld(t, filepath.Join(root, "data", "BackupCADToolsItaliano.bundle"))
	if existsDir(legacy) || existsDir(legacy+".ag-migrazione") {
		t.Fatal("legacy remains active")
	}
}
func TestMigrationBothBundlesAndUninstall(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	data := filepath.Join(root, "data")
	_, e := installWithProgress(target, data, nil)
	if e != nil {
		t.Fatal(e)
	}
	os.WriteFile(filepath.Join(target, "ag-marker"), []byte("AG"), 0644)
	legacy := oldFixture(t, target)
	if _, e = installWithMigration(target, data, nil); e != nil {
		t.Fatal(e)
	}
	assertOld(t, filepath.Join(data, "BackupCADToolsItaliano.bundle"))
	if _, e = os.Stat(filepath.Join(data, "BackupPrecedente.bundle", "ag-marker")); e != nil {
		t.Fatal("AG backup missing")
	}
	oldFixture(t, target)
	if e = uninstallAll(target); e != nil {
		t.Fatal(e)
	}
	if existsDir(target) || existsDir(legacy) {
		t.Fatal("bundle remains after uninstall")
	}
}
