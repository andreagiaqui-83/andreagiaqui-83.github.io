package main

import (
	"go/ast"
	"go/parser"
	"go/token"
	"strings"
	"testing"
)

func TestModernLayoutStates(t *testing.T) {
	for _, s := range []installerView{
		{Target: `%APPDATA%\Autodesk\ApplicationPlugins\AGCADTools.bundle`},
		{Installed: true, InstalledVer: "2.0", AutoCAD: []string{"AutoCAD 2024", "AutoCAD 2025", "AutoCAD 2026", "AutoCAD 2027"}, Progress: 100},
		{Operating: true, Progress: -10}, {Operating: true, Progress: 150},
	} {
		ops := installerScene(s)
		for _, o := range ops {
			r := o.Box
			if r[0] < 0 || r[1] < 0 || r[2] > 920 || r[3] > 600 || r[2] <= r[0] || r[3] <= r[1] {
				t.Fatalf("Out of canvas: %+v", o)
			}
		}
		found := false
		for _, o := range ops {
			if s.Installed && strings.Contains(o.Text, "Installato") {
				found = true
			}
		}
		if s.Installed && !found {
			t.Fatal("Installed state missing")
		}
	}
	bs := installerButtons()
	for i, b := range bs {
		if b.Box[3]-b.Box[1] < 40 {
			t.Fatal("Small button")
		}
		for _, c := range bs[i+1:] {
			if b.Box[0] < c.Box[2] && c.Box[0] < b.Box[2] {
				t.Fatal("Overlapping buttons")
			}
		}
	}
}

// Source contract for the native boundary. This does not execute user32.dll.
func TestNativeInstallFlowContract(t *testing.T) {
	f, err := parser.ParseFile(token.NewFileSet(), "main.go", nil, 0)
	if err != nil {
		t.Fatal(err)
	}
	funcs := map[string]*ast.FuncDecl{}
	for _, d := range f.Decls {
		if fn, ok := d.(*ast.FuncDecl); ok {
			funcs[fn.Name.Name] = fn
		}
	}
	countCalls := func(n ast.Node, name string) int {
		count := 0
		ast.Inspect(n, func(n ast.Node) bool {
			if c, ok := n.(*ast.CallExpr); ok {
				if id, ok := c.Fun.(*ast.Ident); ok && id.Name == name {
					count++
				}
			}
			return true
		})
		return count
	}
	start := funcs["startInstall"]
	if countCalls(start, "messageBox") != 1 {
		t.Fatal("Unexpected pre-install confirmation")
	}
	guarded := false
	ast.Inspect(start, func(n ast.Node) bool {
		if i, ok := n.(*ast.IfStmt); ok {
			if call, ok := i.Cond.(*ast.CallExpr); ok {
				if name, ok := call.Fun.(*ast.Ident); ok && name.Name == "autoCADRunning" {
					guarded = countCalls(i.Body, "messageBox") == 1
				}
			}
		}
		return true
	})
	if !guarded {
		t.Fatal("AutoCAD running guard missing")
	}
	if countCalls(funcs["startUninstall"], "messageBox") != 2 {
		t.Fatal("Uninstall confirmation changed")
	}
	closeAfterOK := false
	ast.Inspect(funcs["handleDone"], func(n ast.Node) bool {
		i, ok := n.(*ast.IfStmt)
		if !ok {
			return true
		}
		eq, ok := i.Cond.(*ast.BinaryExpr)
		if !ok || eq.Op != token.EQL {
			return true
		}
		c, ok := eq.X.(*ast.CallExpr)
		if !ok {
			return true
		}
		name, ok := c.Fun.(*ast.Ident)
		if !ok || name.Name != "messageBox" {
			return true
		}
		rhs, ok := eq.Y.(*ast.Ident)
		if !ok || rhs.Name != "idOK" {
			return true
		}
		ast.Inspect(i.Body, func(n ast.Node) bool {
			if sel, ok := n.(*ast.SelectorExpr); ok {
				if obj, ok := sel.X.(*ast.Ident); ok && obj.Name == "procDestroyWindow" {
					closeAfterOK = true
				}
			}
			return true
		})
		return true
	})
	if !closeAfterOK {
		t.Fatal("Success acknowledgement no longer closes installer")
	}
}
