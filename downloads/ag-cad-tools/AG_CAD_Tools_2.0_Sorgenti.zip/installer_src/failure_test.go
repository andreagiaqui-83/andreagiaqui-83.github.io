package main

import (
	"os"
	"path/filepath"
	"testing"
)

// Il codice Win32 non gira qui: si verificano i rami reali del motore file.
func TestStagingFailurePreservesExisting(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	if err := os.MkdirAll(target, 0755); err != nil {
		t.Fatal(err)
	}
	marker := filepath.Join(target, "golden.txt")
	if err := os.WriteFile(marker, []byte("golden"), 0644); err != nil {
		t.Fatal(err)
	}
	blocker := target + ".staging"
	if err := os.MkdirAll(blocker, 0755); err != nil {
		t.Fatal(err)
	}
	// La callback corrompe un file estratto prima della verifica dello staging.
	corrupted := false
	_, err := installWithProgress(target, filepath.Join(root, "data"), func(_ string, p int) {
		if p == 45 && !corrupted {
			corrupted = true
			if e := os.WriteFile(filepath.Join(blocker, "PackageContents.xml"), []byte("alterato"), 0644); e != nil {
				t.Fatal(e)
			}
		}
	})
	if err == nil || !corrupted {
		t.Fatal("corruzione staging non rilevata")
	}
	b, e := os.ReadFile(marker)
	if e != nil || string(b) != "golden" {
		t.Fatalf("golden alterata: %v", e)
	}
}

func TestBackupFailurePreservesExisting(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	if err := os.MkdirAll(target, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(target, "golden.txt"), []byte("golden"), 0644); err != nil {
		t.Fatal(err)
	}
	blocker := filepath.Join(root, "data")
	if err := os.WriteFile(blocker, []byte("non è una cartella"), 0644); err != nil {
		t.Fatal(err)
	}
	_, err := installWithProgress(target, blocker, nil)
	if err == nil {
		t.Fatal("backup impossibile non rilevato")
	}
	b, e := os.ReadFile(filepath.Join(target, "golden.txt"))
	if e != nil || string(b) != "golden" {
		t.Fatal("versione precedente alterata")
	}
}

func TestFinalVerificationRollback(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGCADTools.bundle")
	if err := os.MkdirAll(target, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(target, "golden.txt"), []byte("golden"), 0644); err != nil {
		t.Fatal(err)
	}
	corrupted := false
	_, err := installWithProgress(target, filepath.Join(root, "data"), func(_ string, p int) {
		if p == 84 && !corrupted {
			corrupted = true
			if e := os.WriteFile(filepath.Join(target, "PackageContents.xml"), []byte("alterato"), 0644); e != nil {
				t.Fatal(e)
			}
		}
	})
	if err == nil || !corrupted {
		t.Fatal("corruzione finale non rilevata")
	}
	b, e := os.ReadFile(filepath.Join(target, "golden.txt"))
	if e != nil || string(b) != "golden" {
		t.Fatal("rollback non riuscito")
	}
	b, e = os.ReadFile(filepath.Join(root, "data", "BackupPrecedente.bundle", "golden.txt"))
	if e != nil || string(b) != "golden" {
		t.Fatal("backup non preservato")
	}
}
