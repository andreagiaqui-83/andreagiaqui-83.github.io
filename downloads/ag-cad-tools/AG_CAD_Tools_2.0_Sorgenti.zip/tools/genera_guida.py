"""Guida offline basata sul registro UI e sui prompt effettivi del sorgente."""
from pathlib import Path
import base64,csv,html,json,sys
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'release/AGCADTools.bundle/Contents/Win64'
sys.path.insert(0,str(ROOT/'verifiche'))
from lisp_audit import parse,definitions,head,walk,Sym
REG=json.loads((ROOT/'REGISTRO_UI_2_0.json').read_text());D={}
for p in W.glob('*.lsp'):
    if 'community' not in p.name:D.update(definitions(parse(p.read_text(encoding='utf-8-sig'))))
def esc(x):return html.escape(str(x),quote=True)
def all_nodes(n):
    yield n
    if isinstance(n.value,list):
        for a in n.value:yield from all_nodes(a)
def targets(name):
    n=D[name]
    calls=[x for x in walk(n) if head(x)=='cti2:esegui-comando']
    if calls:
        return [str(x.value) for x in all_nodes(calls[0].value[2]) if isinstance(x.value,Sym) and x.value in D]
    return [head(x) for x in n.value[3:] if head(x) in D]
def prompts(cmd):
    out=[];seen=set()
    def visit(name,depth=0):
        if name in seen or depth>10 or name in ('cti2:esegui-comando','cti2:cleanup','cti:run'):return
        seen.add(name)
        n=D.get(name)
        if not n:return
        for x in walk(n):
            if head(x) in ('prompt','getangle','getpoint','getcorner','getreal','getint','getdist','getstring','getkword','getfiled','entsel','nentsel'):
                for v in all_nodes(x):
                    if type(v.value)==str:
                        s=v.value.replace('\n',' ').strip()
                        if len(s)>6 and (head(x) not in ('getfiled',) or v is x.value[1]) and s not in out:out.append(s)
        for x in walk(n):
            if head(x) in D:visit(head(x),depth+1)
    for target in targets('c:'+cmd.lower()):visit(target)
    return out
aliases={}
for name,n in D.items():
    if name.startswith('c:'):
        calls=[head(x) for x in n.value[3:] if (head(x) or '').startswith('c:')]
        if len(calls)==1:aliases.setdefault(calls[0][2:].upper(),[]).append(name[2:].upper())
def aliases_for(cmd):
    out=[];todo=[cmd]
    while todo:
        for a in aliases.get(todo.pop(),[]):
            if a not in out and a!=cmd:out.append(a);todo.append(a)
    return sorted(out)
web={r['Comando CTI']:r for r in csv.DictReader((ROOT/'provenienza/MANIFEST_100_WEB_FASE2D.csv').open(encoding='utf-8-sig'),delimiter=';')}
web={('AG_'+k[4:] if k.startswith('CTI_') else k):v for k,v in web.items()}
manual={}
for line in (ROOT/'sorgenti/manuale_comandi.tsv').read_text().splitlines():
    ident,prepare,steps,limits,example=line.split('|')
    manual[int(ident)]={'prepare':prepare,'steps':steps,'limits':limits,'example':example}
assert set(manual)==set(range(1,201)), 'Manuale incompleto o duplicato'
cats=[r['Pannello'] for r in csv.DictReader((ROOT/'provenienza/ARCHITETTURA_RIBBON_2.0.csv').open(encoding='utf-8-sig'))]
assert len(cats)==16,cats
css='''.utility-links{display:flex;flex-wrap:wrap;gap:8px 22px;margin-top:10px}.utility-links a{color:#fff;text-underline-offset:3px;font-size:14px}.result-count{font-size:14px;color:#52697f;margin:4px 0 8px}.intro,.support{scroll-margin-top:85px}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#edf2f6;color:#203448;font:16px/1.55 "Segoe UI",Arial,sans-serif}header{background:#173f68;color:white;padding:20px max(5vw,20px)}header h1{margin:0 0 5px;font-size:30px}header p{margin:0;color:#dfebf5}main{max-width:1240px;margin:auto;padding:16px 24px}.intro,.support{background:white;border:1px solid #cfdae4;padding:20px;border-radius:12px;margin:0 0 20px}.search{position:sticky;top:0;background:#edf2f6;padding:8px 0;z-index:1;display:flex;gap:8px}input{width:100%;font:inherit;padding:12px;border:1px solid #9aafc3;border-radius:8px}button{padding:10px 18px;background:#173f68;color:white;border:0;border-radius:8px;font:inherit}nav{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 18px}a{color:#135b91}nav a{background:white;border:1px solid #c7d7e5;border-radius:7px;padding:5px 10px;text-decoration:none}.category{scroll-margin-top:90px;margin:20px 0}.category h2{font-size:24px;color:#173f68;border-bottom:2px solid #c7d7e5;padding-bottom:8px}.cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.card{background:white;border:1px solid #cfdae4;border-radius:12px;padding:20px;overflow-wrap:anywhere;scroll-margin-top:90px}.card h3{display:flex;align-items:center;gap:12px;font-size:19px;margin:0 0 12px}.card img{width:32px;height:32px;flex-shrink:0;image-rendering:auto}.card p{margin:8px 0}.card h4{font-size:15px;color:#173f68;margin:17px 0 4px}.procedure{border-top:1px solid #e0e7ef;margin-top:16px}.compat-table{width:100%;border-collapse:collapse}.compat-table td,.compat-table th{padding:9px;border:1px solid #cfdae4;text-align:left}.table-wrap{overflow-x:auto}[hidden]{display:none!important}.meta{color:#52697f;font-size:13px}code{font:13px/1.6 Consolas,monospace;background:#f0f4f8;padding:2px 5px;border-radius:3px}.prompt{border-left:3px solid #7c9fc2;padding:8px 12px;margin:8px 0;background:#f5f8fb;font-size:14px}.note{background:#fff8e8;border-left:3px solid #bd922c;padding:10px 12px}.small{font-size:13px;color:#5b6f82}details{margin-top:14px}summary{cursor:pointer;color:#135b91}footer{padding:24px;color:#536a81}@media(max-width:760px){.cards{grid-template-columns:1fr}main{padding:16px}header h1{font-size:26px}}@media print{.search,nav{display:none}.card{break-inside:avoid}.cards{display:block}.card{margin:10px 0}body{background:white}}'''
general_sections='''<section class="intro" id="installazione"><h2>Installazione e uso</h2><p><b>Avvio:</b> digita <code>AGCADTOOLS</code> per aprire il catalogo, oppure usa Ribbon, menu o il nome del comando. Le categorie con più strumenti continuano nella parte espansa del pannello Ribbon.</p><p><b>Installazione:</b> chiudi AutoCAD, avvia il setup e scegli Installa, Aggiorna o Ripara. L’operazione parte subito; dopo il messaggio finale, OK chiude l’installer. Al riavvio esegui <code>AG_DIAGNOSTICA</code>. Il setup aggiorna il bundle installato e conserva una copia precedente. Il setup non richiede privilegi amministrativi per la cartella del profilo.</p><p><b>Nome e compatibilità:</b> AG sono le iniziali di Andrea Giaquinto. Puoi aprire il catalogo con <code>AGCADTOOLS</code> o <code>AGCAD</code>. I precedenti comandi <code>CTI</code> e <code>CTI_…</code> restano validi come alias.</p><p><b>Annullamento:</b> ESC interrompe il comando e ripristina le impostazioni temporanee. Le modifiche geometriche già completate possono restare nel disegno: usa UNDO per il gruppo di operazioni. Salvataggi, esportazioni, cambi di documento e altri effetti sui file non si annullano con UNDO.</p><p class="small">Versione definitiva 2.0, approvata dall’autore il 3 ottobre 2026 dopo il riscontro positivo su installer, Guida e menu della RC5. Logica dei comandi invariata. Già verificati caricamento e diversi comandi con buon esito su AutoCAD 2027 italiano (198/198 funzioni e 541/541 nomi). Il campione non è identificato comando per comando e non certifica tutte le funzioni o altre versioni/lingue. Il log riporta SECURELOAD=0.</p></section><section class="intro" id="compatibilita"><h2>Compatibilità e primo avvio</h2><div class="table-wrap"><table class="compat-table"><tr><th>Ambiente</th><th>Requisiti e stato</th></tr><tr><td>AutoCAD completo 2024–2026 ITA/ENG</td><td>Abilitati dal pacchetto; Windows 10/11 x64 secondo i requisiti Autodesk della versione. Controllo del codice e dei nomi internazionali, collaudo nativo da completare.</td></tr><tr><td>AutoCAD completo 2027 ITA/ENG</td><td>Windows 11 x64 secondo Autodesk. Italiano: caricamento, Ribbon e un campione di comandi confermati; installer, Guida e menu superiore RC5 approvati dall’autore. Versione 2.0 con la stessa logica. Inglese non collaudato nativamente.</td></tr><tr><td>AutoCAD 2021–2023</td><td>Motore Unicode disponibile, ma versioni non abilitate dal manifest attuale. Nessuna compatibilità dichiarata senza pacchetto e collaudo dedicati.</td></tr><tr><td>AutoCAD 2020 e precedenti; LT; Mac/Web; Windows 7/8/8.1; 32 bit; ARM nativo</td><td>Fuori dal perimetro di questa distribuzione. Il setup è compilato Windows amd64; il plugin usa AutoLISP/ActiveX di AutoCAD completo.</td></tr></table></div><p><b>Windows 10:</b> compare nei requisiti delle release 2024–2026, ma Autodesk ne ha concluso il supporto il 14 ottobre 2025. È un ambiente storico da collaudare, non una piattaforma attualmente assistita da Autodesk. Per nuove installazioni fare riferimento a Windows 11 e ai requisiti aggiornati della specifica release.</p><p><b>Lingue:</b> interfaccia e richieste del plugin restano italiane anche in AutoCAD inglese. Le chiamate ai comandi nativi usano nomi internazionali; i prompt delle sessioni native restano nella lingua di AutoCAD.</p><p><b>Unicode:</b> utilizzare LISPSYS=1 o 2. Una variazione di LISPSYS richiede il riavvio di AutoCAD. I moduli sono UTF-8; LISPSYS=0 non è il profilo di riferimento.</p><p><b>Caricamento protetto:</b> non disattivare SECURELOAD per installare il plugin. Se AutoCAD segnala un file non attendibile, verifica provenienza e cartella del bundle e configura, se autorizzato, soltanto quel percorso nelle Posizioni attendibili (Trusted Locations). Le policy aziendali possono richiedere l’intervento del gestore CAD.</p><p><b>Uso del manuale:</b> i valori fra &lt;…&gt; nei prompt sono i predefiniti accettati con Invio. F2 mostra la cronologia. Le misure sono in unità disegno salvo indicazione diversa; le progressive si misurano dall’inizio geometrico della curva. Le etichette create sono generalmente statiche. Per file CSV con virgola decimale preferire il separatore punto e virgola.</p><p><b>Operazioni estese:</b> le schede specificano quando il comando agisce su tutto il DWG o su tutti i layout. Eseguire le prime prove su una copia del disegno; verificare il risultato e UNDO prima di salvare.</p><p><a href="AG_CAD_Tools_Compatibilita.html">Matrice di compatibilità, fonti ufficiali ed evidenze di collaudo</a></p></section><section class="support" id="supporto"><h2>Supporto, sito e licenze</h2><a href="https://andreagiaquinto.it">andreagiaquinto.it</a> · <a href="https://wa.me/393337240544">WhatsApp 3337240544</a> · <a href="AG_CAD_Tools_Sostieni.html">Sostieni</a> · <a href="LICENZE_TERZE_PARTI.txt">Fonti e licenze MIT</a></section>'''
parts=[f'''<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AG CAD Tools 2.0 · Guida</title><style>{css}</style></head><body><header><h1>Guida ai comandi · AG CAD Tools</h1><p>2.0 · 198 strumenti · 16 categorie · Italiano</p><div class="utility-links"><a href="#installazione">Installazione e uso</a><a href="#compatibilita">Compatibilità</a><a href="#supporto">Supporto e sito</a></div></header><main><div class="search" id="strumenti"><input id="q" type="search" aria-label="Cerca nei comandi" placeholder="Cerca nome, comando, alias o funzione…"><button id="clear" type="button">Pulisci</button></div><p class="result-count" id="count" aria-live="polite">200 schede: 198 strumenti e 2 servizi</p><nav aria-label="Categorie dei comandi">''']
for i,cat in enumerate(cats):parts.append(f'<a href="#cat-{i}">{esc(cat)}</a>')
parts.append('</nav>')
for i,cat in enumerate(cats):
    rows=[r for r in REG if r['category']==cat]
    parts.append(f'<section class="category" id="cat-{i}"><h2>{esc(cat)} · {len(rows)}</h2><div class="cards">')
    for r in rows:
        cmd=r['command'];als=aliases_for(cmd);icon=base64.b64encode((W/r['icon32']).read_bytes()).decode()
        parts.append(f'<article class="card" id="{esc(cmd)}"><h3><img alt="" src="data:image/png;base64,{icon}">{esc(r["name"])}</h3><p><code>{esc(cmd)}</code></p><p>{esc(r["tip"])}</p><p class="meta">Origine: {esc(r["origin"])}</p>')
        if als:parts.append('<p class="meta">Alias compatibili: '+esc(', '.join(als))+'</p>')
        m=manual[r['id']]
        parts.append(f'<div class="procedure"><h4>Prima di iniziare</h4><p>{esc(m["prepare"])}</p><h4>Come si usa</h4><p>{esc(m["steps"])}</p><h4>Risultato e limiti</h4><p>{esc(m["limits"])}</p><h4>Esempio pratico</h4><p>{esc(m["example"])}</p></div>')
        if cmd=='AG_MURO_STRATIGRAFICO':parts.append('<p class="small">Layer: Muro_Finitura_1_Num_Penna__156; Muro_Finitura_2_Num_Penna__148; Muro_Portante_1_Num_Penna__148; Muro_Portante_2_Num_Penna__149.</p>')
        ps=prompts(cmd)
        if ps:
            parts.append('<details><summary>Richieste del comando</summary><p class="small">Le richieste cambiano in base alle opzioni e alla selezione.</p>')
            for pr in ps:parts.append('<div class="prompt">'+esc(pr)+'</div>')
            parts.append('</details>')
        if cmd in web:
            v=web[cmd];parts.append(f'<p class="small">Adattamento MIT da <a href="{esc(v["URL sorgente"])}">{esc(v["Repository"])}</a>. Fonte e commit fissati nel manifest allegato.</p>')
        parts.append('</article>')
    parts.append('</div></section>')
parts.append(general_sections)
parts.append('''<footer><p><a href="#strumenti">Torna alla ricerca dei comandi</a></p>AG CAD Tools 2.0 · 93 core, 100 Web e 5 personali. 200 schede con preparazione, procedura, risultato, limiti ed esempio. Le descrizioni sono verificate sul sorgente; il collaudo geometrico nativo resta distinto dalla revisione documentale.</footer></main><script>
const q=document.getElementById('q'),cards=[...document.querySelectorAll('.card')];
function filter(){const term=q.value.trim().toLocaleLowerCase('it');let n=0;cards.forEach(c=>{const show=!term||c.textContent.toLocaleLowerCase('it').includes(term);c.hidden=!show;if(show)n++;});document.querySelectorAll('.category').forEach(s=>s.hidden=![...s.querySelectorAll('.card')].some(c=>!c.hidden));document.getElementById('count').textContent=n+' schede visibili';}
q.addEventListener('input',filter);document.getElementById('clear').addEventListener('click',()=>{q.value='';filter();q.focus();});
</script></body></html>''')
(W/'AG_CAD_Tools_Help.html').write_text(''.join(parts),encoding='utf-8',newline='\n')
print('Guida generata: 200 schede complete, 16 categorie, procedure e limiti verificati sul sorgente.')

from genera_documenti_release import generate
generate()
