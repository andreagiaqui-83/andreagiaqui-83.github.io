"""Quattro definizioni corrette: layout indipendenti dalla lingua, overlap raster e specchiatura WMF."""
from pathlib import Path

def apply(w):
    p=w/'ag_cad_tools.lsp';s=p.read_text()
    old='(/= (strcase (vla-get-Name lay)) "MODEL")'
    assert s.count(old)==1
    s=s.replace(old,'(= (vla-get-ModelType lay) :vlax-false)')
    old='(rtos pw 2 3) ">: "))) (if (null dx) (setq dx pw))'
    new='(rtos (if (= (vla-get-ObjectName pat) "AcDbRasterImage") (ag:passo-tassello pw *CTI-IMAGEOVERLAP*) pw) 2 3) ">: "))) (if (null dx) (setq dx (if (= (vla-get-ObjectName pat) "AcDbRasterImage") (ag:passo-tassello pw *CTI-IMAGEOVERLAP*) pw)))'
    assert s.count(old)==1;s=s.replace(old,new)
    old='(rtos ph 2 3) ">: "))) (if (null dy) (setq dy ph))'
    new='(rtos (if (= (vla-get-ObjectName pat) "AcDbRasterImage") (ag:passo-tassello ph *CTI-IMAGEOVERLAP*) ph) 2 3) ">: "))) (if (null dy) (setq dy (if (= (vla-get-ObjectName pat) "AcDbRasterImage") (ag:passo-tassello ph *CTI-IMAGEOVERLAP*) ph)))'
    assert s.count(old)==1;s=s.replace(old,new)
    s+='\n; RC4: passo immagine sempre positivo; una sovrapposizione eccessiva viene ignorata.\n(defun ag:passo-tassello (dimensione sovrapposizione)\n  (if (and (numberp sovrapposizione) (> sovrapposizione 0.0) (< sovrapposizione dimensione))\n    (- dimensione sovrapposizione) dimensione))\n'
    # MIRROR con No lasciava copie specchiate estranee al set esportato WMF.
    # ActiveX restituisce l'oggetto creato: il set resta esplicito e senza duplicati.
    old='(vl-catch-all-apply \'command-s (list "_.MIRROR" ss2 "" axis1 axis2 "_No"))'
    assert s.count(old)==1
    s=s.replace(old,'(setq ss2 (ag:specchia-selezione ss2 axis1 axis2 T))')
    old='(vl-catch-all-apply \'command-s (list "_.MIRROR" out "" axis1 axis2 "_No"))'
    assert s.count(old)==1
    s=s.replace(old,'(setq out (ag:specchia-selezione out axis1 axis2 nil))')
    s+='\n(defun ag:specchia-selezione (ss asse1 asse2 provvisorio / risultato i vecchio nuovo)\n  (setq risultato (ssadd) i 0)\n  (repeat (sslength ss)\n    (setq vecchio (vlax-ename->vla-object (ssname ss i))\n          nuovo (vla-Mirror vecchio (vlax-3d-point asse1) (vlax-3d-point asse2)))\n    (if provvisorio (cti2:oggetto-provvisorio nuovo))\n    (ssadd (vlax-vla-object->ename nuovo) risultato)\n    (vla-Delete vecchio)\n    (setq i (1+ i)))\n  risultato)\n'
    p.write_text(s)
    p=w/'ag_web_2_0.lsp';s=p.read_text();old='(/= (strcase (vla-get-Name lay)) "MODEL")';assert s.count(old)==1;p.write_text(s.replace(old,'(= (vla-get-ModelType lay) :vlax-false)'))

CHANGED={'cti:layout-name-list','cti:retinoavanzato-core','cti:esploditesto-core','cti2c:cmd-copia-su-layout'}
