"""Documenti riproducibili della versione definitiva 2.0, con evidenze distinte."""
from pathlib import Path
import html,json
R=Path(__file__).resolve().parents[1]
W=R/'release/AGCADTools.bundle/Contents/Win64'
CSS='''*{box-sizing:border-box}body{margin:0;background:#eff4fa;color:#20364d;font:16px/1.6 "Segoe UI",Arial,sans-serif}header{background:#143c66;color:#fff;padding:35px max(5vw,22px)}h1{margin:0}main{max-width:1080px;margin:auto;padding:25px}section{background:#fff;border:1px solid #d1dce8;border-radius:12px;padding:24px;margin-bottom:20px}h2{font-size:24px;color:#134f84}h3{font-size:19px}a{color:#0067c0}table{border-collapse:collapse;width:100%;font-size:15px}th,td{border:1px solid #d1dce8;padding:12px;text-align:left;vertical-align:top}th{background:#edf4ff}.table-wrap{overflow-x:auto}.note{border-left:4px solid #c58618;padding:12px 18px;background:#fff7e5}code{overflow-wrap:anywhere}.small{font-size:14px;color:#52677a}li{margin:8px 0}.back{display:inline-block;background:#0067c0;color:#fff;padding:9px 15px;border-radius:7px;text-decoration:none}footer{padding:20px 0}@media(max-width:650px){main{padding:12px}section{padding:17px}h1{font-size:29px}}'''
BASE='https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/'
SOURCES=[(f'Autodesk — requisiti AutoCAD {y}',BASE+f'System-requirements-for-AutoCAD-{y}-including-Specialized-Toolsets.html') for y in range(2024,2028)]+[
 ('Autodesk — fine del supporto Windows 10',BASE+'Autodesk-Announcing-End-of-Support-for-Windows-10.html'),
 ('Autodesk — LISPSYS e motore Unicode','https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-Core/files/GUID-1853092D-6E6D-4A06-8956-AD2C3DF203A3.htm'),
 ('Autodesk — comandi e opzioni internazionali AutoLISP','https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-AutoLISP/files/GUID-D156B6ED-B1B4-42CB-BE1D-CA251BFC08C3.htm'),
 ('Autodesk — Layout.ModelType (ActiveX, Windows)','https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-ActiveX-Reference/files/GUID-7D01DF6D-1D7D-4505-8EDC-861C38551593.htm'),
 ('Autodesk — Mirror (ActiveX, Windows)','https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-ActiveX-Reference/files/GUID-F89941D6-676B-43C0-8D92-9AFDAFB03780.htm'),
 ('Go — requisito minimo Windows da Go 1.21','https://go.dev/doc/go1.21')]
MATRIX=[
 ('2024','R24.3','Windows 11; Windows 10 storico, 1809+ nei requisiti Autodesk','Italiano e inglese','Abilitata dal manifest; verifica statica. Nessun collaudo nativo documentato.'),
 ('2025','R25.0','Windows 11; Windows 10 storico, 1809+ nei requisiti Autodesk','Italiano e inglese','Abilitata dal manifest; verifica statica. Nessun collaudo nativo documentato.'),
 ('2026','R25.1','Windows 11; Windows 10 storico nei requisiti Autodesk','Italiano e inglese','Abilitata dal manifest; verifica statica. Nessun collaudo nativo documentato.'),
 ('2027','R26.0','Windows 11','Italiano e inglese','Italiano: caricamento, Ribbon e campione di comandi confermati; installer, Guida e menu RC5 approvati. La 2.0 ne conserva la logica. Inglese non collaudato nativamente.'),
 ('2021–2023','R24.0–R24.2','Fuori perimetro','Non dichiarate','Motore Unicode disponibile, ma release non abilitate da questo manifest.'),
 ('2020 e precedenti','R23.x e precedenti','Fuori perimetro','Non dichiarate','Nessuna variante legacy UTF-8/Unicode distribuita.')]
EVIDENCE={
 'data':'2026-10-03','versione_pubblica':'2.0','app_version':'2.0.0.6',
 'stato':'Versione definitiva autorizzata dall’autore',
 'base_approvata':'2.0 RC5',
 'riscontro_autore':'Ok interfaccia di installazione, guida e compare nel menu. Mi sembra tutto ok. Per me puoi rilasciare la versione definitiva per la pubblicazione con tutte le specifiche del caso.',
 'ambiente':'AutoCAD 2027 italiano, Windows x64; log precedente ACADVER 26.0s, LISPSYS=1, SECURELOAD=0; build Windows non documentata.',
 'evidenze':['RC5: installer, Guida e menu approvati dall’autore.','Schermata ricevuta: menu testuale AG CAD Tools e scheda Ribbon presenti in AutoCAD 2027 italiano.','RC4: diagnostica 198/198 funzioni e 541/541 nomi; diversi comandi provati con buon esito, senza elenco puntuale.'],
 'limiti':['Il setup definitivo ricompilato non è eseguito nativamente in questo ambiente.','Nessun collaudo nativo puntuale completo di tutti i 198 comandi.','AutoCAD 2024–2026 e inglese: abilitazione e verifica statica, non collaudo nativo.','SECURELOAD 1/2, WMF/font e interazioni con altri plugin non certificati integralmente.'],
 'matrice':MATRIX,'fonti':SOURCES}
REGISTER='''AG CAD TOOLS 2.0 — REGISTRO DEL RILASCIO E DEI COLLAUDI
3 ottobre 2026 · Andrea Giaquinto

DECISIONE DI RILASCIO
L’autore autorizza la versione definitiva dopo aver approvato le tre
modifiche RC5: installer, Guida e menu superiore. Non si richiede la
ripetizione di questi controlli per la promozione a 2.0.

EVIDENZE NATIVE DISPONIBILI
- RC4: caricamento su AutoCAD 2027 italiano, 198/198 e 541/541.
- RC4: diversi comandi provati dall’autore con buon esito; elenco non fornito.
- RC5: interfaccia installer, disposizione della Guida e menu approvati.
- Schermata finale: AG CAD Tools presente nella barra testuale e nel Ribbon.
- Log: ACADVER 26.0s; LISPSYS=1; SECURELOAD=0; Windows NT 10.0 Intel64.
  La stringa NT 10.0 non distingue Windows 10/11 e non indica la build.
- ETIT Companion, BlockHub e YQArch presenti nella sessione precedente.
  La coesistenza del caricamento non certifica tutte le interazioni.

PROMOZIONE A 2.0
Confronto dei sorgenti con baseline RC5: stessa logica LISP e motore
installer, stesse 200 schede della Guida. Cambiano solo metadati, etichette,
stato del rilascio e documentazione generale. Il rapporto registra i
controlli automatici realmente eseguiti sul pacchetto definitivo.
I test automatici girano su Linux con API AutoCAD simulate; la compilazione
produce il setup Windows x64. Il setup definitivo non è eseguito qui.

COPERTURA NON DOCUMENTATA
Non risultano prove native per tutte le 198 funzioni singolarmente,
AutoCAD 2024–2026, AutoCAD inglese, SECURELOAD 1/2, tutte le varianti
WMF/font, tutte le scale Windows, rollback/disinstallazione nativi e tutte
le interazioni con altri plugin. Queste combinazioni restano esplicitamente
non collaudate. Il manifest non le trasforma in prove superate.
Questa è una delimitazione delle evidenze, non una nuova checklist richiesta
all’autore per rilasciare la 2.0.

FUTURE SEGNALAZIONI
Per arricchire il registro: versione plugin, comando, lingua/build AutoCAD,
Windows, passaggi, risultato atteso/ottenuto, eventuale ESC/UNDO e file di
esempio. Il CSV delle 198 funzioni può annotare successivi test individuali.
Supporto: https://andreagiaquinto.it — WhatsApp +39 333 724 0544.
'''

def generate():
    rows=''.join('<tr>'+''.join('<td>'+html.escape(x)+'</td>' for x in r)+'</tr>' for r in MATRIX)
    links=''.join(f'<li><a href="{u}">{html.escape(t)}</a></li>' for t,u in SOURCES)
    body=f'''<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AG CAD Tools 2.0 — Compatibilità</title><style>{CSS}</style></head><body><header><h1>AG CAD Tools · compatibilità</h1><p>2.0 definitiva · Andrea Giaquinto · 3 ottobre 2026</p></header><main><p><a class="back" href="AG_CAD_Tools_Help.html">Torna alla guida dei comandi</a></p>
<section><h2>Versione definitiva e perimetro</h2><p><b>Rilascio autorizzato dall’autore dopo l’approvazione della RC5.</b> Installer, Guida e menu sono stati confermati nell’ambiente AutoCAD 2027 italiano. La versione definitiva conserva la stessa logica; il confronto con la RC5 e la compilazione sono verificati automaticamente. L’approvazione non equivale a un collaudo di tutte le combinazioni elencate.</p><p>198 strumenti, 200 voci, 16 categorie, 541 nomi pubblici inclusi servizi e alias. Il manifest abilita AutoCAD completo Windows x64, serie R24.3–R26.0. AutoLISP UTF-8, DCL, CUIX e ActiveX; nessun Express Tools o runtime esterno aggiuntivo richiesto dal plugin. Restano necessari i componenti previsti da AutoCAD.</p><div class="table-wrap"><table><tr><th>AutoCAD</th><th>Serie</th><th>Windows x64</th><th>Lingue previste</th><th>Evidenza</th></tr>{rows}</table></div><p><b>Windows 10:</b> elencato nei requisiti storici 2024–2026, con supporto Autodesk concluso il 14 ottobre 2025. Per nuove installazioni fare riferimento a Windows 11 e ai requisiti aggiornati della specifica release.</p><p><b>Fuori perimetro:</b> LT, Mac/Web, altri CAD DWG, Windows 7/8/8.1, 32 bit e ARM nativo. Toolset verticali e Windows Server non sono dichiarati collaudati. Il setup è amd64, compilato con Go 1.23.2; da Go 1.21 il minimo desktop è Windows 10, ma valgono anche i requisiti AutoCAD. Il rilevamento nel registro non certifica il funzionamento.</p></section>
<section><h2>Lingua e caricamento</h2><p>Interfaccia, comandi AG_ e Guida restano italiani anche su AutoCAD inglese; i prompt Autodesk seguono la lingua del programma. Le chiamate native impiegano nomi e opzioni internazionali. I layout sono riconosciuti tramite ModelType. Queste verifiche statiche non certificano tutte le sequenze di prompt nelle diverse release.</p><p>Usare LISPSYS=1 o 2; dopo una modifica manuale riavviare AutoCAD. Nessuna variante LISPSYS=0. Il plugin non modifica SECURELOAD, LISPSYS o TRUSTEDPATHS. Il log ricevuto usa SECURELOAD=0: la prova con 1/2 non è documentata. Non è richiesto abbassare la sicurezza; in caso di avviso verificare provenienza e percorso nelle Posizioni attendibili, secondo le policy del proprio ambiente.</p></section>
<section><h2>Riscontri nativi registrati</h2><ul><li>RC4: AutoCAD 2027 italiano, ACADVER 26.0s; diagnostica 198/198 funzioni e 541/541 nomi, Ribbon presente; diversi comandi provati con buon esito, senza elenco puntuale.</li><li>RC5: autore soddisfatto di installer, Guida e menu; autorizzazione alla versione definitiva. La schermata allegata mostra AG CAD Tools nel menu superiore e nel Ribbon.</li><li>Windows x64; il log NT 10.0 non distingue Windows 10/11. Edizione e build esatte non documentate. LISPSYS=1.</li><li>ETIT Companion, BlockHub e YQArch risultano caricati insieme; nessun collaudo esaustivo delle interazioni.</li><li>Il setup 2.0 ricompilato è verificato automaticamente; l’esecuzione nativa approvata riguarda la RC5, la cui logica è preservata.</li></ul></section>
<section><h2>Limiti delle prove</h2><p>Non sono documentati collaudi nativi puntuali per tutti i 198 strumenti, AutoCAD 2024–2026, inglese, tutte le varianti WMF/font, scale Windows o tutti i casi di errore. I test automatici usano API simulate: non sostituiscono il motore geometrico Autodesk. Le singole schede illustrano i limiti operativi, ESC e UNDO.</p><p>La 2.0 è la versione definitiva autorizzata; le combinazioni non provate rimangono indicate come tali. Non è richiesta una nuova tornata di collaudo all’autore per questa promozione. Le future segnalazioni potranno ampliare il registro.</p></section>
<section><h2>Fonti ufficiali</h2><p class="small">Consultate il 3 ottobre 2026. Requisiti e ciclo di supporto Autodesk sono distinti dal perimetro del manifest e dalle evidenze del plugin.</p><ul>{links}</ul></section><p><a class="back" href="AG_CAD_Tools_Help.html">Torna alla guida dei comandi</a></p><footer><a href="https://andreagiaquinto.it">andreagiaquinto.it</a> · Andrea Giaquinto</footer></main></body></html>'''
    (W/'AG_CAD_Tools_Compatibilita.html').write_text(body,encoding='utf-8')
    (R/'REGISTRO_COLLAUDI_AG_CAD_Tools_2.0.txt').write_text(REGISTER,encoding='utf-8')
    (R/'verifiche/MATRICE_COMPATIBILITA.json').write_text(json.dumps(EVIDENCE,ensure_ascii=False,indent=2)+'\n')
    (R/'LEGGIMI_AG_CAD_Tools_2.0.txt').write_text((R/'sorgenti/LEGGIMI_2_0.txt').read_text(),encoding='utf-8')
    print('Documenti definitivi generati: compatibilità, fonti, registro e istruzioni.')

if __name__=='__main__':generate()
