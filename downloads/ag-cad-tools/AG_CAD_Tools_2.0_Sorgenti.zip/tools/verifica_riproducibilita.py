"""Rigenera due volte il payload e conserva gli hash di tutti i file."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[1];B=R/'release/AGCADTools.bundle';V=R/'verifiche'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build():
    for script in ['genera_finale.py','genera_guida.py']:
        subprocess.run([sys.executable,str(R/'tools'/script)],cwd=R,check=True)
    return {p.relative_to(B).as_posix():sha(p) for p in B.rglob('*') if p.is_file()}
a=build();b=build();assert a==b,'Payload non riproducibile'
(V/'PAYLOAD_SHA256.json').write_text(json.dumps(b,indent=2,sort_keys=True)+'\n')
result={'stato':'PASS','versione':'2.0','file_identici':len(b),'metodo':'Due generazioni consecutive dalle baseline incluse, confronto SHA-256 di ogni file.'}
(V/'RIPRODUCIBILITA_PAYLOAD.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result)
