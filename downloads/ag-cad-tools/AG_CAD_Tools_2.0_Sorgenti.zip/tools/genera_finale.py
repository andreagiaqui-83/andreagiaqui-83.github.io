"""Ricostruisce AG CAD Tools 2.0 dalla RC2, preservando logica e dati persistenti."""
from pathlib import Path
import json,shutil,subprocess,sys,zipfile
import xml.etree.ElementTree as ET
from branding import ROOT,COMMANDS,FILES,name,text,lisp,ui
sys.path.insert(0,str(ROOT/'verifiche'))
from lisp_audit import parse,definitions
subprocess.run([sys.executable,str(ROOT/'tools/genera_base_rc2.py')],cwd=ROOT,check=True)
base=ROOT/'build_intermedio/CADToolsItaliano.bundle';B=ROOT/'release/AGCADTools.bundle';W=B/'Contents/Win64'
if B.exists():shutil.rmtree(B)
W.mkdir(parents=True)
for p in (base/'Contents/Win64').iterdir():
 if not p.is_file() or p.suffix=='.cuix':continue
 dest=W/name(p.name)
 if p.suffix=='.lsp':dest.write_text(lisp(p.read_text(encoding='utf-8-sig')),encoding='utf-8')
 elif p.suffix in ['.html','.dcl','.txt','.csv']:
  content=text(p.read_text(encoding='utf-8-sig'))
  if p.suffix=='.html':
   content=content.replace('AG CAD Tools 1.9','AG CAD Tools 2.0').replace('CAD%20Tools%20Italiano%201.9','AG%20CAD%20Tools%202.0').replace('Versione%20CAD%20Tools%3A%201.9','Versione%20AG%20CAD%20Tools%3A%202.0')
  dest.write_text(content,encoding='utf-8')
 else:shutil.copyfile(p,dest)
from correzioni_rc4 import apply as apply_rc4
apply_rc4(W)
# All legacy public names delegate to the corresponding new public command.
alias='; Compatibilità dei comandi storici; usare AGCADTOOLS e AG_.\n'
for old,new in sorted(COMMANDS.items()):alias+=f'(defun c:{old} () (c:{new}))\n'
alias+='(defun c:AGCAD () (c:AGCADTOOLS))\n(princ)\n'
(W/'ag_compatibilita.lsp').write_text(alias)
bootstrap=W/'ag_bootstrap_2_0.lsp';s=bootstrap.read_text();s=s.replace('(cti2:carica-modulo "ag_diagnostica_2_0.lsp"))','(cti2:carica-modulo "ag_diagnostica_2_0.lsp")\n  (cti2:carica-modulo "ag_compatibilita.lsp"))')
s=s.replace('(setq *CTI2-LOAD-COMPLETE*\n', (ROOT/'sorgenti/menu_classico.lsp').read_text()+'\n'+(ROOT/'sorgenti/migrazione_ui.lsp').read_text()+'\n(if *CTI-LOAD-COMPLETE* (cti:startup-call "Interfaccia AG CAD Tools" \'ag:aggiorna-interfaccia))\n(setq *CTI2-LOAD-COMPLETE*\n')
bootstrap.write_text(s)
(W/'AGCADTools.mnl').write_text('(vl-load-com)\n'+(ROOT/'sorgenti/menu_classico.lsp').read_text()+'\n'+(ROOT/'sorgenti/AGCADTools.mnl').read_text())
# Package sources use the same transformed XML and unchanged PNG pixels.
ui_dir=ROOT/'sorgenti_ui/ag_cuix_src'
if ui_dir.exists():shutil.rmtree(ui_dir)
ui_dir.mkdir()
for p in (ROOT/'sorgenti_ui/cuix_src').iterdir():
 if p.is_file():
  q=ui_dir/name(p.name)
  if p.suffix in ['.cui','.xml']:q.write_text(ui(p.read_text(encoding='utf-8-sig')))
  else:shutil.copyfile(p,q)
with zipfile.ZipFile(W/'AGCADTools.cuix','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(ui_dir.iterdir()):
  zi=zipfile.ZipInfo(p.name,(2026,10,3,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,p.read_bytes())
reg=json.loads((ROOT/'REGISTRO_UI_2_0.json').read_text())
for row in reg:
 for key,value in row.items():
  if isinstance(value,str):row[key]=ui(value) if key=='uid' else text(value)
(ROOT/'REGISTRO_UI_2_0.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
public={n:p.name for p in sorted(W.glob('*.lsp')) for n in definitions(parse(p.read_text())).keys() if n.startswith('c:')}
assert len(public)==541
(ROOT/'verifiche/REGISTRO_PUBBLICO.json').write_text(json.dumps(public,indent=2)+'\n')
(ROOT/'verifiche/MAPPA_RINOMINA_COMANDI.json').write_text(json.dumps(COMMANDS,indent=2)+'\n')
# Diagnostics count aliases actually defined, including compatibility names.
diag=W/'ag_diagnostica_2_0.lsp';s=diag.read_text();lines=s.splitlines();lines[1]='(setq *CTI2-COMANDI-PUBBLICI* \''+'('+ ' '.join('"'+c[2:].upper()+'"' for c in sorted(public))+'))';diag.write_text('\n'.join(lines)+'\n')
package=ET.fromstring(text((base/'PackageContents.xml').read_text()))
package.set('AppVersion','2.0.0.6');package.set('ProductCode','{D01E2C3A-ABC6-4D43-9831-91B9166C7D06}');package.set('Author','Andrea Giaquinto')
cs=package.find('.//Commands');cs.clear();cs.set('GroupName','AGCADTOOLS')
for c in sorted(public):ET.SubElement(cs,'Command',Global=c[2:].upper(),Local=c[2:].upper())
ET.indent(package,space='  ');ET.ElementTree(package).write(B/'PackageContents.xml',encoding='utf-8',xml_declaration=True)
for a,b in [('installer_main.go','main.go'),('installer_ui_design.go','ui_design.go'),('installer_common.go','common.go'),('installer_migration.go','migration.go')]:
 shutil.copyfile(ROOT/'sorgenti'/a,ROOT/'installer_src'/b)
print(f'AG CAD Tools 2.0: 198 strumenti, 200 voci, {len(public)} nomi pubblici; 210 alias CTI compatibili.')
