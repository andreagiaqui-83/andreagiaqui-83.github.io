"""Consegna definitiva 2.0: byte verificati, evidenze reali e specifiche di pubblicazione."""
from pathlib import Path
import base64,csv,hashlib,html,json,re,shutil,zipfile
from genera_documenti_release import CSS,EVIDENCE
R=Path(__file__).resolve().parents[1];V=R/'verifiche';B=R/'release/AGCADTools.bundle';W=B/'Contents/Win64'
OUT=R.parents[1]/'consegna_AG_CAD_Tools_2_0';OUT.mkdir(exist_ok=True)
def read(n):return json.loads((V/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def esc(s):return html.escape(str(s))
names={'promozione':'ESITO_PROMOZIONE_2_0.json','audit':'ESITO_AUDIT_FINALE.json','integrazione':'ESITO_INTEGRAZIONE.json','web':'ESITO_TEST_LOGICA.json','personali':'ESITO_TEST_PERSONALI.json','bootstrap':'ESITO_BOOTSTRAP.json','menu':'ESITO_MIGRAZIONE_UI.json','correzioni':'ESITO_RC4.json','documenti':'ESITO_RELEASE.json','continuita':'ESITO_CONTINUITA_INTERFACCIA.json'}
checks={k:read(n) for k,n in names.items()};assert all(d['fail']==0 for d in checks.values())
build=read('ESITO_BUILD_INSTALLER.json');repro=read('RIPRODUCIBILITA_PAYLOAD.json');assert build['stato']==repro['stato']=='PASS'
payload={p.relative_to(B).as_posix():sha(p) for p in B.rglob('*') if p.is_file()}
assert read('PAYLOAD_SHA256.json')==payload
setup=R/'release'/build['file'];assert sha(setup)==build['sha256']
assert payload=={p.relative_to(R/'installer_src/bundle').as_posix():sha(p) for p in (R/'installer_src/bundle').rglob('*') if p.is_file()}
# Authenticode security-directory entry in the PE32+ optional header.
pe=setup.read_bytes();off=int.from_bytes(pe[60:64],'little');opt=off+24
assert int.from_bytes(pe[opt:opt+2],'little')==0x20b
security_offset=opt+112+4*8
signed=any(pe[security_offset:security_offset+8]);assert not signed
reg=json.loads((R/'REGISTRO_UI_2_0.json').read_text());mapping=read('MAPPA_RINOMINA_COMANDI.json')
mapfile=R/'MAPPA_COMANDI_AG_CAD_Tools.csv'
with mapfile.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['Comando precedente (alias compatibile)','Nuovo comando','Nome italiano','Categoria']);by={r['command']:r for r in reg}
 for old,new in sorted(mapping.items()):w.writerow([old,new,by.get(new,{}).get('name','Launcher o alias'),by.get(new,{}).get('category','Servizio / alias')])
manifest=R/'MANIFEST_198_FUNZIONI.csv'
with manifest.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['Comando','Nome italiano','Categoria','Origine','Protezione','Audit automatico 2.0','Collaudo nativo individuale documentato','Note'])
 for r in reg:
  if r['origin']!='Servizio':w.writerow([r['command'],r['name'],r['category'],r['origin'],'cti2:esegui-comando','PASS','Non identificato nel riscontro ricevuto','Campione positivo riferito dall’autore; nessun elenco individuale. Non equivale a un esito negativo.'])
go_tests=sum(line.startswith('--- PASS:') for rec in build['verifiche'] if rec['comando']=='go test -v ./...' for line in rec['output'].splitlines());assert go_tests==13
spec={
 'prodotto':'AG CAD Tools','autore':'Andrea Giaquinto','sito':'https://andreagiaquinto.it',
 'versione':'2.0','canale':'definitiva','app_version':'2.0.0.6','data_rilascio':'2026-10-03',
 'base_approvata':'2.0 RC5','strumenti':198,'core':93,'web_mit':100,'personali':5,
 'categorie':list(dict.fromkeys(r['category'] for r in reg)),'voci_visibili':200,'nomi_pubblici_servizi_alias':541,'alias_cti':210,
 'comandi':{'catalogo':['AGCADTOOLS','AGCAD'],'diagnostica':'AG_DIAGNOSTICA','guida':'AG_AIUTOSTRUMENTI','supporto':'AG_SOSTIENI'},
 'pacchetto':{'bundle':'AGCADTools.bundle','gruppo_cui':'AGCADTOOLS','installazione':'%APPDATA%\\Autodesk\\ApplicationPlugins\\AGCADTools.bundle','per_utente':True,'runtime_esterno_richiesto':False,'express_tools_richiesti':False,'lingua_interfaccia':'it-IT'},
 'compatibilita':EVIDENCE,
 'installer':{'file':setup.name,'byte':build['dimensione'],'sha256':build['sha256'],'target':'Windows x64 GUI','toolchain':build['toolchain'],'firma_authenticode':signed,'conferma_installa_ripara':False,'ok_finale_chiude':True,'backup_sha256_rollback':True},
 'controlli_automatici':{k:{'pass':v['pass'],'fail':v['fail']} for k,v in checks.items()},
 'go_test':go_tests,'riproducibilita_payload':repro,
 'licenze':'Licenze e attribuzioni delle cinque fonti MIT incluse; non attribuire MIT automaticamente all’intero progetto.',
 'pubblicazione':{'stato':'Pacchetto pronto; messa online del sito non eseguita in questa consegna','url_pagina_proposto':'https://andreagiaquinto.it/ag-cad-tools/','directory_download_proposta':'/downloads/ag-cad-tools/2.0/'}}
specpath=R/'SPECIFICHE_AG_CAD_Tools_2.0.json';specpath.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
preview_file=V/'ANTEPRIMA_INSTALLER_AG_CAD_Tools_2.0.png';preview=base64.b64encode(preview_file.read_bytes()).decode()
rows=[('Promozione RC5 → 2.0',checks['promozione']['pass'],'Tutte le forme LISP/MNL confrontate, motore installer e flussi identici; ammesse soltanto etichette, metadati e testi di rilascio. Stesse 200 schede e icone.'),('Audit del pacchetto',checks['audit']['pass'],'198 ingressi protetti, 541 nomi, 200 voci, 16 categorie, risorse, licenze, CUIX e baseline.'),('Integrazione LISP simulata',checks['integrazione']['pass'],'Include 594 scenari dei wrapper: 198 × successo/ESC/errore. Non esegue le API native o tutti i corpi geometrici.'),('Logica Web',checks['web']['pass'],'API simulate; ulteriori 300 combinazioni del runtime, non 300 prove native.'),('Personali',checks['personali']['pass'],'Geometria, selezioni e cleanup simulati.'),('Bootstrap',checks['bootstrap']['pass'],'Registrazione, risorse mancanti e caricamento.'),('Menu e migrazione',checks['menu']['pass'],'Inserimento idempotente e convivenza fra gruppi con API simulate.'),('Correzioni ereditate RC4',checks['correzioni']['pass'],'Layout, overlap raster e specchiatura: simulazioni; WMF/font reali non coperti integralmente.'),('Guida e compatibilità',checks['documenti']['pass'],'200 schede, link, ancore, ricerca JS con DOM simulato, manifest e nomi internazionali.'),('Continuità interfaccia dalla RC4',checks['continuita']['pass'],'Solo modifica della gestione interfaccia e helper menu privato; logica strumenti preservata.'),('Installer Go',go_tests,'Motore su Linux, race detector, vet Linux/Windows e compilazione PE x64. Nessuna esecuzione della finestra Windows in questo ambiente.')]
body=''.join('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in row)+'</tr>' for row in rows)
report=R/'RAPPORTO_AG_CAD_Tools_2.0.html'
report.write_text(f'''<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AG CAD Tools 2.0 — Rapporto di rilascio</title><style>{CSS}img{{width:100%;height:auto;border-radius:12px;border:1px solid #cbd8ec}}</style></head><body><header><h1>AG CAD Tools 2.0</h1><p>Versione definitiva · Andrea Giaquinto · 3 ottobre 2026</p></header><main><p><a class="back" href="AG_CAD_Tools_Help.html">Apri la Guida dei comandi</a></p>
<section><h2>Decisione di rilascio</h2><p><b>Versione definitiva autorizzata dall’autore dopo il riscontro positivo sulla RC5.</b> Installer, Guida e menu sono stati approvati. La schermata ricevuta mostra AG CAD Tools nella barra testuale e nel Ribbon di AutoCAD 2027 italiano. Il rilascio 2.0 conserva la logica approvata; non si richiede una nuova tornata di collaudi all’autore per questa promozione.</p><p>Versione pubblica <b>2.0</b>; AppVersion <b>2.0.0.6</b>, crescente rispetto alla RC5. UpgradeCode storico conservato; ProductCode della build aggiornato. Nomi e impostazioni restano compatibili.</p></section>
<section><h2>Contenuto della versione</h2><p><b>198 strumenti: 93 core + 100 Web + 5 personali.</b> 16 categorie, 200 voci e 541 nomi pubblici comprensivi di servizi e alias. Conservati tutti i 330 nomi storici, inclusi i 210 alias CTI. Nessuna dipendenza dagli Express Tools Autodesk.</p><ul><li>Installer con titolo AG CAD TOOLS, sito vicino, pulsanti blu/turchese/viola e contorni coordinati.</li><li>Installa/Ripara senza conferma iniziale; messaggio di successo mantenuto, OK chiude automaticamente. Conferma per disinstallazione ed errori a finestra aperta preservati.</li><li>Menu AG CAD Tools nella barra superiore e nel Ribbon. Inserimento senza duplicati; MENUBAR resta una preferenza dell’utente.</li><li>Guida con ricerca e categorie in cima, 200 schede complete e sezioni generali ordinate più in basso.</li><li>Staging, backup, verifica SHA-256 e rollback; aggiornamento dalla vecchia identità CAD Tools Italiano.</li></ul><img src="data:image/png;base64,{preview}" alt="Anteprima dell’installer AG CAD Tools 2.0"><p class="small">Anteprima dal modello grafico Go, con font sostitutivo DejaVu Sans; non è uno screenshot Windows. Stato installato di esempio.</p></section>
<section><h2>Continuità con la RC5</h2><p>Il confronto automatico copre tutte le forme LISP/MNL, non soltanto il conteggio delle funzioni: logica identica salvo le stringhe di versione e lo stato della diagnostica. Anche motore e flussi del setup sono identici; cambiano badge e nome privato della classe finestra. Le 200 schede HTML, il manuale sorgente, il CUIX e le icone sono preservati, salvo etichette di versione dove presenti.</p><p>Conservati chiavi delle preferenze, strutture XData, reattori, impostazioni personali e alias. Nessuna modifica geometrica introdotta nella promozione. Le correzioni RC4 a layout, overlap raster e specchiatura rimangono. I messaggi predisposti per WhatsApp ora riportano la versione definitiva 2.0.</p></section>
<section><h2>Evidenze e limiti</h2><p>RC4: diagnostica 198/198 e 541/541 su AutoCAD 2027 italiano; diversi comandi provati dall’autore con buon esito, senza elenco individuale. RC5: installer, Guida e menu approvati. Il setup definitivo ricompilato è controllato automaticamente; non è stato eseguito nativamente qui.</p><p>Il log ricevuto riporta ACADVER 26.0s, LISPSYS=1, SECURELOAD=0, Windows NT 10.0 Intel64. Edizione/build Windows non documentate. ETIT Companion, BlockHub e YQArch caricati insieme; nessun collaudo esaustivo delle interazioni.</p><p>Il manifest abilita AutoCAD completo 2024–2027 Windows x64, italiano/inglese. Le prove native disponibili riguardano l’ambiente italiano 2027 indicato; le altre release, inglese e tutti i 198 comandi singolarmente non sono dichiarati collaudati. <a href="AG_CAD_Tools_Compatibilita.html">Matrice completa, requisiti e fonti ufficiali</a>.</p></section>
<section><h2>Verifiche della build definitiva</h2><div class="table-wrap"><table><tr><th>Ambito</th><th>Prove superate</th><th>Copertura</th></tr>{body}</table></div><p><b>Riproducibilità:</b> {repro['file_identici']} file di payload identici in due generazioni. Payload del setup uguale al bundle portabile. Verifiche CRC dei tre archivi completate durante il confezionamento.</p><p><b>Setup:</b> {esc(build['toolchain'])}, Windows amd64 GUI, {build['dimensione']:,} byte; nessuna firma Authenticode.<br><b>SHA-256:</b> <code>{build['sha256']}</code></p><p class="small">Test su Linux e API AutoCAD simulate; ricerca HTML con DOM simulato. Nessuna esecuzione Windows o rendering browser della build finale in questo ambiente. Il riscontro visivo nativo dell’autore riguarda la RC5 approvata.</p></section>
<section><h2>Distribuzione e pubblicazione</h2><p>Per installare basta <b>{esc(setup.name)}</b>. Chiudere AutoCAD, avviare il setup, usare Installa/Aggiorna/Ripara, premere OK al termine e riaprire AutoCAD. Il pulsante Ripara installa comunque il payload definitivo 2.0.</p><p>La consegna comprende setup, sorgenti riproducibili, bundle portabile, Guida, compatibilità, istruzioni, registro dei collaudi, mappa comandi, manifest delle funzioni, licenze, specifiche JSON, testi per il sito e SHA-256. Le cinque attribuzioni MIT delle fonti Web sono incluse; non si attribuisce automaticamente MIT all’intero progetto.</p><p><b>Pacchetto definitivo pronto per la pubblicazione.</b> La messa online della pagina e dei download del sito non è stata eseguita in questa consegna. La scheda allegata indica testi, percorsi e verifiche dell’integrazione web.</p></section><p><a class="back" href="AG_CAD_Tools_Help.html">Torna alla Guida</a></p><footer><a href="https://andreagiaquinto.it">andreagiaquinto.it</a> · Andrea Giaquinto</footer></main></body></html>''',encoding='utf-8')
publication=R/'SCHEDA_PUBBLICAZIONE_AG_CAD_Tools_2.0.txt'
publication.write_text(f'''AG CAD TOOLS 2.0 — SCHEDA DI PUBBLICAZIONE
Versione definitiva approvata · 3 ottobre 2026
Pacchetto pronto; integrazione e deploy del sito non eseguiti in questa consegna.

PAGINA E METADATI
URL proposto: https://andreagiaquinto.it/ag-cad-tools/
Titolo SEO: AG CAD Tools — 198 strumenti AutoCAD in italiano | Andrea Giaquinto
Descrizione: 198 strumenti per AutoCAD, menu e guida in italiano, installer
Windows e 16 categorie. Scarica AG CAD Tools 2.0 di Andrea Giaquinto.
H1: AG CAD Tools
Sottotitolo: 198 strumenti per il tuo lavoro in AutoCAD, in italiano.
Badge: Versione 2.0 · Definitiva
Autore: Andrea Giaquinto — AG sono le sue iniziali.

TESTO PRINCIPALE
AG CAD Tools riunisce 198 strumenti per geometria, testi, blocchi, quote,
layer, layout e file, organizzati in 16 categorie. Il menu superiore,
il Ribbon e il catalogo rendono accessibili i comandi; la Guida con ricerca
spiega preparazione, procedura, risultati, limiti ed esempi per ogni voce.
Un unico installer Windows installa o aggiorna il plugin, conservando
impostazioni e alias precedenti. Non sono necessari gli Express Tools.

NOVITÀ DELLA VERSIONE DEFINITIVA
Identità AG CAD Tools, installer con grafica e colori approvati, menu
superiore e Ribbon, Guida con ricerca e comandi subito visibili.
Installa/Ripara senza conferma intermedia; OK al termine chiude il setup.
La versione 2.0 conserva la logica della RC5 approvata dall’autore.

REQUISITI E TRASPARENZA DELLE PROVE
AutoCAD completo 2024–2027 Windows x64, italiano/inglese nel manifest;
interfaccia del plugin in italiano. Windows 11 secondo i requisiti della
release Autodesk; Windows 10 soltanto scenario storico per 2024–2026.
LISPSYS=1 o 2. Nessuna richiesta di disattivare SECURELOAD.
Evidenze native: AutoCAD 2027 italiano, caricamento, campione di comandi;
installer, Guida e menu RC5 approvati. Le altre versioni, l’inglese e tutti
198 comandi singolarmente non sono dichiarati collaudati. Link alla matrice.
LT, Mac/Web, 2023 e precedenti e altri CAD DWG fuori perimetro.

CTA E DOWNLOAD
Primaria: Scarica AG CAD Tools 2.0 per Windows
File: {setup.name}
Dimensione: {build['dimensione']} byte
SHA-256: {build['sha256']}
Firma Authenticode: assente.
Directory proposta: /downloads/ag-cad-tools/2.0/
Secondarie: Leggi la Guida · Verifica compatibilità · Supporto
Guida: AG_CAD_Tools_Help.html
Compatibilità: AG_CAD_Tools_Compatibilita.html
Rapporto: RAPPORTO_AG_CAD_Tools_2.0.html
Sorgenti: AG_CAD_Tools_2.0_Sorgenti.zip
Portabile: AG_CAD_Tools_2.0_Portabile.zip
Pacchetto completo: AG_CAD_Tools_2.0_Consegna.zip
Impronte: SHA256_AG_CAD_Tools_2.0.txt
Specifiche: SPECIFICHE_AG_CAD_Tools_2.0.json

INSTALLAZIONE IN PAGINA
Chiudi AutoCAD, avvia il setup e premi Installa, Aggiorna o Ripara.
Al messaggio di successo premi OK e riapri AutoCAD. Usa AG CAD Tools dal
menu, dal Ribbon oppure digita AGCADTOOLS. Guida: AG_AIUTOSTRUMENTI.
Non occorre disinstallare la RC5 o CAD Tools Italiano prima del setup.

FAQ VISIBILI (DA RIFLETTERE FEDELMENTE NEI DATI STRUTTURATI)
È la versione definitiva? Sì, 2.0 autorizzata dall’autore dopo l’approvazione
RC5; i limiti del collaudo sono dichiarati nella matrice.
Quanti strumenti contiene? 198; 200 voci comprendono Sostieni e Diagnostica.
I 541 nomi includono servizi e alias, non 541 strumenti distinti.
Servono gli Express Tools? No, il plugin non ne dipende.
Funziona in AutoCAD inglese? È previsto dal codice e dal manifest; il plugin
resta italiano. Non è ancora documentato il collaudo nativo inglese.
I vecchi comandi funzionano? Sì: 210 alias CTI e gli altri nomi storici
restano validi, per un totale di 330 nomi precedenti preservati.
Posso aggiornare la RC5? Sì, avvia il nuovo EXE e premi Ripara se proposto.
Come segnalo un problema? Indica comando, versioni e passaggi; invia un
esempio riproducibile tramite Supporto o WhatsApp +39 333 724 0544.
Quali licenze sono incluse? Attribuzioni e licenze MIT delle cinque fonti
Web; evitare di dichiarare MIT l’intero progetto senza una licenza dedicata.

INTEGRAZIONE SUL SITO
Repository: andreagiaqui-83/andreagiaqui-83.github.io.
Rileggere AGENTS.md e .github/PLUGINS-PUBLICATION.md correnti prima di editare.
Preservare le altre landing, tariffe, moduli, consenso e tracciamenti.
Download sul dominio: copiare questo EXE senza modificarlo o ricompilarlo;
verificare dimensione e SHA-256. Aggiornare downloads/releases.json.
Aggiungere canonical, sitemap e dati strutturati coerenti con i testi.
Registrare le pagine in scripts/site-pages.json, con footer comune e ritorni
in alto/basso. La guida offline resta nel bundle; adattare solo la copia web.
Non aggiungere moduli commenti senza integrazione e test del backend.
Eseguire sync-page-navigation.cjs, sync-site-footer.cjs, test del sito,
workflow plugins-verified e audit locale; verificare desktop/mobile.
Dopo il deploy controllare audit live e hash dei download.
Il nome AutoCAD appartiene ad Autodesk; AG CAD Tools è un progetto indipendente.
Supporto: https://andreagiaquinto.it — WhatsApp +39 333 724 0544.
''',encoding='utf-8')
# Source package is self-contained and excludes stale current reports from RCs.
exclude={'CONSEGNA_GENERATA.json','VERIFICA_ARCHIVI_CONSEGNA.json','ANTEPRIMA_INSTALLER_2.0_RC2.png','ANTEPRIMA_INSTALLER_AG_CAD_Tools_2.0_RC3.png','ANTEPRIMA_INSTALLER_AG_CAD_Tools_2.0_RC4.png','ANTEPRIMA_INSTALLER_AG_CAD_Tools_2.0_RC5.png','ESITO_RELEASE_RC4.json','ESITO_RELEASE_RC5.json','MATRICE_COMPATIBILITA_RC4.json','MATRICE_COMPATIBILITA_RC5.json','INVENTARIO_COMPATIBILITA_RC4.json','ESITO_CONTINUITA_RC5.json','BASELINE_ESTERNE_INTEGRE.json','PRESERVAZIONE_RC2.json','LEGGIMI_RC5.txt'}
def zip_files(path,items):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sorted(items):
   zi=zipfile.ZipInfo(name,(2026,10,3,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o644<<16;z.writestr(zi,p.read_bytes())
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
rootdocs=[R/'REGISTRO_UI_2_0.json',manifest,mapfile,report,R/'LEGGIMI_AG_CAD_Tools_2.0.txt',R/'REGISTRO_COLLAUDI_AG_CAD_Tools_2.0.txt',publication,specpath]
entries=[]
for folder in ['baseline_core','baseline_rc2','baseline_rc4','baseline_rc5','sorgenti','tools','verifiche','sorgenti_ui','provenienza','installer_src']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.exe','.log'] and p.name not in exclude:entries.append((p.relative_to(R).as_posix(),p))
for p in B.rglob('*'):
 if p.is_file():entries.append((p.relative_to(R).as_posix(),p))
entries.extend((p.name,p) for p in rootdocs)
files=[]
for p in [setup,report,R/'LEGGIMI_AG_CAD_Tools_2.0.txt',R/'REGISTRO_COLLAUDI_AG_CAD_Tools_2.0.txt',specpath,mapfile,manifest,preview_file,publication]+[W/n for n in ['AG_CAD_Tools_Help.html','AG_CAD_Tools_Compatibilita.html','AG_CAD_Tools_Sostieni.html','LICENZE_TERZE_PARTI.txt']]:
 q=OUT/p.name;shutil.copyfile(p,q);files.append(q)
source=OUT/'AG_CAD_Tools_2.0_Sorgenti.zip';zip_files(source,entries)
portable=OUT/'AG_CAD_Tools_2.0_Portabile.zip';zip_files(portable,[(p.relative_to(B.parent).as_posix(),p) for p in B.rglob('*') if p.is_file()])
files.extend([source,portable]);checksum=OUT/'SHA256_AG_CAD_Tools_2.0.txt'
checksum.write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
delivery=OUT/'AG_CAD_Tools_2.0_Consegna.zip';zip_files(delivery,[(p.name,p) for p in files+[checksum]])
checksum.write_text(checksum.read_text()+sha(delivery)+'  '+delivery.name+'\n')
receipt={'stato':'PASS','sorgenti':len(entries),'payload':build['file_payload'],'file':[{'nome':p.name,'byte':p.stat().st_size,'sha256':sha(p)} for p in files+[delivery,checksum]]}
(V/'CONSEGNA_GENERATA.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2))
