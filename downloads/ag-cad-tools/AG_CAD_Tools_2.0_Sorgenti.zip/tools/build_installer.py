"""Compila il setup Win32 x64 ed esegue i gate Go, senza runtime per l'utente."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'release/AGCADTools.bundle';BUILD=ROOT/'installer_src'
GO=os.environ.get('CTI_GO','go');records=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,windows=False):
    env=os.environ.copy();env.setdefault('GOCACHE',str(ROOT/'cache-go'))
    if windows:env.update(GOOS='windows',GOARCH='amd64',CGO_ENABLED='0')
    r=subprocess.run([GO]+args,cwd=BUILD,env=env,text=True,capture_output=True)
    records.append({'comando':'go '+' '.join(args),'target':'windows/amd64' if windows else sys.platform,
                    'exit_code':r.returncode,'output':r.stdout+r.stderr})
    if r.returncode:raise RuntimeError(records[-1])
    print(records[-1]['comando']+': PASS',flush=True)
    return r.stdout.strip()
try:
    if (BUILD/'bundle').exists():shutil.rmtree(BUILD/'bundle')
    shutil.copytree(SOURCE,BUILD/'bundle')
    src={p.relative_to(SOURCE).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()}
    dst={p.relative_to(BUILD/'bundle').as_posix():digest(p) for p in (BUILD/'bundle').rglob('*') if p.is_file()}
    assert src==dst,'Payload incorporato non identico al bundle di consegna'
    version=run(['version'])
    run(['test','-v','./...']);run(['test','-race','./...']);run(['vet','./...']);run(['vet','./...'],True)
    output=ROOT/'release/AG_CAD_Tools_2.0_Setup.exe'
    run(['build','-buildvcs=false','-trimpath','-ldflags=-H=windowsgui -s -w -buildid=','-o',str(output),'.'],True)
    data=output.read_bytes();assert data[:2]==b'MZ'
    off=int.from_bytes(data[60:64],'little');assert data[off:off+4]==b'PE\0\0'
    assert int.from_bytes(data[off+4:off+6],'little')==0x8664
    assert int.from_bytes(data[off+24+68:off+24+70],'little')==2
    result={'stato':'PASS','toolchain':version,'target':'Windows x64 GUI','file':output.name,'sha256':digest(output),
            'dimensione':len(data),'file_payload':len(src),'verifiche':records,
            'limite':'Motore file testato su Linux; UI Win32 e AutoCAD non eseguiti.'}
except Exception as e:
    result={'stato':'FAIL','errore':str(e),'verifiche':records}
(ROOT/'verifiche/ESITO_BUILD_INSTALLER.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='verifiche'},ensure_ascii=False));sys.exit(result['stato']!='PASS')
