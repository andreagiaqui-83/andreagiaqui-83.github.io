"""Renaming rules: public identity changes, persistent DWG/registry schema does not."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'verifiche'))
from lisp_audit import parse,walk,Sym
OLD_PUBLIC=json.loads((ROOT/'baseline_rc2/REGISTRO_PUBBLICO.json').read_text())
COMMANDS={k[2:].upper():('AGCADTOOLS' if k=='c:cti' else 'AG_'+k[6:].upper()) for k in OLD_PUBLIC if k.startswith('c:cti')}
FILES={p.name:('ag_cad_tools.lsp' if p.name=='cad_tools_italiano.lsp' else p.name.replace('cti_','ag_',1)) for p in (ROOT/'baseline_rc2').glob('*.lsp')}
FILES.update({'cad_tools_italiano.dcl':'ag_cad_tools.dcl','CADToolsItaliano.cuix':'AGCADTools.cuix','CAD_Tools_Italiano_Help.html':'AG_CAD_Tools_Help.html','CAD_Tools_Italiano_Sostieni.html':'AG_CAD_Tools_Sostieni.html','CADToolsItaliano.bundle':'AGCADTools.bundle'})
PAT=re.compile(r'(?<![\w])('+ '|'.join(re.escape(x) for x in sorted(COMMANDS,key=len,reverse=True) if x!='CTI')+r')(?![\w])',re.I)
def command(c):return COMMANDS.get(c.upper(),c)
def name(s):return FILES.get(s,s.replace('CTI20_','AG20_'))
TIP_FIXES=json.loads((ROOT/"sorgenti/revisione_descrizioni.json").read_text())
def text(s):
    # Existing profile preferences are intentionally retained at their stable key.
    if s.startswith('HKEY_CURRENT_USER'):return s
    for a,b in sorted(FILES.items(),key=lambda x:len(x[0]),reverse=True):s=s.replace(a,b)
    s=PAT.sub(lambda m:command(m.group()),s)
    s=re.sub('CAD Tools Italiano','AG CAD Tools',s,flags=re.I)
    s=s.replace('CADToolsItaliano','AGCADTools').replace('CADTOOLSITALIANO','AGCADTOOLS')
    s=s.replace('CTI20_','AG20_').replace('cti_main','ag_main')
    s=s.replace('2.0 RC2','2.0').replace('RC2 indica','La versione 2.0 indica').replace('Diagnostica CAD Tools','Diagnostica AG CAD Tools')
    s=s.replace('Candidata al collaudo nativo.', 'Versione definitiva 2.0.').replace('Candidata al collaudo.', 'Versione definitiva.').replace('candidata 2.0', 'versione 2.0')
    for a,b in TIP_FIXES.items():s=s.replace(a,b)
    if s=='CTI':return 'AGCADTOOLS'
    s=s.replace('Digita CTI','Digita AGCADTOOLS').replace('digita CTI','digita AGCADTOOLS').replace('comandi CTI_','comandi AG_')
    s=re.sub(r'\bCTI\b','AG CAD Tools',s)
    return s

def all_nodes(n):
    yield n
    if isinstance(n.value,list):
        for child in n.value:yield from all_nodes(child)

def lisp(s):
    edits=[]
    for form in parse(s):
        for n in all_nodes(form):
            if isinstance(n.value,Sym):
                k=str(n.value)
                if k.startswith('c:') and k[2:].upper() in COMMANDS:edits.append((n.start,n.end,'c:'+command(k[2:])))
            elif type(n.value)==str:
                changed=text(n.value)
                if changed!=n.value:edits.append((n.start,n.end,json.dumps(changed,ensure_ascii=False)))
    for a,b,v in sorted(edits,reverse=True):s=s[:a]+v+s[b:]
    # Comments are not executed; update only the visible project name/version there.
    s='\n'.join(text(line) if line.lstrip().startswith(';') else line for line in s.split('\n'))
    return s

def ui(s):
    return text(s).replace('CTI_','AG_').replace('CTI20','AG20')
