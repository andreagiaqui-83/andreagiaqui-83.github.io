"""Anteprima dal modello Go effettivo. Pillow è richiesto solo per questa immagine."""
from pathlib import Path
import json,os,shutil,subprocess,tempfile
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];out=R/'verifiche';go=os.environ.get('CTI_GO','go')
with tempfile.TemporaryDirectory(prefix='cti-preview-') as d:
    d=Path(d);shutil.copyfile(R/'installer_src/ui_design.go',d/'ui_design.go')
    (d/'main.go').write_text('''package main
import("encoding/json";"os")
func main(){s:=installerView{Installed:true,InstalledVer:"2.0",Status:"Pronto per aggiornare il plugin",Target:`%APPDATA%\\Autodesk\\ApplicationPlugins\\AGCADTools.bundle`,AutoCAD:[]string{"AutoCAD 2027"}};bs:=installerButtons();ops:=installerScene(s);for _,b:=range bs {fill,border,ink:=buttonPalette(b.ID,false,false);ops=append(ops,sceneOp{Kind:"box",Box:b.Box,Fill:fill,Border:border,Radius:6},sceneOp{Kind:"text",Box:b.Box,Text:func()string{if b.ID==1001{return "Ripara"};return b.Label}(),Fill:ink,Font:"normal",Center:true})};json.NewEncoder(os.Stdout).Encode(ops)}''')
    env=os.environ.copy();env.setdefault('GOCACHE','/tmp/cti_go_cache')
    data=subprocess.check_output([go,'run','-buildvcs=false',str(d/'ui_design.go'),str(d/'main.go')],env=env,text=True)
ops=json.loads(data);(out/'ANTEPRIMA_MODELLO_INSTALLER.json').write_text(json.dumps(ops,ensure_ascii=False,indent=2)+'\n')
scale=2;im=Image.new('RGB',(920*scale,600*scale));draw=ImageDraw.Draw(im)
fontroot=Path('/usr/share/fonts/truetype/dejavu')
sizes={'small':14,'normal':16,'section':18,'title':30,'logo':24,'brand':34}
fonts={k:ImageFont.truetype(str(fontroot/('DejaVuSans-Bold.ttf' if k in ['section','title','logo','brand'] else 'DejaVuSans.ttf')),v*scale) for k,v in sizes.items()}
color=lambda c: '#%06x'%c
for o in ops:
    x1,y1,x2,y2=[v*scale for v in o['Box']]
    if o['Kind']=='box':
        if o['Radius']:draw.rounded_rectangle((x1,y1,x2-1,y2-1),o['Radius']*scale,fill=color(o['Fill']),outline=color(o['Border']),width=scale)
        else:draw.rectangle((x1,y1,x2,y2),fill=color(o['Fill']))
        continue
    font=fonts[o['Font']];text=o['Text'];width=x2-x1
    if o['Wrap']:
        lines=[]
        for para in text.split('\n'):
            line=''
            for word in para.split(' '):
                candidate=(line+' '+word).strip()
                if line and draw.textlength(candidate,font=font)>width:lines.append(line);line=word
                else:line=candidate
            lines.append(line)
        lh=int(sizes[o['Font']]*1.22*scale)
        for i,line in enumerate(lines):
            if y1+(i+1)*lh>y2:raise RuntimeError('Testo fuori scheda: '+text)
            draw.text((x1,y1+i*lh),line,font=font,fill=color(o['Fill']),anchor='lt')
    else:
        if draw.textlength(text,font=font)>width:
            print('Font sostitutivo: ellissi per',text)
            while text and draw.textlength(text+'…',font=font)>width:text=text[:-1]
            text+='…'
        x=(x1+x2)/2 if o['Center'] else x1
        draw.text((x,(y1+y2)/2),text,font=font,fill=color(o['Fill']),anchor='mm' if o['Center'] else 'lm')
im.save(out/'ANTEPRIMA_INSTALLER_AG_CAD_Tools_2.0.png')
print('Anteprima salvata; font sostitutivo DejaVu Sans. Non è uno screenshot Windows.')
