"""Integra la candidata 2.0 RC2 dalle baseline congelate, senza modificarle."""
from pathlib import Path
import csv, hashlib, json, re, shutil, sys, zipfile
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'verifiche'))
from lisp_audit import parse,definitions,head,walk,Sym
B=ROOT/'build_intermedio/CADToolsItaliano.bundle'; W=B/'Contents/Win64'; S=ROOT/'sorgenti'
W.mkdir(parents=True,exist_ok=True)
shutil.copyfile(S/'sostieni_base.html',W/'CAD_Tools_Italiano_Sostieni.html')
REG=json.loads((ROOT/'provenienza/REGISTRO_UI_FASE3.json').read_text())
CORE={r['command'] for r in REG if r['origin']=='Core 1.9'}
changes=[]
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def once(s,a,b,label):
    if s.count(a)!=1:raise AssertionError((label,s.count(a),a[:100]))
    changes.append(label);return s.replace(a,b,1)
def edit_nodes(s,edits):
    last=len(s)
    for a,b,t in sorted(edits,reverse=True):
        assert b<=last,(a,b,last)
        s=s[:a]+t+s[b:];last=a
    return s
def replace_defs(s,replacements):
    ds=definitions(parse(s));edits=[]
    for name,body in replacements.items():
        if name in ds:
            n=ds[name];edits.append((n.start,n.end,body))
    return edit_nodes(s,edits)

# Un'unica definizione del runtime, prima di tutti i moduli.
runtime=(S/'runtime_base.lsp').read_text()
runtime=runtime.replace('; Runtime comune Web 2.0, Fase 2D. Nessuna modifica al core golden.',
                        '; Runtime comune CAD Tools Italiano 2.0 RC2: core, Web e personali.')
runtime=once(runtime,'(setq *CTI2-NOME* nome)','(setq *CTI2-NOME* nome *CTI2-ATTIVO* T)','Frame runtime attivo')
runtime=once(runtime,'*CTI2-FILE-APERTI* *CTI2-TEMPORANEI* *CTI2-ESPORTAZIONI* *CTI2-AVVISI*)',
    '*CTI2-FILE-APERTI* *CTI2-TEMPORANEI* *CTI2-ESPORTAZIONI* *CTI2-AVVISI*\n    *CTI2-FILE-CORE* *CTI2-ATTIVO* *CTI2-AZIONE-DOPO* *CTI2-TEMPORANEI-PASSATI*)',
    'Risorse core e azione differita locali al wrapper')
runtime=once(runtime,'(if (findfile item)\n          (if (not (vl-file-delete item))',
    '(if (and (not (and riuscito (member item *CTI2-TEMPORANEI-PASSATI*))) (findfile item))\n          (if (not (vl-file-delete item))',
    'Proprietà dello script trasferita dopo il cleanup')
ds=definitions(parse(runtime));n=ds['cti2:esegui-comando'];body=runtime[n.start:n.end]
assert body.endswith('(princ))')
body=body[:-len('(princ))')]+'(if (and (not (vl-catch-all-error-p r)) *CTI2-AZIONE-DOPO*)\n    *CTI2-AZIONE-DOPO*\n    (princ)))'
runtime=runtime[:n.start]+body+runtime[n.end:]
runtime+='\n'+(S/'runtime_estensioni.lsp').read_text()+'\n(setq *CTI2-RUNTIME-OK* T)\n(princ)\n'
write(W/'cti_runtime_2_0.lsp',runtime)

replacement_source=(S/'core_sostituzioni.lsp').read_text()
replacements={k:replacement_source[n.start:n.end] for k,n in definitions(parse(replacement_source)).items()}
used=set();wrapper_map={}
for p in sorted((ROOT/'baseline_core').glob('*.lsp')):
    if 'community' in p.name:continue
    s=p.read_text(encoding='utf-8-sig')
    if p.name=='cad_tools_italiano.lsp':
        s=once(s,'(repeat n (setq count (+ count (cti:copy-ss-vector ss (cti:vscale u (* step i)))) i (1+ i)))))))',
            '(repeat n (setq count (+ count (cti:copy-ss-vector ss (cti:vscale u (* step i)))) i (1+ i))))))))',
            'Chiude il ramo Misura di COPIAMULTIPLA e ripristina le definizioni al livello principale')
        s=once(s,'(princ "\\nNessuna polilinea disponibile dopo la selezione/conversione."))))',
            '(princ "\\nNessuna polilinea disponibile dopo la selezione/conversione.")))',
            'Elimina la chiusura estranea a MODIFICAPOLILINEE')
        s=s.replace('(setq *CTI-VERSION* "1.9")','(setq *CTI-VERSION* "2.0 RC2")')
        s=s.replace('(setq *CTI-COMMUNITY-COUNT* 12)','(setq *CTI-COMMUNITY-COUNT* 100)')
        s=once(s,'(setq path (findfile filename))',
            '(setq path (findfile (strcat *CTI2-DIRECTORY* filename)))','Moduli core caricati dalla stessa cartella del bootstrap')
        s=once(s,'(defun c:CTI_DIAGNOSTICA (/ w)','(defun cti:diagnostica-storica (/ w)','Diagnostica storica privata')
        s=once(s,'(defun cti:cancel-p (msg / u)\n  (setq u (strcase (vl-princ-to-string msg)))\n  (or (wcmatch u "*CANCEL*") (wcmatch u "*ANNULLAT*") (wcmatch u "*QUIT*") (wcmatch u "*EXIT ABORT*")))',
            '(defun cti:cancel-p (msg) (cti2:annullamento-p msg))','Riconoscimento preciso di ESC nel core')
    # Corregge LAST usato come in Common Lisp: in AutoLISP restituisce già l'elemento.
    for var in ('pts','out'):
        old=f'(car (last {var}))'
        if old in s:
            changes.append(f'{p.name}: LAST {var} restituisce il punto');s=s.replace(old,f'(last {var})')
    ds=definitions(parse(s)); used.update(set(ds)&set(replacements))
    s=replace_defs(s,replacements)
    # TYPE produce simboli: EQ è il confronto previsto, anche con registro vuoto.
    s=s.replace('(= (type ', '(eq (type ')
    if '(or (= r T) (= r 1) (= r "1"))' in s:
        s=s.replace('(or (= r T) (= r 1) (= r "1"))','(or (eq r T) (equal r 1) (equal r "1"))')
        changes.append('LOGDISEGNO: valori del registro booleani, numerici, stringa o assenti')
    edits=[]
    for name,n in definitions(parse(s)).items():
        for x in walk(n):
            h=head(x)
            if h in ('open','close','setvar','vl-filename-mktemp','entmakex'):
                nh={'open':'cti2:apri-core','close':'cti2:chiudi-core',
                    'setvar':'cti2:setvar-temporanea','vl-filename-mktemp':'cti2:file-temporaneo',
                    'entmakex':'cti2:crea-entita'}[h]
                if h=='setvar' and x.value[1].value in ('IMAGEFRAME','WIPEOUTFRAME'):nh='cti2:setvar-finale'
                edits.append((x.value[0].start,x.value[0].end,nh))
    s=edit_nodes(s,edits)
    # Le copie ausiliarie esistenti sono registrate prima di operazioni fallibili.
    if p.name=='cad_tools_italiano.lsp':
        for expr in ['(vla-Copy (vlax-ename->vla-object e))','(vla-Copy pat)','(vla-Copy o)']:
            if expr in s:s=s.replace(expr,f'(cti2:oggetto-provvisorio {expr})')
        s=once(s,'(setq objs (cti:variant-list r) ss (ssadd))',
            '(setq objs (cti2:oggetti-provvisori (cti:variant-list r)) ss (ssadd))','Geometria limite temporanea del blocco protetta')
        s=once(s,'(setq objs (cti:variant-list ex)\n                doc',
            '(setq objs (cti2:oggetti-provvisori (cti:variant-list ex))\n                doc','Geometria provvisoria SHAPE protetta')
        # Il poligono di ritaglio viene sempre eliminato, anche in errore.
        ds=definitions(parse(s));n=ds['cti:temp-poly'];old=s[n.start:n.end]
        new=old.replace('(cti2:crea-entita data)','(cti2:entita-provvisoria (cti2:crea-entita data))')
        s=s[:n.start]+new+s[n.end:]
        # Blocco WMF importato: ausiliario, mentre la geometria finale resta annullabile.
        s=once(s,'(cti:fit-object-bbox (vlax-ename->vla-object br) bb)',
            '(cti2:oggetto-provvisorio (vlax-ename->vla-object br))\n                  (cti:fit-object-bbox (vlax-ename->vla-object br) bb)',
            'Inserimento WMF ausiliario protetto')
        n=definitions(parse(s))['c:cti'];s=s[:n.start]+'''(defun c:CTI ()
  (cti2:esegui-differita (cti2:esegui-comando "CTI" 'cti:launcher-core)))'''+s[n.end:]
        # Il solo bootstrap annuncia lo stato complessivo dopo l'ultimo modulo.
        marker='(princ (strcat "\\nCAD Tools Italiano " *CTI-VERSION* " caricato.'
        pos=s.index(marker);s=s[:pos]+'(princ)\n'
    if p.name=='cti_05c_textmask.lsp':
        s=once(s,'(setq pl (entlast))','(setq pl (cti2:entita-provvisoria (entlast)))','Polilinea ausiliaria WIPEOUT protetta')
    # Tutti i 93 pubblici passano direttamente dal medesimo wrapper.
    edits=[]
    for name,n in definitions(parse(s)).items():
        cmd=name[2:].upper() if name.startswith('c:') else ''
        if cmd not in CORE and cmd!='CTI_SOSTIENI':continue
        b=n.value[3:];private=None
        if len(b)==1 and head(b[0])=='cti:run':
            target=s[b[0].value[1].start:b[0].value[1].end]
        elif cmd=='CTI_SELEZIONERAPIDA':target="'cti:selezionecontatto-core"
        elif cmd=='CTI_CHIUDIVELOCE':target="'cti:chiudiveloce-core"
        elif len(b)==1 and len(b[0].value)==1:
            target="'"+str(head(b[0]))
        else:
            private='cti2:core-'+cmd.lower()[4:]
            original=s[n.start:n.end]
            original=original[:n.value[1].start-n.start]+private+original[n.value[1].end-n.start:]
            target="'"+private
        call=f'(cti2:esegui-comando "{cmd}" {target})'
        if cmd in ('CTI_CHIUDIVELOCE','CTI_RIPRISTINADISEGNO'):call=f'(cti2:esegui-differita {call})'
        new=(original+'\n' if private else '')+f'(defun c:{cmd} () {call})'
        edits.append((n.start,n.end,new));wrapper_map[cmd]=target
    s=edit_nodes(s,edits)
    if p.name=='cad_tools_italiano.lsp':
        # Funzioni ausiliarie aggiuntive prima delle inizializzazioni finali.
        extras=['cti:chiudiveloce-core','cti:launcher-core','cti:launcher-voce','cti:launcher-categoria','cti:dwglog-write-risorse']
        at=s.index('; Tutte le definizioni pubbliche')
        s=s[:at]+'\n\n'.join(replacements[x] for x in extras)+'\n\n'+s[at:]
    if p.name=='cti_05d1_rtext_base.lsp':s+='\n'+replacements['cti:rtext-read-risorse']+'\n'
    write(W/p.name,s)
assert CORE<=set(wrapper_map),(CORE-set(wrapper_map))

web=(S/'web_fase2d.lsp').read_text();base=(S/'runtime_base.lsp').read_text()
assert base in web
web=web.replace(base,'; Runtime comune caricato dal bootstrap.\n',1)
web=web.replace('; CAD Tools Italiano 2.0 - checkpoint Fase 2D','; CAD Tools Italiano 2.0 RC2 - 100 strumenti Web MIT')
web=web.replace('; 100 strumenti Web MIT, 12 alias storici. NON INSTALLARE al posto della golden 1.9.',
                '; 100 strumenti Web MIT, 12 alias storici; consolidato Fase 2D.')
web=web.replace('LEGGIMI_FASE2D.txt e MANIFEST_100_WEB_FASE2D.csv.','LICENZE_TERZE_PARTI.txt e MANIFEST_100_WEB_FASE2D.csv.')
write(W/'cti_web_2_0.lsp',web)
personal=(S/'cti_andrea_2_0.lsp').read_text().replace('2.0 - Fase 3','2.0 RC2').replace('del modulo Web Fase 2D','caricato dal bootstrap').replace('2.0-fase3','2.0 RC2')
write(W/'cti_andrea_2_0.lsp',personal)
for r in REG:
    if r['command']=='CTI_DIAGNOSTICA_2_0':
        r.update(command='CTI_DIAGNOSTICA',name='Diagnostica CAD Tools',
                 tip='Verifica moduli, comandi registrati, alias e risorse della versione installata.')
    if r['origin']=='Core 1.9':r['origin']='Core'
catalog=(S/'cti_catalogo_2_0.lsp').read_text().replace('Catalogo Fase 3','Catalogo 2.0 RC2').replace('CTI_DIAGNOSTICA_2_0','CTI_DIAGNOSTICA').replace('Diagnostica sviluppo 2.0','Diagnostica CAD Tools')
write(W/'cti_catalogo_2_0.lsp',catalog)
write(W/'cad_tools_italiano.dcl',(S/'cad_tools_italiano.dcl').read_text())
old=W/'cti_community_1_9.lsp'
if old.exists():old.unlink()

# UI 200 voci, stesso gruppo e identificatori delle macro, immagini identiche a Fase 3.
ui=ROOT/'sorgenti_ui/cuix_src'
for p in ui.glob('*.cui'):
    s=p.read_text(encoding='utf-8-sig').replace('CTI_DIAGNOSTICA_2_0','CTI_DIAGNOSTICA')
    s=s.replace('Diagnostica sviluppo 2.0','Diagnostica CAD Tools')
    s=s.replace('Mostra lo stato dei moduli del checkpoint e gli obblighi di integrazione ancora aperti.',
                'Verifica moduli, comandi registrati, alias e risorse della versione installata.')
    write(p,s)
with zipfile.ZipFile(W/'CADToolsItaliano.cuix','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(ui.rglob('*')):
        if p.is_file():
            info=zipfile.ZipInfo(p.relative_to(ui).as_posix(),(2026,10,3,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,p.read_bytes())
for p in ui.glob('*.png'):shutil.copy2(p,W/p.name)

# Elenco pubblico estratto dalle definizioni reali, non dai conteggi delle macro.
public={}
for p in sorted(W.glob('*.lsp')):
    if p.name in ('cti_bootstrap_2_0.lsp','cti_diagnostica_2_0.lsp'):continue
    for name,n in definitions(parse(p.read_text(encoding='utf-8-sig'))).items():
        if name.startswith('c:'):
            assert name not in public,(name,p.name,public.get(name));public[name]=p.name
public.update({'c:cti_diagnostica':'cti_diagnostica_2_0.lsp','c:cti_diagnostica_2_0':'cti_diagnostica_2_0.lsp'})
commands=sorted(k[2:].upper() for k in public)
functional=sorted(r['command'] for r in REG if r['origin']!='Servizio')
assert len(set(functional))==198
assert set(functional)<=set(commands)
write(ROOT/'REGISTRO_UI_2_0.json',json.dumps(REG,ensure_ascii=False,indent=2)+'\n')
write(ROOT/'verifiche/MAPPA_CORE.json',json.dumps(wrapper_map,ensure_ascii=False,indent=2)+'\n')
write(ROOT/'verifiche/REGISTRO_PUBBLICO.json',json.dumps(public,ensure_ascii=False,indent=2)+'\n')
write(ROOT/'verifiche/MODIFICHE_CORE.json',json.dumps(changes,ensure_ascii=False,indent=2)+'\n')

diag=(S/'diagnostica.lsp').read_text()
prefix='(setq *CTI2-COMANDI-FUNZIONALI* \''+'('+ ' '.join('"'+c+'"' for c in functional)+'))\n'
prefix+='(setq *CTI2-COMANDI-PUBBLICI* \''+'('+ ' '.join('"'+c+'"' for c in commands)+'))\n'
write(W/'cti_diagnostica_2_0.lsp',prefix+diag)
write(W/'cti_bootstrap_2_0.lsp',(S/'bootstrap.lsp').read_text())

package=ET.parse(ROOT/'baseline_core/PackageContents.xml').getroot()
package.set('AppVersion','2.0.0.2');package.set('ProductCode','{699E8461-20C0-4F30-9E90-04F174CD7712}')
package.set('Description','CAD Tools Italiano 2.0 RC2 - 198 strumenti in italiano. Candidata al collaudo.')
components=package.find('Components')
for entry in list(components.findall('ComponentEntry')):
    if entry.get('ModuleName','').lower().endswith('.lsp'):components.remove(entry)
entry=ET.SubElement(components,'ComponentEntry',AppName='CADToolsItaliano',AppDescription='198 strumenti CAD Tools Italiano',
    ModuleName='./Contents/Win64/cti_bootstrap_2_0.lsp',PerDocument='True',LoadReasons='LoadOnCommandInvocation')
cs=ET.SubElement(entry,'Commands',GroupName='CADTOOLSITALIANO')
for c in commands:ET.SubElement(cs,'Command',Global=c,Local=c)
ET.indent(package,space='  ');ET.ElementTree(package).write(B/'PackageContents.xml',encoding='utf-8',xml_declaration=True)

shutil.copy2(ROOT/'provenienza/TERZE_PARTI.txt',W/'LICENZE_TERZE_PARTI.txt')
shutil.copy2(ROOT/'provenienza/MANIFEST_100_WEB_FASE2D.csv',W/'MANIFEST_100_WEB_FASE2D.csv')
print('Ricostruita base RC2 per confronto e trasformazione AG.')
