;;; ---------------------------------------------------------------------
;;;  GAPCHECK-bgol.lsp
;;;  Command:  GAPC
;;;
;;;  PURPOSE
;;;  Checks each selected LWPOLYLINE's actual Closed flag (DXF group 70,
;;;  bit 1) rather than just its visual appearance, and flags every
;;;  polyline that is open even though its first and last points may
;;;  visually coincide. Marks the gap location with a circle so "fake
;;;  closed" polygons are easy to find before GIS/Land Records export.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   GAPC   at the command line and press Enter.
;;;    3. Select the polylines to check.
;;;    4. Every polyline found to be open (Closed flag = 0) is marked
;;;       with a circle at its start point, on layer "BGOL-GAPC".
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of open-polygon detection
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-gapc-radius* 1.5)

(defun BGOL:GAPC-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:GAPC-MakeMarker (pt radius lname / dxfdata)
  (setq dxfdata (list '(0 . "CIRCLE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbCircle")
                       (cons 10 pt)
                       (cons 40 radius)
                 )
  )
  (entmakex dxfdata)
)

(defun C:GAPC ( / ss n i ename edata closed obj pt flagged)
  (BGOL:GAPC-EnsureLayer "BGOL-GAPC")
  (princ "\nSelect polylines to check for open (not truly closed) polygons: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq flagged 0)
      (setq i 0)
      (while (< i n)
        (setq ename (ssname ss i))
        (setq edata (entget ename))
        (setq closed (= 1 (logand 1 (cdr (assoc 70 edata)))))
        (if (not closed)
          (progn
            (setq obj (vlax-ename->vla-object ename))
            (setq pt (vlax-curve-getStartPoint obj))
            (if pt
              (progn
                (BGOL:GAPC-MakeMarker pt *bgol-gapc-radius* "BGOL-GAPC")
                (setq flagged (1+ flagged))
              )
            )
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nGAPC: " (itoa flagged) " of " (itoa n)
                      " selected polyline(s) found open (marked on layer BGOL-GAPC)."))
    )
    (princ "\nNo polylines selected.")
  )
  (princ)
)

(princ "\nGAPCHECK-bgol.lsp loaded. Type GAPC to find and mark open (not truly closed) polylines.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
