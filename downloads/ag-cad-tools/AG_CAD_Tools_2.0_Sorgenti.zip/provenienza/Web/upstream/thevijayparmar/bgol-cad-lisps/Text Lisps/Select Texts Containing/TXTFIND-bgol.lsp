;;; ---------------------------------------------------------------------
;;;  TXTFIND-bgol.lsp
;;;  Command:  SLTC
;;;
;;;  PURPOSE
;;;  Pattern-based text search & select: finds every TEXT entity in
;;;  the drawing whose string starts with, ends with, or contains a
;;;  user-supplied substring, and leaves the matches selected for
;;;  further batch editing. Fills the gap left by AutoCAD's basic
;;;  Find/Replace, which lacks this kind of pattern-based selection.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   SLTC   at the command line and press Enter.
;;;    3. Enter the search text/substring.
;;;    4. Choose the match mode: Starts-with / Ends-with / Contains.
;;;    5. Every TEXT entity matching the chosen pattern is selected
;;;       and grip-highlighted, ready for further editing.
;;;
;;;  NOTES
;;;    - Matching is case-sensitive, using AutoLISP's native wcmatch
;;;      wildcard function.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of pattern-based text
;;;      search utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and
;;;      are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:TXTFIND-ListToSS (elist / ss e)
  (setq ss (ssadd))
  (foreach e elist (setq ss (ssadd e ss)))
  ss
)

(defun C:SLTC ( / pattern mode alltext n i ent edata val ok result cnt wc)
  (setq pattern (getstring T "\nEnter search text: "))
  (if (and pattern (> (strlen pattern) 0))
    (progn
      (initget "Starts Ends Contains")
      (setq mode (getkword "\nMatch mode [Starts/Ends/Contains] <Contains>: "))
      (if (not mode) (setq mode "Contains"))
      (cond
        ((= mode "Starts")   (setq wc (strcat pattern "*")))
        ((= mode "Ends")     (setq wc (strcat "*" pattern)))
        (t                   (setq wc (strcat "*" pattern "*")))
      )
      (setq alltext (ssget "_X" '((0 . "TEXT"))))
      (if alltext
        (progn
          (setq n (sslength alltext))
          (setq result '())
          (setq i 0)
          (while (< i n)
            (setq ent (ssname alltext i))
            (setq edata (entget ent))
            (setq val (cdr (assoc 1 edata)))
            (if (and val (wcmatch val wc))
              (setq result (append result (list ent)))
            )
            (setq i (1+ i))
          )
          (setq cnt (length result))
          (if (> cnt 0)
            (progn
              (sssetfirst nil (BGOL:TXTFIND-ListToSS result))
              (princ (strcat "\nSLTC: " (itoa cnt) " text entity(ies) matched \"" pattern "\" (" mode ")."))
            )
            (princ (strcat "\nSLTC: no text entities matched \"" pattern "\"."))
          )
        )
        (princ "\nNo TEXT entities found in the drawing.")
      )
    )
    (princ "\nNo search text entered.")
  )
  (princ)
)

(princ "\nTXTFIND-bgol.lsp loaded. Type SLTC to select text by starts-with/ends-with/contains pattern.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
