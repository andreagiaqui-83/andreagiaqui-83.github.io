;;; ---------------------------------------------------------------------
;;;  ROTBLKS-bgol.lsp
;;;  Command:  RMBA
;;;
;;;  PURPOSE
;;;  Rotates multiple selected block references simultaneously to a
;;;  single angle derived from two user-picked reference points, instead
;;;  of requiring the user to know or type an exact angle value, and
;;;  instead of rotating each block one at a time.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   RMBA   at the command line and press Enter.
;;;    3. Select the block(s) to rotate, then press Enter.
;;;    4. Pick a first reference point, then a second reference point.
;;;       The angle between them becomes the new rotation angle.
;;;    5. Every selected block is instantly rotated (about its own
;;;       insertion point) to that angle. A short direction indicator is
;;;       drawn on layer "BGOL-RMBA" for visual confirmation.
;;;
;;;  NOTES
;;;    - Rotation is applied via the VLA Rotation property (radians),
;;;      which rotates each block about its own insertion point.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of two-point-angle batch
;;;      block rotation common in survey/drafting alignment workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:RMBA-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:RMBA-DrawIndicator (p1 p2 lname / )
  (entmake (list '(0 . "LINE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbLine")
                 (cons 10 p1)
                 (cons 11 p2)))
)

(defun C:RMBA ( / ss n i ent obj p1 p2 ang lname cnt)
  (setq lname "BGOL-RMBA")
  (BGOL:RMBA-EnsureLayer lname)
  (setq ss (ssget '((0 . "INSERT"))))
  (if ss
    (progn
      (setq p1 (getpoint "\nFirst reference point: "))
      (setq p2 (getpoint p1 "\nSecond reference point: "))
      (if (and p1 p2)
        (progn
          (setq ang (angle p1 p2))
          (BGOL:RMBA-DrawIndicator p1 p2 lname)
          (setq n (sslength ss))
          (setq i 0)
          (setq cnt 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq obj (vlax-ename->vla-object ent))
            (vlax-put obj 'Rotation ang)
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          (princ (strcat "\n" (itoa cnt) " block(s) rotated to "
                          (rtos (/ (* ang 180.0) pi) 2 2)
                          " degrees (BGOL-RMBA)."))
        )
        (princ "\nRotation cancelled - two points required.")
      )
    )
    (princ "\nNo blocks selected.")
  )
  (princ)
)

(princ "\nROTBLKS-bgol.lsp loaded. Type RMBA to rotate multiple blocks to a two-point angle.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
