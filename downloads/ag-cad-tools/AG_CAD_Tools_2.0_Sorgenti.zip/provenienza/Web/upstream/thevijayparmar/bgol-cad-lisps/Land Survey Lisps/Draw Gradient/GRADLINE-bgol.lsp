;;; ---------------------------------------------------------------------
;;;  GRADLINE-bgol.lsp
;;;  Command:  GRDL
;;;
;;;  PURPOSE
;;;  Draws a formation/design line segment-by-segment on a longitudinal
;;;  section (profile) drawing directly from an entered gradient value,
;;;  correctly accounting for the profile's distorted horizontal and
;;;  vertical scales. Lets the user chain multiple gradient segments in
;;;  one command run, each new segment starting where the last ended.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   GRDL   at the command line and press Enter.
;;;    3. Pick a start point on the profile (e.g. on the ground line).
;;;    4. Enter the profile's Horizontal Scale and Vertical Scale
;;;       factors (Enter to keep the previous values).
;;;    5. For each segment: enter the real-world chainage length and the
;;;       gradient (e.g. 1/50 for 1 in 50 falling, or -50 for the same
;;;       expressed as a ratio denominator with sign). Press Enter with
;;;       no length to finish.
;;;    6. Each computed segment is drawn as a line on layer "BGOL-GRDL";
;;;       the new endpoint becomes the next segment's start point.
;;;
;;;  NOTES
;;;    - Gradient convention: enter gradient as "1 in N" using just the
;;;      N value, with sign indicating rise (+) or fall (-); e.g. -50
;;;      means falling at 1 in 50.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of scale-aware gradient
;;;      line drafting utilities common in civil/survey profile
;;;      drawings, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:GRDL-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:GRDL-MakeLine (p1 p2 lname / )
  (entmake (list '(0 . "LINE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbLine")
                 (cons 10 p1)
                 (cons 11 p2)))
)

(defun C:GRDL ( / hs vs p1 p2 chlen gradN drawDx drawDy rise cont)
  (BGOL:GRDL-EnsureLayer "BGOL-GRDL")
  (setq p1 (getpoint "\nStart point on profile: "))
  (if p1
    (progn
      (if (not *bgol-grdl-hs*) (setq *bgol-grdl-hs* 100.0))
      (if (not *bgol-grdl-vs*) (setq *bgol-grdl-vs* 10.0))
      (setq hs (getreal (strcat "\nHorizontal scale <" (rtos *bgol-grdl-hs* 2 2) ">: ")))
      (if hs (setq *bgol-grdl-hs* hs))
      (setq hs *bgol-grdl-hs*)
      (setq vs (getreal (strcat "\nVertical scale <" (rtos *bgol-grdl-vs* 2 2) ">: ")))
      (if vs (setq *bgol-grdl-vs* vs))
      (setq vs *bgol-grdl-vs*)
      (setq cont T)
      (while cont
        (setq chlen (getreal "\nChainage length for this segment (Enter to finish): "))
        (if (not chlen)
          (setq cont nil)
          (progn
            (setq gradN (getreal "\nGradient as 1 in N (enter N, negative = falling): "))
            (if (not gradN) (setq gradN 1.0))
            (setq rise (if (zerop gradN) 0.0 (/ chlen gradN)))
            (setq drawDx (/ chlen hs))
            (setq drawDy (/ rise vs))
            (setq p2 (list (+ (car p1) drawDx) (+ (cadr p1) drawDy) 0.0))
            (BGOL:GRDL-MakeLine p1 p2 "BGOL-GRDL")
            (princ (strcat "\nSegment drawn: chainage " (rtos chlen 2 2)
                            "  gradient 1 in " (rtos gradN 2 2)
                            "  rise " (rtos rise 2 3)))
            (setq p1 p2)
          )
        )
      )
      (princ "\nGRDL: gradient line construction finished.")
    )
    (princ "\nNo start point given.")
  )
  (princ)
)

(princ "\nGRADLINE-bgol.lsp loaded. Type GRDL to draw a scale-aware gradient formation line.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
