;;; ---------------------------------------------------------------------
;;;  MULTIAREA-bgol.lsp
;;;  Command:  MAAR
;;;
;;;  PURPOSE
;;;  Selects multiple closed polylines at once, labels each one at its
;;;  approximate centroid with its own individual area, and reports the
;;;  combined total area of all selected objects together. Eliminates
;;;  the tedious add/subtract toggling of AutoCAD's native AREA command
;;;  when totaling many polygons.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   MAAR   at the command line and press Enter.
;;;    3. Select all the closed polylines/polygons to total.
;;;    4. Each polygon is labeled at its centroid with its own area, on
;;;       layer "BGOL-MAAR", and the combined total is printed to the
;;;       command line.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of multi-object area
;;;      auditing utilities common in land-survey drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:MAAR-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:MAAR-Text (pt txt ht lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 txt)))
)

(defun BGOL:MAAR-Centroid (obj / n i vlist pt sumx sumy)
  (setq sumx 0.0 sumy 0.0 n 0 i 0)
  (while (setq pt (vl-catch-all-apply 'vlax-curve-getPointAtParam (list obj (float i))))
    (if (not (vl-catch-all-error-p pt))
      (progn
        (setq sumx (+ sumx (car pt)))
        (setq sumy (+ sumy (cadr pt)))
        (setq n (1+ n))
      )
    )
    (setq i (1+ i))
    (if (> i 200) (setq pt nil))
  )
  (if (> n 0)
    (list (/ sumx n) (/ sumy n) 0.0)
    (list 0.0 0.0 0.0)
  )
)

(defun C:MAAR ( / ss n i ent obj area total cen)
  (BGOL:MAAR-EnsureLayer "BGOL-MAAR")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq total 0.0)
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq area (vlax-curve-getArea obj))
        (setq cen (BGOL:MAAR-Centroid obj))
        (BGOL:MAAR-Text cen (rtos area 2 3) 2.5 "BGOL-MAAR")
        (setq total (+ total area))
        (setq i (1+ i))
      )
      (princ (strcat "\nTotal of Selected Objects...: " (rtos total 2 3)))
    )
    (princ "\nNo closed polylines selected.")
  )
  (princ)
)

(princ "\nMULTIAREA-bgol.lsp loaded. Type MAAR to label and total the area of multiple polygons.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
