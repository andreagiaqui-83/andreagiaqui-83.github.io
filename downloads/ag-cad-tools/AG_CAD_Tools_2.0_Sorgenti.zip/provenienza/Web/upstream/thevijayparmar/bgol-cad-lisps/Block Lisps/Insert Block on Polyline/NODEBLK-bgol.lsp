;;; ---------------------------------------------------------------------
;;;  NODEBLK-bgol.lsp
;;;  Command:  IBNP
;;;
;;;  PURPOSE
;;;  Inserts a chosen block at the endpoints, intersections, or both, of
;;;  a set of selected lines/polylines. Useful for marking junction /
;;;  node points in drainage, road, or pipeline network drawings.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   IBNP   at the command line and press Enter.
;;;    3. Choose a mode: [Intersections/Endpoints/Both] <Both>.
;;;    4. Select the lines/polylines to process, then press Enter.
;;;    5. Type the name of the block to insert.
;;;    6. The routine finds the relevant junction points (per the chosen
;;;       mode) and inserts a copy of the block at each, on layer
;;;       "BGOL-IBNP". Coincident points are only marked once.
;;;
;;;  NOTES
;;;    - Intersections are computed pairwise between all selected
;;;      entities using vlax-invoke's IntersectWith (acExtendNone).
;;;    - Endpoints are read via vlax-curve-getStartPoint / EndPoint,
;;;      which works for LINE, LWPOLYLINE and ARC alike.
;;;    - Block scale and rotation default to 1/1/0; edit
;;;      *bgol-ibnp-scale* and *bgol-ibnp-rot* below to change defaults.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of automatic junction/node
;;;      marking common in utility and drainage network drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-ibnp-scale* 1.0)
(setq *bgol-ibnp-rot* 0.0)
(setq *bgol-ibnp-tol* 0.001)

(defun BGOL:IBNP-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:IBNP-InsertBlock (blkname pt lname scl rot / )
  (entmake (list '(0 . "INSERT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbBlockReference")
                 (cons 2 blkname)
                 (cons 10 pt)
                 (cons 41 scl)
                 (cons 42 scl)
                 (cons 43 scl)
                 (cons 50 rot)))
)

(defun BGOL:IBNP-PointExists (pt ptlist / found p)
  (setq found nil)
  (foreach p ptlist
    (if (< (distance pt p) *bgol-ibnp-tol*)
      (setq found T)
    )
  )
  found
)

(defun BGOL:IBNP-AddPoint (pt ptlist)
  (if (BGOL:IBNP-PointExists pt ptlist)
    ptlist
    (append ptlist (list pt))
  )
)

(defun C:IBNP ( / mode ss n objs i j obj1 obj2 pts sp ep interlist ip
                  blkname lname cnt pt)
  (setq lname "BGOL-IBNP")
  (BGOL:IBNP-EnsureLayer lname)
  (initget "Intersections Endpoints Both")
  (setq mode (getkword "\nMark [Intersections/Endpoints/Both] <Both>: "))
  (if (not mode) (setq mode "Both"))
  (setq ss (ssget '((-4 . "<OR") (0 . "LINE") (0 . "LWPOLYLINE") (0 . "ARC") (-4 . "OR>"))))
  (if ss
    (progn
      (setq blkname (getstring T "\nBlock name to insert at each node: "))
      (if (not (tblsearch "BLOCK" blkname))
        (princ (strcat "\nBlock \"" blkname "\" is not defined in this drawing. Nothing inserted."))
        (progn
          (setq n (sslength ss))
          (setq objs '())
          (setq i 0)
          (while (< i n)
            (setq objs (append objs (list (vlax-ename->vla-object (ssname ss i)))))
            (setq i (1+ i))
          )
          (setq pts '())

          ;; Endpoints
          (if (or (= mode "Endpoints") (= mode "Both"))
            (foreach obj1 objs
              (setq sp (vlax-curve-getStartPoint obj1))
              (setq ep (vlax-curve-getEndPoint obj1))
              (setq pts (BGOL:IBNP-AddPoint sp pts))
              (setq pts (BGOL:IBNP-AddPoint ep pts))
            )
          )

          ;; Intersections
          (if (or (= mode "Intersections") (= mode "Both"))
            (progn
              (setq i 0)
              (while (< i n)
                (setq obj1 (nth i objs))
                (setq j (1+ i))
                (while (< j n)
                  (setq obj2 (nth j objs))
                  (setq interlist (vlax-invoke obj1 'IntersectWith obj2 acExtendNone))
                  (while interlist
                    (setq ip (list (car interlist) (cadr interlist) (caddr interlist)))
                    (setq pts (BGOL:IBNP-AddPoint ip pts))
                    (setq interlist (cdddr interlist))
                  )
                  (setq j (1+ j))
                )
                (setq i (1+ i))
              )
            )
          )

          (setq cnt 0)
          (foreach pt pts
            (BGOL:IBNP-InsertBlock blkname pt lname *bgol-ibnp-scale* *bgol-ibnp-rot*)
            (setq cnt (1+ cnt))
          )
          (princ (strcat "\n" (itoa cnt) " node point(s) marked with block (BGOL-IBNP), mode=" mode "."))
        )
      )
    )
    (princ "\nNo lines/polylines selected.")
  )
  (princ)
)

(princ "\nNODEBLK-bgol.lsp loaded. Type IBNP to insert blocks at line endpoints/intersections.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
