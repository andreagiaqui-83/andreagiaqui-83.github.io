;;; ---------------------------------------------------------------------
;;;  MIDBLK-bgol.lsp
;;;  Command:  IBSM
;;;
;;;  PURPOSE
;;;  Inserts a copy of a chosen block at the true midpoint of EVERY
;;;  individual segment of a selected polyline, regardless of how long
;;;  or short each segment is. Neither MEASURE (fixed distance) nor
;;;  DIVIDE (equal count along the whole polyline) can target the
;;;  midpoint of each separate segment when segment lengths vary -
;;;  this routine fills that gap.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   IBSM   at the command line and press Enter.
;;;    3. Select the polyline whose segments should each get a block.
;;;    4. Type the name of an existing block to insert.
;;;    5. A copy of that block is inserted at the midpoint of every
;;;       segment of the selected polyline, on layer "BGOL-IBSM".
;;;
;;;  NOTES
;;;    - Works on LWPOLYLINE entities (2D polylines with straight
;;;      segments). Arc segments (bulges) are treated as their chord
;;;      midpoint for simplicity.
;;;    - Block scale and rotation default to 1/1/0; edit
;;;      *bgol-ibsm-scale* and *bgol-ibsm-rot* below to change defaults.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of per-segment midpoint
;;;      block insertion common in landscape/planting layout workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-ibsm-scale* 1.0)
(setq *bgol-ibsm-rot* 0.0)

(defun BGOL:IBSM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:IBSM-InsertBlock (blkname pt lname scl rot / )
  (entmake (list '(0 . "INSERT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbBlockReference")
                 (cons 2 blkname)
                 (cons 10 pt)
                 (cons 41 scl)
                 (cons 42 scl)
                 (cons 43 scl)
                 (cons 50 rot)))
)

(defun C:IBSM ( / ent obj blkname n pts i p1 p2 mid cnt lname)
  (setq lname "BGOL-IBSM")
  (BGOL:IBSM-EnsureLayer lname)
  (setq ent (car (entsel "\nSelect polyline: ")))
  (if (and ent (= (cdr (assoc 0 (entget ent))) "LWPOLYLINE"))
    (progn
      (setq blkname (getstring T "\nBlock name to insert at each segment midpoint: "))
      (if (not (tblsearch "BLOCK" blkname))
        (princ (strcat "\nBlock \"" blkname "\" is not defined in this drawing. Nothing inserted."))
        (progn
          (setq obj (vlax-ename->vla-object ent))
          (setq pts (vlax-invoke obj 'Coordinates))
          ;; pts is a flat list of x y x y ... ; rebuild as list of 2D points
          (setq n (/ (length pts) 2))
          (setq i 0)
          (setq cnt 0)
          (while (< i (1- n))
            (setq p1 (list (nth (* 2 i) pts) (nth (1+ (* 2 i)) pts)))
            (setq p2 (list (nth (* 2 (1+ i)) pts) (nth (1+ (* 2 (1+ i))) pts)))
            (setq mid (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2))
            (BGOL:IBSM-InsertBlock blkname mid lname *bgol-ibsm-scale* *bgol-ibsm-rot*)
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          ;; if polyline is closed, add the closing segment midpoint too
          (if (= 1 (logand 1 (cdr (assoc 70 (entget ent)))))
            (progn
              (setq p1 (list (nth (* 2 (1- n)) pts) (nth (1+ (* 2 (1- n))) pts)))
              (setq p2 (list (nth 0 pts) (nth 1 pts)))
              (setq mid (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2))
              (BGOL:IBSM-InsertBlock blkname mid lname *bgol-ibsm-scale* *bgol-ibsm-rot*)
              (setq cnt (1+ cnt))
            )
          )
          (princ (strcat "\n" (itoa cnt) " block(s) inserted at segment midpoints (BGOL-IBSM)."))
        )
      )
    )
    (princ "\nNo polyline selected (must be an LWPOLYLINE).")
  )
  (princ)
)

(princ "\nMIDBLK-bgol.lsp loaded. Type IBSM to insert a block at every segment midpoint of a polyline.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
