;;; ---------------------------------------------------------------------
;;;  PLCSVOUT-bgol.lsp
;;;  Command:  PCSV
;;;
;;;  PURPOSE
;;;  Exports every vertex of a selected polyline to a Comma Separated
;;;  Values (CSV) file, one row per vertex: point number, Easting (X),
;;;  Northing (Y), Elevation (Z). A simple, general-purpose polyline
;;;  vertex-to-CSV export.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PCSV   at the command line and press Enter.
;;;    3. Select the polyline whose vertices you want to export.
;;;    4. Choose a location to save the .csv file.
;;;    5. A CSV file with one row per vertex is written to disk.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of vertex-to-CSV export
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:PCSV ( / ent obj coords elev n i x y f path)
  (setq ent (car (entsel "\nSelect polyline to export vertex coordinates: ")))
  (if (and ent (= (cdr (assoc 0 (entget ent))) "LWPOLYLINE"))
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (setq coords (vlax-get obj 'Coordinates))
      (setq elev (vl-catch-all-apply 'vlax-get (list obj 'Elevation)))
      (if (vl-catch-all-error-p elev) (setq elev 0.0))
      (setq path (getfiled "Save Point List" "pntlist" "csv" 1))
      (if path
        (progn
          (setq f (open path "w"))
          (write-line "PointNo,Easting,Northing,Elevation" f)
          (setq n (/ (length coords) 2))
          (setq i 0)
          (while (< i n)
            (setq x (nth (* 2 i) coords))
            (setq y (nth (1+ (* 2 i)) coords))
            (write-line
              (strcat (itoa (1+ i)) ","
                      (rtos x 2 4) ","
                      (rtos y 2 4) ","
                      (rtos elev 2 4))
              f)
            (setq i (1+ i))
          )
          (close f)
          (princ (strcat "\nPCSV: " (itoa n) " vertex row(s) exported to " path))
        )
        (princ "\nNo output file chosen; export cancelled.")
      )
    )
    (princ "\nSelected entity is not an LWPOLYLINE. Nothing exported.")
  )
  (princ)
)

(princ "\nPLCSVOUT-bgol.lsp loaded. Type PCSV to export a polyline's vertex coordinates to CSV.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
