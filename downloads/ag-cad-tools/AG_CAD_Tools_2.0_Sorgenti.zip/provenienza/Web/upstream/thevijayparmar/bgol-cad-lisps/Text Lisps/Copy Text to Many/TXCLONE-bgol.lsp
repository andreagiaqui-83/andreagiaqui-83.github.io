;;; ---------------------------------------------------------------------
;;;  TXCLONE-bgol.lsp
;;;  Command:  TXCL
;;;
;;;  PURPOSE
;;;  Broadcasts one "source" TEXT entity's caption to many other TEXT
;;;  entities in a single command -- e.g. resetting a batch of outlier
;;;  values to a correct common value, or repeating the same road/street
;;;  name across several labels, without repeated copy-paste-via-DDEDIT.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   TXCL   at the command line and press Enter.
;;;    3. Select the SOURCE (reference) text whose content will be
;;;       copied.
;;;    4. Select the TARGET text entities that should receive that
;;;       content, press Enter to finish.
;;;    5. Every target text is updated to match the source text's
;;;       content. A small reference tick mark is placed above each
;;;       updated target on layer "BGOL-TXCL".
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of copy-one-text-to-many
;;;      utilities common in CAD drafting workflows, but the code,
;;;      command name and file name here are new and are NOT copied
;;;      from, nor identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:TXCL-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:TXCL-MarkTick (obj lname / pt h)
  (setq pt (vlax-get obj 'InsertionPoint))
  (setq h (vlax-get obj 'Height))
  (entmake (list '(0 . "POINT")
                 (cons 8 lname)
                 (cons 10 (list (car pt) (+ (cadr pt) (* h 1.4)) (caddr pt)))))
)

(defun C:TXCL ( / lname srcent srcval ss n i ent edata obj)
  (setq lname "BGOL-TXCL")
  (BGOL:TXCL-EnsureLayer lname)
  (setq srcent (car (entsel "\nSelect SOURCE (reference) text: ")))
  (if (and srcent (= (cdr (assoc 0 (entget srcent))) "TEXT"))
    (progn
      (setq srcval (cdr (assoc 1 (entget srcent))))
      (princ (strcat "\nSource text value: \"" srcval "\""))
      (princ "\nSelect TARGET text entities to update: ")
      (setq ss (ssget '((0 . "TEXT"))))
      (if ss
        (progn
          (setq n 0)
          (setq i 0)
          (repeat (sslength ss)
            (setq ent (ssname ss i))
            (if (/= ent srcent)
              (progn
                (setq edata (entget ent))
                (entmod (subst (cons 1 srcval) (assoc 1 edata) edata))
                (entupd ent)
                (setq obj (vlax-ename->vla-object ent))
                (BGOL:TXCL-MarkTick obj lname)
                (setq n (1+ n))
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nTXCL: " (itoa n) " target text entit"
                         (if (= n 1) "y" "ies") " updated to match source."))
        )
        (princ "\nNo target text selected.")
      )
    )
    (princ "\nNo valid TEXT entity selected as source.")
  )
  (princ)
)

(princ "\nTXCLONE-bgol.lsp loaded. Type TXCL to copy one text's value to many others.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
