;;; ---------------------------------------------------------------------
;;;  SNAPGRID-bgol.lsp
;;;  Command:  STG
;;;
;;;  PURPOSE
;;;  Snaps the insertion point of selected TEXT entities onto the
;;;  nearest point of a regular grid, defined by a chosen grid spacing.
;;;  Ensures elevation/point label data conforms to strict
;;;  grid-coordinate requirements of downstream GIS/terrain software.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   STG   at the command line and press Enter.
;;;    3. Select one or more TEXT entities to snap.
;;;    4. Enter the grid spacing.
;;;    5. Each selected text's insertion point is moved to the nearest
;;;       grid intersection (X and Y each rounded to the nearest
;;;       multiple of the spacing). A small marker circle is drawn at
;;;       the new point on layer "BGOL-STG" for visual confirmation.
;;;
;;;  NOTES
;;;    - Modifies the selected TEXT entities in place (their insertion
;;;      point only; the text string/height/style are unchanged).
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of grid-snapping utilities
;;;      common in survey/GIS drafting workflows, but the code, command
;;;      name and file name here are new and are NOT copied from, nor
;;;      identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:STG-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:STG-Mark (pt lname / )
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 (cons 40 0.25)))
)

(defun BGOL:STG-RoundTo (v gs / q)
  (setq q (/ v gs))
  (if (>= q 0.0)
    (* gs (fix (+ q 0.5)))
    (* gs (- (fix (+ (- q) 0.5))))
  )
)

(defun C:STG ( / ss gs n i ent edata pt newx newy newpt)
  (BGOL:STG-EnsureLayer "BGOL-STG")
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq gs (getreal "\nEnter grid spacing: "))
      (if (and gs (> gs 0))
        (progn
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq pt (cdr (assoc 10 edata)))
            (if pt
              (progn
                (setq newx (BGOL:STG-RoundTo (car pt) gs))
                (setq newy (BGOL:STG-RoundTo (cadr pt) gs))
                (setq newpt (list newx newy (caddr pt)))
                (entmod (subst (cons 10 newpt) (assoc 10 edata) edata))
                (entupd ent)
                (BGOL:STG-Mark newpt "BGOL-STG")
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nSTG: " (itoa n) " text entitie(s) snapped to " (rtos gs 2 2) " grid."))
        )
        (princ "\nInvalid grid spacing. Aborted.")
      )
    )
    (princ "\nNo text entities selected.")
  )
  (princ)
)

(princ "\nSNAPGRID-bgol.lsp loaded. Type STG to snap selected text to the nearest grid point.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
