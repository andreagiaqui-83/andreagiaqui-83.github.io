;;; ---------------------------------------------------------------------
;;;  VXFILL-bgol.lsp
;;;  Command:  VXFL
;;;
;;;  PURPOSE
;;;  Increases vertex density on selected LWPOLYLINEs by inserting a
;;;  user-specified number of new, evenly-spaced vertices into EVERY
;;;  segment. Unlike text-driven vertex insertion, this is a purely
;;;  mathematical densification: each segment gets the same number of
;;;  new intermediate points, regardless of any markers.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   VXFL   at the command line and press Enter.
;;;    3. Select one or more LWPOLYLINE entities.
;;;    4. Enter how many new vertices to insert per segment.
;;;    5. A new, denser LWPOLYLINE is created on layer "BGOL-VXFL" for
;;;       each selected polyline. Originals are left untouched.
;;;
;;;  NOTES
;;;    - New points are computed as linear interpolations between each
;;;      pair of original vertices; no smoothing/curve-fitting is applied.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of uniform vertex
;;;      densification utilities common in CAD/survey drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:VXFL-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 5)          ; blue
                   '(6 . "Continuous")))
  )
)

(defun BGOL:VXFL-MakePolyline (pointlist closed lname / dxfdata pt)
  (setq dxfdata (list '(0 . "LWPOLYLINE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbPolyline")
                       (cons 90 (length pointlist))
                       (cons 70 (if closed 1 0))
                 )
  )
  (foreach pt pointlist
    (setq dxfdata (append dxfdata (list (cons 10 pt))))
  )
  (entmake dxfdata)
)

;; Returns the ordered 2D vertex list of a polyline VLA object
(defun BGOL:VXFL-GetVerts (obj / n coords i pts)
  (setq coords (vlax-safearray->list (vlax-variant-value (vlax-get obj 'Coordinates))))
  (setq pts '())
  (while coords
    (setq pts (append pts (list (list (car coords) (cadr coords)))))
    (setq coords (cddr coords))
  )
  pts
)

(defun C:VXFL ( / ss n i ent obj closed verts newpts p1 p2 j k frac newpt cnt)
  (BGOL:VXFL-EnsureLayer "BGOL-VXFL")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq n (getint "\nNumber of vertices to insert per segment <2>: "))
      (if (not n) (setq n 2))
      (if (< n 1) (setq n 1))
      (setq cnt 0)
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq closed (vlax-get obj 'Closed))
        (setq verts (BGOL:VXFL-GetVerts obj))
        (setq newpts '())
        (setq j 0)
        (while (< j (1- (length verts)))
          (setq p1 (nth j verts))
          (setq p2 (nth (1+ j) verts))
          (setq newpts (append newpts (list p1)))
          (setq k 1)
          (while (<= k n)
            (setq frac (/ (float k) (1+ n)))
            (setq newpt (list (+ (car p1) (* frac (- (car p2) (car p1))))
                               (+ (cadr p1) (* frac (- (cadr p2) (cadr p1))))))
            (setq newpts (append newpts (list newpt)))
            (setq k (1+ k))
          )
          (setq j (1+ j))
        )
        (setq newpts (append newpts (list (last verts))))
        (if closed
          (progn
            (setq p1 (last verts))
            (setq p2 (car verts))
            (setq k 1)
            (while (<= k n)
              (setq frac (/ (float k) (1+ n)))
              (setq newpt (list (+ (car p1) (* frac (- (car p2) (car p1))))
                                 (+ (cadr p1) (* frac (- (cadr p2) (cadr p1))))))
              (setq newpts (append newpts (list newpt)))
              (setq k (1+ k))
            )
          )
        )
        (BGOL:VXFL-MakePolyline newpts closed "BGOL-VXFL")
        (setq cnt (1+ cnt))
        (setq i (1+ i))
      )
      (princ (strcat "\nVXFL: densified " (itoa cnt) " polyline(s) with " (itoa n) " new vertex/vertices per segment (BGOL-VXFL)."))
    )
    (princ "\nNo LWPOLYLINE selected.")
  )
  (princ)
)

(princ "\nVXFILL-bgol.lsp loaded. Type VXFL to insert evenly-spaced vertices into every segment.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
