;;; ---------------------------------------------------------------------
;;;  FASTLYR-bgol.lsp
;;;  Command:  FLY
;;;
;;;  PURPOSE
;;;  Creates a new layer in two quick command-line prompts (name and
;;;  colour number) and makes it current, skipping the native Layer
;;;  Properties Manager dialog entirely. Built for keyboard-driven
;;;  workflows that need to create many layers quickly.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   FLY   at the command line and press Enter.
;;;    3. At the "Type the Layer Name:" prompt, type the new layer name.
;;;    4. At the "Type the Colour Number:" prompt, type the AutoCAD
;;;       colour index number (1-255).
;;;    5. The new layer is created immediately with that name and colour,
;;;       and set as the current layer.
;;;
;;;  NOTES
;;;    - If a layer with the given name already exists, its colour is
;;;      updated instead of erroring, and it is still set current.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of fast, dialog-free layer
;;;      creation utilities common in CAD drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:FLY ( / lname colornum existing)
  (setq lname (getstring T "\nType the Layer Name: "))
  (if (and lname (/= lname ""))
    (progn
      (setq colornum (getint "\nType the Colour Number (1-255): "))
      (if (and colornum (>= colornum 1) (<= colornum 255))
        (progn
          (setq existing (tblsearch "LAYER" lname))
          (if existing
            (entmod (subst (cons 62 colornum) (assoc 62 existing) existing))
            (entmake (list '(0 . "LAYER")
                           '(100 . "AcDbSymbolTableRecord")
                           '(100 . "AcDbLayerTableRecord")
                           (cons 2 lname)
                           '(70 . 0)
                           (cons 62 colornum)
                           '(6 . "Continuous")))
          )
          (setvar "CLAYER" lname)
          (princ (strcat "\nFLY: layer \"" lname "\" created/updated (colour "
                          (itoa colornum) ") and set current."))
        )
        (princ "\nInvalid colour number entered — command cancelled.")
      )
    )
    (princ "\nNo layer name entered — command cancelled.")
  )
  (princ)
)

(princ "\nFASTLYR-bgol.lsp loaded. Type FLY to quickly create a new layer.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
