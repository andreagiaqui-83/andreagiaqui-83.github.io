;;; ---------------------------------------------------------------------
;;;  MIDSCL-bgol.lsp
;;;  Command:  MSL
;;;
;;;  PURPOSE
;;;  Scales one or more selected LINE entities about each line's own
;;;  midpoint (rather than a shared external base point), given a single
;;;  scale factor. Both endpoints move symmetrically inward or outward
;;;  while the midpoint stays fixed. Handy for uniformly lengthening or
;;;  shortening a batch of cross-section lines along an alignment.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   MSL   at the command line and press Enter.
;;;    3. Select the line(s) to scale; press Enter to confirm selection.
;;;    4. Enter the scale factor (>1 lengthens, <1 shortens).
;;;    5. Each selected line is scaled about its own midpoint.
;;;
;;;  NOTES
;;;    - Only LINE entities are affected; other entity types in the
;;;      selection are silently skipped.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of midpoint-based batch line
;;;      scaling utilities common in CAD drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:MSL-ScaleAboutMid (p1 p2 factor / mid newp1 newp2)
  (setq mid (list (/ (+ (car p1) (car p2)) 2.0)
                   (/ (+ (cadr p1) (cadr p2)) 2.0)
                   (/ (+ (caddr p1) (caddr p2)) 2.0)))
  (setq newp1 (list (+ (car mid) (* factor (- (car p1) (car mid))))
                     (+ (cadr mid) (* factor (- (cadr p1) (cadr mid))))
                     (+ (caddr mid) (* factor (- (caddr p1) (caddr mid))))))
  (setq newp2 (list (+ (car mid) (* factor (- (car p2) (car mid))))
                     (+ (cadr mid) (* factor (- (cadr p2) (cadr mid))))
                     (+ (caddr mid) (* factor (- (caddr p2) (caddr mid))))))
  (list newp1 newp2)
)

(defun C:MSL ( / ss factor n i ent edata etype p1 p2 result newpts scaled)
  (setq ss (ssget '((0 . "LINE"))))
  (if ss
    (progn
      (setq factor (getreal "\nScale factor (about each line's midpoint): "))
      (if (and factor (> factor 0))
        (progn
          (setq scaled 0)
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq etype (cdr (assoc 0 edata)))
            (if (= etype "LINE")
              (progn
                (setq p1 (cdr (assoc 10 edata)))
                (setq p2 (cdr (assoc 11 edata)))
                (if (< (length p1) 3) (setq p1 (append p1 (list 0.0))))
                (if (< (length p2) 3) (setq p2 (append p2 (list 0.0))))
                (setq result (BGOL:MSL-ScaleAboutMid p1 p2 factor))
                (setq newpts (car result))
                (setq edata (subst (cons 10 (car result)) (assoc 10 edata) edata))
                (setq edata (subst (cons 11 (cadr result)) (assoc 11 edata) edata))
                (entmod edata)
                (setq scaled (1+ scaled))
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nMSL: scaled " (itoa scaled)
                          " line(s) by factor " (rtos factor 2 4)
                          " about each line's own midpoint."))
        )
        (princ "\nInvalid scale factor entered — command cancelled.")
      )
    )
    (princ "\nNo lines selected.")
  )
  (princ)
)

(princ "\nMIDSCL-bgol.lsp loaded. Type MSL to scale lines about their own midpoints.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
