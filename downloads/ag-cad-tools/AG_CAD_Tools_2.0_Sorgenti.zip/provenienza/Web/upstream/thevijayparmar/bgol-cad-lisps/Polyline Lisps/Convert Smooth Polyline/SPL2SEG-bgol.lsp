;;; ---------------------------------------------------------------------
;;;  SPL2SEG-bgol.lsp
;;;  Command:  SP2P
;;;
;;;  PURPOSE
;;;  Converts a smooth (spline-fit) polyline back into a regular,
;;;  densely-segmented polyline that closely follows the smooth curve's
;;;  shape, but is made of many short straight segments carrying real
;;;  vertex geometry that other vertex-based LISP routines can process
;;;  correctly.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   SP2P   at the command line and press Enter.
;;;    3. Select a smoothed (PEDIT > Spline) LWPOLYLINE.
;;;    4. A new densely-segmented regular polyline that traces the
;;;       smooth curve is created on layer "BGOL-SP2P". The original
;;;       smooth polyline is left untouched.
;;;
;;;  NOTES
;;;    - Sampling density defaults to *bgol-sp2p-samples* points; edit
;;;      the constant below to change resolution.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of spline-to-polyline
;;;      resampling utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-sp2p-samples* 60)  ; number of sample points along the curve

(defun BGOL:SP2P-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 4)          ; cyan
                   '(6 . "Continuous")))
  )
)

(defun BGOL:SP2P-MakePolyline (pointlist closed lname / dxfdata pt)
  (setq dxfdata (list '(0 . "LWPOLYLINE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbPolyline")
                       (cons 90 (length pointlist))
                       (cons 70 (if closed 1 0))
                 )
  )
  (foreach pt pointlist
    (setq dxfdata (append dxfdata (list (cons 10 pt))))
  )
  (entmakex dxfdata)
)

(defun C:SP2P ( / ent edata obj closed totalDist nseg i d pts pt2d)
  (BGOL:SP2P-EnsureLayer "BGOL-SP2P")
  (setq ent (car (entsel "\nSelect smoothed (splined) polyline to resample: ")))
  (if ent
    (progn
      (setq edata (entget ent))
      (if (= (cdr (assoc 0 edata)) "LWPOLYLINE")
        (progn
          (setq obj (vlax-ename->vla-object ent))
          (setq closed (= 1 (logand 1 (cdr (assoc 70 edata)))))
          (setq totalDist (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
          (setq nseg (max 8 *bgol-sp2p-samples*))
          (setq pts '())
          (setq i 0)
          (while (<= i nseg)
            (setq d (* totalDist (/ (float i) nseg)))
            (setq pt2d (vlax-curve-getPointAtDist obj d))
            (if pt2d
              (setq pts (append pts (list (list (car pt2d) (cadr pt2d)))))
            )
            (setq i (1+ i))
          )
          (if closed
            (setq pts (reverse (cdr (reverse pts)))) ; drop duplicate closing sample
          )
          (BGOL:SP2P-MakePolyline pts closed "BGOL-SP2P")
          (princ (strcat "\nSP2P: smooth polyline resampled into " (itoa (length pts))
                          " straight segments (layer BGOL-SP2P)."))
        )
        (princ "\nSelected entity is not an LWPOLYLINE. Nothing converted.")
      )
    )
    (princ "\nNo entity selected.")
  )
  (princ)
)

(princ "\nSPL2SEG-bgol.lsp loaded. Type SP2P to resample a smooth polyline into straight segments.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
