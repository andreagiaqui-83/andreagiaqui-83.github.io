;;; ---------------------------------------------------------------------
;;;  PREC-bgol.lsp
;;;  Command:  PDEC
;;;
;;;  PURPOSE
;;;  Reformats the numeric value of selected TEXT entities to a fixed
;;;  number of decimal places (1 to 4, chosen interactively), giving a
;;;  drawing consistent decimal precision across elevation, coordinate
;;;  or dimension callouts that may have arrived with mixed precision.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PDEC   at the command line and press Enter.
;;;    3. Enter the desired decimal precision (1-4) at the prompt.
;;;    4. Select the numeric TEXT entities to convert, press Enter to
;;;       finish.
;;;    5. Each selected text's numeric value is reformatted to the
;;;       chosen number of decimal digits. A small reference tick mark
;;;       is placed above each updated text on layer "BGOL-PDEC".
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of fixed-decimal text
;;;      precision utilities common in survey/CAD drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:PDEC-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

(defun BGOL:PDEC-MarkTick (obj lname / pt h)
  (setq pt (vlax-get obj 'InsertionPoint))
  (setq h (vlax-get obj 'Height))
  (entmake (list '(0 . "POINT")
                 (cons 8 lname)
                 (cons 10 (list (car pt) (+ (cadr pt) (* h 1.4)) (caddr pt)))))
)

(defun BGOL:PDEC-IsNumeric (s / c i ok len)
  (setq ok T len (strlen s) i 1)
  (if (= len 0) (setq ok nil))
  (while (and ok (<= i len))
    (setq c (substr s i 1))
    (if (not (or (and (>= c "0") (<= c "9")) (= c ".") (= c "-") (= c "+")))
      (setq ok nil)
    )
    (setq i (1+ i))
  )
  ok
)

(defun C:PDEC ( / prec ss n i ent edata oldval val newval obj)
  (BGOL:PDEC-EnsureLayer "BGOL-PDEC")
  (setq prec (getint "\nEnter decimal precision (1-4): "))
  (if (and prec (>= prec 1) (<= prec 4))
    (progn
      (princ "\nSelect numeric TEXT entities to convert: ")
      (setq ss (ssget '((0 . "TEXT"))))
      (if ss
        (progn
          (setq n 0)
          (setq i 0)
          (repeat (sslength ss)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq oldval (cdr (assoc 1 edata)))
            (if (BGOL:PDEC-IsNumeric oldval)
              (progn
                (setq val (atof oldval))
                (setq newval (rtos val 2 prec))
                (entmod (subst (cons 1 newval) (assoc 1 edata) edata))
                (entupd ent)
                (setq obj (vlax-ename->vla-object ent))
                (BGOL:PDEC-MarkTick obj "BGOL-PDEC")
                (setq n (1+ n))
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nPDEC: " (itoa n) " text entit"
                         (if (= n 1) "y" "ies") " reformatted to "
                         (itoa prec) " decimal place(s)."))
        )
        (princ "\nNo text selected.")
      )
    )
    (princ "\nInvalid precision. Enter a whole number from 1 to 4.")
  )
  (princ)
)

(princ "\nPREC-bgol.lsp loaded. Type PDEC to set decimal precision on selected text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
