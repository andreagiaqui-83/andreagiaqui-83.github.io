;;; ---------------------------------------------------------------------
;;;  XLYRMRK-bgol.lsp
;;;  Command:  XLM
;;;
;;;  PURPOSE
;;;  Finds every intersection between a selected base polyline and a set
;;;  of other selected lines/polylines, reports each intersection's
;;;  distance along the base polyline from its start point, records the
;;;  layer of the intersecting entity, and exports the results to CSV.
;;;  Useful for town-planning / infrastructure coordination where a
;;;  reference alignment crosses many differently-layered features.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   XLM   at the command line and press Enter.
;;;    3. Select the base polyline (the reference alignment).
;;;    4. Select all other lines/polylines that cross it.
;;;    5. Each intersection point is marked on layer "BGOL-XLM"; a CSV
;;;       file listing distance-from-start and intersecting layer is
;;;       written to the drawing's folder.
;;;
;;;  NOTES
;;;    - Intersections are found with vlax-invoke's IntersectWith method.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of alignment/feature
;;;      intersection-reporting utilities common in civil/survey
;;;      drafting workflows, but the code, command name and file name
;;;      here are new and are NOT copied from, nor identical to, any
;;;      specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:XLM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:XLM-MarkPoint (pt lname)
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 (cons 40 4.0)))
)

(defun C:XLM ( / baseent baseobj ss n i otherent otherobj iresult
                 j pt dist lyr fname fh rowcount)
  (BGOL:XLM-EnsureLayer "BGOL-XLM")
  (setq baseent (car (entsel "\nSelect base polyline (reference alignment): ")))
  (if baseent
    (progn
      (setq baseobj (vlax-ename->vla-object baseent))
      (setq ss (ssget "_:L" (list (cons -4 "<NOT") (cons -1 baseent) (cons -4 "NOT>"))))
      (if (not ss) (setq ss (ssget)))
      (if ss
        (progn
          (setq fname (strcat (getvar "DWGPREFIX") "BGOL-XLM-Intersections.csv"))
          (setq fh (open fname "w"))
          (write-line "Distance,Layer" fh)
          (setq rowcount 0)
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq otherent (ssname ss i))
            (if (/= otherent baseent)
              (progn
                (setq otherobj (vlax-ename->vla-object otherent))
                (setq iresult
                  (vl-catch-all-apply
                    'vlax-invoke
                    (list baseobj 'IntersectWith otherobj acExtendNone)))
                (if (and iresult (not (vl-catch-all-error-p iresult)) iresult)
                  (progn
                    (setq j 0)
                    (while (< j (length iresult))
                      (setq pt (list (nth j iresult) (nth (1+ j) iresult) (nth (+ j 2) iresult)))
                      (setq dist (vlax-curve-getDistAtParam baseobj (vlax-curve-getParamAtPoint baseobj pt)))
                      (setq lyr (cdr (assoc 8 (entget otherent))))
                      (BGOL:XLM-MarkPoint pt "BGOL-XLM")
                      (write-line (strcat (rtos dist 2 3) "," lyr) fh)
                      (setq rowcount (1+ rowcount))
                      (setq j (+ j 3))
                    )
                  )
                )
              )
            )
            (setq i (1+ i))
          )
          (close fh)
          (princ (strcat "\nXLM: found " (itoa rowcount) " intersection(s). CSV written to " fname " (marks on BGOL-XLM)."))
        )
        (princ "\nNo intersecting lines selected.")
      )
    )
    (princ "\nNo base polyline selected.")
  )
  (princ)
)

(princ "\nXLYRMRK-bgol.lsp loaded. Type XLM to mark and log intersections against a base polyline.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
