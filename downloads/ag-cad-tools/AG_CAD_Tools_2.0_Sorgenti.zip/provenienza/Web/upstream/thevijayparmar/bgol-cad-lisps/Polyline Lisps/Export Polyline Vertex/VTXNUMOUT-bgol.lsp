;;; ---------------------------------------------------------------------
;;;  VTXNUMOUT-bgol.lsp
;;;  Command:  VNUM
;;;
;;;  PURPOSE
;;;  Numbers every vertex across one or more selected polylines/polygons
;;;  sequentially (continuing the count across objects, not restarting
;;;  per object), marks each number directly on the drawing, and
;;;  exports the same numbered data to a CSV file - matching drawing
;;;  numbers to CSV rows for setting-out/staking work.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   VNUM   at the command line and press Enter.
;;;    3. Select one or more polylines/polygons.
;;;    4. Choose a location to save the .csv file.
;;;    5. Every vertex is numbered on-screen (layer "BGOL-VNUM") and
;;;       exported in the same order to the CSV.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of numbered-vertex export
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:VNUM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:VNUM-MakeText (pt str ht lname / dxfdata)
  (setq dxfdata (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbText")
                       (cons 10 pt)
                       (cons 40 ht)
                       (cons 1 str)
                 )
  )
  (entmakex dxfdata)
)

(defun C:VNUM ( / ss n i ename obj coords elev cnt m j x y pt f path th)
  (BGOL:VNUM-EnsureLayer "BGOL-VNUM")
  (princ "\nSelect polylines/polygons to number and export: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq path (getfiled "Save Numbered Point List" "vertexlist" "csv" 1))
      (if path
        (progn
          (setq f (open path "w"))
          (write-line "PointNo,Easting,Northing,Elevation" f)
          (setq n (sslength ss))
          (setq cnt 1)
          (setq th 2.0)
          (setq i 0)
          (while (< i n)
            (setq ename (ssname ss i))
            (setq obj (vlax-ename->vla-object ename))
            (setq coords (vlax-get obj 'Coordinates))
            (setq elev (vl-catch-all-apply 'vlax-get (list obj 'Elevation)))
            (if (vl-catch-all-error-p elev) (setq elev 0.0))
            (setq m (/ (length coords) 2))
            (setq j 0)
            (while (< j m)
              (setq x (nth (* 2 j) coords))
              (setq y (nth (1+ (* 2 j)) coords))
              (setq pt (list x y elev))
              (BGOL:VNUM-MakeText pt (itoa cnt) th "BGOL-VNUM")
              (write-line
                (strcat (itoa cnt) ","
                        (rtos x 2 4) ","
                        (rtos y 2 4) ","
                        (rtos elev 2 4))
                f)
              (setq cnt (1+ cnt))
              (setq j (1+ j))
            )
            (setq i (1+ i))
          )
          (close f)
          (princ (strcat "\nVNUM: " (itoa (1- cnt)) " vertex(es) numbered on layer BGOL-VNUM and exported to " path))
        )
        (princ "\nNo output file chosen; export cancelled.")
      )
    )
    (princ "\nNo polylines selected.")
  )
  (princ)
)

(princ "\nVTXNUMOUT-bgol.lsp loaded. Type VNUM to number and export polyline vertices.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
