;;; ---------------------------------------------------------------------
;;;  MT2TX-bgol.lsp
;;;  Command:  M2TX
;;;
;;;  PURPOSE
;;;  Converts selected MTEXT entities into equivalent single-line TEXT
;;;  entities, flattening any multi-line content into one continuous
;;;  line (unlike native EXPLODE, which would split multi-line MText
;;;  into multiple separate TEXT entities). Useful for making MText
;;;  content usable by other TEXT-only LISP routines.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   M2TX   at the command line and press Enter.
;;;    3. Select the MTEXT entities to convert, press Enter to finish.
;;;    4. Each selected MText's full content is flattened into a single
;;;       line and recreated as a new TEXT entity on layer "BGOL-M2TX"
;;;       at the MText's insertion point and text height. The original
;;;       MText entity is deleted.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of MText-to-Text flattening
;;;      utilities common in CAD drafting workflows, but the code,
;;;      command name and file name here are new and are NOT copied
;;;      from, nor identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:M2TX-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

;; Strip common MText control codes and line breaks, collapsing to one line
(defun BGOL:M2TX-Flatten (s / out)
  (setq out s)
  (while (vl-string-search "\\P" out) (setq out (vl-string-subst " " "\\P" out)))
  (while (vl-string-search "\\p" out) (setq out (vl-string-subst " " "\\p" out)))
  ;; strip simple formatting braces
  (while (vl-string-search "{" out) (setq out (vl-string-subst "" "{" out)))
  (while (vl-string-search "}" out) (setq out (vl-string-subst "" "}" out)))
  out
)

(defun C:M2TX ( / ss n i ent obj content flat pt h ang lname)
  (setq lname "BGOL-M2TX")
  (BGOL:M2TX-EnsureLayer lname)
  (princ "\nSelect MTEXT entities to convert: ")
  (setq ss (ssget '((0 . "MTEXT"))))
  (if ss
    (progn
      (setq n 0)
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq content (vlax-get obj 'TextString))
        (setq flat (BGOL:M2TX-Flatten content))
        (setq pt (vlax-get obj 'InsertionPoint))
        (setq h (vlax-get obj 'Height))
        (setq ang (vlax-get obj 'Rotation))
        (entmake (list '(0 . "TEXT")
                       (cons 8 lname)
                       (cons 10 pt)
                       (cons 40 h)
                       (cons 1 flat)
                       (cons 50 ang)))
        (entdel ent)
        (setq n (1+ n))
        (setq i (1+ i))
      )
      (princ (strcat "\nM2TX: " (itoa n) " MTEXT entit"
                     (if (= n 1) "y" "ies") " converted to single-line TEXT on layer " lname "."))
    )
    (princ "\nNo MTEXT selected.")
  )
  (princ)
)

(princ "\nMT2TX-bgol.lsp loaded. Type M2TX to convert MText to single-line Text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
