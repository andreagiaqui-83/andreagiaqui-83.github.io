;;; ---------------------------------------------------------------------
;;;  PSAP-bgol.lsp
;;;  Command:  PSFX
;;;
;;;  PURPOSE
;;;  Adds a user-specified prefix and/or suffix string to every selected
;;;  TEXT entity in one pass. Useful for labeling elevation values with
;;;  a descriptive prefix (e.g. "GL: ") and/or a unit suffix (e.g. " M")
;;;  across many text entities at once.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PSFX   at the command line and press Enter.
;;;    3. Enter a prefix string (or press Enter for none).
;;;    4. Enter a suffix string (or press Enter for none).
;;;    5. Select the TEXT entities to update, press Enter to finish.
;;;    6. Every selected text is updated with prefix + original value +
;;;       suffix. A small reference tick mark is placed above each
;;;       updated text on layer "BGOL-PSFX" for a quick visual audit.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of batch prefix/suffix
;;;      text-labeling utilities common in CAD drafting workflows, but
;;;      the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:PSFX-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:PSFX-MarkTick (obj lname / pt h)
  (setq pt (vlax-get obj 'InsertionPoint))
  (setq h (vlax-get obj 'Height))
  (entmake (list '(0 . "POINT")
                 (cons 8 lname)
                 (cons 10 (list (car pt) (+ (cadr pt) (* h 1.4)) (caddr pt)))))
)

(defun C:PSFX ( / prefix suffix ss n i ent edata oldval newval obj)
  (BGOL:PSFX-EnsureLayer "BGOL-PSFX")
  (setq prefix (getstring T "\nEnter prefix (or press Enter for none): "))
  (setq suffix (getstring T "\nEnter suffix (or press Enter for none): "))
  (if (or (/= prefix "") (/= suffix ""))
    (progn
      (princ "\nSelect TEXT entities to update: ")
      (setq ss (ssget '((0 . "TEXT"))))
      (if ss
        (progn
          (setq n 0)
          (setq i 0)
          (repeat (sslength ss)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq oldval (cdr (assoc 1 edata)))
            (setq newval (strcat prefix oldval suffix))
            (entmod (subst (cons 1 newval) (assoc 1 edata) edata))
            (entupd ent)
            (setq obj (vlax-ename->vla-object ent))
            (BGOL:PSFX-MarkTick obj "BGOL-PSFX")
            (setq n (1+ n))
            (setq i (1+ i))
          )
          (princ (strcat "\nPSFX: " (itoa n) " text entit"
                         (if (= n 1) "y" "ies") " updated with prefix/suffix."))
        )
        (princ "\nNo text selected.")
      )
    )
    (princ "\nBoth prefix and suffix were empty. Nothing to do.")
  )
  (princ)
)

(princ "\nPSAP-bgol.lsp loaded. Type PSFX to append a prefix/suffix to selected text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
