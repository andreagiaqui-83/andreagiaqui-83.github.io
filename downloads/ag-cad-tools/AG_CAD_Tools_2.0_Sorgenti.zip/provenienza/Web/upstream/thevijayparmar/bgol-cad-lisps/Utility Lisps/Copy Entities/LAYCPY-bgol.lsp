;;; ---------------------------------------------------------------------
;;;  LAYCPY-bgol.lsp
;;;  Command:  LCY
;;;
;;;  PURPOSE
;;;  Copies a selected set of entities into every Paper Space layout in
;;;  the current drawing, using a single picked base point as the common
;;;  placement reference. Useful for propagating a title-block element,
;;;  north arrow, legend, or standard annotation identically across every
;;;  sheet of a multi-layout drawing.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   LCY   at the command line and press Enter.
;;;    3. Select the entities to duplicate across all layouts.
;;;    4. Specify a base point (the placement reference).
;;;    5. Copies of the selected entities are inserted into every Paper
;;;       Space layout in the drawing, each copy sharing the same base
;;;       point reference. Copies are placed on layer "BGOL-LCY" so they
;;;       are easy to identify/select afterward on each sheet.
;;;
;;;  NOTES
;;;    - Model Space is skipped; only Paper Space layouts are targeted.
;;;    - Uses the ActiveX CopyObjects method to duplicate entities into
;;;      each target layout's block.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of multi-layout entity-copy
;;;      utilities common in CAD sheet-set workflows, but the code,
;;;      command name and file name here are new and are NOT copied
;;;      from, nor identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:LCY-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 5)          ; blue
                   '(6 . "Continuous")))
  )
)

(defun C:LCY ( / ss basept doc layouts lyt blk n i ent entobj
                 newobjs copyresult srcents count)
  (setq ss (ssget))
  (if ss
    (progn
      (setq basept (getpoint "\nSpecify base point: "))
      (if basept
        (progn
          (BGOL:LCY-EnsureLayer "BGOL-LCY")
          (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
          (setq layouts (vla-get-Layouts doc))
          ;; Build a VLA object array of the selected entities
          (setq srcents (vlax-make-safearray vlax-vbObject (cons 0 (1- (sslength ss)))))
          (setq i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (vlax-safearray-put-element srcents i (vlax-ename->vla-object ent))
            (setq i (1+ i))
          )
          (setq count 0)
          (vlax-for lyt layouts
            (if (/= (strcase (vla-get-Name lyt)) "MODEL")
              (progn
                (setq blk (vla-get-Block lyt))
                (setq copyresult
                  (vl-catch-all-apply
                    'vla-copyobjects
                    (list doc srcents blk)
                  )
                )
                (if (not (vl-catch-all-error-p copyresult))
                  (progn
                    ;; move each newly-copied object onto BGOL-LCY layer
                    (if (= (vlax-safearray-type (vlax-variant-value copyresult)) vlax-vbObject)
                      (progn
                        (setq newobjs (vlax-safearray->list (vlax-variant-value copyresult)))
                        (foreach nob newobjs
                          (vl-catch-all-apply 'vla-put-Layer (list nob "BGOL-LCY"))
                        )
                      )
                    )
                    (setq count (1+ count))
                  )
                )
              )
            )
          )
          (princ (strcat "\nCopied " (itoa (sslength ss)) " entity(ies) to "
                          (itoa count) " layout(s) via LCY."))
        )
        (princ "\nNo base point specified — command cancelled.")
      )
    )
    (princ "\nNo entities selected.")
  )
  (princ)
)

(princ "\nLAYCPY-bgol.lsp loaded. Type LCY to copy selected entities to all layouts.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
