;;; ---------------------------------------------------------------------
;;;  PTXPORT-bgol.lsp
;;;  Command:  PXYZ
;;;
;;;  PURPOSE
;;;  Extracts point coordinate data (X/Easting, Y/Northing, Z/Elevation)
;;;  plus each point's text caption from selected TEXT entities and
;;;  writes it out as rows in a Comma Separated Values (CSV) file --
;;;  the reverse of a Total Station import, useful for reporting,
;;;  further processing, or reimport into other software.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PXYZ   at the command line and press Enter.
;;;    3. Select the TEXT entities representing point data, press Enter
;;;       to finish.
;;;    4. Choose a destination CSV file in the save dialog.
;;;    5. Each selected text's X, Y, Z insertion-point coordinates and
;;;       its caption are written as one CSV row. A small marker point
;;;       is placed at each exported text's location on layer
;;;       "BGOL-PXYZ" so the exported set can be reviewed visually.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of point-data CSV export
;;;      utilities common in survey/CAD drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:PXYZ-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 5)          ; blue
                   '(6 . "Continuous")))
  )
)

(defun BGOL:PXYZ-MarkPoint (pt lname / )
  (entmake (list '(0 . "POINT")
                 (cons 8 lname)
                 (cons 10 pt)))
)

(defun C:PXYZ ( / lname ss n i ent obj pt val path f)
  (setq lname "BGOL-PXYZ")
  (BGOL:PXYZ-EnsureLayer lname)
  (princ "\nSelect TEXT entities representing point data: ")
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq path (getfiled "Save Point Data" "" "csv" 1))
      (if path
        (progn
          (setq f (open path "w"))
          (if f
            (progn
              (write-line "Easting,Northing,Elevation,Value" f)
              (setq n 0)
              (setq i 0)
              (repeat (sslength ss)
                (setq ent (ssname ss i))
                (setq obj (vlax-ename->vla-object ent))
                (setq pt (vlax-get obj 'InsertionPoint))
                (setq val (vlax-get obj 'TextString))
                (write-line (strcat (rtos (car pt) 2 4) ","
                                     (rtos (cadr pt) 2 4) ","
                                     (rtos (caddr pt) 2 4) ","
                                     val) f)
                (BGOL:PXYZ-MarkPoint pt lname)
                (setq n (1+ n))
                (setq i (1+ i))
              )
              (close f)
              (princ (strcat "\nPXYZ: " (itoa n) " point(s) exported to " path "."))
            )
            (princ "\nCould not open the destination file for writing.")
          )
        )
        (princ "\nNo output file chosen. Export cancelled.")
      )
    )
    (princ "\nNo text selected.")
  )
  (princ)
)

(princ "\nPTXPORT-bgol.lsp loaded. Type PXYZ to export point data (X,Y,Z,text) to CSV.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
