;;; ---------------------------------------------------------------------
;;;  SETOUT-bgol.lsp
;;;  Command:  SOUT
;;;
;;;  PURPOSE
;;;  Processes all closed rectangle/polyline pillar entities on a chosen
;;;  layer (default "Pillar"), numbers each of their 4 corner points
;;;  plus the centroid, marks them in the drawing, and exports the full
;;;  numbered Easting/Northing point list as a ready-to-import CSV for a
;;;  Total Station setting-out job.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   SOUT   at the command line and press Enter.
;;;    3. Enter the layer holding the pillar rectangles (Enter for the
;;;       default "Pillar" layer).
;;;    4. Choose an output CSV file path in the standard save dialog.
;;;    5. Every pillar polyline on that layer gets its 4 corners and
;;;       center marked and numbered sequentially on layer "BGOL-SOUT",
;;;       and all point coordinates are written to the CSV.
;;;
;;;  NOTES
;;;    - Point numbering continues sequentially across all pillars in
;;;      the selection (4 corners + 1 center per pillar).
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of setting-out point
;;;      generation utilities common in construction survey drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:SOUT-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

(defun BGOL:SOUT-Mark (pt num lname / )
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 (cons 40 0.3)))
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 (list (+ (car pt) 0.4) (+ (cadr pt) 0.4) (caddr pt)))
                 (cons 40 1.2)
                 (cons 1 (itoa num))))
)

(defun BGOL:SOUT-Vertices (obj / n i pts pt)
  (setq pts '())
  (setq n (fix (vlax-curve-getEndParam obj)))
  (setq i 0)
  (while (<= i (1- (max n 1)))
    (setq pt (vlax-curve-getPointAtParam obj (float i)))
    (setq pts (append pts (list pt)))
    (setq i (1+ i))
  )
  pts
)

(defun BGOL:SOUT-Centroid (pts / n sumx sumy p)
  (setq sumx 0.0 sumy 0.0 n (length pts))
  (foreach p pts
    (setq sumx (+ sumx (car p)))
    (setq sumy (+ sumy (cadr p)))
  )
  (if (> n 0)
    (list (/ sumx n) (/ sumy n) 0.0)
    (list 0.0 0.0 0.0)
  )
)

(defun C:SOUT ( / lyr ss n i ent obj verts cen fname f ptnum vtx east north)
  (BGOL:SOUT-EnsureLayer "BGOL-SOUT")
  (setq lyr (getstring T "\nLayer holding pillar rectangles <Pillar>: "))
  (if (= lyr "") (setq lyr "Pillar"))
  (setq ss (ssget "_X" (list '(0 . "LWPOLYLINE") (cons 8 lyr))))
  (if ss
    (progn
      (setq fname (getfiled "Save Setting-Out Point CSV" "setout" "csv" 1))
      (if fname
        (progn
          (setq f (open fname "w"))
          (write-line "Point No,Easting,Northing" f)
          (setq ptnum 1)
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq obj (vlax-ename->vla-object ent))
            (setq verts (BGOL:SOUT-Vertices obj))
            (foreach vtx verts
              (BGOL:SOUT-Mark vtx ptnum "BGOL-SOUT")
              (setq east (rtos (car vtx) 2 3))
              (setq north (rtos (cadr vtx) 2 3))
              (write-line (strcat (itoa ptnum) "," east "," north) f)
              (setq ptnum (1+ ptnum))
            )
            (setq cen (BGOL:SOUT-Centroid verts))
            (BGOL:SOUT-Mark cen ptnum "BGOL-SOUT")
            (setq east (rtos (car cen) 2 3))
            (setq north (rtos (cadr cen) 2 3))
            (write-line (strcat (itoa ptnum) "," east "," north) f)
            (setq ptnum (1+ ptnum))
            (setq i (1+ i))
          )
          (close f)
          (princ (strcat "\nSOUT: " (itoa (1- ptnum)) " setting-out point(s) written to " fname))
        )
        (princ "\nNo output file selected. Aborted.")
      )
    )
    (princ (strcat "\nNo pillar polylines found on layer \"" lyr "\"."))
  )
  (princ)
)

(princ "\nSETOUT-bgol.lsp loaded. Type SOUT to generate numbered pillar setting-out points and CSV.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
