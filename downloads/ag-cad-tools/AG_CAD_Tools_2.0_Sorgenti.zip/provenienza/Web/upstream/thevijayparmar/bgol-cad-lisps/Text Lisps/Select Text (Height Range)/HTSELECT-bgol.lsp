;;; ---------------------------------------------------------------------
;;;  HTSELECT-bgol.lsp
;;;  Command:  SLHT
;;;
;;;  PURPOSE
;;;  Scans all TEXT entities in the drawing and builds a selection
;;;  set containing only those whose height falls within a
;;;  user-specified minimum/maximum range, then highlights that
;;;  selection so it's ready for further batch operations (move,
;;;  recolor, delete, change layer, etc.).
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   SLHT   at the command line and press Enter.
;;;    3. Enter the minimum text height.
;;;    4. Enter the maximum text height.
;;;    5. Every TEXT entity whose height falls within [min,max] is
;;;       selected and highlighted (grip-selected) for further use.
;;;
;;;  NOTES
;;;    - Uses (sssetfirst nil ss) so the qualifying text appears
;;;      selected (grips shown) immediately after the command ends,
;;;      ready for a follow-up MOVE/CHPROP/ERASE/etc.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of height-range text
;;;      selection utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and
;;;      are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:SLHT ( / alltext n i ent edata h minh maxh result cnt)
  (setq minh (getreal "\nMinimum text height: "))
  (if minh
    (progn
      (setq maxh (getreal "\nMaximum text height: "))
      (if maxh
        (progn
          (setq alltext (ssget "_X" '((0 . "TEXT"))))
          (if alltext
            (progn
              (setq n (sslength alltext))
              (setq result '())
              (setq i 0)
              (while (< i n)
                (setq ent (ssname alltext i))
                (setq edata (entget ent))
                (setq h (cdr (assoc 40 edata)))
                (if (and h (<= minh h maxh))
                  (setq result (append result (list ent)))
                )
                (setq i (1+ i))
              )
              (setq cnt (length result))
              (if (> cnt 0)
                (progn
                  (setq result (BGOL:SLHT-ListToSS result))
                  (sssetfirst nil result)
                  (princ (strcat "\nSLHT: " (itoa cnt) " text entity(ies) selected with height between "
                                 (rtos minh 2 3) " and " (rtos maxh 2 3) "."))
                )
                (princ "\nSLHT: no text entities found in that height range.")
              )
            )
            (princ "\nNo TEXT entities found in the drawing.")
          )
        )
        (princ "\nNo maximum height entered.")
      )
    )
    (princ "\nNo minimum height entered.")
  )
  (princ)
)

;; Build a selection set from a plain list of entity names.
(defun BGOL:SLHT-ListToSS (elist / ss e)
  (setq ss (ssadd))
  (foreach e elist (setq ss (ssadd e ss)))
  ss
)

(princ "\nHTSELECT-bgol.lsp loaded. Type SLHT to select text within a height range.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
