;;; ---------------------------------------------------------------------
;;;  TXTSNAP-bgol.lsp
;;;  Command:  TSNP
;;;
;;;  PURPOSE
;;;  Snaps a set of selected TEXT/MTEXT entities onto the nearest point
;;;  of a chosen target polyline, cleaning up scattered or inconsistently
;;;  placed labels into a visually aligned, professional presentation.
;;;  (For a fixed-offset alignment, first OFFSET the polyline and run
;;;  this routine against the offset copy instead of the original.)
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   TSNP   at the command line and press Enter.
;;;    3. Select the text entities to align.
;;;    4. Select the target polyline to snap them onto.
;;;    5. Each text's insertion point is moved to the nearest point on
;;;       the target polyline. A record of moved texts is placed on
;;;       layer "BGOL-TSNP" for reference (small markers at new
;;;       positions); the text entities themselves are simply relocated.
;;;
;;;  NOTES
;;;    - Uses vlax-curve-getClosestPointTo to find the nearest point on
;;;      the target curve for each text.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of text-to-curve snapping
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:TSNP-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

(defun BGOL:TSNP-MarkPoint (pt lname)
  (entmake (list '(0 . "POINT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbPoint")
                 (cons 10 pt)))
)

(defun C:TSNP ( / ssTxt ssPl plEnt plObj n i ent edata pt nearpt cnt)
  (BGOL:TSNP-EnsureLayer "BGOL-TSNP")
  (setq ssTxt (ssget '((0 . "TEXT,MTEXT"))))
  (if ssTxt
    (progn
      (setq plEnt (car (entsel "\nSelect target polyline to snap texts onto: ")))
      (if plEnt
        (progn
          (setq plObj (vlax-ename->vla-object plEnt))
          (setq cnt 0)
          (setq n (sslength ssTxt))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ssTxt i))
            (setq edata (entget ent))
            (setq pt (cdr (assoc 10 edata)))
            (setq nearpt (vlax-curve-getClosestPointTo plObj pt))
            (if nearpt
              (progn
                (entmod (subst (cons 10 nearpt) (assoc 10 edata) edata))
                (entupd ent)
                (BGOL:TSNP-MarkPoint nearpt "BGOL-TSNP")
                (setq cnt (1+ cnt))
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nTSNP: snapped " (itoa cnt) " text object(s) onto the target polyline (markers on BGOL-TSNP)."))
        )
        (princ "\nNo target polyline selected.")
      )
    )
    (princ "\nNo TEXT/MTEXT entities selected.")
  )
  (princ)
)

(princ "\nTXTSNAP-bgol.lsp loaded. Type TSNP to snap selected text onto a polyline.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
