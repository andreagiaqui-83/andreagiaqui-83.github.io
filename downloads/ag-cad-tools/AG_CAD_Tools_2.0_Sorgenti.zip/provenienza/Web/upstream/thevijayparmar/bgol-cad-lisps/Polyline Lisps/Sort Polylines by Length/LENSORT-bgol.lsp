;;; ---------------------------------------------------------------------
;;;  LENSORT-bgol.lsp
;;;  Command:  LSRT
;;;
;;;  PURPOSE
;;;  Filters a selection of polylines by length: every polyline shorter
;;;  than a user-specified threshold is moved onto a dedicated layer
;;;  ("BGOL-LSRT-SHORT"), making tiny, insignificant broken line
;;;  fragments (from imprecise digitizing, breakline errors, etc.) easy
;;;  to review, freeze, or delete in bulk.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   LSRT   at the command line and press Enter.
;;;    3. Enter the length threshold.
;;;    4. Select all the polylines to check against that threshold.
;;;    5. Every polyline shorter than the threshold is moved onto layer
;;;       "BGOL-LSRT-SHORT"; longer ones are left untouched.
;;;
;;;  NOTES
;;;    - Non-destructive: entities are moved to a review layer, not
;;;      deleted, so you can inspect the flagged short polylines before
;;;      committing to freeze/delete them.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of length-based polyline
;;;      filtering utilities common in civil/infrastructure drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:LSRT-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun C:LSRT ( / minlen ss n i ent obj len edata cnt flaggedcnt)
  (BGOL:LSRT-EnsureLayer "BGOL-LSRT-SHORT")
  (setq minlen (getdist "\nSpecify length threshold: "))
  (if minlen
    (progn
      (setq ss (ssget '((0 . "LWPOLYLINE"))))
      (if ss
        (progn
          (setq cnt 0)
          (setq flaggedcnt 0)
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq obj (vlax-ename->vla-object ent))
            (setq len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
            (if (< len minlen)
              (progn
                (setq edata (entget ent))
                (entmod (subst (cons 8 "BGOL-LSRT-SHORT") (assoc 8 edata) edata))
                (entupd ent)
                (setq flaggedcnt (1+ flaggedcnt))
              )
            )
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          (princ (strcat "\nLSRT: checked " (itoa cnt) " polyline(s); moved " (itoa flaggedcnt) " shorter than " (rtos minlen 2 2) " onto BGOL-LSRT-SHORT."))
        )
        (princ "\nNo LWPOLYLINE selected.")
      )
    )
    (princ "\nNo length threshold specified.")
  )
  (princ)
)

(princ "\nLENSORT-bgol.lsp loaded. Type LSRT to flag short polylines onto a review layer.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
