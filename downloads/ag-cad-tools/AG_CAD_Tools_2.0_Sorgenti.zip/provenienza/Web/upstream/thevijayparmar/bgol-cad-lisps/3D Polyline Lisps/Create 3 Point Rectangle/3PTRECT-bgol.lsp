;;; ---------------------------------------------------------------------
;;;  3PTRECT-bgol.lsp
;;;  Command:  3PR
;;;
;;;  PURPOSE
;;;  Draws a closed, true rectangular polyline from just THREE picked
;;;  points (e.g. three corners of a building shot with a Total
;;;  Station). Line 1-2 defines the primary edge/angle; point 3 defines
;;;  the perpendicular offset (width). The 4th corner is computed
;;;  mathematically, so the result is always a perfect rectangle even
;;;  if the picked points are not perfectly square.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   3PR   at the command line and press Enter.
;;;    3. Pick the 1st corner point.
;;;    4. Pick the 2nd corner point (defines the primary edge).
;;;    5. Pick a 3rd point near the opposite side (defines the width).
;;;    6. A closed rectangular LWPOLYLINE is created on layer
;;;       "BGOL-3PR" through the 4 computed corners.
;;;
;;;  NOTES
;;;    - The perpendicular distance from point 3 to line 1-2 sets the
;;;      rectangle width; the sign of the offset determines which side
;;;      of line 1-2 the rectangle is built on.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of 3-point rectangle
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:3PR-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:3PR-MakePolyline (p1 p2 p3 p4 lname / dxfdata)
  (setq dxfdata (list '(0 . "LWPOLYLINE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbPolyline")
                       '(90 . 4)
                       '(70 . 1)          ; closed
                       (cons 10 (list (car p1) (cadr p1)))
                       (cons 10 (list (car p2) (cadr p2)))
                       (cons 10 (list (car p3) (cadr p3)))
                       (cons 10 (list (car p4) (cadr p4)))
                 )
  )
  (entmake dxfdata)
)

(defun C:3PR ( / p1 p2 p3 ang perpang d p4 p3proj)
  (BGOL:3PR-EnsureLayer "BGOL-3PR")
  (setq p1 (getpoint "\nPick 1st corner point: "))
  (if p1
    (setq p2 (getpoint p1 "\nPick 2nd corner point: "))
  )
  (if (and p1 p2)
    (setq p3 (getpoint "\nPick 3rd point (defines rectangle width): "))
  )
  (if (and p1 p2 p3)
    (progn
      (setq ang (angle p1 p2))
      (setq perpang (+ ang (/ pi 2.0)))
      ;; perpendicular (signed) distance from p3 to the infinite line p1-p2
      (setq d (- (* (- (car p3) (car p1)) (sin ang)) (* (- (cadr p3) (cadr p1)) (cos ang))))
      (setq d (- d))
      ;; project p3 onto the p1-p2 direction to find how far along, not
      ;; needed for a true rectangle -- offset p1 and p2 by perp distance
      (setq p4 (polar p1 perpang d))
      (setq p3proj (polar p2 perpang d))
      (BGOL:3PR-MakePolyline p1 p2 p3proj p4 "BGOL-3PR")
      (princ "\n3-point rectangle created on layer BGOL-3PR.")
    )
    (princ "\nRectangle not created — 3 points required.")
  )
  (princ)
)

(princ "\n3PTRECT-bgol.lsp loaded. Type 3PR to draw a rectangle from 3 picked points.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
