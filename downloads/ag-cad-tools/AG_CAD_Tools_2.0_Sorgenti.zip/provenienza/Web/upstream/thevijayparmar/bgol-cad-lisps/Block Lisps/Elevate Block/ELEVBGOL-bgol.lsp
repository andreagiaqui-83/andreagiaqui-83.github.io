;;; ---------------------------------------------------------------------
;;;  ELEVBGOL-bgol.lsp
;;;  Command:  EZB
;;;
;;;  PURPOSE
;;;  Updates the Z value (elevation) of each selected block insertion
;;;  point to match the numeric value of the nearest TEXT/MTEXT entity
;;;  in the drawing. Intended for 2D survey drawings (blocks at Z = 0)
;;;  that need to be converted to properly elevated 3D-ready drawings
;;;  using nearby spot-level / elevation annotation text.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   EZB   at the command line and press Enter.
;;;    3. Select the block(s) whose elevation (Z) should be updated.
;;;    4. Press Enter to finish selection.
;;;    5. Each selected block's insertion point Z is set to the numeric
;;;       value of the nearest TEXT/MTEXT entity in the drawing. X and Y
;;;       are left unchanged. A marker circle is created at each block's
;;;       new position on layer "BGOL-EZB" for visual confirmation.
;;;
;;;  NOTES
;;;    - Only TEXT/MTEXT whose string content parses as a valid number
;;;      (via DISTOF) are considered candidate elevation labels; other
;;;      text is skipped.
;;;    - "Nearest" is measured as 2D planar distance from the block's
;;;      insertion point to the text's insertion point.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of matching blocks to nearby
;;;      elevation text common in survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:EZB-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

(defun BGOL:EZB-MarkPoint (pt lname / )
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 '(40 . 0.6)))
)

(defun BGOL:EZB-NumericText (str / v)
  ;; Returns a real number if str parses as one, else nil
  (setq v (distof str))
  v
)

(defun C:EZB ( / ss n i blkobj blkpt txtss m j txtent txtobj
                 txtpt txtstr txtval bestd bestv d newpt cnt)
  (BGOL:EZB-EnsureLayer "BGOL-EZB")
  (setq ss (ssget '((0 . "INSERT"))))
  (if ss
    (progn
      (setq txtss (ssget "_X" '((0 . "TEXT"))))
      (if (not txtss)
        (princ "\nNo TEXT entities found in drawing to use as elevation labels.")
        (progn
          (setq n (sslength ss))
          (setq i 0)
          (setq cnt 0)
          (while (< i n)
            (setq blkobj (vlax-ename->vla-object (ssname ss i)))
            (setq blkpt (vlax-get blkobj 'InsertionPoint))
            (setq bestd nil)
            (setq bestv nil)
            (setq m (sslength txtss))
            (setq j 0)
            (while (< j m)
              (setq txtent (ssname txtss j))
              (setq txtobj (vlax-ename->vla-object txtent))
              (setq txtstr (vlax-get txtobj 'TextString))
              (setq txtval (BGOL:EZB-NumericText txtstr))
              (if txtval
                (progn
                  (setq txtpt (vlax-get txtobj 'InsertionPoint))
                  (setq d (distance (list (car blkpt) (cadr blkpt))
                                     (list (car txtpt) (cadr txtpt))))
                  (if (or (null bestd) (< d bestd))
                    (progn
                      (setq bestd d)
                      (setq bestv txtval)
                    )
                  )
                )
              )
              (setq j (1+ j))
            )
            (if bestv
              (progn
                (setq newpt (list (car blkpt) (cadr blkpt) bestv))
                (vlax-put blkobj 'InsertionPoint newpt)
                (BGOL:EZB-MarkPoint newpt "BGOL-EZB")
                (setq cnt (1+ cnt))
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\n" (itoa cnt) " block(s) elevated to nearest text value (BGOL-EZB)."))
        )
      )
    )
    (princ "\nNo blocks selected.")
  )
  (princ)
)

(princ "\nELEVBGOL-bgol.lsp loaded. Type EZB to elevate blocks to nearest elevation text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
