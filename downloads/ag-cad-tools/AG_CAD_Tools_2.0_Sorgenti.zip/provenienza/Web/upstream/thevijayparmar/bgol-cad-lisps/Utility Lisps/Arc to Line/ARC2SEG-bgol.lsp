;;; ---------------------------------------------------------------------
;;;  ARC2SEG-bgol.lsp
;;;  Command:  A2S
;;;
;;;  PURPOSE
;;;  Converts a selected ARC or CIRCLE entity into an equivalent
;;;  LWPOLYLINE made of many small straight-line segments approximating
;;;  the original curve. Useful for exporting to formats/tools that
;;;  don't handle curved entities well, or as prep for vertex-based
;;;  routines that require straight-segment polylines.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   A2S   at the command line and press Enter.
;;;    3. Select an ARC or CIRCLE entity.
;;;    4. A new LWPOLYLINE approximating the curve is created on layer
;;;       "BGOL-A2S". The original entity is left untouched.
;;;
;;;  NOTES
;;;    - Segmentation density is fixed at 5-degree steps; edit the
;;;      *bgol-a2s-step* constant below to change resolution.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of arc/circle-to-polyline
;;;      conversion utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-a2s-step* (/ pi 36.0))  ; 5 degrees per segment

(defun BGOL:A2S-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 4)          ; cyan
                   '(6 . "Continuous")))
  )
)

(defun BGOL:A2S-MakePolyline (pointlist closed lname / dxfdata pt)
  (setq dxfdata (list '(0 . "LWPOLYLINE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbPolyline")
                       (cons 90 (length pointlist))
                       (cons 70 (if closed 1 0))
                 )
  )
  (foreach pt pointlist
    (setq dxfdata (append dxfdata (list (cons 10 pt))))
  )
  (entmake dxfdata)
)

(defun C:A2S ( / ent edata etype obj startang endang
                 pts closed step totalDist nseg i d)
  (BGOL:A2S-EnsureLayer "BGOL-A2S")
  (setq ent (car (entsel "\nSelect arc or circle to convert: ")))
  (if ent
    (progn
      (setq edata (entget ent))
      (setq etype (cdr (assoc 0 edata)))
      (setq obj (vlax-ename->vla-object ent))
      (cond
        ((= etype "ARC")
         (setq startang (vlax-get obj 'StartAngle))
         (setq endang   (vlax-get obj 'EndAngle))
         (if (< endang startang) (setq endang (+ endang (* 2 pi))))
         (setq step *bgol-a2s-step*)
         ;; Sample evenly by distance along the arc's curve parameterization
         (setq pts '())
         (setq totalDist (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
         (setq nseg (max 8 (fix (/ (- endang startang) step))))
         (setq i 0)
         (while (<= i nseg)
           (setq d (* totalDist (/ (float i) nseg)))
           (setq pts (append pts (list (vlax-curve-getPointAtDist obj d))))
           (setq i (1+ i))
         )
         (setq closed nil)
         (BGOL:A2S-MakePolyline pts closed "BGOL-A2S")
         (princ "\nArc converted to segmented polyline (BGOL-A2S).")
        )
        ((= etype "CIRCLE")
         (setq totalDist (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
         (setq nseg 72) ; 5-degree resolution around full circle
         (setq pts '())
         (setq i 0)
         (while (< i nseg)
           (setq d (* totalDist (/ (float i) nseg)))
           (setq pts (append pts (list (vlax-curve-getPointAtDist obj d))))
           (setq i (1+ i))
         )
         (setq closed T)
         (BGOL:A2S-MakePolyline pts closed "BGOL-A2S")
         (princ "\nCircle converted to segmented polyline (BGOL-A2S).")
        )
        (t
         (princ "\nSelected entity is not an ARC or CIRCLE. Nothing converted.")
        )
      )
    )
    (princ "\nNo entity selected.")
  )
  (princ)
)

(princ "\nARC2SEG-bgol.lsp loaded. Type A2S to convert an arc/circle to a segmented polyline.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
