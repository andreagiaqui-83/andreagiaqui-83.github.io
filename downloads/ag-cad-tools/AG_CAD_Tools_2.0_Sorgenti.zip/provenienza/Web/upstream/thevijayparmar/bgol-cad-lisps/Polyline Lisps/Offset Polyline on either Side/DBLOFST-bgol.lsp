;;; ---------------------------------------------------------------------
;;;  DBLOFST-bgol.lsp
;;;  Command:  DBOF
;;;
;;;  PURPOSE
;;;  Offsets every selected polyline on BOTH sides simultaneously, using
;;;  independently specified right-side and left-side distances. Built
;;;  for road/subdivision layout work where centerlines need edge lines
;;;  generated on both sides in a single pass instead of running OFFSET
;;;  twice per centerline.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   DBOF   at the command line and press Enter.
;;;    3. Select the centerline polyline(s) to offset.
;;;    4. Enter the right-side distance, then the left-side distance.
;;;    5. Two new offset polylines are created for every selected
;;;       centerline (one per side), on layer "BGOL-DBOF".
;;;
;;;  NOTES
;;;    - Uses the VLA Offset method twice per polyline (positive and
;;;      negative distance) so left/right sense is consistent regardless
;;;      of the original polyline's direction.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of double-sided polyline
;;;      offset utilities common in civil/road layout drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:DBOF-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:DBOF-SetLayer (obj lname)
  (vl-catch-all-apply 'vlax-put (list obj 'Layer lname))
)

(defun C:DBOF ( / ss n i ent obj rdist ldist res1 res2 item cnt)
  (BGOL:DBOF-EnsureLayer "BGOL-DBOF")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq rdist (getdist "\nRight side offset distance: "))
      (setq ldist (getdist "\nLeft side offset distance: "))
      (if (and rdist ldist)
        (progn
          (setq cnt 0)
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq obj (vlax-ename->vla-object ent))
            (setq res1 (vl-catch-all-apply 'vlax-invoke (list obj 'Offset rdist)))
            (if (and res1 (not (vl-catch-all-error-p res1)))
              (foreach item res1 (BGOL:DBOF-SetLayer item "BGOL-DBOF"))
            )
            (setq res2 (vl-catch-all-apply 'vlax-invoke (list obj 'Offset (- ldist))))
            (if (and res2 (not (vl-catch-all-error-p res2)))
              (foreach item res2 (BGOL:DBOF-SetLayer item "BGOL-DBOF"))
            )
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          (princ (strcat "\nDBOF: offset " (itoa cnt) " centerline(s) on both sides (right " (rtos rdist 2 2) ", left " (rtos ldist 2 2) ") onto BGOL-DBOF."))
        )
        (princ "\nOffset cancelled — both distances are required.")
      )
    )
    (princ "\nNo LWPOLYLINE selected.")
  )
  (princ)
)

(princ "\nDBLOFST-bgol.lsp loaded. Type DBOF to offset polylines on both sides at once.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
