;;; ---------------------------------------------------------------------
;;;  BATCHINS-bgol.lsp
;;;  Command:  BIN
;;;
;;;  PURPOSE
;;;  Inserts every .dwg file from a chosen folder into the current
;;;  drawing, laid out in a single row with a consistent user-specified
;;;  spacing gap between each inserted drawing. Useful for compiling many
;;;  individual sheet/section drawings into a single overview drawing.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   BIN   at the command line and press Enter.
;;;    3. In the file dialog, select any .dwg file inside the target
;;;       folder (the containing folder is used as the source).
;;;    4. Enter the spacing gap to use between each inserted drawing.
;;;    5. Every .dwg file in that folder is inserted in a row, each
;;;       offset from the previous by that drawing's width plus the gap.
;;;       Inserted blocks are placed on layer "BGOL-BIN".
;;;
;;;  NOTES
;;;    - Uses the native INSERT command via (command ...) for actual
;;;      block insertion, then queries the inserted block's bounding box
;;;      to compute the next offset.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of batch drawing-insertion
;;;      utilities common in CAD sheet-compilation workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:BIN-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:BIN-FolderOf (fpath / )
  (if (vl-filename-directory fpath)
    (vl-filename-directory fpath)
    fpath
  )
)

(defun C:BIN ( / picked folder files gap xoffset lname n i fn fullpath
                 lastEnt bbMin bbMax obj width)
  (setq picked (getfiled "Select any .dwg file in the target folder" "" "dwg" 4))
  (if picked
    (progn
      (setq folder (BGOL:BIN-FolderOf picked))
      (setq files (vl-directory-files folder "*.dwg" 1))
      (if files
        (progn
          (setq gap (getreal "\nSpacing between drawings: "))
          (if (and gap (>= gap 0))
            (progn
              (setq lname "BGOL-BIN")
              (BGOL:BIN-EnsureLayer lname)
              (setq xoffset 0.0)
              (setq n 0)
              (foreach fn files
                (setq fullpath (strcat folder "\\" fn))
                (setq lastEnt (entlast))
                (command "_.-insert" fullpath (list xoffset 0.0 0.0) 1 1 0)
                (setq lastEnt (if lastEnt (entnext lastEnt) (entnext)))
                (if lastEnt
                  (progn
                    (setq obj (vl-catch-all-apply 'vlax-ename->vla-object (list lastEnt)))
                    (if (not (vl-catch-all-error-p obj))
                      (progn
                        (vl-catch-all-apply 'vla-put-Layer (list obj lname))
                        (setq bbMin nil bbMax nil)
                        (vl-catch-all-apply
                          '(lambda ()
                             (vla-getboundingbox obj 'bbMinV 'bbMaxV)
                             (setq bbMin (vlax-safearray->list bbMinV))
                             (setq bbMax (vlax-safearray->list bbMaxV))
                          )
                          nil
                        )
                        (if (and bbMin bbMax)
                          (setq width (- (car bbMax) (car bbMin)))
                          (setq width 10.0)
                        )
                      )
                      (setq width 10.0)
                    )
                  )
                  (setq width 10.0)
                )
                (setq xoffset (+ xoffset width gap))
                (setq n (1+ n))
              )
              (princ (strcat "\nBIN: inserted " (itoa n) " drawing(s) from \"" folder "\"."))
            )
            (princ "\nInvalid spacing entered — command cancelled.")
          )
        )
        (princ (strcat "\nNo .dwg files found in \"" folder "\"."))
      )
    )
    (princ "\nNo file/folder selected.")
  )
  (princ)
)

(princ "\nBATCHINS-bgol.lsp loaded. Type BIN to batch-insert all drawings from a folder.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
