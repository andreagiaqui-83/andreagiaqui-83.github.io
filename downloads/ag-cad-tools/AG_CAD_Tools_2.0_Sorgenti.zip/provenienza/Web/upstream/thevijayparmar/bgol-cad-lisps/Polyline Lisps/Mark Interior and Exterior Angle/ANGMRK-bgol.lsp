;;; ---------------------------------------------------------------------
;;;  ANGMRK-bgol.lsp
;;;  Command:  AGMK
;;;
;;;  PURPOSE
;;;  Computes and marks the interior and exterior angle at every internal
;;;  vertex of a selected polyline. A small circular arc marker is drawn
;;;  at each vertex, with both angle values placed as text nearby. Useful
;;;  for site planning, structural analysis and road/pathway curve design
;;;  where vertex angles need to be quickly reviewed.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   AGMK   at the command line and press Enter.
;;;    3. Select the polyline to analyze.
;;;    4. Every internal vertex is marked with a small circle and two
;;;       angle labels (interior / exterior, in degrees), placed on
;;;       layer "BGOL-AGMK".
;;;
;;;  NOTES
;;;    - Interior angle is measured as the angle swept from the incoming
;;;      segment direction to the outgoing segment direction at each
;;;      vertex; exterior angle is simply 360 minus that value.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of vertex-angle marking
;;;      utilities common in civil/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:AGMK-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 4)          ; cyan
                   '(6 . "Continuous")))
  )
)

(defun BGOL:AGMK-GetVerts (obj / coords pts)
  (setq coords (vlax-safearray->list (vlax-variant-value (vlax-get obj 'Coordinates))))
  (setq pts '())
  (while coords
    (setq pts (append pts (list (list (car coords) (cadr coords)))))
    (setq coords (cddr coords))
  )
  pts
)

(defun BGOL:AGMK-MakeCircle (cen rad lname)
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 cen)
                 (cons 40 rad)))
)

(defun BGOL:AGMK-MakeText (pt txt ht lname)
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 txt)
                 '(100 . "AcDbText")))
)

(defun C:AGMK ( / ent obj verts n i v0 v1 v2 a1 a2 interior exterior
                  markrad markpt txt1 txt2 cnt)
  (BGOL:AGMK-EnsureLayer "BGOL-AGMK")
  (setq ent (car (entsel "\nSelect polyline to mark angles: ")))
  (if ent
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (setq verts (BGOL:AGMK-GetVerts obj))
      (setq n (length verts))
      (if (< n 3)
        (princ "\nPolyline needs at least 3 vertices to have an internal angle.")
        (progn
          (setq markrad 10.0)
          (setq cnt 0)
          (setq i 1)
          (while (< i (1- n))
            (setq v0 (nth (1- i) verts))
            (setq v1 (nth i verts))
            (setq v2 (nth (1+ i) verts))
            (setq a1 (angle v1 v0))
            (setq a2 (angle v1 v2))
            (setq interior (* (/ (rem (+ (- a2 a1) (* 2 pi)) (* 2 pi)) pi) 180.0))
            (setq exterior (- 360.0 interior))
            (BGOL:AGMK-MakeCircle v1 markrad "BGOL-AGMK")
            (setq markpt (list (+ (car v1) (* markrad 1.3)) (+ (cadr v1) (* markrad 0.3))))
            (setq txt1 (strcat (rtos interior 2 1) "d / " (rtos exterior 2 1) "d"))
            (BGOL:AGMK-MakeText markpt txt1 6.0 "BGOL-AGMK")
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          (princ (strcat "\nAGMK: marked interior/exterior angles at " (itoa cnt) " internal vertex/vertices (BGOL-AGMK)."))
        )
      )
    )
    (princ "\nNo polyline selected.")
  )
  (princ)
)

(princ "\nANGMRK-bgol.lsp loaded. Type AGMK to mark interior/exterior angles at polyline vertices.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
