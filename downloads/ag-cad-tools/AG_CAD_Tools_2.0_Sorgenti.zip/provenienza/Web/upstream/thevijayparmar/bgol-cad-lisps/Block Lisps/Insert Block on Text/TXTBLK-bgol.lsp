;;; ---------------------------------------------------------------------
;;;  TXTBLK-bgol.lsp
;;;  Command:  IBOT
;;;
;;;  PURPOSE
;;;  Inserts a copy of a chosen block precisely at the insertion point of
;;;  each selected TEXT (or MTEXT) entity. Useful for flagging or
;;;  symbolizing labeled points (e.g. point-number labels) with a marker
;;;  block, exactly centered on the text's insertion point.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   IBOT   at the command line and press Enter.
;;;    3. Select the text entity (or entities) whose insertion point
;;;       should receive a block.
;;;    4. Type the name of the block to insert.
;;;    5. A copy of that block is inserted at the exact insertion point
;;;       of each selected text, on layer "BGOL-IBOT".
;;;
;;;  NOTES
;;;    - Works on TEXT and MTEXT entities.
;;;    - Block scale and rotation default to 1/1/0; edit
;;;      *bgol-ibot-scale* and *bgol-ibot-rot* below to change defaults.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of placing a block at a
;;;      text's insertion point, common in survey point-flagging
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-ibot-scale* 1.0)
(setq *bgol-ibot-rot* 0.0)

(defun BGOL:IBOT-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 30)         ; orange
                   '(6 . "Continuous")))
  )
)

(defun BGOL:IBOT-InsertBlock (blkname pt lname scl rot / )
  (entmake (list '(0 . "INSERT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbBlockReference")
                 (cons 2 blkname)
                 (cons 10 pt)
                 (cons 41 scl)
                 (cons 42 scl)
                 (cons 43 scl)
                 (cons 50 rot)))
)

(defun C:IBOT ( / ss n i ent etype obj pt blkname lname cnt)
  (setq lname "BGOL-IBOT")
  (BGOL:IBOT-EnsureLayer lname)
  (setq ss (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
  (if ss
    (progn
      (setq blkname (getstring T "\nBlock name to insert at each text point: "))
      (if (not (tblsearch "BLOCK" blkname))
        (princ (strcat "\nBlock \"" blkname "\" is not defined in this drawing. Nothing inserted."))
        (progn
          (setq n (sslength ss))
          (setq i 0)
          (setq cnt 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq etype (cdr (assoc 0 (entget ent))))
            (setq obj (vlax-ename->vla-object ent))
            (setq pt
              (if (= etype "MTEXT")
                (vlax-get obj 'InsertionPoint)
                (vlax-get obj 'InsertionPoint)
              )
            )
            (BGOL:IBOT-InsertBlock blkname pt lname *bgol-ibot-scale* *bgol-ibot-rot*)
            (setq cnt (1+ cnt))
            (setq i (1+ i))
          )
          (princ (strcat "\n" (itoa cnt) " block(s) inserted at text insertion point(s) (BGOL-IBOT)."))
        )
      )
    )
    (princ "\nNo text entities selected.")
  )
  (princ)
)

(princ "\nTXTBLK-bgol.lsp loaded. Type IBOT to insert a block at each selected text's insertion point.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
