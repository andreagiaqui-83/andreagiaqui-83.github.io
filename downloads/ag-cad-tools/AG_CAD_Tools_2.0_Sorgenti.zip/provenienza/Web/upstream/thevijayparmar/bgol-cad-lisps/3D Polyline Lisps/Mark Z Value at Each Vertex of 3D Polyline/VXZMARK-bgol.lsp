;;; ---------------------------------------------------------------------
;;;  VXZMARK-bgol.lsp
;;;  Command:  ZMK
;;;
;;;  PURPOSE
;;;  Labels every vertex of one or more selected 3D polylines with a
;;;  text callout showing that vertex's Z (elevation) value. 3D
;;;  polylines are preferred for infrastructure work because each
;;;  vertex carries its own elevation, but reading those values inside
;;;  the CAD interface normally means walking the Properties panel
;;;  vertex-by-vertex. This routine automates that.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   ZMK   at the command line and press Enter.
;;;    3. Select one or multiple 3D polylines whose vertex elevations
;;;       you want marked.
;;;    4. A text entity is created at each vertex showing its Z value,
;;;       placed on a dedicated layer, "BGOL-ZMK".
;;;
;;;  NOTES
;;;    - Supports multi-selection: label many 3D polylines in a single
;;;      command run.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of vertex Z-marking
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-zmk-precision* 3)

(defun BGOL:ZMK-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 140)        ; light blue
                   '(6 . "Continuous")))
  )
)

(defun BGOL:ZMK-MakeText (pt lname / dxfdata)
  (setq dxfdata (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbText")
                       (cons 10 pt)
                       '(40 . 2.0)
                       (cons 1 (rtos (caddr pt) 2 *bgol-zmk-precision*))
                 )
  )
  (entmake dxfdata)
)

;; Walk VERTEX sub-entities of a legacy 3D POLYLINE
(defun BGOL:ZMK-PolyVertices (ent / sub sdata pts)
  (setq pts '())
  (setq sub (entnext ent))
  (while (and sub (/= (cdr (assoc 0 (entget sub))) "SEQEND"))
    (setq sdata (entget sub))
    (if (= (cdr (assoc 0 sdata)) "VERTEX")
      (setq pts (append pts (list (cdr (assoc 10 sdata)))))
    )
    (setq sub (entnext sub))
  )
  pts
)

;; Extract (x y z) for each vertex of an LWPOLYLINE, using elevation (38) as Z
(defun BGOL:ZMK-LWVertices (ent / edata elev pts)
  (setq edata (entget ent))
  (setq elev (cdr (assoc 38 edata)))
  (if (not elev) (setq elev 0.0))
  (setq pts '())
  (foreach pair edata
    (if (= (car pair) 10)
      (setq pts (append pts (list (list (car (cdr pair)) (cadr (cdr pair)) elev))))
    )
  )
  pts
)

(defun C:ZMK ( / ss n i ent etype pts total lname)
  (setq lname "BGOL-ZMK")
  (BGOL:ZMK-EnsureLayer lname)
  (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq total 0)
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq etype (cdr (assoc 0 (entget ent))))
        (cond
          ((= etype "POLYLINE") (setq pts (BGOL:ZMK-PolyVertices ent)))
          ((= etype "LWPOLYLINE") (setq pts (BGOL:ZMK-LWVertices ent)))
          (t (setq pts '()))
        )
        (foreach pt pts
          (BGOL:ZMK-MakeText pt lname)
          (setq total (1+ total))
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nZ-value labels created at " (itoa total) " vertices across "
                      (itoa n) " polyline(s), layer " lname "."))
    )
    (princ "\nNo 3D polylines selected.")
  )
  (princ)
)

(princ "\nVXZMARK-bgol.lsp loaded. Type ZMK to mark the Z value at every vertex of selected 3D polylines.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
