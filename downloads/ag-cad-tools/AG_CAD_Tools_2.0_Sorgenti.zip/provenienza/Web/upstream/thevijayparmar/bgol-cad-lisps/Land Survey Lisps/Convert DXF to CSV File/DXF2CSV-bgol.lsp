;;; ---------------------------------------------------------------------
;;;  DXF2CSV-bgol.lsp
;;;  Command:  DXC
;;;
;;;  PURPOSE
;;;  Scans a drawing for coded point text on a chosen layer (default
;;;  "Code") and rebuilds a clean Sl.No / Easting / Northing / Elevation /
;;;  Remark CSV point list from the text insertion points and their
;;;  string values. Useful for recovering structured point data from a
;;;  DXF/drawing when the original instrument CSV export is unavailable.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   DXC   at the command line and press Enter.
;;;    3. Enter the layer name holding the coded point text (Enter for
;;;       the default "Code" layer).
;;;    4. Choose an output CSV file path in the standard save dialog.
;;;    5. Every TEXT/MTEXT entity on that layer is read (insertion point
;;;       + string), written to CSV with an incrementing serial number,
;;;       and marked with a small circle on layer "BGOL-DXC" so you can
;;;       see exactly which points were exported.
;;;
;;;  NOTES
;;;    - Drawing convention assumed: X = Easting, Y = Northing,
;;;      Z = Elevation.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of reconstructing point
;;;      lists from coded DXF text common in total-station survey
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:DXC-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:DXC-MarkPoint (pt lname / )
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 '(40 . 0.35)))
)

(defun C:DXC ( / lyr ss n i ent edata pt txt fname f sl east north elev remark)
  (BGOL:DXC-EnsureLayer "BGOL-DXC")
  (setq lyr (getstring T "\nLayer holding coded point text <Code>: "))
  (if (= lyr "") (setq lyr "Code"))
  (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 8 lyr))))
  (if ss
    (progn
      (setq fname (getfiled "Save Point List CSV" "points" "csv" 1))
      (if fname
        (progn
          (setq f (open fname "w"))
          (write-line "Sl No,Easting,Northing,Elevation,Remark" f)
          (setq n (sslength ss))
          (setq i 0)
          (setq sl 1)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq pt (cdr (assoc 10 edata)))
            (setq txt (cdr (assoc 1 edata)))
            (if (and pt txt)
              (progn
                (setq east  (rtos (car pt) 2 3))
                (setq north (rtos (cadr pt) 2 3))
                (setq elev  (if (caddr pt) (rtos (caddr pt) 2 3) "0.000"))
                (setq remark txt)
                (write-line (strcat (itoa sl) "," east "," north "," elev "," remark) f)
                (BGOL:DXC-MarkPoint pt "BGOL-DXC")
                (setq sl (1+ sl))
              )
            )
            (setq i (1+ i))
          )
          (close f)
          (princ (strcat "\nDXC: " (itoa (1- sl)) " point(s) written to " fname))
        )
        (princ "\nNo output file selected. Aborted.")
      )
    )
    (princ (strcat "\nNo TEXT/MTEXT entities found on layer \"" lyr "\"."))
  )
  (princ)
)

(princ "\nDXF2CSV-bgol.lsp loaded. Type DXC to export coded point text to a CSV point list.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
