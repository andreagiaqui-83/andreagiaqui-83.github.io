;;; ---------------------------------------------------------------------
;;;  COORDGRID-bgol.lsp
;;;  Command:  CGRD
;;;
;;;  PURPOSE
;;;  Draws a full Easting/Northing coordinate grid across a rectangular
;;;  extent defined by two picked corner points, at a chosen spacing,
;;;  with axis-labeled text along the bottom (Easting, "E") and left
;;;  edge (Northing, "N"). Speeds up adding a reference grid to a survey
;;;  base map or boundary drawing.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   CGRD   at the command line and press Enter.
;;;    3. Pick the Lower-left corner and Top-right corner of the area to
;;;       cover.
;;;    4. Enter the grid spacing.
;;;    5. A full set of vertical and horizontal grid lines, rounded
;;;       outward to the nearest spacing multiple, is drawn on layer
;;;       "BGOL-CGRD", with "E ####" labels along the bottom and
;;;       "N ####" labels along the left edge.
;;;
;;;  NOTES
;;;    - Grid extents are rounded outward to the nearest multiple of the
;;;      spacing so lines land on clean round coordinate values.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of coordinate-grid overlay
;;;      utilities common in land-survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:CGRD-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 8)          ; grey
                   '(6 . "Continuous")))
  )
)

(defun BGOL:CGRD-Line (p1 p2 lname / )
  (entmake (list '(0 . "LINE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbLine")
                 (cons 10 p1)
                 (cons 11 p2)))
)

(defun BGOL:CGRD-Text (pt txt ht lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 txt)))
)

(defun BGOL:CGRD-FloorTo (v gs) (* gs (fix (/ v gs))))
(defun BGOL:CGRD-CeilTo  (v gs) (* gs (1+ (fix (/ v gs)))))

(defun C:CGRD ( / p1 p2 gs xmin xmax ymin ymax x y th)
  (BGOL:CGRD-EnsureLayer "BGOL-CGRD")
  (setq p1 (getpoint "\nLower left corner: "))
  (setq p2 (if p1 (getpoint p1 "\nTop right corner: ")))
  (if (and p1 p2)
    (progn
      (setq gs (getreal "\nEnter grid spacing: "))
      (if (and gs (> gs 0))
        (progn
          (setq xmin (BGOL:CGRD-FloorTo (min (car p1) (car p2)) gs))
          (setq xmax (BGOL:CGRD-CeilTo  (max (car p1) (car p2)) gs))
          (setq ymin (BGOL:CGRD-FloorTo (min (cadr p1) (cadr p2)) gs))
          (setq ymax (BGOL:CGRD-CeilTo  (max (cadr p1) (cadr p2)) gs))
          (setq th (* gs 0.08))
          ;; vertical lines (constant X) + Easting labels along bottom
          (setq x xmin)
          (while (<= x xmax)
            (BGOL:CGRD-Line (list x ymin 0.0) (list x ymax 0.0) "BGOL-CGRD")
            (BGOL:CGRD-Text (list x (- ymin (* gs 0.15)) 0.0)
                             (strcat "E " (rtos x 2 0)) th "BGOL-CGRD")
            (setq x (+ x gs))
          )
          ;; horizontal lines (constant Y) + Northing labels along left
          (setq y ymin)
          (while (<= y ymax)
            (BGOL:CGRD-Line (list xmin y 0.0) (list xmax y 0.0) "BGOL-CGRD")
            (BGOL:CGRD-Text (list (- xmin (* gs 0.35)) y 0.0)
                             (strcat "N " (rtos y 2 0)) th "BGOL-CGRD")
            (setq y (+ y gs))
          )
          (princ (strcat "\nCGRD: coordinate grid drawn at spacing " (rtos gs 2 2) "."))
        )
        (princ "\nInvalid grid spacing. Aborted.")
      )
    )
    (princ "\nGrid extent not fully defined.")
  )
  (princ)
)

(princ "\nCOORDGRID-bgol.lsp loaded. Type CGRD to draw a labeled Easting/Northing grid.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
