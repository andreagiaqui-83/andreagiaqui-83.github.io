;;; ---------------------------------------------------------------------
;;;  LYTALIGN-bgol.lsp
;;;  Commands:  RTLA  (associate reference angle)
;;;             RTLM  (match/rotate text for current layout twist)
;;;
;;;  PURPOSE
;;;  A two-command pair that keeps Model Space text readable inside a
;;;  rotated paper-space Layout viewport. RTLA stores a reference
;;;  angle on selected text as XDATA. RTLM reads the active layout's
;;;  viewport twist angle and rotates a matching COPY of that text
;;;  (created fresh in the current space, on its own layer) so it
;;;  displays upright/readable relative to the rotated viewport.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. In Model Space, type   RTLA   and select the text entities
;;;       that should carry a reference angle (defaults to each
;;;       text's own current rotation).
;;;    3. Switch to (or activate) the target Layout / viewport.
;;;    4. Type   RTLM   and enter the viewport's twist angle when
;;;       prompted. A rotated copy of each tagged text is created on
;;;       layer "BGOL-RTLM", compensating for the layout rotation so
;;;       it reads correctly on the printed sheet.
;;;
;;;  NOTES
;;;    - Reference angle is stored as XDATA under application name
;;;      "BGOL-RTLA" (registered automatically).
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of layout-rotation text
;;;      compensation utilities common in CAD/survey drafting
;;;      workflows, but the code, command names and file name here
;;;      are new and are NOT copied from, nor identical to, any
;;;      specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:RTLM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 5)          ; blue
                   '(6 . "Continuous")))
  )
)

(defun BGOL:RTLA-EnsureApp (appname / )
  (if (not (tblsearch "APPID" appname))
    (regapp appname)
  )
)

(defun C:RTLA ( / ss n i ent edata refang txval)
  (BGOL:RTLA-EnsureApp "BGOL-RTLA")
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq refang (cdr (assoc 50 edata)))
        (if (not refang) (setq refang 0.0))
        (setq edata (append edata
                             (list (list -3 (list "BGOL-RTLA" (cons 1040 refang))))
                    )
        )
        (entmod edata)
        (setq i (1+ i))
      )
      (princ (strcat "\nRTLA: reference angle stored on " (itoa n) " text entity(ies)."))
    )
    (princ "\nNo text selected.")
  )
  (princ)
)

(defun BGOL:RTLM-GetRefAngle (ent / edata xd applist rec)
  (setq edata (entget ent '("BGOL-RTLA")))
  (setq xd (assoc -3 edata))
  (if xd
    (progn
      (setq applist (cdr xd))
      (setq rec (assoc "BGOL-RTLA" applist))
      (if rec
        (cdr (assoc 1040 (cdr rec)))
        nil
      )
    )
    nil
  )
)

(defun C:RTLM ( / ss n i ent edata refang twist newang pt ht style newdata)
  (BGOL:RTLM-EnsureLayer "BGOL-RTLM")
  (setq twist (getreal "\nCurrent layout/viewport twist angle (degrees) <0>: "))
  (if (not twist) (setq twist 0.0))
  (setq twist (* twist (/ pi 180.0)))
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq refang (BGOL:RTLM-GetRefAngle ent))
        (if (not refang) (setq refang (cdr (assoc 50 edata))))
        (setq newang (- refang twist))
        (setq pt (cdr (assoc 10 edata)))
        (setq ht (cdr (assoc 40 edata)))
        (setq newdata (list '(0 . "TEXT")
                             '(100 . "AcDbEntity")
                             (cons 8 "BGOL-RTLM")
                             '(100 . "AcDbText")
                             (cons 10 pt)
                             (cons 40 ht)
                             (cons 1 (cdr (assoc 1 edata)))
                             (cons 50 newang)
                       )
        )
        (entmake newdata)
        (setq i (1+ i))
      )
      (princ (strcat "\nRTLM: " (itoa n) " layout-compensated text copy(ies) created on layer BGOL-RTLM."))
    )
    (princ "\nNo tagged text selected.")
  )
  (princ)
)

(princ "\nLYTALIGN-bgol.lsp loaded. Type RTLA to tag text, RTLM to create layout-compensated copies.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
