;;; ---------------------------------------------------------------------
;;;  PLELEV-bgol.lsp
;;;  Command:  3DEV
;;;
;;;  PURPOSE
;;;  Walks every vertex of one or more selected 3D polylines and writes
;;;  a plain TEXT entity showing that vertex's Z (elevation) value,
;;;  positioned at the vertex. Makes elevation data that is normally
;;;  hidden inside the polyline visible directly on the drawing.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   3DEV   at the command line and press Enter.
;;;    3. Select one or more 3D polylines (or LWPOLYLINEs with varying
;;;       elevation via vertex Z).
;;;    4. An elevation TEXT label is created at every vertex, placed on
;;;       a dedicated layer "BGOL-3DEV", so it can be toggled or frozen
;;;       independently of the source geometry.
;;;
;;;  NOTES
;;;    - Text height and decimal precision are controlled by the
;;;      *bgol-3dev-height* and *bgol-3dev-precision* constants below.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of vertex-elevation
;;;      labeling utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-3dev-height* 2.0)
(setq *bgol-3dev-precision* 3)

(defun BGOL:3DEV-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:3DEV-MakeText (pt zval lname / dxfdata)
  (setq dxfdata (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbText")
                       (cons 10 pt)
                       (cons 40 *bgol-3dev-height*)
                       (cons 1 (rtos zval 2 *bgol-3dev-precision*))
                 )
  )
  (entmake dxfdata)
)

(defun BGOL:3DEV-ProcessEntity (ent lname / obj etype vlist)
  (setq etype (cdr (assoc 0 (entget ent))))
  (cond
    ;; Lightweight polyline - may carry per-vertex elevation via 3D flag
    ((= etype "LWPOLYLINE")
     (setq obj (vlax-ename->vla-object ent))
     (setq vlist (BGOL:3DEV-LWVertices ent))
     (foreach pt vlist
       (BGOL:3DEV-MakeText pt (caddr pt) lname)
     )
    )
    ;; Old-style 3D POLYLINE - walk VERTEX sub-entities
    ((= etype "POLYLINE")
     (setq vlist (BGOL:3DEV-PolyVertices ent))
     (foreach pt vlist
       (BGOL:3DEV-MakeText pt (caddr pt) lname)
     )
    )
  )
)

;; Extract (x y z) for each vertex of an LWPOLYLINE, using elevation (38) as Z
(defun BGOL:3DEV-LWVertices (ent / edata elev pts)
  (setq edata (entget ent))
  (setq elev (cdr (assoc 38 edata)))
  (if (not elev) (setq elev 0.0))
  (setq pts '())
  (foreach pair edata
    (if (= (car pair) 10)
      (setq pts (append pts (list (list (car (cdr pair)) (cadr (cdr pair)) elev))))
    )
  )
  pts
)

;; Walk VERTEX sub-entities of a legacy 3D POLYLINE
(defun BGOL:3DEV-PolyVertices (ent / sub sdata pts)
  (setq pts '())
  (setq sub (entnext ent))
  (while (and sub (/= (cdr (assoc 0 (entget sub))) "SEQEND"))
    (setq sdata (entget sub))
    (if (= (cdr (assoc 0 sdata)) "VERTEX")
      (setq pts (append pts (list (cdr (assoc 10 sdata)))))
    )
    (setq sub (entnext sub))
  )
  pts
)

(defun C:3DEV ( / ss n i ent)
  (BGOL:3DEV-EnsureLayer "BGOL-3DEV")
  (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (BGOL:3DEV-ProcessEntity ent "BGOL-3DEV")
        (setq i (1+ i))
      )
      (princ (strcat "\nElevation labels created for " (itoa n) " polyline(s) on layer BGOL-3DEV."))
    )
    (princ "\nNo polylines selected.")
  )
  (princ)
)

(princ "\nPLELEV-bgol.lsp loaded. Type 3DEV to label vertex elevations of a 3D polyline.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
