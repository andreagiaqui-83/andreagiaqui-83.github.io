;;; ---------------------------------------------------------------------
;;;  ELEVCOUNT-bgol.lsp
;;;  Command:  ELVN
;;;
;;;  PURPOSE
;;;  Given two selected elevation TEXT entities, lets the user specify
;;;  exactly how many intermediate elevation values to generate between
;;;  them (a count, not a distance). The routine linearly interpolates
;;;  that many evenly-spaced values and creates a text label for each.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   ELVN   at the command line and press Enter.
;;;    3. Select the first (start) elevation TEXT entity.
;;;    4. Select the second (end) elevation TEXT entity.
;;;    5. Enter how many intermediate levels to generate.
;;;    6. That many evenly-spaced elevation TEXT entities are created
;;;       along the straight line between the two references, on layer
;;;       "BGOL-ELVN".
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of count-driven elevation
;;;      interpolation utilities common in survey/profile drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:ELVN-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 4)          ; cyan
                   '(6 . "Continuous")))
  )
)

(defun BGOL:ELVN-MakeText (pt val ht lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 (rtos val 2 2))))
)

(defun C:ELVN ( / e1 e2 ed1 ed2 v1 v2 p1 p2 n i frac pt elev ht totalDist)
  (BGOL:ELVN-EnsureLayer "BGOL-ELVN")
  (setq e1 (entsel "\nSelect first (start) elevation text: "))
  (setq e2 (if e1 (entsel "\nSelect second (end) elevation text: ")))
  (if (and e1 e2)
    (progn
      (setq ed1 (entget (car e1)))
      (setq ed2 (entget (car e2)))
      (setq v1 (atof (cdr (assoc 1 ed1))))
      (setq v2 (atof (cdr (assoc 1 ed2))))
      (setq p1 (cdr (assoc 10 ed1)))
      (setq p2 (cdr (assoc 10 ed2)))
      (setq ht (cdr (assoc 40 ed1)))
      (if (not ht) (setq ht 2.5))
      (setq totalDist (distance p1 p2))
      (setq n (getint "\nNumber of levels to interpolate: "))
      (if (and n (> n 0))
        (progn
          (setq i 1)
          (while (<= i n)
            (setq frac (/ (float i) (1+ n)))
            (setq pt (polar p1 (angle p1 p2) (* frac totalDist)))
            (setq elev (+ v1 (* frac (- v2 v1))))
            (BGOL:ELVN-MakeText pt elev ht "BGOL-ELVN")
            (setq i (1+ i))
          )
          (princ (strcat "\nELVN: " (itoa n) " intermediate elevation(s) created."))
        )
        (princ "\nInvalid count. Aborted.")
      )
    )
    (princ "\nTwo elevation text entities are required.")
  )
  (princ)
)

(princ "\nELEVCOUNT-bgol.lsp loaded. Type ELVN to interpolate N intermediate elevations.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
