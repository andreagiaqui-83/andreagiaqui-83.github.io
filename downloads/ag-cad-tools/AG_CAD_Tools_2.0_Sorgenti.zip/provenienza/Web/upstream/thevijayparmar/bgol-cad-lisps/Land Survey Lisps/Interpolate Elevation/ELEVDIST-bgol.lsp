;;; ---------------------------------------------------------------------
;;;  ELEVDIST-bgol.lsp
;;;  Command:  ELVD
;;;
;;;  PURPOSE
;;;  Given two selected elevation TEXT entities, fills in as many
;;;  intermediate elevation labels as fit between them at a fixed
;;;  real-world distance interval (e.g. every 3 m or 5 m), rather than a
;;;  fixed count. The number of generated points automatically adapts to
;;;  the distance between the two reference texts.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   ELVD   at the command line and press Enter.
;;;    3. Select the first (start) elevation TEXT entity.
;;;    4. Select the second (end) elevation TEXT entity.
;;;    5. Enter the desired distance interval.
;;;    6. Intermediate elevation TEXT entities are linearly interpolated
;;;       and placed along the straight line between the two references,
;;;       spaced at that interval, on layer "BGOL-ELVD".
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of distance-driven elevation
;;;      interpolation utilities common in survey/profile drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:ELVD-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

(defun BGOL:ELVD-MakeText (pt val ht lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 (rtos val 2 2))))
)

(defun C:ELVD ( / e1 e2 ed1 ed2 v1 v2 p1 p2 step totalDist n i frac pt elev ht)
  (BGOL:ELVD-EnsureLayer "BGOL-ELVD")
  (setq e1 (entsel "\nSelect first (start) elevation text: "))
  (setq e2 (if e1 (entsel "\nSelect second (end) elevation text: ")))
  (if (and e1 e2)
    (progn
      (setq ed1 (entget (car e1)))
      (setq ed2 (entget (car e2)))
      (setq v1 (atof (cdr (assoc 1 ed1))))
      (setq v2 (atof (cdr (assoc 1 ed2))))
      (setq p1 (cdr (assoc 10 ed1)))
      (setq p2 (cdr (assoc 10 ed2)))
      (setq ht (cdr (assoc 40 ed1)))
      (if (not ht) (setq ht 2.5))
      (setq step (getreal "\nEnter distance interval: "))
      (if (and step (> step 0))
        (progn
          (setq totalDist (distance p1 p2))
          (setq n (1- (fix (/ totalDist step))))
          (if (< n 1)
            (princ "\nInterval too large for the distance between the two points.")
            (progn
              (setq i 1)
              (while (<= i n)
                (setq frac (/ (* i step) totalDist))
                (setq pt (polar p1 (angle p1 p2) (* i step)))
                (setq elev (+ v1 (* frac (- v2 v1))))
                (BGOL:ELVD-MakeText pt elev ht "BGOL-ELVD")
                (setq i (1+ i))
              )
              (princ (strcat "\nELVD: " (itoa n) " intermediate elevation(s) created at " (rtos step 2 2) " spacing."))
            )
          )
        )
        (princ "\nInvalid interval. Aborted.")
      )
    )
    (princ "\nTwo elevation text entities are required.")
  )
  (princ)
)

(princ "\nELEVDIST-bgol.lsp loaded. Type ELVD to interpolate elevations at a fixed distance interval.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
