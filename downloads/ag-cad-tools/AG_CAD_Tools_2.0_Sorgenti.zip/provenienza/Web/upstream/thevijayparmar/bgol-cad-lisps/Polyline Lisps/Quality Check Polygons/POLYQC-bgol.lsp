;;; ---------------------------------------------------------------------
;;;  POLYQC-bgol.lsp
;;;  Command:  PQC
;;;
;;;  PURPOSE
;;;  QA check for CAD-to-GIS workflows: verifies whether selected
;;;  polylines are TRULY closed by their DXF "Closed" property flag
;;;  (group 70, bit 1) rather than just visually appearing closed.
;;;  Computes and totals the area of confirmed-closed polygons, marks
;;;  each checked polygon, and exports a CSV report.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PQC   at the command line and press Enter.
;;;    3. Select one or more polylines intended to represent polygons.
;;;    4. Each polyline's true Closed flag is checked; a small marker is
;;;       placed at its first vertex on layer "BGOL-PQC" (green if truly
;;;       closed, red if not). A CSV report and the total area of
;;;       confirmed-closed objects are printed to the command line.
;;;
;;;  NOTES
;;;    - A polyline can look visually closed (start point = end point)
;;;      while its Closed property is still 0/No — this routine flags
;;;      that specific mismatch, which AutoCAD's native overlap tools do
;;;      not check for.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of closed-polygon QA
;;;      utilities common in CAD-to-GIS drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:PQC-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:PQC-MarkPoint (pt lname col)
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 (cons 62 col)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 (cons 40 6.0)))
)

(defun C:PQC ( / ss n i ent edata flag closedp obj area totalarea
                 fname fh firstpt cnt closedcnt)
  (BGOL:PQC-EnsureLayer "BGOL-PQC")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq fname (strcat (getvar "DWGPREFIX") "BGOL-PQC-AreaTable.csv"))
      (setq fh (open fname "w"))
      (write-line "Handle,ClosedFlag,Area" fh)
      (setq totalarea 0.0)
      (setq cnt 0)
      (setq closedcnt 0)
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq flag (cdr (assoc 70 edata)))
        (setq closedp (= 1 (logand 1 flag)))
        (setq firstpt (cdr (assoc 10 edata)))
        (setq area 0.0)
        (if closedp
          (progn
            (setq obj (vlax-ename->vla-object ent))
            (setq area (vlax-curve-getArea obj))
            (setq totalarea (+ totalarea area))
            (setq closedcnt (1+ closedcnt))
            (BGOL:PQC-MarkPoint firstpt "BGOL-PQC" 3)
          )
          (BGOL:PQC-MarkPoint firstpt "BGOL-PQC" 1)
        )
        (write-line (strcat (cdr (assoc 5 edata)) "," (if closedp "Yes" "No") "," (rtos area 2 3)) fh)
        (setq cnt (1+ cnt))
        (setq i (1+ i))
      )
      (close fh)
      (princ (strcat "\nPQC: checked " (itoa cnt) " polyline(s); " (itoa closedcnt) " truly closed."))
      (princ (strcat "\nTotal Area of Selected Objects (Closed): " (rtos totalarea 2 3)))
      (princ (strcat "\nCSV report written to " fname " (markers on BGOL-PQC)."))
    )
    (princ "\nNo LWPOLYLINE selected.")
  )
  (princ)
)

(princ "\nPOLYQC-bgol.lsp loaded. Type PQC to QA-check polygon Closed flags and export a CSV area report.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
