;;; ---------------------------------------------------------------------
;;;  RTPARALLEL-bgol.lsp
;;;  Command:  RT2P
;;;
;;;  PURPOSE
;;;  Rotates one or more selected TEXT/MTEXT entities so they are
;;;  exactly parallel to the direction defined by two picked
;;;  reference points -- e.g. aligning street-name labels parallel to
;;;  a road, or plot numbers parallel to a parcel boundary, without
;;;  eyeballing the angle.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   RT2P   at the command line and press Enter.
;;;    3. Select the text entity/entities to rotate.
;;;    4. Pick the first reference point.
;;;    5. Pick the second reference point.
;;;    6. Every selected text entity is rotated to the exact angle
;;;       between the two picked points; insertion points are left
;;;       unchanged.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of two-point text-rotation
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:RT2P ( / ss n i ent p1 p2 ang edata)
  (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if ss
    (progn
      (setq p1 (getpoint "\nFirst reference point: "))
      (if p1
        (progn
          (setq p2 (getpoint p1 "\nSecond reference point: "))
          (if p2
            (progn
              (setq ang (angle p1 p2))
              (setq n (sslength ss))
              (setq i 0)
              (while (< i n)
                (setq ent (ssname ss i))
                (setq edata (entget ent))
                (setq edata (subst (cons 50 ang) (assoc 50 edata) edata))
                (entmod edata)
                (entupd ent)
                (setq i (1+ i))
              )
              (princ (strcat "\nRT2P: " (itoa n) " text entity(ies) rotated parallel to the picked reference line."))
            )
            (princ "\nNo second point picked.")
          )
        )
        (princ "\nNo first point picked.")
      )
    )
    (princ "\nNo text selected.")
  )
  (princ)
)

(princ "\nRTPARALLEL-bgol.lsp loaded. Type RT2P to rotate text parallel to two picked points.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
