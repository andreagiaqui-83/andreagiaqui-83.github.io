;;; ---------------------------------------------------------------------
;;;  TEXTELEV-bgol.lsp
;;;  Command:  TXZ
;;;
;;;  PURPOSE
;;;  Fixes elevation-label TEXT entities whose caption shows a real
;;;  elevation (e.g. "484.947") but whose actual Z coordinate is still
;;;  0. Reads the numeric value in each selected text's string and
;;;  writes that same number into the entity's true Z coordinate, so
;;;  downstream software that trusts geometry (not text) sees the
;;;  correct elevation.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   TXZ   at the command line and press Enter.
;;;    3. Select one or more TEXT entities whose captions are numeric
;;;       elevation values.
;;;    4. Each selected text's Z coordinate is set to match the number
;;;       shown in its own caption; X and Y are left unchanged.
;;;
;;;  NOTES
;;;    - Text entities whose caption does not parse as a number are
;;;      skipped and reported, not modified.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of "sync text-to-Z"
;;;      elevation utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:TXZ-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 6)          ; magenta
                   '(6 . "Continuous")))
  )
)

;; Basic numeric-string test: allow digits, one decimal point, sign
(defun BGOL:TXZ-IsNumeric (s / c i ok hasdigit)
  (setq ok T hasdigit nil i 0)
  (if (or (null s) (= (strlen s) 0)) (setq ok nil))
  (while (and ok (< i (strlen s)))
    (setq c (substr s (1+ i) 1))
    (cond
      ((and (>= c "0") (<= c "9")) (setq hasdigit T))
      ((member c (list "." "-" "+")) T)
      (t (setq ok nil))
    )
    (setq i (1+ i))
  )
  (and ok hasdigit)
)

(defun C:TXZ ( / ss n i ent edata txt pt elev newpt updated skipped)
  (BGOL:TXZ-EnsureLayer "BGOL-TXZ")
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq updated 0)
      (setq skipped 0)
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq txt (cdr (assoc 1 edata)))
        (if (BGOL:TXZ-IsNumeric txt)
          (progn
            (setq elev (atof txt))
            (setq pt (cdr (assoc 10 edata)))
            (setq newpt (list (car pt) (cadr pt) elev))
            (entmod (subst (cons 10 newpt) (assoc 10 edata) edata))
            (entupd ent)
            (setq updated (1+ updated))
          )
          (setq skipped (1+ skipped))
        )
        (setq i (1+ i))
      )
      (princ (strcat "\n" (itoa updated) " text elevation(s) synced to Z. "
                      (itoa skipped) " non-numeric text(s) skipped."))
    )
    (princ "\nNo text entities selected.")
  )
  (princ)
)

(princ "\nTEXTELEV-bgol.lsp loaded. Type TXZ to sync elevation text captions into their true Z coordinate.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
