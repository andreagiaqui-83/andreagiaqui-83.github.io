;;; ---------------------------------------------------------------------
;;;  EXTFIX-bgol.lsp
;;;  Command:  EXF
;;;
;;;  PURPOSE
;;;  Scans every entity in the drawing and resets any non-default
;;;  extrusion direction (DXF group 210) back to the normal (0,0,1)
;;;  value. Some drawings contain entities created under a non-default
;;;  UCS that carry a nonzero extrusion vector, causing them to behave
;;;  or display unexpectedly. Running this routine is a safe first-pass
;;;  recovery step: it has no visible effect on unaffected drawings.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   EXF   at the command line and press Enter.
;;;    3. The routine scans all entities and resets any non-default
;;;       extrusion vector to (0.0 0.0 1.0).
;;;
;;;  CAVEAT
;;;    Some entities may shift position slightly as a side effect of the
;;;    correction, since overwriting group 210 without recalculating the
;;;    entity's stored coordinates relative to the new extrusion can
;;;    change how those coordinates are interpreted. Review affected
;;;    entities' positions after running this command.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of extrusion-direction
;;;      recovery utilities common in CAD drawing-repair workflows, but
;;;      the code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:EXF-IsDefaultExtrusion (vec / tol)
  (setq tol 1e-6)
  (and vec
       (< (abs (- (car vec) 0.0)) tol)
       (< (abs (- (cadr vec) 0.0)) tol)
       (< (abs (- (caddr vec) 1.0)) tol))
)

(defun C:EXF ( / ss n i ent edata extpair fixed skipped result)
  (setq ss (ssget "_X"))
  (if ss
    (progn
      (setq fixed 0)
      (setq skipped 0)
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq extpair (assoc 210 edata))
        (if (and extpair (not (BGOL:EXF-IsDefaultExtrusion (cdr extpair))))
          (progn
            (setq result
              (vl-catch-all-apply
                'entmod
                (list (subst (cons 210 '(0.0 0.0 1.0)) extpair edata))
              )
            )
            (if (vl-catch-all-error-p result)
              (setq skipped (1+ skipped))
              (setq fixed (1+ fixed))
            )
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nEXF: reset extrusion direction on " (itoa fixed)
                      " entity(ies) to normal (0,0,1)."))
      (if (> skipped 0)
        (princ (strcat " (" (itoa skipped) " could not be modified.)"))
      )
      (if (= fixed 0)
        (princ " No non-default extrusions found — drawing already normal.")
      )
      (princ "\nNote: review entity positions — some may shift slightly as a side effect.")
    )
    (princ "\nNo entities found in drawing.")
  )
  (princ)
)

(princ "\nEXTFIX-bgol.lsp loaded. Type EXF to reset non-default entity extrusion directions.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
