;;; ---------------------------------------------------------------------
;;;  ELEVMID-bgol.lsp
;;;  Command:  ELVM
;;;
;;;  PURPOSE
;;;  Given two selected elevation TEXT entities, computes their exact
;;;  midpoint location and the average (midpoint) of their two values,
;;;  then creates a single new elevation TEXT there. The simplest and
;;;  most common interpolation need in survey drafting.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   ELVM   at the command line and press Enter.
;;;    3. Select the first elevation TEXT entity.
;;;    4. Select the second elevation TEXT entity.
;;;    5. A new TEXT entity is created at the geometric midpoint of the
;;;       two insertion points, showing the averaged elevation value, on
;;;       layer "BGOL-ELVM".
;;;    6. Repeat by pressing Enter to process another pair, or Escape to
;;;       finish.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of midpoint elevation
;;;      interpolation utilities common in survey/profile drafting
;;;      workflows, but the code, command name and file name here are
;;;      new and are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:ELVM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

(defun BGOL:ELVM-MakeText (pt val ht lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 ht)
                 (cons 1 (rtos val 2 2))))
)

(defun BGOL:ELVM-DoOne ( / e1 e2 ed1 ed2 v1 v2 p1 p2 midpt midval ht)
  (setq e1 (entsel "\nSelect first elevation text: "))
  (setq e2 (if e1 (entsel "\nSelect second elevation text: ")))
  (if (and e1 e2)
    (progn
      (setq ed1 (entget (car e1)))
      (setq ed2 (entget (car e2)))
      (setq v1 (atof (cdr (assoc 1 ed1))))
      (setq v2 (atof (cdr (assoc 1 ed2))))
      (setq p1 (cdr (assoc 10 ed1)))
      (setq p2 (cdr (assoc 10 ed2)))
      (setq ht (cdr (assoc 40 ed1)))
      (if (not ht) (setq ht 2.5))
      (setq midpt (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2))
      (setq midval (/ (+ v1 v2) 2.0))
      (BGOL:ELVM-MakeText midpt midval ht "BGOL-ELVM")
      (princ (strcat "\nELVM: midpoint elevation " (rtos midval 2 2) " created."))
      T
    )
    (progn (princ "\nTwo elevation text entities are required.") nil)
  )
)

(defun C:ELVM ( / cont)
  (BGOL:ELVM-EnsureLayer "BGOL-ELVM")
  (setq cont T)
  (while cont
    (setq cont (BGOL:ELVM-DoOne))
  )
  (princ)
)

(princ "\nELEVMID-bgol.lsp loaded. Type ELVM to interpolate a midpoint elevation between two texts.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
