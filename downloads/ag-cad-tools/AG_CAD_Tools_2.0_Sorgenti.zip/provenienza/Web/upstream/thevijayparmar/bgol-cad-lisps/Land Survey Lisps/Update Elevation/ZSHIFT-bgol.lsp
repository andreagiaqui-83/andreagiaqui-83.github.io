;;; ---------------------------------------------------------------------
;;;  ZSHIFT-bgol.lsp
;;;  Command:  ZADD
;;;
;;;  PURPOSE
;;;  Adds a specified offset value to the Z (elevation) coordinate of
;;;  every selected entity in one operation. Provides a bulk Z-shift
;;;  capability that native AutoCAD lacks for arbitrary selections,
;;;  useful for correcting a systematic elevation/datum error or moving
;;;  a point set from a local to a real datum.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   ZADD   at the command line and press Enter.
;;;    3. Select the entities to shift (points, blocks, text, etc. --
;;;       anything with a DXF group 10 base/insertion point).
;;;    4. Enter the value to add to Z (may be negative to lower).
;;;    5. Every selected entity's base point Z coordinate is updated in
;;;       place, and a small confirmation marker is drawn at each new
;;;       position on layer "BGOL-ZADD".
;;;
;;;  NOTES
;;;    - Modifies entities in place (only the Z of their DXF group 10
;;;      point); other geometry/content is unchanged.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of bulk elevation-offset
;;;      utilities common in survey drafting workflows, but the code,
;;;      command name and file name here are new and are NOT copied
;;;      from, nor identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:ZADD-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:ZADD-Mark (pt lname / )
  (entmake (list '(0 . "CIRCLE")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbCircle")
                 (cons 10 pt)
                 (cons 40 0.3)))
)

(defun C:ZADD ( / ss dz n i ent edata pt newpt)
  (BGOL:ZADD-EnsureLayer "BGOL-ZADD")
  (setq ss (ssget))
  (if ss
    (progn
      (setq dz (getreal "\nEnter value to add to Z: "))
      (if dz
        (progn
          (setq n (sslength ss))
          (setq i 0)
          (while (< i n)
            (setq ent (ssname ss i))
            (setq edata (entget ent))
            (setq pt (cdr (assoc 10 edata)))
            (if pt
              (progn
                (setq newpt (list (car pt) (cadr pt) (+ (caddr pt) dz)))
                (entmod (subst (cons 10 newpt) (assoc 10 edata) edata))
                (entupd ent)
                (BGOL:ZADD-Mark newpt "BGOL-ZADD")
              )
            )
            (setq i (1+ i))
          )
          (princ (strcat "\nZADD: Z shifted by " (rtos dz 2 3) " on " (itoa n) " entitie(s)."))
        )
        (princ "\nNo value entered. Aborted.")
      )
    )
    (princ "\nNo entities selected.")
  )
  (princ)
)

(princ "\nZSHIFT-bgol.lsp loaded. Type ZADD to bulk-shift the Z value of selected entities.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
