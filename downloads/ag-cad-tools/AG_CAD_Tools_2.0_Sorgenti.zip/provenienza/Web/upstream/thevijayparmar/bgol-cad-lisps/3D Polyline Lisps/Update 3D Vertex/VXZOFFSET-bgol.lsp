;;; ---------------------------------------------------------------------
;;;  VXZOFFSET-bgol.lsp
;;;  Command:  VZO
;;;
;;;  PURPOSE
;;;  Applies a uniform elevation offset (add or subtract a fixed value)
;;;  to every vertex of a selected 3D polyline at once. AutoCAD's native
;;;  elevation-change workflow only works cleanly on entities with a
;;;  single, uniform Z value — a 3D polyline has a different Z at every
;;;  vertex, so this routine shifts the whole polyline as a rigid body
;;;  in the Z direction while preserving its shape/profile.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   VZO   at the command line and press Enter.
;;;    3. Select a 3D polyline.
;;;    4. Enter the elevation offset to apply (positive to raise,
;;;       negative to lower).
;;;    5. Every vertex's Z value is shifted by the same delta; relative
;;;       elevation differences between vertices are preserved.
;;;
;;;  NOTES
;;;    - Works on legacy 3D POLYLINE entities (per-vertex Z via VERTEX
;;;      sub-entities) and on LWPOLYLINE entities carrying a single
;;;      elevation value (group code 38).
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of uniform vertex-elevation
;;;      offset utilities common in CAD/survey drafting workflows, but
;;;      the code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:VZO-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 130)        ; orange
                   '(6 . "Continuous")))
  )
)

;; Shift every VERTEX sub-entity of a legacy 3D POLYLINE by dz
(defun BGOL:VZO-ShiftPolyVertices (ent dz / sub sdata pt newpt cnt)
  (setq cnt 0)
  (setq sub (entnext ent))
  (while (and sub (/= (cdr (assoc 0 (entget sub))) "SEQEND"))
    (setq sdata (entget sub))
    (if (= (cdr (assoc 0 sdata)) "VERTEX")
      (progn
        (setq pt (cdr (assoc 10 sdata)))
        (setq newpt (list (car pt) (cadr pt) (+ (caddr pt) dz)))
        (entmod (subst (cons 10 newpt) (assoc 10 sdata) sdata))
        (setq cnt (1+ cnt))
      )
    )
    (setq sub (entnext sub))
  )
  cnt
)

;; Shift the single elevation value of an LWPOLYLINE by dz
(defun BGOL:VZO-ShiftLWElevation (ent dz / edata oldelev newelev)
  (setq edata (entget ent))
  (setq oldelev (cdr (assoc 38 edata)))
  (if (not oldelev) (setq oldelev 0.0))
  (setq newelev (+ oldelev dz))
  (if (assoc 38 edata)
    (entmod (subst (cons 38 newelev) (assoc 38 edata) edata))
    (entmod (append edata (list (cons 38 newelev))))
  )
  1
)

(defun C:VZO ( / ent etype dz cnt)
  (BGOL:VZO-EnsureLayer "BGOL-VZO")
  (setq ent (car (entsel "\nSelect 3D polyline to offset: ")))
  (if ent
    (progn
      (setq etype (cdr (assoc 0 (entget ent))))
      (setq dz (getreal "\nEnter elevation offset (+ to raise, - to lower): "))
      (if dz
        (progn
          (cond
            ((= etype "POLYLINE")
             (setq cnt (BGOL:VZO-ShiftPolyVertices ent dz))
             (entupd ent)
             (princ (strcat "\n" (itoa cnt) " vertex(es) shifted by " (rtos dz 2 3) "."))
            )
            ((= etype "LWPOLYLINE")
             (setq cnt (BGOL:VZO-ShiftLWElevation ent dz))
             (entupd ent)
             (princ (strcat "\nElevation shifted by " (rtos dz 2 3) "."))
            )
            (t
             (princ "\nSelected entity is not a 3D POLYLINE or LWPOLYLINE.")
            )
          )
        )
        (princ "\nNo offset value entered.")
      )
    )
    (princ "\nNo entity selected.")
  )
  (princ)
)

(princ "\nVXZOFFSET-bgol.lsp loaded. Type VZO to shift every vertex of a 3D polyline by a uniform Z offset.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
