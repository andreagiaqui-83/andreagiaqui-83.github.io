;;; ---------------------------------------------------------------------
;;;  LYRCUR-bgol.lsp
;;;  Command:  LCX
;;;
;;;  PURPOSE
;;;  Moves all selected entities onto the drawing's current (active)
;;;  layer, entirely from the command line — no ribbon/layer-dropdown
;;;  interaction required.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   LCX   at the command line and press Enter.
;;;    3. Select the entities to move to the current layer.
;;;    4. Press Enter to finish selection — all selected entities are
;;;       switched to whatever layer is currently active (CLAYER).
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of command-line layer
;;;      reassignment utilities common in CAD drafting workflows, but
;;;      the code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:LCX ( / ss n ent edata curlayer)
  (setq curlayer (getvar 'CLAYER))
  (setq ss (ssget))
  (if ss
    (progn
      (setq n 0)
      (repeat (sslength ss)
        (setq ent   (ssname ss n))
        (setq edata (entget ent))
        (entmod (subst (cons 8 curlayer) (assoc 8 edata) edata))
        (setq n (1+ n))
      )
      (princ (strcat "\n" (itoa n) " entities moved to current layer \"" curlayer "\"."))
    )
    (princ "\nNo entities selected.")
  )
  (princ)
)

(princ "\nLYRCUR-bgol.lsp loaded. Type LCX to move selected entities to the current layer.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
