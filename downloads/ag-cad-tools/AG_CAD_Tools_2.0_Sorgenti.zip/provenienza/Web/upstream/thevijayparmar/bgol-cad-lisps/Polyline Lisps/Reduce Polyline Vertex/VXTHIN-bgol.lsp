;;; ---------------------------------------------------------------------
;;;  VXTHIN-bgol.lsp
;;;  Command:  VXTH
;;;
;;;  PURPOSE
;;;  Reduces vertex count on a dense polyline by rebuilding it from
;;;  points sampled at a fixed distance interval along the original
;;;  path. Produces a lighter-weight polyline that still closely follows
;;;  the original geometry — useful for LiDAR/survey-derived breaklines
;;;  with far more vertices than needed.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   VXTH   at the command line and press Enter.
;;;    3. Enter the sampling distance at which new vertices should be
;;;       introduced (default 30).
;;;    4. Select the polyline to reduce.
;;;    5. A new, lighter LWPOLYLINE is created on layer "BGOL-VXTH".
;;;       Before/after vertex counts are reported to the command line.
;;;
;;;  NOTES
;;;    - Not recommended for polylines that already have few vertices or
;;;      widely-spaced points — resampling could distort the shape.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of vertex-reduction/curve-
;;;      sampling utilities common in survey/civil drafting workflows,
;;;      but the code, command name and file name here are new and are
;;;      NOT copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:VXTH-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 1)          ; red
                   '(6 . "Continuous")))
  )
)

(defun BGOL:VXTH-MakePolyline (pointlist lname / dxfdata pt)
  (setq dxfdata (list '(0 . "LWPOLYLINE")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbPolyline")
                       (cons 90 (length pointlist))
                       '(70 . 0)
                 )
  )
  (foreach pt pointlist
    (setq dxfdata (append dxfdata (list (cons 10 pt))))
  )
  (entmake dxfdata)
)

(defun C:VXTH ( / d ent obj len nseg i dist pt pts origcount)
  (BGOL:VXTH-EnsureLayer "BGOL-VXTH")
  (setq d (getdist "\nDistance at which vertices to be introduced <30>: "))
  (if (not d) (setq d 30.0))
  (setq ent (car (entsel "\nSelect polyline to reduce: ")))
  (if ent
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (setq origcount (vlax-get obj 'NumberOfVertices))
      (setq len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
      (setq pts '())
      (setq dist 0.0)
      (while (< dist len)
        (setq pt (vlax-curve-getPointAtDist obj dist))
        (setq pts (append pts (list (list (car pt) (cadr pt)))))
        (setq dist (+ dist d))
      )
      (setq pt (vlax-curve-getEndPoint obj))
      (setq pts (append pts (list (list (car pt) (cadr pt)))))
      (BGOL:VXTH-MakePolyline pts "BGOL-VXTH")
      (princ (strcat "\nNo of Vertexes in Selected Line: " (itoa (fix origcount))))
      (princ (strcat "\nNo of Vertexes in Created Line: " (itoa (length pts)) " (BGOL-VXTH)."))
    )
    (princ "\nNo polyline selected.")
  )
  (princ)
)

(princ "\nVXTHIN-bgol.lsp loaded. Type VXTH to reduce polyline vertex count by distance sampling.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
