;;; ---------------------------------------------------------------------
;;;  ATT2TXT-bgol.lsp
;;;  Command:  A2TX
;;;
;;;  PURPOSE
;;;  Reads every attribute value from selected attribute block(s) and
;;;  creates a new plain TEXT entity for each value, placed on a
;;;  dedicated layer. This preserves attribute data as independent plain
;;;  text even if the source attribute block is later exploded (which
;;;  would otherwise revert attributes to their tag/prompt definitions
;;;  and lose the entered values).
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   A2TX   at the command line and press Enter.
;;;    3. Select the attribute block(s) whose attribute values should be
;;;       converted to text.
;;;    4. For each attribute found, a new plain TEXT entity containing
;;;       that value is created at (or near) the attribute's own
;;;       position, on layer "BGOL-A2TX".
;;;
;;;  NOTES
;;;    - Supports attribute blocks with any number of attribute fields.
;;;    - Text height for each new TEXT entity matches the source
;;;      attribute's height where available, else falls back to
;;;      *bgol-a2tx-height*.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of extracting attribute
;;;      values to plain text common in survey benchmark/station
;;;      labeling workflows, but the code, command name and file name
;;;      here are new and are NOT copied from, nor identical to, any
;;;      specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(setq *bgol-a2tx-height* 2.5)

(defun BGOL:A2TX-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 2)          ; yellow
                   '(6 . "Continuous")))
  )
)

(defun BGOL:A2TX-MakeText (val pt height lname / )
  (entmake (list '(0 . "TEXT")
                 '(100 . "AcDbEntity")
                 (cons 8 lname)
                 '(100 . "AcDbText")
                 (cons 10 pt)
                 (cons 40 height)
                 (cons 1 val)))
)

(defun C:A2TX ( / ss lname n i ent obj atts a attobj val pt height cnt)
  (setq lname "BGOL-A2TX")
  (BGOL:A2TX-EnsureLayer lname)
  (setq ss (ssget '((0 . "INSERT") (66 . 1))))
  (if ss
    (progn
      (setq n (sslength ss))
      (setq i 0)
      (setq cnt 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq atts (vlax-invoke obj 'GetAttributes))
        (foreach attobj atts
          (setq val (vlax-get attobj 'TextString))
          (setq pt (vlax-get attobj 'InsertionPoint))
          (setq height
            (if (vlax-property-available-p attobj 'Height)
              (vlax-get attobj 'Height)
              *bgol-a2tx-height*
            )
          )
          (if (or (null height) (<= height 0))
            (setq height *bgol-a2tx-height*)
          )
          (BGOL:A2TX-MakeText val pt height lname)
          (setq cnt (1+ cnt))
        )
        (setq i (1+ i))
      )
      (princ (strcat "\n" (itoa cnt) " attribute value(s) converted to plain TEXT (BGOL-A2TX)."))
    )
    (princ "\nNo attribute blocks selected (block must contain at least one attribute).")
  )
  (princ)
)

(princ "\nATT2TXT-bgol.lsp loaded. Type A2TX to convert selected block attributes to plain text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
