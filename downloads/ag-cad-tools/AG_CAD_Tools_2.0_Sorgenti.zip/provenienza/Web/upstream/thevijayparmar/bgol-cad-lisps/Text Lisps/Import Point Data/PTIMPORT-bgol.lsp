;;; ---------------------------------------------------------------------
;;;  PTIMPORT-bgol.lsp
;;;  Command:  PTIM
;;;
;;;  PURPOSE
;;;  Reads a CSV/text file of survey point data -- one row per point,
;;;  four comma-separated columns in order: Easting(X), Northing(Y),
;;;  Elevation(Z), Remark -- and creates one TEXT entity per row in
;;;  the current drawing, placed at the point's X,Y,Z coordinate with
;;;  the Remark column as the text caption. A simple, fully editable
;;;  alternative to proprietary total-station import tools.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   PTIM   at the command line and press Enter.
;;;    3. Select the source CSV/TXT file (rows: X,Y,Z,Remark).
;;;    4. Enter a text height (or accept the default).
;;;    5. A TEXT entity is created for each valid row, on layer
;;;       "BGOL-PTIM", positioned at the row's X,Y,Z and captioned
;;;       with the Remark column.
;;;
;;;  NOTES
;;;    - Blank lines and rows with fewer than 4 fields are skipped.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of point-data import
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:PTIM-EnsureLayer (lname / )
  (if (not (tblsearch "LAYER" lname))
    (entmake (list '(0 . "LAYER")
                   '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord")
                   (cons 2 lname)
                   '(70 . 0)
                   '(62 . 3)          ; green
                   '(6 . "Continuous")))
  )
)

;; Split a string on a single-character delimiter, returning a list of
;; substrings. No native AutoLISP split function, so build it manually.
(defun BGOL:PTIM-Split (str delim / pos out remain)
  (setq out '())
  (setq remain str)
  (while (setq pos (vl-string-search delim remain))
    (setq out (append out (list (substr remain 1 pos))))
    (setq remain (substr remain (+ pos 1 (strlen delim))))
  )
  (setq out (append out (list remain)))
  out
)

(defun BGOL:PTIM-MakeText (pt txt height lname / dxfdata)
  (setq dxfdata (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       (cons 8 lname)
                       '(100 . "AcDbText")
                       (cons 10 pt)
                       (cons 40 height)
                       (cons 1 txt)
                 )
  )
  (entmake dxfdata)
)

(defun C:PTIM ( / path f line fields x y z rmk pt height cnt)
  (BGOL:PTIM-EnsureLayer "BGOL-PTIM")
  (setq path (getfiled "Select Point Data File (X,Y,Z,Remark)" "" "csv;txt" 0))
  (if path
    (progn
      (setq height (getreal "\nText height <2.5>: "))
      (if (not height) (setq height 2.5))
      (setq f (open path "r"))
      (setq cnt 0)
      (if f
        (progn
          (while (setq line (read-line f))
            (if (and line (> (strlen (vl-string-trim " \t" line)) 0))
              (progn
                (setq fields (BGOL:PTIM-Split line ","))
                (if (>= (length fields) 4)
                  (progn
                    (setq x (atof (nth 0 fields)))
                    (setq y (atof (nth 1 fields)))
                    (setq z (atof (nth 2 fields)))
                    (setq rmk (vl-string-trim " \t" (nth 3 fields)))
                    (setq pt (list x y z))
                    (BGOL:PTIM-MakeText pt rmk height "BGOL-PTIM")
                    (setq cnt (1+ cnt))
                  )
                )
              )
            )
          )
          (close f)
          (princ (strcat "\nPTIM: " (itoa cnt) " point label(s) imported onto layer BGOL-PTIM."))
        )
        (princ "\nCould not open the selected file.")
      )
    )
    (princ "\nNo file selected.")
  )
  (princ)
)

(princ "\nPTIMPORT-bgol.lsp loaded. Type PTIM to import X,Y,Z,Remark point data as text.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
