;;; ---------------------------------------------------------------------
;;;  RNDVAL-bgol.lsp
;;;  Command:  RNDV
;;;
;;;  PURPOSE
;;;  Rounds the numeric value of each selected TEXT entity to the
;;;  nearest user-specified increment (e.g. 0.005, matching common
;;;  survey-instrument precision or project specifications requiring
;;;  elevations to end in a multiple of 0.005).
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   RNDV   at the command line and press Enter.
;;;    3. Select the numeric text entities to round.
;;;    4. Enter the rounding increment (default 0.005).
;;;    5. Each selected text's numeric value is replaced with its
;;;       nearest multiple of the increment, formatted to 3 decimal
;;;       places.
;;;
;;;  NOTES
;;;    - Non-numeric text in the selection is skipped and reported.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of nearest-increment
;;;      rounding utilities common in CAD/survey drafting workflows,
;;;      but the code, command name and file name here are new and
;;;      are NOT copied from, nor identical to, any specific
;;;      third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:RNDV-IsNumeric (str / c i n ok)
  (setq ok T)
  (setq n (strlen str))
  (setq i 1)
  (if (= n 0) (setq ok nil))
  (while (and ok (<= i n))
    (setq c (substr str i 1))
    (if (not (or (and (>= c "0") (<= c "9")) (= c ".") (= c "-") (= c "+")))
      (setq ok nil)
    )
    (setq i (1+ i))
  )
  ok
)

(defun C:RNDV ( / ss n i ent edata val incr rounded newstr skipped)
  (setq ss (ssget '((0 . "TEXT"))))
  (if ss
    (progn
      (setq incr (getreal "\nRounding increment <0.005>: "))
      (if (not incr) (setq incr 0.005))
      (setq n (sslength ss))
      (setq i 0)
      (setq skipped 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq edata (entget ent))
        (setq val (cdr (assoc 1 edata)))
        (if (BGOL:RNDV-IsNumeric (vl-string-trim " " val))
          (progn
            (setq val (atof val))
            (setq rounded (* incr (atoi (rtos (/ val incr) 2 0))))
            (setq newstr (rtos rounded 2 3))
            (setq edata (subst (cons 1 newstr) (assoc 1 edata) edata))
            (entmod edata)
            (entupd ent)
          )
          (setq skipped (1+ skipped))
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nRNDV: " (itoa (- n skipped)) " value(s) rounded to nearest "
                     (rtos incr 2 3) "; " (itoa skipped) " non-numeric text skipped."))
    )
    (princ "\nNo text selected.")
  )
  (princ)
)

(princ "\nRNDVAL-bgol.lsp loaded. Type RNDV to round selected text values to a chosen increment.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
