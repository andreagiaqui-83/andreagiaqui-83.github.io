;;; ---------------------------------------------------------------------
;;;  TXTSWAP-bgol.lsp
;;;  Command:  TXSW
;;;
;;;  PURPOSE
;;;  Swaps the string content of two selected TEXT (or MTEXT) entities
;;;  in a single command -- useful for fixing title-block cells or
;;;  table entries that were entered in the wrong position, without a
;;;  manual copy/paste/overwrite dance.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   TXSW   at the command line and press Enter.
;;;    3. Select the first text entity.
;;;    4. Select the second text entity.
;;;    5. Their string content is interchanged in place; position,
;;;       height, layer and rotation of each entity are untouched.
;;;
;;;  NOTES
;;;    - Works on TEXT and MTEXT; both selected entities should be the
;;;      same type for a clean swap (mixing types still swaps the
;;;      raw string value).
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of text-content-swap
;;;      utilities common in CAD/survey drafting workflows, but the
;;;      code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:TXSW-GetTextValue (ent / edata etype)
  (setq edata (entget ent))
  (setq etype (cdr (assoc 0 edata)))
  (cond
    ((= etype "MTEXT") (cdr (assoc 1 edata)))
    ((= etype "TEXT")  (cdr (assoc 1 edata)))
    (t nil)
  )
)

(defun BGOL:TXSW-SetTextValue (ent newval / edata)
  (setq edata (entget ent))
  (setq edata (subst (cons 1 newval) (assoc 1 edata) edata))
  (entmod edata)
  (entupd ent)
)

(defun C:TXSW ( / e1 e2 s1 s2)
  (setq e1 (car (entsel "\nSelect first text: ")))
  (if (not e1)
    (princ "\nNo entity selected for first text.")
    (progn
      (setq e2 (car (entsel "\nSelect second text: ")))
      (if (not e2)
        (princ "\nNo entity selected for second text.")
        (if (equal e1 e2)
          (princ "\nSame entity selected twice; nothing to swap.")
          (progn
            (setq s1 (BGOL:TXSW-GetTextValue e1))
            (setq s2 (BGOL:TXSW-GetTextValue e2))
            (if (and s1 s2)
              (progn
                (BGOL:TXSW-SetTextValue e1 s2)
                (BGOL:TXSW-SetTextValue e2 s1)
                (princ "\nTXSW: text content interchanged between the two selected entities.")
              )
              (princ "\nOne or both selected entities are not TEXT/MTEXT. Nothing swapped.")
            )
          )
        )
      )
    )
  )
  (princ)
)

(princ "\nTXTSWAP-bgol.lsp loaded. Type TXSW to interchange two text entities' content.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
