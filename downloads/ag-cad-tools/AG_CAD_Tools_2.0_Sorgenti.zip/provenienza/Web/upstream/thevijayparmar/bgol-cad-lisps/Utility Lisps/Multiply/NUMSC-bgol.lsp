;;; ---------------------------------------------------------------------
;;;  NUMSC-bgol.lsp
;;;  Command:  NSCL
;;;
;;;  PURPOSE
;;;  Batch-scales the numeric value of selected TEXT/MTEXT entities by a
;;;  user-supplied factor (default operation: multiply). Lets a user pick
;;;  +, -, *, or / so the same routine covers simple batch arithmetic on
;;;  text values.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   NSCL   at the command line and press Enter.
;;;    3. Select one or more TEXT/MTEXT entities containing numeric values.
;;;    4. Choose an operator: [Multiply/Add/Subtract/Divide] (default: M).
;;;    5. Enter the operand (the factor/amount to apply).
;;;    6. Each selected text's numeric value is updated in place.
;;;
;;;  NOTES
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of batch numeric-text
;;;      calculators common in CAD drafting workflows, but the code,
;;;      command name and file name here are new and are NOT copied
;;;      from, nor identical to, any specific third-party product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun BGOL:NUMSC-Apply (val op operand)
  (cond
    ((= op "M") (* val operand))
    ((= op "A") (+ val operand))
    ((= op "S") (- val operand))
    ((= op "D") (if (/= operand 0.0) (/ val operand) val))
    (t val)
  )
)

(defun C:NSCL ( / ss n ent edata str val op operand newval newstr decimals kw)
  (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if ss
    (progn
      (initget "Multiply Add Subtract Divide")
      (setq kw (getkword "\nOperator [Multiply/Add/Subtract/Divide] <Multiply>: "))
      (setq op (cond
                 ((= kw "Add") "A")
                 ((= kw "Subtract") "S")
                 ((= kw "Divide") "D")
                 (t "M")
               )
      )
      (setq operand (getreal "\nEnter operand value: "))
      (setq decimals 4)
      (if operand
        (progn
          (setq n 0)
          (repeat (sslength ss)
            (setq ent   (ssname ss n))
            (setq edata (entget ent))
            (setq str   (cdr (assoc 1 edata)))
            (setq val   (vl-catch-all-apply 'atof (list str)))
            (if (and (numberp val) (/= 0 (strlen (vl-string-trim " " str))))
              (progn
                (setq newval (BGOL:NUMSC-Apply val op operand))
                (setq newstr (rtos newval 2 decimals))
                (entmod (subst (cons 1 newstr) (assoc 1 edata) edata))
              )
            )
            (setq n (1+ n))
          )
          (princ (strcat "\n" (itoa n) " text value(s) updated by NSCL."))
        )
        (princ "\nNo operand entered — command cancelled.")
      )
    )
    (princ "\nNo TEXT/MTEXT entities selected.")
  )
  (princ)
)

(princ "\nNUMSC-bgol.lsp loaded. Type NSCL to batch-scale numeric text values.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
