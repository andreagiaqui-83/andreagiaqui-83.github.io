;;; ---------------------------------------------------------------------
;;;  DIMFRZ-bgol.lsp
;;;  Command:  DFZ
;;;
;;;  PURPOSE
;;;  Replaces the default placeholder token (<>) in selected DIMENSION
;;;  entities with their current, actual measured value, "freezing" the
;;;  displayed text so it stays fixed even if the dimension is later
;;;  dragged or otherwise modified. Useful for recording an as-measured
;;;  value that should persist as a fixed record.
;;;
;;;  USAGE
;;;    1. Load this file (APPLOAD or drag-drop onto the drawing window).
;;;    2. Type   DFZ   at the command line and press Enter.
;;;    3. Select the dimension entities to freeze; press Enter to
;;;       confirm selection.
;;;    4. Each selected dimension's text override is set to its current
;;;       measured value, using the drawing's linear dimension precision.
;;;
;;;  NOTES
;;;    - Uses the ActiveX TextOverride property, which is the standard
;;;      mechanism for replacing a dimension's <> placeholder with fixed
;;;      text.
;;;    - This is an original, independently written implementation.
;;;      It is INSPIRED by the general idea of dimension-value-freezing
;;;      utilities common in CAD as-built/record drafting workflows, but
;;;      the code, command name and file name here are new and are NOT
;;;      copied from, nor identical to, any specific third-party
;;;      product.
;;;
;;;  ---------------------------------------------------------------------
;;;  Developed and shared for the CAD community by:  BGol Community
;;;  Community website:                              https://bgol.in/
;;;  License:  Open-source & free to use, modify, and share for all.
;;;            Provided "as is", without warranty of any kind.
;;;  ---------------------------------------------------------------------

(vl-load-com)

(defun C:DFZ ( / ss n i ent obj val precision valtext frozen result)
  (setq ss (ssget '((0 . "DIMENSION"))))
  (if ss
    (progn
      (setq precision (getvar "DIMDEC"))
      (setq frozen 0)
      (setq n (sslength ss))
      (setq i 0)
      (while (< i n)
        (setq ent (ssname ss i))
        (setq result (vl-catch-all-apply 'vlax-ename->vla-object (list ent)))
        (if (not (vl-catch-all-error-p result))
          (progn
            (setq obj result)
            (setq result (vl-catch-all-apply 'vla-get-Measurement (list obj)))
            (if (not (vl-catch-all-error-p result))
              (progn
                (setq val result)
                (setq valtext (rtos val 2 precision))
                (setq result (vl-catch-all-apply 'vla-put-TextOverride (list obj valtext)))
                (if (not (vl-catch-all-error-p result))
                  (setq frozen (1+ frozen))
                )
              )
            )
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\nDFZ: froze the displayed value on " (itoa frozen)
                      " dimension(s) as fixed text."))
    )
    (princ "\nNo DIMENSION entities selected.")
  )
  (princ)
)

(princ "\nDIMFRZ-bgol.lsp loaded. Type DFZ to freeze selected dimensions' displayed values.")
(princ "\n  -- Free & open-source, courtesy of BGol Community (https://bgol.in/) --")
(princ)
