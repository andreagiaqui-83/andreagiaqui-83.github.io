; CAD Tools Italiano 2.0 - FASE 2C - ultimi 28 nuovi strumenti Web MIT
; Modulo incrementale di sviluppo: richiede Fase 2A + Fase 2B.
; NON sostituisce la golden 1.9.
;
; Regole obbligatorie:
; - entrypoint CTI italiani;
; - ESC/Annulla centralizzato e silenzioso tramite cti20w:run;
; - un gruppo UNDO per comando;
; - ripristino centralizzato variabili AutoCAD;
; - errori reali visibili;
; - attribuzione MIT e provenienza per ogni routine;
; - hardening conservativo senza cambiare lo scopo originale.

(vl-load-com)
(if (not (and (fboundp 'cti20w:run) (boundp '*CTI-WEB-PHASE2B-LOADED*)))
  (princ "\nCAD Tools Italiano 2.0 Fase 2C richiede prima i moduli Fase 2A e Fase 2B."))
(setq *CTI-WEB-PHASE2C-VERSION* "2.0-phase2c")
(setq *CTI-WEB-PHASE2C-COUNT* 28)
(setq *CTI-WEB-PHASE2C-LOADED* nil)

; ======================================================================
; BGol CAD Lisps (MIT) - ultimi 12 strumenti selezionati
; ======================================================================

(defun cti20c:ceil-pos (x / n)
  (setq n (fix x)) (if (> x n) (1+ n) n))

(defun cti20c:cmd-arco-segmenti (/ e typ o len step n i d pts p layer closed)
  (setq e (car (entsel "\nSeleziona ARCO o CERCHIO: ")))
  (if (and e (member (setq typ (cdr (assoc 0 (entget e)))) '("ARC" "CIRCLE")))
    (progn
      (setq step (getdist "\nLunghezza massima del segmento <1.0>: "))
      (if (not step) (setq step 1.0))
      (if (> step 0.0)
        (progn
          (setq o (vlax-ename->vla-object e) len (cti20w:curve-length o)
                n (max (if (= typ "CIRCLE") 8 1) (cti20c:ceil-pos (/ len step)))
                layer (cdr (assoc 8 (entget e))) closed (= typ "CIRCLE") pts nil i 0)
          (if closed
            (while (< i n)
              (setq d (* len (/ (float i) n)) p (vlax-curve-getPointAtDist o d) pts (append pts (list p)) i (1+ i)))
            (while (<= i n)
              (setq d (* len (/ (float i) n)) p (vlax-curve-getPointAtDist o d) pts (append pts (list p)) i (1+ i))))
          (cti20w:make-lwpoly pts layer closed)
          (princ (strcat "\nCreata polilinea segmentata con " (itoa n) " segmenti; originale preservato.")))
        (princ "\nLa lunghezza massima deve essere maggiore di zero."))))
  (princ))
(defun c:CTI_ARCO_IN_SEGMENTI () (cti20w:run 'cti20c:cmd-arco-segmenti))

(defun cti20c:cmd-calcola-testi (/ op k ss e v n new)
  (initget "Somma Sottrai Moltiplica Dividi")
  (setq op (getkword "\nOperazione [Somma/Sottrai/Moltiplica/Dividi] <Moltiplica>: "))
  (if (not op) (setq op "Moltiplica"))
  (setq k (getreal "\nValore: "))
  (cond
    ((not k) nil)
    ((and (= op "Dividi") (equal k 0.0 1e-12)) (princ "\nDivisione per zero non consentita."))
    (T
      (prompt "\nSeleziona TESTO/TESTOM numerici: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (if (setq v (cti20w:num-text e))
          (progn
            (setq new (cond ((= op "Somma") (+ v k)) ((= op "Sottrai") (- v k))
                            ((= op "Dividi") (/ v k)) (T (* v k))))
            (if (cti20w:text-set e (rtos new 2 6)) (setq n (1+ n))))))
      (princ (strcat "\nTesti numerici modificati: " (itoa n) "."))))
  (princ))
(defun c:CTI_CALCOLA_TESTI_NUMERICI () (cti20w:run 'cti20c:cmd-calcola-testi))

(defun cti20c:contorno-valido-p (b)
  (and b (= (cdr (assoc 0 (entget b))) "LWPOLYLINE") (cti20w:lw-closed-p b) (not (cti20w:lw-has-bulge-p b))))

(defun cti20c:cmd-cancella-dentro (/ b pts ss ans e n)
  (setq b (car (entsel "\nSeleziona contorno LWPOLYLINE chiuso e rettilineo: ")))
  (cond
    ((not b) nil)
    ((not (cti20c:contorno-valido-p b)) (princ "\nServe un contorno LWPOLYLINE chiuso senza archi."))
    (T
      (setq pts (cti20w:lwverts b) ss (ssget "_WP" pts))
      (if ss (ssdel b ss))
      (setq n (if ss (sslength ss) 0))
      (initget "Si No")
      (setq ans (getkword (strcat "\nEliminare " (itoa n) " oggetti completamente interni? [Si/No] <No>: ")))
      (if (= ans "Si") (foreach e (cti20w:ss-list ss) (entdel e)))))
  (princ))
(defun c:CTI_CANCELLA_DENTRO () (cti20w:run 'cti20c:cmd-cancella-dentro))

(defun cti20c:cmd-mantieni-dentro (/ b pts inside all out e ans tab n)
  (setq b (car (entsel "\nSeleziona contorno LWPOLYLINE chiuso e rettilineo: ")))
  (cond
    ((not b) nil)
    ((not (cti20c:contorno-valido-p b)) (princ "\nServe un contorno LWPOLYLINE chiuso senza archi."))
    (T
      (setq pts (cti20w:lwverts b) inside (ssget "_WP" pts) tab (getvar "CTAB")
            all (ssget "_X" (list (cons 410 tab))) out (ssadd))
      (foreach e (cti20w:ss-list all)
        (if (and (/= e b) (or (not inside) (not (ssmemb e inside)))) (ssadd e out)))
      (setq n (sslength out))
      (initget "Si No")
      (setq ans (getkword (strcat "\nEliminare " (itoa n) " oggetti esterni nella scheda corrente? [Si/No] <No>: ")))
      (if (= ans "Si") (foreach e (cti20w:ss-list out) (entdel e)))))
  (princ))
(defun c:CTI_MANTIENI_DENTRO () (cti20w:run 'cti20c:cmd-mantieni-dentro))

(defun cti20c:list-dwg (dir) (vl-sort (vl-directory-files dir "*.dwg" 1) '<))
(defun cti20c:cmd-inserisci-dwg-cartella (/ sample dir files base gap i file p n r)
  (setq sample (getfiled "Scegli un DWG della cartella da inserire" "" "dwg" 0))
  (if sample
    (progn
      (setq dir (vl-filename-directory sample) files (cti20c:list-dwg dir)
            base (getpoint "\nPunto base del primo inserimento <0,0,0>: "))
      (if (not base) (setq base '(0.0 0.0 0.0)))
      (setq gap (getdist "\nPasso X tra i DWG <1000>: ")) (if (not gap) (setq gap 1000.0))
      (setq i 0 n 0)
      (foreach file files
        (setq p (list (+ (car base) (* i gap)) (cadr base) (if (caddr base) (caddr base) 0.0))
              r (vl-catch-all-apply 'vla-InsertBlock
                    (list (cti20w:space) (vlax-3d-point p) (strcat dir "\\" file) 1.0 1.0 1.0 0.0)))
        (if (not (vl-catch-all-error-p r)) (setq n (1+ n)))
        (setq i (1+ i)))
      (princ (strcat "\nDWG inseriti: " (itoa n) " su " (itoa (length files)) "."))))
  (princ))
(defun c:CTI_INSERISCI_DWG_CARTELLA () (cti20w:run 'cti20c:cmd-inserisci-dwg-cartella))

(defun cti20c:cmd-vertice-arco (/ e ed c a1 a2 r spt ept p1 p2 inter)
  (setq e (car (entsel "\nSeleziona un ARCO: ")))
  (if (and e (= (cdr (assoc 0 (entget e))) "ARC"))
    (progn
      (setq ed (entget e) c (cdr (assoc 10 ed)) r (cdr (assoc 40 ed))
            a1 (cdr (assoc 50 ed)) a2 (cdr (assoc 51 ed))
            spt (polar c a1 r) ept (polar c a2 r)
            p1 (polar spt (+ a1 (/ pi 2.0)) 1.0) p2 (polar ept (+ a2 (/ pi 2.0)) 1.0)
            inter (inters spt p1 ept p2 nil))
      (if inter
        (progn (cti20w:add-circle inter (max (* r 0.03) 0.01) "CTI-VERTICI-IMMAGINARI")
               (princ (strcat "\nVertice immaginario: " (rtos (car inter) 2 4) ", " (rtos (cadr inter) 2 4) ".")))
        (princ "\nLe tangenti risultano parallele: vertice non determinabile."))))
  (princ))
(defun c:CTI_VERTICE_IMMAGINARIO_ARCO () (cti20w:run 'cti20c:cmd-vertice-arco))

(defun cti20c:cmd-layer-corrente (/ ss e o lay n)
  (setq lay (getvar "CLAYER")) (prompt "\nSeleziona oggetti da spostare sul layer corrente: ") (setq ss (ssget) n 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e))
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list o lay)))) (setq n (1+ n))))
  (princ (strcat "\nOggetti spostati su " lay ": " (itoa n) ".")) (princ))
(defun c:CTI_SPOSTA_LAYER_CORRENTE () (cti20w:run 'cti20c:cmd-layer-corrente))

(defun cti20c:cmd-layer-rapido (/ name color)
  (setq name (vl-string-trim " " (getstring T "\nNome nuovo layer: "))
        color (getint "\nColore ACI [1-255] <7>: "))
  (if (not color) (setq color 7))
  (if (or (< color 1) (> color 255)) (setq color 7))
  (if (/= name "")
    (progn (cti20w:ensure-layer name color) (setvar "CLAYER" name) (princ (strcat "\nLayer corrente: " name "."))))
  (princ))
(defun c:CTI_CREA_LAYER_RAPIDO () (cti20w:run 'cti20c:cmd-layer-rapido))

(defun cti20c:cmd-scala-linee-centro (/ factor ss e o c n r)
  (setq factor (getreal "\nFattore scala linee (>0): "))
  (if (and factor (> factor 0.0))
    (progn
      (prompt "\nSeleziona LINEE da scalare rispetto al proprio punto medio: ")
      (setq ss (ssget '((0 . "LINE"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (setq o (vlax-ename->vla-object e) c (cti20w:bbox-center o)
              r (and c (vl-catch-all-apply 'vla-ScaleEntity (list o (vlax-3d-point c) factor))))
        (if (and c (not (vl-catch-all-error-p r))) (setq n (1+ n))))
      (princ (strcat "\nLinee scalate: " (itoa n) "."))))
  (princ))
(defun c:CTI_SCALA_LINEE_CENTRO () (cti20w:run 'cti20c:cmd-scala-linee-centro))

(defun cti20c:estrusione-standard-p (v)
  (and v (< (abs (car v)) 1e-8) (< (abs (cadr v)) 1e-8) (< (abs (- (caddr v) 1.0)) 1e-8)))
(defun cti20c:cmd-normalizza-estrusione (/ ss affected e ed ep ans fixed skipped r)
  (setq ss (ssget "_X") affected nil)
  (foreach e (cti20w:ss-list ss)
    (setq ed (entget e) ep (assoc 210 ed))
    (if (and ep (not (cti20c:estrusione-standard-p (cdr ep)))) (setq affected (cons e affected))))
  (if affected
    (progn
      (princ (strcat "\nEntità con estrusione non standard: " (itoa (length affected)) "."))
      (princ "\nAttenzione: normalizzare DXF 210 può spostare alcune entità. UNDO ripristina l'operazione.")
      (initget "Si No") (setq ans (getkword "\nNormalizzare a (0,0,1)? [Si/No] <No>: "))
      (if (= ans "Si")
        (progn
          (setq fixed 0 skipped 0)
          (foreach e affected
            (setq ed (entget e) ep (assoc 210 ed)
                  r (vl-catch-all-apply 'entmod (list (subst (cons 210 '(0.0 0.0 1.0)) ep ed))))
            (if (vl-catch-all-error-p r) (setq skipped (1+ skipped))
              (progn (entupd e) (setq fixed (1+ fixed)))))
          (princ (strcat "\nEstrusione normalizzata su " (itoa fixed) " entità; non modificabili: " (itoa skipped) ".")))))
    (princ "\nNessuna estrusione non standard trovata."))
  (princ))
(defun c:CTI_NORMALIZZA_ESTRUSIONE () (cti20w:run 'cti20c:cmd-normalizza-estrusione))

(defun cti20c:cmd-blocca-quota (/ ss e o m n r)
  (prompt "\nSeleziona quote da congelare come testo: ") (setq ss (ssget '((0 . "DIMENSION"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e) m (vl-catch-all-apply 'vla-get-Measurement (list o)))
    (if (numberp m)
      (progn (setq r (vl-catch-all-apply 'vla-put-TextOverride (list o (rtos m 2 (getvar "DIMDEC")))))
             (if (not (vl-catch-all-error-p r)) (setq n (1+ n))))))
  (princ (strcat "\nQuote congelate: " (itoa n) ".")) (princ))
(defun c:CTI_BLOCCA_VALORE_QUOTA () (cti20w:run 'cti20c:cmd-blocca-quota))

(defun cti20c:band-color (z zmin zmax bands / span idx)
  (setq span (- zmax zmin))
  (if (<= span 1e-12) 1
    (progn (setq idx (fix (* bands (/ (- z zmin) span)))) (if (>= idx bands) (setq idx (1- bands))) (1+ (rem idx 9)))))
(defun cti20c:swatch (p len color / o)
  (setq o (cti20w:add-line p (list (+ (car p) len) (cadr p) (if (caddr p) (caddr p) 0.0)) "CTI-QUOTE-CSV"))
  (vla-put-Color o color) o)
(defun cti20c:cmd-plotta-quote-csv (/ path f line sep vals x y z pts minz maxz ht bands p color legend rowh sw i lo hi y0)
  (setq path (getfiled "CSV/TXT quote X,Y,Z" "" "csv;txt" 0))
  (if path
    (progn
      (setq f (open path "r") pts nil minz nil maxz nil)
      (if f
        (progn
          (while (setq line (read-line f))
            (if (> (strlen (vl-string-trim " \t" line)) 0)
              (progn
                (setq sep (cti20w:csv-sep line) vals (cti20w:csv-split line sep))
                (if (>= (length vals) 3)
                  (progn
                    (setq x (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 0 vals))) 2)
                          y (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 1 vals))) 2)
                          z (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 2 vals))) 2))
                    (if (and x y z)
                      (progn (setq p (list x y z) pts (cons p pts))
                             (if (or (null minz) (< z minz)) (setq minz z))
                             (if (or (null maxz) (> z maxz)) (setq maxz z)))))))))
          (close f)
          (if pts
            (progn
              (setq bands (getint "\nNumero bande colore [1-9] <5>: ")) (if (not bands) (setq bands 5))
              (setq bands (max 1 (min 9 bands)) ht (getreal "\nAltezza testo quote <2.5>: ")) (if (not ht) (setq ht 2.5))
              (cti20w:ensure-layer "CTI-QUOTE-CSV" 7)
              (foreach p (reverse pts)
                (setq color (cti20c:band-color (caddr p) minz maxz bands))
                (vla-put-Color (cti20w:add-text p (rtos (caddr p) 2 3) ht "CTI-QUOTE-CSV") color))
              (setq legend (getpoint "\nPunto inserimento legenda <Invio per saltare>: "))
              (if legend
                (progn
                  (setq rowh (* ht 1.8) sw (* ht 3.0) i 0 y0 (cadr legend))
                  (while (< i bands)
                    (setq lo (+ minz (* (- maxz minz) (/ (float i) bands)))
                          hi (+ minz (* (- maxz minz) (/ (float (1+ i)) bands))) color (1+ (rem i 9))
                          p (list (car legend) (- y0 (* i rowh)) (if (caddr legend) (caddr legend) 0.0)))
                    (cti20c:swatch p sw color)
                    (cti20w:add-text (list (+ (car p) sw (* ht 0.5)) (- (cadr p) (* ht 0.35)) (caddr p))
                                     (strcat (rtos lo 2 2) " - " (rtos hi 2 2)) (* ht 0.85) "CTI-QUOTE-CSV")
                    (setq i (1+ i)))))
              (princ (strcat "\nQuote importate: " (itoa (length pts)) ". Min=" (rtos minz 2 3) " Max=" (rtos maxz 2 3) ".")))
            (princ "\nNessuna riga X,Y,Z valida trovata.")))
        (princ "\nImpossibile aprire il file selezionato."))))
  (princ))
(defun c:CTI_PLOTTA_QUOTE_DA_CSV () (cti20w:run 'cti20c:cmd-plotta-quote-csv))

; ======================================================================
; Sorgenti MIT esterne - 16 strumenti
; ======================================================================
(vl-load-com)
(setq *CTI-WEB-EXTERNAL-VERSION* "2.0-phase2c")
(setq *CTI-WEB-EXTERNAL-COUNT* 16)
(setq *CTI-WEB-EXTERNAL-LOADED* nil)
(setq *CTI20X-CARTIGLIO-ATTRIBUTI* nil)

(defun cti20x:run (fn)
  (if (fboundp 'cti20w:run)
    (cti20w:run fn)
    (princ "\nRuntime Web 2.0 non caricato: impossibile eseguire il comando.")))

(defun cti20x:mid (a b) (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b))
(defun cti20x:pt3 (p) (list (car p) (cadr p) (if (caddr p) (caddr p) 0.0)))

(defun cti20x:text-height (/ h)
  (setq h (vl-catch-all-apply 'getvar (list "TEXTSIZE")))
  (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0)) 2.5 h))

(defun cti20x:unit-to-m (/ u)
  (setq u (getvar "INSUNITS"))
  (cond ((= u 1) 0.0254) ((= u 2) 0.3048) ((= u 4) 0.001)
        ((= u 5) 0.01) ((= u 6) 1.0) ((= u 7) 1000.0) (T nil)))

(defun cti20x:length-label (v / f)
  (setq f (cti20x:unit-to-m))
  (if f (strcat (rtos (* v f) 2 2) " m") (rtos v 2 2)))


(defun cti20x:dot2 (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))
(defun cti20x:vec2 (a b) (list (- (car b) (car a)) (- (cadr b) (cadr a))))
(defun cti20x:near (a b tol) (<= (abs (- a b)) (* tol (max 1.0 (abs a) (abs b)))))

(defun cti20x:rettangolo-p (pts / p1 p2 p3 p4 v1 v2 v3 v4 l1 l2 l3 l4 tol)
  (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
        v1 (cti20x:vec2 p1 p2) v2 (cti20x:vec2 p2 p3)
        v3 (cti20x:vec2 p3 p4) v4 (cti20x:vec2 p4 p1)
        l1 (distance p1 p2) l2 (distance p2 p3) l3 (distance p3 p4) l4 (distance p4 p1)
        tol 1e-6)
  (and (> l1 1e-9) (> l2 1e-9) (> l3 1e-9) (> l4 1e-9)
       (< (/ (abs (cti20x:dot2 v1 v2)) (* l1 l2)) tol)
       (< (/ (abs (cti20x:dot2 v2 v3)) (* l2 l3)) tol)
       (cti20x:near l1 l3 tol)
       (cti20x:near l2 l4 tol)))

(defun cti20x:rect-verts (e / pts)
  (if (and e (= (cdr (assoc 0 (entget e))) "LWPOLYLINE") (cti20w:lw-closed-p e) (not (cti20w:lw-has-bulge-p e)))
    (progn
      (setq pts (cti20w:lwverts e))
      (if (and (= (length pts) 4) (cti20x:rettangolo-p pts)) pts nil))
    nil))

(defun cti20x:make-centered-text (pt str ht ang layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddText (cti20w:space) str (vlax-3d-point pt) ht))
  (vla-put-Layer o layer)
  (vla-put-Alignment o 10) ; acAlignmentMiddleCenter
  (vla-put-TextAlignmentPoint o (vlax-3d-point pt))
  (vla-put-Rotation o ang)
  o)

(defun cti20x:dim-side (a b center offset / mid dir p o)
  (setq mid (cti20x:mid a b) dir (angle center mid) p (polar mid dir offset))
  (setq o (vl-catch-all-apply 'vla-AddDimAligned
            (list (cti20w:space) (vlax-3d-point a) (vlax-3d-point b) (vlax-3d-point p))))
  (if (vl-catch-all-error-p o) nil o))

(defun cti20x:make-rect (p1 p2 layer / x1 y1 x2 y2)
  (setq x1 (car p1) y1 (cadr p1) x2 (car p2) y2 (cadr p2))
  (cti20w:make-lwpoly (list (list x1 y1 0.0) (list x2 y1 0.0) (list x2 y2 0.0) (list x1 y2 0.0)) layer T))

(defun cti20x:csv-write-row (f vals /)
  (write-line (cti20w:join (mapcar 'cti20w:csv-quote vals) ";") f))

(defun cti20x:block-attrs (obj / out a)
  (setq out nil)
  (if (= :vlax-true (vla-get-HasAttributes obj))
    (foreach a (cti20w:in-lista (vlax-invoke obj 'GetAttributes))
      (setq out (cons (cons (strcase (vla-get-TagString a)) (vla-get-TextString a)) out))))
  (reverse out))

(defun cti20x:set-block-attrs (obj pairs / a p n)
  (setq n 0)
  (if (= :vlax-true (vla-get-HasAttributes obj))
    (foreach a (cti20w:in-lista (vlax-invoke obj 'GetAttributes))
      (if (setq p (assoc (strcase (vla-get-TagString a)) pairs))
        (progn (vla-put-TextString a (cdr p)) (setq n (1+ n))))))
  n)

; ----------------------------------------------------------------------
; vjspab/autocad-lisp-toolkit (MIT) - 8 strumenti
; ----------------------------------------------------------------------
(defun cti20x:cmd-quota-automatica (/ e pts p1 p2 p3 p4 d1 d2 len wid ang center ht off olddim)
  (setq e (car (entsel "\nSeleziona un rettangolo chiuso LWPOLYLINE: ")))
  (if (setq pts (cti20x:rect-verts e))
    (progn
      (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
            d1 (distance p1 p2) d2 (distance p2 p3))
      (if (> d1 d2) (setq len d1 wid d2 ang (angle p1 p2)) (setq len d2 wid d1 ang (angle p2 p3)))
      (if (and (> ang (/ pi 2.0)) (<= ang (* pi 1.5))) (setq ang (- ang pi)))
      (setq center (cti20x:mid p1 p3)
            ht (getreal (strcat "\nAltezza testo/quote <" (rtos (cti20x:text-height) 2 2) ">: ")))
      (if (not ht) (setq ht (cti20x:text-height)))
      (setq off (getdist (strcat "\nDistanza quote dal contorno <" (rtos (* ht 1.5) 2 2) ">: ")))
      (if (not off) (setq off (* ht 1.5)))
      (setvar "DIMTXT" ht)
      (cti20x:make-centered-text center (strcat (cti20x:length-label len) " x " (cti20x:length-label wid)) ht ang "CTI-QUOTE-AUTO")
      (cti20x:dim-side p1 p2 center off) (cti20x:dim-side p2 p3 center off)
      (cti20x:dim-side p3 p4 center off) (cti20x:dim-side p4 p1 center off)
      (princ "\nQuotatura automatica completata."))
    (princ "\nServe una LWPOLYLINE chiusa con esattamente quattro vertici."))
  (princ))
(defun c:CTI_QUOTA_AUTOMATICA () (cti20x:run 'cti20x:cmd-quota-automatica))

(defun cti20x:cmd-copia-poligoni-chiusi (/ tab ss e o cp n layer)
  (setq tab (getvar "CTAB") layer "CTI-POLIGONI-COPIATI" n 0
        ss (ssget "_X" (list '(0 . "LWPOLYLINE") '(-4 . "&") '(70 . 1) (cons 410 tab))))
  (cti20w:ensure-layer layer 5)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e) cp (vl-catch-all-apply 'vla-Copy (list o)))
    (if (not (vl-catch-all-error-p cp)) (progn (vla-put-Layer cp layer) (setq n (1+ n)))))
  (princ (strcat "\nPoligoni chiusi copiati sul layer " layer ": " (itoa n) ".")) (princ))
(defun c:CTI_COPIA_POLIGONI_CHIUSI () (cti20x:run 'cti20x:cmd-copia-poligoni-chiusi))

(defun cti20x:cmd-dividi-lunghezze (/ e o maxd cur d p n)
  (setq e (car (entsel "\nSeleziona arco o curva da dividere: ")) n 0)
  (if e
    (progn
      (setq o (vlax-ename->vla-object e) maxd (cti20w:curve-length o) cur 0.0)
      (if maxd
        (progn
          (princ (strcat "\nLunghezza totale: " (rtos maxd 2 3) "."))
          (while (setq d (getreal (strcat "\nLunghezza segmento successivo; Invio termina [restano " (rtos (- maxd cur) 2 3) "]: ")))
            (if (<= d 0.0)
              (princ "\nLa lunghezza deve essere positiva.")
              (if (<= (+ cur d) (+ maxd 1e-8))
                (progn (setq cur (+ cur d) p (vlax-curve-getPointAtDist o cur))
                       (if p (progn (entmakex (list '(0 . "POINT") (cons 10 p))) (setq n (1+ n)))))
                (princ "\nIl segmento supera la lunghezza residua; valore ignorato.")))))))
  (princ (strcat "\nPunti di divisione creati: " (itoa n) ".")) (princ))
)
(defun c:CTI_DIVIDI_LUNGHEZZE () (cti20x:run 'cti20x:cmd-dividi-lunghezze))

(defun cti20x:cmd-esporta-dati-lotti (/ ss pols texts e typ p val path f pts area cen label tdata titem n)
  (prompt "\nSeleziona poligoni chiusi e testi identificativi dei lotti: ")
  (setq ss (ssget '((0 . "LWPOLYLINE,TEXT,MTEXT"))) pols nil texts nil n 0)
  (foreach e (cti20w:ss-list ss)
    (setq typ (cdr (assoc 0 (entget e))))
    (cond
      ((= typ "LWPOLYLINE") (if (and (cti20w:lw-closed-p e) (not (cti20w:lw-has-bulge-p e))) (setq pols (cons e pols))))
      (T (if (setq p (cti20w:inspt e)) (setq texts (cons (list e p (cti20w:text-get e)) texts))))))
  (if pols
    (progn
      (setq path (getfiled "Salva dati lotti" "dati_lotti" "csv" 1))
      (if path
        (progn
          (setq f (open path "w"))
          (if f
            (progn
              (cti20x:csv-write-row f '("Lotto" "Area" "Centro X" "Centro Y"))
              (foreach e pols
                (setq pts (cti20w:lwverts e) area (vla-get-Area (vlax-ename->vla-object e))
                      cen (cti20w:poly-centroid pts) label "LOTTO_SENZA_NOME")
                (foreach titem texts (if (cti20w:point-in-poly (cadr titem) pts) (setq label (caddr titem))))
                (cti20x:csv-write-row f (list label (rtos area 2 3) (rtos (car cen) 2 3) (rtos (cadr cen) 2 3)))
                (setq n (1+ n)))
              (close f) (princ (strcat "\nLotti esportati: " (itoa n) ". File: " path)))
            (princ "\nImpossibile creare il file CSV."))))))
  (princ))
(defun c:CTI_ESPORTA_DATI_LOTTI () (cti20x:run 'cti20x:cmd-esporta-dati-lotti))

(defun cti20x:cmd-genera-lottizzazione (/ w d cols rows back gap roads rw p bx by bw bd ht i j x1 y1 x2 y2 num rightoff total z)
  (setq w (getdist "\nLarghezza/fronte lotto: ") d (getdist "\nProfondità lotto: ")
        cols (getint "\nNumero colonne per lato: ") rows (getint "\nNumero righe: "))
  (initget "Si No") (setq back (getkword "\nLotti contrapposti schiena-a-schiena [Si/No] <No>: ")) (if (not back) (setq back "No"))
  (setq gap 0.0)
  (if (= back "Si") (progn (setq gap (getdist "\nDistanza/corridoio fra i due lati <0>: ")) (if (not gap) (setq gap 0.0))))
  (initget "Si No") (setq roads (getkword "\nDisegnare strade laterali [Si/No] <Si>: ")) (if (not roads) (setq roads "Si"))
  (setq rw 0.0)
  (if (= roads "Si") (progn (setq rw (getdist "\nLarghezza strada: ")) (if (not rw) (setq rw (* w 1.5)))))
  (setq p (getpoint "\nPunto di inserimento inferiore sinistro: "))
  (if (and w d cols rows p (> w 0) (> d 0) (> cols 0) (> rows 0))
    (progn
      (foreach z '(("CTI-LOTTI" 2) ("CTI-LOTTI-TESTO" 3) ("CTI-LOTTI-BLOCCO" 1) ("CTI-LOTTI-STRADA" 4)) (cti20w:ensure-layer (car z) (cadr z)))
      (setq bx (car p) by (cadr p) bw (if (= back "Si") (+ (* 2 cols w) gap) (* cols w)) bd (* rows d) ht (* (min w d) 0.12) num 1)
      (setq j 0)
      (repeat rows
        (setq i 0)
        (repeat cols
          (setq x1 (+ bx (* i w)) y1 (+ by (* j d)) x2 (+ x1 w) y2 (+ y1 d))
          (cti20x:make-rect (list x1 y1) (list x2 y2) "CTI-LOTTI")
          (cti20x:make-centered-text (list (/ (+ x1 x2) 2.0) (/ (+ y1 y2) 2.0) 0.0) (strcat "L-" (itoa num)) ht 0.0 "CTI-LOTTI-TESTO")
          (setq num (1+ num) i (1+ i)))
        (setq j (1+ j)))
      (if (= back "Si")
        (progn (setq rightoff (+ (* cols w) gap) j 0)
          (repeat rows (setq i 0) (repeat cols
            (setq x1 (+ bx rightoff (* i w)) y1 (+ by (* j d)) x2 (+ x1 w) y2 (+ y1 d))
            (cti20x:make-rect (list x1 y1) (list x2 y2) "CTI-LOTTI")
            (cti20x:make-centered-text (list (/ (+ x1 x2) 2.0) (/ (+ y1 y2) 2.0) 0.0) (strcat "L-" (itoa num)) ht 0.0 "CTI-LOTTI-TESTO")
            (setq num (1+ num) i (1+ i))) (setq j (1+ j)))))
      (cti20x:make-rect (list bx by) (list (+ bx bw) (+ by bd)) "CTI-LOTTI-BLOCCO")
      (if (= roads "Si")
        (progn (cti20x:make-rect (list (- bx rw) by) (list bx (+ by bd)) "CTI-LOTTI-STRADA")
               (cti20x:make-rect (list (+ bx bw) by) (list (+ bx bw rw) (+ by bd)) "CTI-LOTTI-STRADA")))
      (setq total (1- num)) (princ (strcat "\nLottizzazione generata. Lotti: " (itoa total) "."))))
  (princ))
(defun c:CTI_GENERA_LOTTIZZAZIONE () (cti20x:run 'cti20x:cmd-genera-lottizzazione))

(defun cti20x:cmd-poligono-da-area (/ layer p before after n _cti_boundary_result)
  (setq layer "CTI-POLIGONI-DA-AREA" n 0) (cti20w:ensure-layer layer 4)
  (princ "\nIndica punti interni ad aree chiuse; Invio termina.")
  (while (setq p (getpoint "\nPunto interno: "))
    (setq before (entlast))
    (setq _cti_boundary_result
      (vl-catch-all-apply 'command-s (list "_.-BOUNDARY" "_A" "_O" "_P" "" p "")))
    (setq after (entlast))
    (if (and after (not (eq after before)))
      (progn (vla-put-Layer (vlax-ename->vla-object after) layer) (setq n (1+ n)) (princ "\nPoligono creato."))
      (princ "\nContorno non trovato.")))
  (princ (strcat "\nPoligoni creati: " (itoa n) ".")) (princ))
(defun c:CTI_POLIGONO_DA_AREA () (cti20x:run 'cti20x:cmd-poligono-da-area))

(defun cti20x:cmd-dettagli-lotto (/ e pts p1 p2 p3 p4 center area ht off ang)
  (setq e (car (entsel "\nSeleziona un lotto rettangolare chiuso: ")))
  (if (setq pts (cti20x:rect-verts e))
    (progn
      (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
            center (cti20x:mid p1 p3) area (vla-get-Area (vlax-ename->vla-object e))
            ht (cti20x:text-height) off (* ht 1.5) ang (angle p1 p2))
      (if (and (> ang (/ pi 2.0)) (<= ang (* pi 1.5))) (setq ang (- ang pi)))
      (cti20x:make-centered-text center (strcat "Area: " (rtos area 2 2)) ht ang "CTI-DETTAGLI-LOTTO")
      (cti20x:dim-side p1 p2 center off) (cti20x:dim-side p2 p3 center off)
      (cti20x:dim-side p3 p4 center off) (cti20x:dim-side p4 p1 center off)
      (princ "\nArea e quote del lotto create."))
    (princ "\nServe una LWPOLYLINE rettangolare chiusa con quattro vertici."))
  (princ))
(defun c:CTI_DETTAGLI_LOTTO () (cti20x:run 'cti20x:cmd-dettagli-lotto))

(defun cti20x:cmd-numera-lotti (/ prefix start ht ss e obj closed guide pols data cen q d sorted n item)
  (setq prefix (getstring T "\nPrefisso lotti <L>: ")) (if (= prefix "") (setq prefix "L"))
  (setq start (getint "\nNumero iniziale <1>: ")) (if (not start) (setq start 1))
  (setq ht (getdist (strcat "\nAltezza testo <" (rtos (cti20x:text-height) 2 2) ">: "))) (if (not ht) (setq ht (cti20x:text-height)))
  (prompt "\nSeleziona poligoni chiusi e UNA polilinea aperta guida: ")
  (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) pols nil guide nil)
  (foreach e (cti20w:ss-list ss)
    (setq obj (vlax-ename->vla-object e) closed (vlax-curve-isClosed obj))
    (if closed (setq pols (cons e pols)) (if guide (princ "\nAvviso: più guide aperte; uso l'ultima selezionata.")) (setq guide obj)))
  (if (and guide pols)
    (progn
      (setq data nil)
      (foreach e pols
        (setq cen (cti20w:bbox-center e) q (vlax-curve-getClosestPointTo guide cen) d (vlax-curve-getDistAtPoint guide q))
        (setq data (cons (list d cen) data)))
      (setq sorted (vl-sort data '(lambda (a b) (< (car a) (car b)))) n start)
      (foreach item sorted
        (cti20x:make-centered-text (cadr item) (strcat prefix (if (< n 10) "0" "") (itoa n)) ht 0.0 "CTI-NUMERI-LOTTI")
        (setq n (1+ n)))
      (princ (strcat "\nLotti numerati: " (itoa (length sorted)) ".")))
    (princ "\nSelezionare almeno un poligono chiuso e una polilinea aperta guida."))
  (princ))
(defun c:CTI_NUMERA_LOTTI () (cti20x:run 'cti20x:cmd-numera-lotti))

; ----------------------------------------------------------------------
; LetsBIMtogether/AutoLisp (MIT) - 4 strumenti
; ----------------------------------------------------------------------
(defun cti20x:cmd-quota-porta (/ p1 p2 h ht side width ang mid normal labpt label)
  (setq p1 (getpoint "\nPrimo stipite della porta: ") p2 (getpoint p1 "\nSecondo stipite della porta: "))
  (if (and p1 p2 (> (distance p1 p2) 1e-9))
    (progn
      (setq width (distance p1 p2)
            h (getdist (strcat "\nAltezza porta in unità disegno <" (rtos (cond ((= (getvar "INSUNITS") 4) 2100.0) ((= (getvar "INSUNITS") 6) 2.10) (T width)) 2 2) ">: ")))
      (if (not h) (setq h (cond ((= (getvar "INSUNITS") 4) 2100.0) ((= (getvar "INSUNITS") 6) 2.10) (T width))))
      (setq ht (getdist (strcat "\nAltezza testo <" (rtos (cti20x:text-height) 2 2) ">: "))) (if (not ht) (setq ht (cti20x:text-height)))
      (setq side (getpoint (cti20x:mid p1 p2) "\nIndica il lato su cui posizionare la sigla: ") ang (angle p1 p2) mid (cti20x:mid p1 p2)
            normal (if side (angle mid side) (+ ang (/ pi 2.0))) labpt (polar mid normal (* ht 2.0))
            label (strcat (cti20x:length-label width) " x " (cti20x:length-label h)))
      (cti20x:make-centered-text labpt label ht ang "CTI-QUOTE-PORTE")
      (princ (strcat "\nQuota porta creata: " label "."))))
  (princ))
(defun c:CTI_QUOTA_PORTA () (cti20x:run 'cti20x:cmd-quota-porta))


(defun cti20x:zoom-object (obj / mn mx r a b dx dy p1 p2 app)
  (setq r (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'mn 'mx)))
  (if (vl-catch-all-error-p r) nil
    (progn
      (setq a (vlax-safearray->list mn) b (vlax-safearray->list mx)
            dx (max 1e-6 (- (car b) (car a))) dy (max 1e-6 (- (cadr b) (cadr a)))
            p1 (list (- (car a) (* dx 0.25)) (- (cadr a) (* dy 0.25)) (if (caddr a) (caddr a) 0.0))
            p2 (list (+ (car b) (* dx 0.25)) (+ (cadr b) (* dy 0.25)) (if (caddr b) (caddr b) 0.0))
            app (vlax-get-acad-object))
      (vl-catch-all-apply 'vla-ZoomWindow (list app (vlax-3d-point p1) (vlax-3d-point p2))))))

(defun cti20x:split-slash (s / p)
  (setq p (vl-string-search "/" s))
  (if p (list (substr s 1 p) (substr s (+ p 2))) (list s nil)))

(defun cti20x:cmd-trova-tag (/ raw parts a b doc blk obj attrs hit found att val)
  (setq raw (strcase (getstring T "\nTag/attributi da cercare (es. 3/A-5): ")))
  (if (/= raw "")
    (progn
      (setq parts (cti20x:split-slash raw) a (car parts) b (cadr parts) found 0 doc (cti20w:doc) blk (vla-get-Block (vla-get-ActiveLayout doc)))
      (vlax-for obj blk
        (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference") (= :vlax-true (vla-get-HasAttributes obj)))
          (progn
            (setq hit 0 attrs (cti20w:in-lista (vlax-invoke obj 'GetAttributes)) att nil)
            (foreach att attrs
              (setq val (strcase (vla-get-TextString att)))
              (if (= val a) (setq hit (logior hit 1)))
              (if (and b (= val b)) (setq hit (logior hit 2))))
            (if (or (and b (= hit 3)) (and (not b) (= hit 1)))
              (progn
                (setq found (1+ found))
                (cti20x:zoom-object obj)
                (getstring (strcat "\nTrovato #" (itoa found) ". Invio per continuare; ESC interrompe: ")))))))
      (princ (strcat "\nRicerca completata. Tag trovati: " (itoa found) "."))))
  (princ))
(defun c:CTI_TROVA_TAG () (cti20x:run 'cti20x:cmd-trova-tag))

(defun cti20x:color-label (c)
  (cond ((= c 1) "rosso") ((= c 2) "giallo") ((= c 3) "verde") ((= c 4) "ciano")
        ((= c 5) "blu") ((= c 6) "magenta") ((= c 7) "bianco/nero") (T (strcat "ACI " (itoa c)))))

(defun cti20x:cmd-legenda-layer (/ p ht len spacing lays lay data name col desc y a b txt n ln tx layerout)
  (setq p (getpoint "\nPunto iniziale della legenda layer: ") layerout "CTI-LEGENDA-LAYER")
  (if p
    (progn
      (cti20w:ensure-layer layerout 7)
      (setq ht (getdist (strcat "\nAltezza testo <" (rtos (cti20x:text-height) 2 2) ">: "))) (if (not ht) (setq ht (cti20x:text-height)))
      (setq len (getdist (strcat "\nLunghezza campione linea <" (rtos (* ht 12.0) 2 2) ">: "))) (if (not len) (setq len (* ht 12.0)) spacing (* ht 1.8) lays nil n 0)
      (vlax-for lay (vla-get-Layers (cti20w:doc))
        (setq lays (cons (list (vla-get-Name lay) (vla-get-Color lay) (vla-get-Description lay)) lays)))
      (setq lays (vl-sort lays '(lambda (x y) (< (strcase (car x)) (strcase (car y))))))
      (foreach data lays
        (setq name (nth 0 data) col (nth 1 data) desc (nth 2 data) y (- (cadr p) (* n spacing))
              a (list (car p) y 0.0) b (list (+ (car p) len) y 0.0)
              txt (strcat name " | " (cti20x:color-label (if (or (= col 0) (= col 256)) 7 col)) (if (and desc (/= desc "")) (strcat " | " desc) "")))
        (setq ln (cti20w:add-line a b layerout))
        (vl-catch-all-apply 'vla-put-Color (list ln (if (or (= col 0) (= col 256)) 7 col)))
        (setq tx (cti20w:add-text (list (+ (car p) len (* ht 1.5)) (- y (/ ht 2.0)) 0.0) txt ht layerout))
        (vla-put-Color tx 7)
        (setq n (1+ n)))
      (princ (strcat "\nLegenda completata. Layer elencati: " (itoa n) "."))))
  (princ))
(defun c:CTI_LEGENDA_LAYER () (cti20x:run 'cti20x:cmd-legenda-layer))

(defun cti20x:cmd-quota-stanza (/ p1 p2 p3 lab dx dy ht txt)
  (setq p1 (getpoint "\nPrimo angolo della stanza: ") p2 (getpoint p1 "\nAngolo diagonalmente opposto: "))
  (if (and p1 p2)
    (progn
      (setq lab (getpoint "\nPunto per l'etichetta dimensioni: ") p3 (list (car p1) (cadr p2) 0.0)
            dx (distance p3 p2) dy (distance p1 p3) ht (cti20x:text-height)
            txt (strcat (cti20x:length-label dx) " x " (cti20x:length-label dy)))
      (if lab (cti20x:make-centered-text lab txt ht 0.0 "CTI-QUOTE-STANZE"))
      (princ (strcat "\nDimensioni stanza: " txt "."))))
  (princ))
(defun c:CTI_QUOTA_STANZA () (cti20x:run 'cti20x:cmd-quota-stanza))

; ----------------------------------------------------------------------
; cantinalabs/acad-scripts (MIT) - 3 strumenti
; ----------------------------------------------------------------------
(defun cti20x:cmd-scala-riferimento (/ ss base a b newlen oldlen factor e o r n)
  (prompt "
Seleziona gli oggetti da scalare: ") (setq ss (ssget))
  (if ss
    (progn
      (setq base (getpoint "
Punto base: ") a (getpoint "
Primo punto della lunghezza di riferimento: "))
      (if a (setq b (getpoint a "
Secondo punto della lunghezza di riferimento: ")))
      (setq newlen (getdist "
Nuova lunghezza: "))
      (if (and base a b newlen (> (setq oldlen (distance a b)) 1e-12) (> newlen 0.0))
        (progn
          (setq factor (/ newlen oldlen) n 0)
          (foreach e (cti20w:ss-list ss)
            (setq o (vlax-ename->vla-object e) r (vl-catch-all-apply 'vla-ScaleEntity (list o (vlax-3d-point base) factor)))
            (if (not (vl-catch-all-error-p r)) (setq n (1+ n))))
          (princ (strcat "
Scala per riferimento completata su " (itoa n) " oggetti. Fattore=" (rtos factor 2 6) "."))))))
  (princ))
(defun c:CTI_SCALA_PER_RIFERIMENTO () (cti20x:run 'cti20x:cmd-scala-riferimento))

(defun cti20x:cmd-scala-immagine-contorno (/ img box io bo imn imx bmn bmx a b c d iw ih bw bh factor ic bc)
  (setq img (car (entsel "\nSeleziona l'immagine raster: ")) box (car (entsel "\nSeleziona il contorno di destinazione: ")))
  (if (and img box (= (cdr (assoc 0 (entget img))) "IMAGE"))
    (progn
      (setq io (vlax-ename->vla-object img) bo (vlax-ename->vla-object box))
      (if (and (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list io 'imn 'imx))))
               (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list bo 'bmn 'bmx)))))
        (progn
          (setq a (vlax-safearray->list imn) b (vlax-safearray->list imx) c (vlax-safearray->list bmn) d (vlax-safearray->list bmx)
                iw (- (car b) (car a)) ih (- (cadr b) (cadr a)) bw (- (car d) (car c)) bh (- (cadr d) (cadr c)))
          (if (and (> iw 1e-12) (> ih 1e-12) (> bw 0) (> bh 0))
            (progn
              (setq factor (min (/ bw iw) (/ bh ih)) ic (cti20x:mid a b) bc (cti20x:mid c d))
              (vla-ScaleEntity io (vlax-3d-point ic) factor)
              (vla-Move io (vlax-3d-point ic) (vlax-3d-point bc))
              (princ (strcat "\nImmagine adattata al contorno. Fattore: " (rtos factor 2 5) "."))))))))
  (princ))
(defun c:CTI_SCALA_IMMAGINE_CONTORNO () (cti20x:run 'cti20x:cmd-scala-immagine-contorno))

(defun cti20x:cmd-ruota-riferimento (/ ss base a b ref typ refang curang delta e o)
  (prompt "\nSeleziona gli oggetti da ruotare: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq base (getpoint "\nPunto base della rotazione: ")
            a (getpoint "\nPrimo punto della direzione attuale: "))
      (if a (setq b (getpoint a "\nSecondo punto della direzione attuale: ")))
      (if (and base a b (> (distance a b) 1e-10))
        (progn
          (setq ref (car (entsel "\nSeleziona LINEA/ARCO/POLILINEA di riferimento: ")))
          (if ref (setq typ (cdr (assoc 0 (entget ref)))))
          (if (member typ '("LINE" "ARC" "LWPOLYLINE" "POLYLINE"))
            (progn
              (setq curang (angle a b)
                    refang (cti20w:curve-angle-at ref base)
                    delta (- refang curang))
              (foreach e (cti20w:ss-list ss)
                (setq o (vlax-ename->vla-object e))
                (vl-catch-all-apply 'vla-Rotate (list o (vlax-3d-point base) delta)))
              (princ (strcat "\nRotazione applicata: " (rtos (* delta (/ 180.0 pi)) 2 2) "°.")))
            (princ "\nRiferimento non valido: seleziona LINEA, ARCO o POLILINEA."))))))
  (princ))
(defun c:CTI_RUOTA_COME_RIFERIMENTO () (cti20x:run 'cti20x:cmd-ruota-riferimento))

; ----------------------------------------------------------------------
; dtgoitia/civil-autolisp (MIT) - 1 strumento
; ----------------------------------------------------------------------
(defun cti20x:select-block-ref (msg / e o)
  (setq e (car (entsel msg)))
  (if e (progn (setq o (vlax-ename->vla-object e)) (if (= (vla-get-ObjectName o) "AcDbBlockReference") o nil)) nil))

(defun cti20x:cmd-aggiorna-cartiglio (/ op src dst n)
  (initget "Copia Incolla Pulisci")
  (setq op (getkword "\nOperazione cartiglio [Copia/Incolla/Pulisci] <Copia>: ")) (if (not op) (setq op "Copia"))
  (cond
    ((= op "Copia")
     (if (setq src (cti20x:select-block-ref "\nSeleziona il cartiglio sorgente: "))
       (progn (setq *CTI20X-CARTIGLIO-ATTRIBUTI* (cti20x:block-attrs src))
              (princ (strcat "\nAttributi copiati in memoria: " (itoa (length *CTI20X-CARTIGLIO-ATTRIBUTI*)) ".")))
       (princ "\nSelezione non valida.")))
    ((= op "Incolla")
     (if *CTI20X-CARTIGLIO-ATTRIBUTI*
       (if (setq dst (cti20x:select-block-ref "\nSeleziona il cartiglio destinazione: "))
         (progn (setq n (cti20x:set-block-attrs dst *CTI20X-CARTIGLIO-ATTRIBUTI*)) (princ (strcat "\nAttributi aggiornati: " (itoa n) ".")))
         (princ "\nSelezione non valida."))
       (princ "\nNessun cartiglio è stato copiato in memoria.")))
    ((= op "Pulisci") (setq *CTI20X-CARTIGLIO-ATTRIBUTI* nil) (princ "\nMemoria cartiglio svuotata.")))
  (princ))
(defun c:CTI_AGGIORNA_CARTIGLIO () (cti20x:run 'cti20x:cmd-aggiorna-cartiglio))


(setq *CTI-WEB-EXTERNAL-LOADED* T)
(setq *CTI-WEB-PHASE2C-LOADED* T)
(princ "\nCAD Tools Italiano 2.0 Fase 2C: ultimi 28 strumenti Web MIT caricati (88 nuovi cumulativi con 2A+2B).")
(princ)
