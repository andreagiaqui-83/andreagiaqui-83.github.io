; CAD Tools Italiano 2.0 - FASE 2A - primi 30 strumenti Web MIT
; Modulo isolato di sviluppo: NON sostituisce la golden 1.9.
; 30 nuovi strumenti adattati/reimplementati da BGol CAD Lisps (MIT).
; Commit sorgente verificato: 3acbe32f71b489f4c81dcd9372f989591a9be858
;
; Regole obbligatorie applicate a tutti gli entrypoint pubblici:
; - namespace CTI;
; - prompt e output in italiano;
; - ESC/Annulla centralizzato e silenzioso;
; - un solo gruppo UNDO per comando;
; - ripristino centralizzato delle variabili AutoCAD protette;
; - errori reali non mascherati;
; - conservazione della geometria/Z quando tecnicamente rappresentabile.
;
; Licenza/provenienza: vedere LICENZA_BGOL_MIT.txt e MANIFEST_FASE2A_30.csv.


(vl-load-com)
(setq *CTI-WEB-EXTRA-VERSION* "2.0-phase2a")
(setq *CTI-WEB-EXTRA-COUNT* 30)
(setq *CTI-WEB-EXTRA-LOADED* nil)

; ----------------------------------------------------------------------
; INFRASTRUTTURA COMUNE
; ----------------------------------------------------------------------
(defun cti20w:annullamento-p (msg / u)
  (setq u (strcase (if msg (vl-princ-to-string msg) "")))
  (or (wcmatch u "*ANNULL*") (wcmatch u "*CANCEL*") (wcmatch u "*QUIT*")
      (wcmatch u "*EXIT*") (wcmatch u "*ABORT*") (wcmatch u "*BREAK*")))

(defun cti20w:doc () (vla-get-ActiveDocument (vlax-get-acad-object)))
(defun cti20w:space (/ d) (setq d (cti20w:doc)) (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace d) (vla-get-ModelSpace d)))

(setq *CTI20W-VARIABILI-PROTETTE*
  '("CMDECHO" "OSMODE" "CLAYER" "PDMODE" "DIMTXT" "FILEDIA" "ORTHOMODE"
    "SNAPMODE" "MIRRTEXT" "TEXTFILL" "PEDITACCEPT" "FILLETRAD" "BACKGROUNDPLOT"))

(defun cti20w:salva-variabili (/ out n v)
  (setq out nil)
  (foreach n *CTI20W-VARIABILI-PROTETTE*
    (setq v (vl-catch-all-apply 'getvar (list n)))
    (if (not (vl-catch-all-error-p v)) (setq out (cons (cons n v) out))))
  out)

(defun cti20w:ripristina-variabili (lst / x)
  (foreach x lst (vl-catch-all-apply 'setvar (list (car x) (cdr x))))
  (princ))

(defun cti20w:run (fn / r doc undo-open vars)
  (setq doc (cti20w:doc) undo-open nil vars (cti20w:salva-variabili))
  (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-StartUndoMark (list doc))))
    (setq undo-open T))
  (setq r (vl-catch-all-apply fn '()))
  (cti20w:ripristina-variabili vars)
  (if undo-open (vl-catch-all-apply 'vla-EndUndoMark (list doc)))
  (if (vl-catch-all-error-p r)
    (if (not (cti20w:annullamento-p (vl-catch-all-error-message r)))
      (princ (strcat "\nErrore Web MIT: " (vl-catch-all-error-message r)))))
  (princ))

(defun cti20w:in-lista (v / r)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond ((listp v) v)
        (T (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
           (if (vl-catch-all-error-p r) nil r))))

(defun cti20w:ss-list (ss / out i)
  (setq out nil i 0)
  (if ss (repeat (sslength ss) (setq out (cons (ssname ss i) out) i (1+ i))))
  (reverse out))

(defun cti20w:ensure-layer (name color /)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous"))))
  name)

(defun cti20w:point-list (v / r)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond ((listp v) v)
        (T (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
           (if (vl-catch-all-error-p r) nil r))))

(defun cti20w:inspt (e / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vlax-get (list o 'InsertionPoint)))
  (if (vl-catch-all-error-p r) nil (cti20w:point-list r)))

(defun cti20w:text-get (e / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-get-TextString (list o)))
  (if (vl-catch-all-error-p r) nil r))

(defun cti20w:text-set (e s / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-put-TextString (list o s)))
  (not (vl-catch-all-error-p r)))

(defun cti20w:num-text (e / s n)
  (setq s (cti20w:text-get e))
  (if (and s (/= (vl-string-trim " \t" s) ""))
    (progn (setq n (distof (vl-string-translate "," "." (vl-string-trim " \t" s)) 2)) n)
    nil))

(defun cti20w:add-text (pt str ht layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddText (cti20w:space) str (vlax-3d-point pt) ht))
  (vla-put-Layer o layer) o)

(defun cti20w:add-line (p1 p2 layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddLine (cti20w:space) (vlax-3d-point p1) (vlax-3d-point p2)))
  (vla-put-Layer o layer) o)

(defun cti20w:add-circle (p r layer / o)
  (cti20w:ensure-layer layer 1)
  (setq o (vla-AddCircle (cti20w:space) (vlax-3d-point p) r))
  (vla-put-Layer o layer) o)

(defun cti20w:bbox-center (e / o mn mx r a b)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-GetBoundingBox (list o 'mn 'mx)))
  (if (vl-catch-all-error-p r) nil
    (progn (setq a (vlax-safearray->list mn) b (vlax-safearray->list mx))
           (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b))))

(defun cti20w:curve-length (e / o ep r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        ep (vl-catch-all-apply 'vlax-curve-getEndParam (list o)))
  (if (vl-catch-all-error-p ep) nil
    (progn (setq r (vl-catch-all-apply 'vlax-curve-getDistAtParam (list o ep)))
           (if (vl-catch-all-error-p r) nil r))))

(defun cti20w:closest (e p / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list o p)))
  (if (vl-catch-all-error-p r) nil r))

(defun cti20w:curve-angle-at (e p / o q par der)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        q (cti20w:closest o p))
  (if q
    (progn
      (setq par (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list o q)))
      (if (vl-catch-all-error-p par) 0.0
        (progn (setq der (vl-catch-all-apply 'vlax-curve-getFirstDeriv (list o par)))
               (if (vl-catch-all-error-p der) 0.0 (angle '(0.0 0.0 0.0) der)))))
    0.0))

(defun cti20w:lwverts (e / ed typ o c z n i out v vd)
  (setq ed (entget e) typ (cdr (assoc 0 ed)) out nil)
  (cond
    ((= typ "LWPOLYLINE")
     (setq o (vlax-ename->vla-object e) c (cti20w:in-lista (vlax-get o 'Coordinates))
           z (vl-catch-all-apply 'vlax-get (list o 'Elevation)))
     (if (vl-catch-all-error-p z) (setq z 0.0))
     (setq n (/ (length c) 2) i 0)
     (while (< i n) (setq out (cons (list (nth (* 2 i) c) (nth (1+ (* 2 i)) c) z) out) i (1+ i)))
     (reverse out))
    ((= typ "POLYLINE")
     (setq v (entnext e))
     (while (and v (= (cdr (assoc 0 (entget v))) "VERTEX"))
       (setq vd (entget v) out (cons (cdr (assoc 10 vd)) out) v (entnext v)))
     (reverse out))
    (T nil)))

(defun cti20w:lw-closed-p (e / ed) (setq ed (entget e)) (= 1 (logand 1 (if (assoc 70 ed) (cdr (assoc 70 ed)) 0))))
(defun cti20w:lw-has-bulge-p (e / x yes) (setq yes nil) (foreach x (entget e) (if (and (= (car x) 42) (> (abs (cdr x)) 1e-10)) (setq yes T))) yes)

(defun cti20w:make-lwpoly (pts layer closed / data p z samez)
  (cti20w:ensure-layer layer 7)
  (setq z (if (and pts (caddr (car pts))) (caddr (car pts)) 0.0) samez T)
  (foreach p pts
    (if (> (abs (- (if (caddr p) (caddr p) 0.0) z)) 1e-9) (setq samez nil)))
  (if (not samez)
    (cti20w:make-3dpoly pts layer closed)
    (progn
      (setq data (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 layer)
                       '(100 . "AcDbPolyline") (cons 90 (length pts))
                       (cons 70 (if closed 1 0)) (cons 38 z)))
      (foreach p pts
        (setq data (append data (list (cons 10 (list (car p) (cadr p)))))))
      (entmakex data))))

(defun cti20w:make-3dpoly (pts layer closed / head p last)
  (cti20w:ensure-layer layer 7)
  (setq head (entmakex (list '(0 . "POLYLINE") '(100 . "AcDbEntity") (cons 8 layer)
                             '(100 . "AcDb3dPolyline") (cons 66 1) (cons 70 (+ 8 (if closed 1 0))) (cons 10 '(0.0 0.0 0.0)))))
  (foreach p pts
    (entmakex (list '(0 . "VERTEX") '(100 . "AcDbEntity") (cons 8 layer) '(100 . "AcDbVertex")
                    '(100 . "AcDb3dPolylineVertex") (cons 10 p) '(70 . 32))))
  (entmakex '((0 . "SEQEND"))) head)

(defun cti20w:poly-area2 (pts / a i n p q)
  (setq a 0.0 n (length pts) i 0)
  (while (< i n)
    (setq p (nth i pts) q (nth (rem (1+ i) n) pts)
          a (+ a (- (* (car p) (cadr q)) (* (car q) (cadr p)))) i (1+ i)))
  (/ a 2.0))

(defun cti20w:poly-centroid (pts / a cx cy i n p q cross)
  (setq a (cti20w:poly-area2 pts) cx 0.0 cy 0.0 n (length pts) i 0)
  (if (< (abs a) 1e-12)
    (list (/ (apply '+ (mapcar 'car pts)) n) (/ (apply '+ (mapcar 'cadr pts)) n) 0.0)
    (progn
      (while (< i n)
        (setq p (nth i pts) q (nth (rem (1+ i) n) pts)
              cross (- (* (car p) (cadr q)) (* (car q) (cadr p)))
              cx (+ cx (* (+ (car p) (car q)) cross))
              cy (+ cy (* (+ (cadr p) (cadr q)) cross))
              i (1+ i)))
      (list (/ cx (* 6.0 a)) (/ cy (* 6.0 a)) 0.0))))

(defun cti20w:point-in-poly (pt poly / x y inside i j pi pj xi yi xj yj)
  (setq x (car pt) y (cadr pt) inside nil i 0 j (1- (length poly)))
  (while (< i (length poly))
    (setq pi (nth i poly) pj (nth j poly) xi (car pi) yi (cadr pi) xj (car pj) yj (cadr pj))
    (if (and (/= (> yi y) (> yj y))
             (< x (+ xi (* (/ (- y yi) (- yj yi)) (- xj xi)))))
      (setq inside (not inside)))
    (setq j i i (1+ i))) inside)

(defun cti20w:split-char (s ch / out pos start)
  (setq out nil start 1)
  (while (setq pos (vl-string-search ch s (1- start)))
    (setq out (append out (list (substr s start (1+ (- pos start))))) start (+ pos 2)))
  (append out (list (substr s start))))

(defun cti20w:csv-split (s sep / out fld i q c)
  (setq out nil fld "" i 1 q nil)
  (while (<= i (strlen s))
    (setq c (substr s i 1))
    (cond ((= c "\"")
           (if (and q (< i (strlen s)) (= (substr s (1+ i) 1) "\""))
             (progn (setq fld (strcat fld "\"")) (setq i (1+ i)))
             (setq q (not q))))
          ((and (not q) (= c sep)) (setq out (append out (list fld)) fld ""))
          (T (setq fld (strcat fld c))))
    (setq i (1+ i)))
  (append out (list fld)))

(defun cti20w:csv-sep (s / c1 c2 c)
  (setq c1 0 c2 0)
  (foreach c (vl-string->list s)
    (cond ((= c 44) (setq c1 (1+ c1)))
          ((= c 59) (setq c2 (1+ c2)))))
  (if (> c2 c1) ";" ","))

(defun cti20w:str-replace-all (new old s / pos start out)
  (setq s (if s s "") start 0 out "")
  (while (setq pos (vl-string-search old s start))
    (setq out (strcat out (substr s (1+ start) (- pos start)) new)
          start (+ pos (strlen old))))
  (strcat out (substr s (1+ start))))

(defun cti20w:csv-quote (s)
  (strcat "\"" (cti20w:str-replace-all "\"\"" "\"" (if s s "")) "\""))

(defun cti20w:join (lst sep / out x)
  (setq out "")
  (foreach x lst
    (setq out (strcat out (if (= out "") "" sep) x)))
  out)

(defun cti20w:make-cloud (pts layer / data p)
  (cti20w:ensure-layer layer 6)
  (setq data (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 layer)
                   '(100 . "AcDbPolyline") (cons 90 (length pts)) '(70 . 1)))
  (foreach p pts
    (setq data (append data (list (cons 10 (list (car p) (cadr p))) (cons 42 0.42)))))
  (entmakex data))

(defun cti20w:insert-block (name pt scale rot layer / o)
  (if (tblsearch "BLOCK" name)
    (progn
      (setq o (vla-InsertBlock (cti20w:space) (vlax-3d-point pt) name scale scale scale rot))
      (if layer (vla-put-Layer o layer)) o)
    nil))

(defun cti20w:ask-block-name (/ n)
  (setq n (getstring T "\nNome del blocco già definito nel disegno: "))
  (if (and n (/= n "") (tblsearch "BLOCK" n)) n (progn (princ "\nBlocco non trovato.") nil)))

(defun cti20w:find-numeric-texts (/ ss out e v tab)
  ; Cerca soltanto nello spazio/layout corrente, evitando riferimenti incrociati fra schede.
  (setq tab (getvar "CTAB")
        ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab)))
        out nil)
  (foreach e (cti20w:ss-list ss)
    (if (setq v (cti20w:num-text e))
      (setq out (cons (list e v (cti20w:inspt e)) out))))
  out)

(defun cti20w:nearest-num-text (pt data / best bd d x)
  (setq best nil bd nil)
  (foreach x data
    (if (caddr x)
      (progn (setq d (distance pt (caddr x))) (if (or (null bd) (< d bd)) (setq bd d best x))))) best)

(defun cti20w:move-z (o dz / p1 p2)
  (setq p1 (vlax-3d-point '(0.0 0.0 0.0)) p2 (vlax-3d-point (list 0.0 0.0 dz)))
  (vl-catch-all-apply 'vla-Move (list o p1 p2)))

(defun cti20w:poly-segment-midpoints (pts closed / out i n a b)
  (setq out nil i 0 n (length pts))
  (while (< i (1- n)) (setq a (nth i pts) b (nth (1+ i) pts) out (cons (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b) out) i (1+ i)))
  (if (and closed (> n 2)) (setq out (cons (mapcar '(lambda (x y) (/ (+ x y) 2.0)) (car pts) (nth (1- n) pts)) out)))
  (reverse out))

(defun cti20w:rebuild-lw-straight (e pts / o arr flat)
  (setq flat (apply 'append (mapcar '(lambda (p) (list (car p) (cadr p))) pts))
        arr (vlax-make-safearray vlax-vbDouble (cons 0 (1- (length flat)))))
  (vlax-safearray-fill arr flat)
  (setq o (vlax-ename->vla-object e))
  (vla-put-Coordinates o arr) o)

; ----------------------------------------------------------------------
; RILIEVO / MISURE / ALLINEAMENTI
; ----------------------------------------------------------------------
(defun cti20w:cmd-offset-quota (/ ss dz e o n)
  (prompt "\nSeleziona gli oggetti da spostare in quota Z: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq dz (getreal "\nOffset Z (positivo o negativo): ")
            n 0)
      (if dz
        (progn
          (foreach e (cti20w:ss-list ss)
            (setq o (vlax-ename->vla-object e))
            (if (not (vl-catch-all-error-p (cti20w:move-z o dz)))
              (setq n (1+ n))))
          (princ (strcat "\nOggetti spostati in Z: " (itoa n) "."))))))
  (princ))
(defun c:CTI_OFFSET_QUOTA () (cti20w:run 'cti20w:cmd-offset-quota))

(defun cti20w:cmd-punti-codificati-csv (/ lay ss path f i e p code)
  (setq lay (getstring T "\nLayer dei testi codificati <Code>: "))
  (if (= lay "") (setq lay "Code"))
  (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 8 lay) (cons 410 (getvar "CTAB")))))
  (if ss
    (progn
      (setq path (getfiled "Salva elenco punti codificati" "punti_codificati" "csv" 1))
      (if path
        (progn
          (setq f (open path "w"))
          (if f
            (progn
              (write-line "N;Codice;X;Y;Z" f)
              (setq i 1)
              (foreach e (cti20w:ss-list ss)
                (setq p (cti20w:inspt e)
                      code (cti20w:text-get e))
                (if p
                  (write-line
                    (strcat (itoa i) ";" (cti20w:csv-quote code) ";"
                            (rtos (car p) 2 4) ";"
                            (rtos (cadr p) 2 4) ";"
                            (rtos (if (caddr p) (caddr p) 0.0) 2 4))
                    f))
                (setq i (1+ i)))
              (close f)
              (princ (strcat "\nEsportati " (itoa (1- i)) " punti in " path ".")))
            (princ "\nImpossibile creare il file CSV.")))))
    (princ "\nNessun testo trovato sul layer indicato."))
  (princ))
(defun c:CTI_PUNTI_CODIFICATI_CSV () (cti20w:run 'cti20w:cmd-punti-codificati-csv))

(defun cti20w:cmd-distanza-su-polilinea (/ e p1 p2 q1 q2 d1 d2)
  (setq e (car (entsel "\nSeleziona la curva: ")))
  (if e (progn (setq p1 (getpoint "\nPrimo punto sulla curva: ") p2 (getpoint "\nSecondo punto sulla curva: ")
                     q1 (cti20w:closest e p1) q2 (cti20w:closest e p2))
    (if (and q1 q2) (progn (setq d1 (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q1) d2 (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q2))
                           (princ (strcat "\nDistanza lungo curva: " (rtos (abs (- d2 d1)) 2 4) ".")))))) (princ))
(defun c:CTI_DISTANZA_SU_POLILINEA () (cti20w:run 'cti20w:cmd-distanza-su-polilinea))

(defun cti20w:two-num-texts (/ a b va vb pa pb)
  (setq a (car (entsel "\nSeleziona la prima quota testuale: ")) b (car (entsel "\nSeleziona la seconda quota testuale: ")))
  (if (and a b (setq va (cti20w:num-text a)) (setq vb (cti20w:num-text b)) (setq pa (cti20w:inspt a)) (setq pb (cti20w:inspt b)))
    (list a b va vb pa pb) nil))

(defun cti20w:interp-texts (data n / va vb pa pb i frac p v ht)
  (setq va (nth 2 data) vb (nth 3 data) pa (nth 4 data) pb (nth 5 data) ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (setq i 1)
  (while (<= i n)
    (setq frac (/ (float i) (1+ n)) p (mapcar (function (lambda (a b) (+ a (* frac (- b a))))) pa pb) v (+ va (* frac (- vb va))))
    (cti20w:add-text p (rtos v 2 3) ht "CTI-QUOTE-INTERPOLATE") (setq i (1+ i))))

(defun cti20w:cmd-interpola-quote-numero (/ d n)
  (if (setq d (cti20w:two-num-texts)) (progn (setq n (getint "\nNumero di quote intermedie: ")) (if (and n (> n 0)) (cti20w:interp-texts d n)))) (princ))
(defun c:CTI_INTERPOLA_QUOTE_NUMERO () (cti20w:run 'cti20w:cmd-interpola-quote-numero))

(defun cti20w:cmd-interpola-quote-passo (/ d step len va vb pa pb dist frac p v ht count)
  ; Inserisce le quote esattamente a step, 2*step, 3*step... lungo il segmento.
  (if (setq d (cti20w:two-num-texts))
    (progn
      (setq step (getdist "\nPasso fra le quote: ")
            len  (distance (nth 4 d) (nth 5 d)))
      (if (and step (> step 0.0) (> len step))
        (progn
          (setq va (nth 2 d) vb (nth 3 d)
                pa (nth 4 d) pb (nth 5 d)
                ht (getreal "\nAltezza testo <2.5>: "))
          (if (not ht) (setq ht 2.5))
          (setq dist step count 0)
          (while (< dist (- len 1e-8))
            (setq frac (/ dist len)
                  p (mapcar (function (lambda (a b) (+ a (* frac (- b a))))) pa pb)
                  v (+ va (* frac (- vb va))))
            (cti20w:add-text p (rtos v 2 3) ht "CTI-QUOTE-INTERPOLATE")
            (setq count (1+ count) dist (+ dist step)))
          (princ (strcat "\nQuote intermedie create: " (itoa count) ".")))
        (princ "\nIl passo deve essere positivo e minore della distanza fra le due quote."))))
  (princ))
(defun c:CTI_INTERPOLA_QUOTE_PASSO () (cti20w:run 'cti20w:cmd-interpola-quote-passo))

(defun cti20w:cmd-quota-intermedia (/ d p v ht)
  (if (setq d (cti20w:two-num-texts))
    (progn (setq p (mapcar '(lambda (a b) (/ (+ a b) 2.0)) (nth 4 d) (nth 5 d)) v (/ (+ (nth 2 d) (nth 3 d)) 2.0) ht (getreal "\nAltezza testo <2.5>: "))
           (if (not ht) (setq ht 2.5)) (cti20w:add-text p (rtos v 2 3) ht "CTI-QUOTE-INTERPOLATE"))) (princ))
(defun c:CTI_QUOTA_INTERMEDIA () (cti20w:run 'cti20w:cmd-quota-intermedia))

(defun cti20w:cmd-griglia-coordinate (/ p1 p2 sx sy x y xmin xmax ymin ymax ht)
  (setq p1 (getpoint "\nPrimo angolo della griglia: ") p2 (getcorner p1 "\nAngolo opposto: ") sx (getdist "\nPasso X: ") sy (getdist "\nPasso Y <uguale a X>: "))
  (if (not sy) (setq sy sx))
  (if (and p1 p2 sx sy (> sx 0) (> sy 0))
    (progn (cti20w:ensure-layer "CTI-GRIGLIA" 8) (setq xmin (min (car p1) (car p2)) xmax (max (car p1) (car p2)) ymin (min (cadr p1) (cadr p2)) ymax (max (cadr p1) (cadr p2)) ht (* 0.25 (min sx sy)) x xmin)
      (while (<= x (+ xmax 1e-8)) (cti20w:add-line (list x ymin 0) (list x ymax 0) "CTI-GRIGLIA") (cti20w:add-text (list x ymin 0) (rtos x 2 2) ht "CTI-GRIGLIA") (setq x (+ x sx)))
      (setq y ymin) (while (<= y (+ ymax 1e-8)) (cti20w:add-line (list xmin y 0) (list xmax y 0) "CTI-GRIGLIA") (cti20w:add-text (list xmin y 0) (rtos y 2 2) ht "CTI-GRIGLIA") (setq y (+ y sy))))) (princ))
(defun c:CTI_GRIGLIA_COORDINATE () (cti20w:run 'cti20w:cmd-griglia-coordinate))

(defun cti20w:cmd-aree-multiple (/ ss e o a total c ht n)
  (prompt "\nSeleziona polilinee chiuse: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) total 0.0 n 0 ht (getreal "\nAltezza etichetta <2.5>: ")) (if (not ht) (setq ht 2.5))
  (foreach e (cti20w:ss-list ss) (if (cti20w:lw-closed-p e) (progn (setq o (vlax-ename->vla-object e) a (vla-get-Area o) c (cti20w:poly-centroid (cti20w:lwverts e))) (cti20w:add-text c (strcat "A=" (rtos a 2 2)) ht "CTI-AREE") (setq total (+ total a) n (1+ n)))))
  (princ (strcat "\nPoligoni: " (itoa n) "  Area totale: " (rtos total 2 3) ".")) (princ))
(defun c:CTI_AREE_MULTIPLE () (cti20w:run 'cti20w:cmd-aree-multiple))

(defun cti20w:insunit-to-m (u)
  (cond ((= u 1) 0.0254) ((= u 2) 0.3048) ((= u 4) 0.001) ((= u 5) 0.01) ((= u 6) 1.0) ((= u 7) 1000.0) (T nil)))
(defun cti20w:cmd-area-multiunita (/ e o a f m2)
  (setq e (car (entsel "\nSeleziona una polilinea chiusa: ")))
  (if (and e (cti20w:lw-closed-p e)) (progn (setq o (vlax-ename->vla-object e) a (vla-get-Area o) f (cti20w:insunit-to-m (getvar "INSUNITS")))
    (princ (strcat "\nArea disegno: " (rtos a 2 4) " unita^2"))
    (if f (progn (setq m2 (* a f f)) (princ (strcat "\nArea: " (rtos m2 2 4) " m² | " (rtos (* m2 10.7639104167) 2 4) " ft² | " (rtos (/ m2 10000.0) 2 6) " ha."))) (princ "\nINSUNITS non consente una conversione affidabile in metri.")))) (princ))
(defun c:CTI_AREA_MULTIUNITA () (cti20w:run 'cti20w:cmd-area-multiunita))

(defun cti20w:cmd-picchettamento-pilastri (/ ss path f idx e pts c p ht)
  (prompt "\nSeleziona polilinee chiuse dei pilastri/fondazioni: ")
  (setq ss (ssget '((0 . "LWPOLYLINE")))
        path (getfiled "Salva picchettamento" "picchettamento" "csv" 1)
        ht 2.0)
  (if (and ss path)
    (progn
      (setq f (open path "w"))
      (if f
        (progn
          (setq idx 1)
          (write-line "N;X;Y;Z;Tipo" f)
          (foreach e (cti20w:ss-list ss)
            (if (cti20w:lw-closed-p e)
              (progn
                (setq pts (cti20w:lwverts e) c (cti20w:poly-centroid pts))
                (foreach p (append pts (list c))
                  (cti20w:add-text p (itoa idx) ht "CTI-PICCHETTAMENTO")
                  (write-line (strcat (itoa idx) ";" (rtos (car p) 2 4) ";"
                                      (rtos (cadr p) 2 4) ";"
                                      (rtos (if (caddr p) (caddr p) 0.0) 2 4) ";"
                                      (if (equal p c 1e-8) "CENTRO" "VERTICE")) f)
                  (setq idx (1+ idx))))))
          (close f)
          (princ (strcat "\nPunti esportati: " (itoa (1- idx)) ".")))
        (princ "\nImpossibile creare il file CSV."))))
  (princ))
(defun c:CTI_PICCHETTAMENTO_PILASTRI () (cti20w:run 'cti20w:cmd-picchettamento-pilastri))

(defun cti20w:cmd-linea-pendenza (/ p1 p2 n mode len dx dy ux uy dz end)
  (setq p1 (getpoint "\nPunto iniziale: ") p2 (getpoint p1 "\nDirezione/orizzontale di riferimento: ") n (getreal "\nPendenza 1:N, inserisci N: "))
  (initget "Sale Scende") (setq mode (getkword "\nDirezione verticale [Sale/Scende] <Scende>: ")) (if (not mode) (setq mode "Scende"))
  (if (and p1 p2 n (> n 0)) (progn (setq len (distance p1 p2) dx (- (car p2) (car p1)) dy (- (cadr p2) (cadr p1)) dz (/ len n)) (if (= mode "Scende") (setq dz (- dz)))
    (setq end (list (car p2) (+ (cadr p2) dz) (if (caddr p2) (caddr p2) 0.0))) (cti20w:add-line p1 end "CTI-PENDENZA"))) (princ))
(defun c:CTI_LINEA_PENDENZA () (cti20w:run 'cti20w:cmd-linea-pendenza))

(defun cti20w:cmd-simbolo-linea-elettrica (/ e amp step len d p ang n p1 p2 side)
  (setq e (car (entsel "\nSeleziona la polilinea della linea elettrica: ")) amp (getdist "\nAmpiezza zig-zag <2.0>: ") step (getdist "\nPasso <10.0>: "))
  (if (not amp) (setq amp 2.0)) (if (not step) (setq step 10.0))
  (if e (progn (setq len (cti20w:curve-length e) d 0.0 side 1.0)
    (while (and len (< d len)) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d) ang (cti20w:curve-angle-at e p) n (list (* (- (sin ang)) amp side) (* (cos ang) amp side) 0.0) p1 (mapcar '+ p n) p2 (mapcar '- p n)) (cti20w:add-line p1 p2 "CTI-LINEA-ELETTRICA") (setq side (- side) d (+ d step))))) (princ))
(defun cti20w:nonpub-cti_simbolo_linea_elettrica () (cti20w:run 'cti20w:cmd-simbolo-linea-elettrica))

(defun cti20w:cmd-testo-su-griglia (/ ss sx sy e o p q)
  (setq sx (getdist "\nPasso griglia X: ") sy (getdist "\nPasso griglia Y <uguale a X>: ")) (if (not sy) (setq sy sx))
  (prompt "\nSeleziona TESTO/TESTOM da agganciare alla griglia: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if (and ss sx sy (> sx 0) (> sy 0)) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e) p (cti20w:inspt o) q (list (* sx (fix (+ 0.5 (/ (car p) sx)))) (* sy (fix (+ 0.5 (/ (cadr p) sy)))) (if (caddr p) (caddr p) 0.0))) (vla-Move o (vlax-3d-point p) (vlax-3d-point q)))) (princ))
(defun c:CTI_TESTO_SU_GRIGLIA () (cti20w:run 'cti20w:cmd-testo-su-griglia))

(defun cti20w:add-vertices-from-points (e points tol / pts p q d pairs new added)
  (if (or (cti20w:lw-has-bulge-p e) (not (= (cdr (assoc 0 (entget e))) "LWPOLYLINE"))) nil
    (progn
      (setq pts (cti20w:lwverts e) pairs nil added 0)
      (foreach p points
        (setq q (cti20w:closest e p))
        (if (and q (<= (distance p q) tol))
          (progn
            (setq d (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q)
                  pairs (cons (cons d q) pairs) added (1+ added)))))
      ; Ricostruzione conservativa: vertici originali + soli marker realmente vicini.
      (foreach p pts
        (setq d (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) p)
              pairs (cons (cons d p) pairs)))
      (setq pairs (vl-sort pairs '(lambda (a b) (< (car a) (car b))))
            new (mapcar 'cdr pairs))
      (if (> added 0) (cti20w:rebuild-lw-straight e new))
      added)))

(defun cti20w:cmd-vertici-su-allineamento (/ e lay tol ss pts x n)
  (setq e (car (entsel "\nSeleziona l'allineamento LWPOLYLINE rettilineo: "))
        lay (getstring T "\nLayer dei testi marker <Extra>: "))
  (if (= lay "") (setq lay "Extra"))
  (setq tol (getdist "\nDistanza massima marker-allineamento <1.0>: "))
  (if (not tol) (setq tol 1.0))
  (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 8 lay) (cons 410 (getvar "CTAB")))) pts nil)
  (foreach x (cti20w:ss-list ss)
    (if (cti20w:inspt x) (setq pts (cons (cti20w:inspt x) pts))))
  (if (and e pts (> tol 0.0))
    (progn
      (setq n (cti20w:add-vertices-from-points e pts tol))
      (cond
        ((null n) (princ "\nSono supportate solo LWPOLYLINE rettilinee senza archi."))
        ((= n 0) (princ "\nNessun marker entro la tolleranza indicata."))
        (T (princ (strcat "\nMarker trasformati in vertici: " (itoa n) "."))))))
  (princ))
(defun c:CTI_VERTICI_SU_ALLINEAMENTO () (cti20w:run 'cti20w:cmd-vertici-su-allineamento))

(defun cti20w:cmd-blocchi-su-allineamento (/ e name step start len d p ang cnt)
  (setq e (car (entsel "\nSeleziona allineamento/curva: ")) name (cti20w:ask-block-name) step (getdist "\nPasso inserimento: ") start (getdist "\nProgressiva iniziale <0>: ")) (if (not start) (setq start 0.0))
  (if (and e name step (> step 0)) (progn (setq len (cti20w:curve-length e) d start cnt 0) (cti20w:ensure-layer "CTI-BLOCCHI-ALLINEAMENTO" 3)
    (while (and len (<= d len)) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d) ang (cti20w:curve-angle-at e p)) (cti20w:insert-block name p 1.0 ang "CTI-BLOCCHI-ALLINEAMENTO") (setq cnt (1+ cnt) d (+ d step))) (princ (strcat "\nBlocchi inseriti: " (itoa cnt) ".")))) (princ))
(defun c:CTI_BLOCCHI_SU_ALLINEAMENTO () (cti20w:run 'cti20w:cmd-blocchi-su-allineamento))

(defun cti20w:bulge-at (e i / o r)
  (setq o (vlax-ename->vla-object e)
        r (vl-catch-all-apply 'vla-GetBulge (list o i)))
  (if (vl-catch-all-error-p r) 0.0 r))
(defun cti20w:cmd-dettagli-curve (/ e pts i b p1 p2 chord theta rad arc ins y ht)
  (setq e (car (entsel "\nSeleziona LWPOLYLINE con tratti curvi: "))
        ins (getpoint "\nPunto per il rapporto: ") ht 2.5)
  (if (and e (= (cdr (assoc 0 (entget e))) "LWPOLYLINE") ins)
    (progn
      (setq pts (cti20w:lwverts e) i 0 y 0)
      (cti20w:add-text ins "CURVE ALLINEAMENTO" ht "CTI-DETTAGLI-CURVE")
      (while (< i (1- (length pts)))
        (setq b (cti20w:bulge-at e i))
        (if (> (abs b) 1e-10)
          (progn
            (setq p1 (nth i pts) p2 (nth (1+ i) pts) chord (distance p1 p2)
                  theta (* 4.0 (atan (abs b)))
                  rad (/ chord (* 2.0 (sin (/ theta 2.0))))
                  arc (* rad theta) y (- y (* 1.6 ht)))
            (cti20w:add-text (list (car ins) (+ (cadr ins) y) (if (caddr ins) (caddr ins) 0.0))
              (strcat "Curva " (itoa (1+ i)) "  R=" (rtos rad 2 3)
                      "  Ang=" (rtos (* theta (/ 180.0 pi)) 2 3) "°  L=" (rtos arc 2 3))
              ht "CTI-DETTAGLI-CURVE")))
        (setq i (1+ i)))))
  (princ))
(defun c:CTI_DETTAGLI_CURVE () (cti20w:run 'cti20w:cmd-dettagli-curve))

(defun cti20w:sample-curve-range (e d1 d2 step / out d p)
  (setq out nil d d1)
  (while (< d d2) (if (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d)) (setq out (append out (list p)))) (setq d (+ d step)))
  (if (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d2)) (setq out (append out (list p)))) out)
(defun cti20w:cmd-taglia-allineamento (/ e len d1 d2 step pts layer)
  (setq e (car (entsel "\nSeleziona l'allineamento: ")))
  (if e (progn (setq len (cti20w:curve-length e) d1 (getreal "\nProgressiva iniziale: ") d2 (getreal "\nProgressiva finale: "))
    (if (and len d1 d2 (> d2 d1) (>= d1 0) (<= d2 len)) (progn (setq step (max (/ (- d2 d1) 100.0) 0.01) layer (cdr (assoc 8 (entget e))) pts (cti20w:sample-curve-range e d1 d2 step)) (cti20w:make-lwpoly pts layer nil) (princ "\nCreato nuovo tratto campionato; originale preservato."))))) (princ))
(defun c:CTI_TAGLIA_ALLINEAMENTO_PROGRESSIVE () (cti20w:run 'cti20w:cmd-taglia-allineamento))

(defun cti20w:cmd-progressive (/ e step start len d p ang n p1 p2 ht)
  (setq e (car (entsel "\nSeleziona allineamento: ")) step (getdist "\nIntervallo progressive: ") start (getreal "\nProgressiva iniziale <0>: ") ht (getreal "\nAltezza testo <2.5>: "))
  (if (not start) (setq start 0.0)) (if (not ht) (setq ht 2.5))
  (if (and e step (> step 0)) (progn (setq len (cti20w:curve-length e) d 0.0)
    (while (and len (<= d len)) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d) ang (cti20w:curve-angle-at e p) n (list (* -1.0 (sin ang)) (cos ang) 0.0) p1 (mapcar '(lambda (a b) (+ a (* b 2.0))) p n) p2 (mapcar '(lambda (a b) (- a (* b 2.0))) p n)) (cti20w:add-line p1 p2 "CTI-PROGRESSIVE") (cti20w:add-text p1 (rtos (+ start d) 2 2) ht "CTI-PROGRESSIVE") (setq d (+ d step))))) (princ))
(defun c:CTI_PROGRESSIVE_ALLINEAMENTO () (cti20w:run 'cti20w:cmd-progressive))

(defun cti20w:cmd-vertici-allineamento (/ ss e pts i p ht)
  (prompt "\nSeleziona gli allineamenti: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) ht (getreal "\nAltezza numero <2.5>: ")) (if (not ht) (setq ht 2.5))
  (foreach e (cti20w:ss-list ss) (setq pts (cti20w:lwverts e) i 1) (foreach p (if (> (length pts) 2) (cdr (reverse (cdr (reverse pts)))) nil) (cti20w:add-circle p (* ht 0.5) "CTI-APICI") (cti20w:add-text p (itoa i) ht "CTI-APICI") (setq i (1+ i)))) (princ))
(defun c:CTI_VERTICI_ALLINEAMENTO () (cti20w:run 'cti20w:cmd-vertici-allineamento))

; ----------------------------------------------------------------------
; POLILINEE / CONTROLLO / MISURE
; ----------------------------------------------------------------------
(defun cti20w:cmd-polilinea-da-testi (/ ss pts e)
  (prompt "\nSeleziona TESTO/TESTOM nell'ordine desiderato: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) pts nil)
  (foreach e (cti20w:ss-list ss) (if (cti20w:inspt e) (setq pts (append pts (list (cti20w:inspt e))))))
  (if (> (length pts) 1) (cti20w:make-lwpoly pts "CTI-POLILINEA-TESTI" nil)) (princ))
(defun c:CTI_POLILINEA_DA_TESTI () (cti20w:run 'cti20w:cmd-polilinea-da-testi))

(defun cti20w:assoc-add (key val alist / p) (if (setq p (assoc key alist)) (subst (cons key (+ val (cdr p))) p alist) (cons (cons key val) alist)))
(defun cti20w:cmd-lunghezze-layer (/ ss sums e l len p ht y x)
  (prompt "\nSeleziona curve da sommare: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE"))) sums nil)
  (foreach e (cti20w:ss-list ss) (setq l (cdr (assoc 8 (entget e))) len (cti20w:curve-length e)) (if len (setq sums (cti20w:assoc-add l len sums))))
  (if sums (progn (setq p (getpoint "\nPunto per tabella testuale: ") ht (getreal "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5)) (setq y 0.0)
    (foreach x (vl-sort sums '(lambda (a b) (< (strcase (car a)) (strcase (car b))))) (cti20w:add-text (list (car p) (- (cadr p) y) 0) (strcat (car x) " = " (rtos (cdr x) 2 3)) ht "CTI-LUNGHEZZE-LAYER") (setq y (+ y (* ht 1.5)))))) (princ))
(defun c:CTI_LUNGHEZZE_PER_LAYER () (cti20w:run 'cti20w:cmd-lunghezze-layer))

(defun cti20w:cmd-faccia3d-polilinea (/ e ed pts p4 layer)
  (setq e (car (entsel "\nSeleziona una 3DFACE: ")))
  (if (and e (= (cdr (assoc 0 (entget e))) "3DFACE")) (progn (setq ed (entget e) pts (list (cdr (assoc 10 ed)) (cdr (assoc 11 ed)) (cdr (assoc 12 ed))) p4 (cdr (assoc 13 ed))) (if (and p4 (not (equal p4 (nth 2 pts) 1e-9))) (setq pts (append pts (list p4)))) (setq layer (cdr (assoc 8 ed))) (cti20w:make-3dpoly pts layer T))) (princ))
(defun c:CTI_FACCIA3D_IN_POLILINEA () (cti20w:run 'cti20w:cmd-faccia3d-polilinea))

(defun cti20w:cmd-curva-segmenti (/ e step len d pts p layer)
  (setq e (car (entsel "\nSeleziona curva/polilinea da campionare: "))
        step (getdist "\nPasso segmentazione <1.0>: "))
  (if (not step) (setq step 1.0))
  (if (and e (> step 0.0))
    (progn
      (setq len (cti20w:curve-length e)
            d 0.0
            pts nil
            layer (cdr (assoc 8 (entget e))))
      (if len
        (progn
          (while (< d len)
            (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d))
            (if p (setq pts (append pts (list p))))
            (setq d (+ d step)))
          (setq p (vlax-curve-getEndPoint (vlax-ename->vla-object e)))
          (if p (setq pts (append pts (list p))))
          (if (> (length pts) 1)
            (cti20w:make-lwpoly pts layer nil))))))
  (princ))
(defun c:CTI_POLILINEA_LISCIA_IN_SEGMENTI () (cti20w:run 'cti20w:cmd-curva-segmenti))

(defun cti20w:cmd-asse-bordi (/ e1 e2 n i l1 l2 p1 p2 pts o1 o2 s1 s2 e2p invert frac)
  (setq e1 (car (entsel "\nSeleziona primo bordo: "))
        e2 (car (entsel "\nSeleziona secondo bordo: "))
        n (getint "\nNumero campioni <50>: "))
  (if (not n) (setq n 50))
  (if (and e1 e2 (> n 1))
    (progn
      (setq l1 (cti20w:curve-length e1) l2 (cti20w:curve-length e2)
            o1 (vlax-ename->vla-object e1) o2 (vlax-ename->vla-object e2))
      (if (and l1 l2 (> l1 1e-9) (> l2 1e-9))
        (progn
          (setq s1 (vlax-curve-getStartPoint o1)
                s2 (vlax-curve-getStartPoint o2)
                e2p (vlax-curve-getEndPoint o2)
                invert (> (distance s1 s2) (distance s1 e2p))
                i 0 pts nil)
          (while (<= i n)
            (setq frac (/ (float i) n)
                  p1 (vlax-curve-getPointAtDist o1 (* l1 frac))
                  p2 (vlax-curve-getPointAtDist o2 (* l2 (if invert (- 1.0 frac) frac))))
            (if (and p1 p2)
              (setq pts (append pts (list (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2)))))
            (setq i (1+ i)))
          (if (> (length pts) 1) (cti20w:make-lwpoly pts "CTI-ASSE-MEDIO" nil))))))
  (princ))
(defun c:CTI_ASSE_TRA_BORDI () (cti20w:run 'cti20w:cmd-asse-bordi))

(defun cti20w:cmd-corda-estremi (/ ss e pts layer)
  (prompt "\nSeleziona polilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))))
  (foreach e (cti20w:ss-list ss) (setq pts (cti20w:lwverts e) layer (cdr (assoc 8 (entget e)))) (if (> (length pts) 1) (cti20w:add-line (car pts) (car (last pts)) layer))) (princ))
(defun cti20w:nonpub-cti_corda_estremi () (cti20w:run 'cti20w:cmd-corda-estremi))

(defun cti20w:cmd-rimuovi-archi (/ ss e ed out x)
  (prompt "\nSeleziona LWPOLYLINE da rendere rettilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (foreach e (cti20w:ss-list ss) (setq ed (entget e) out nil) (foreach x ed (setq out (append out (list (if (= (car x) 42) (cons 42 0.0) x))))) (entmod out) (entupd e)) (princ))
(defun cti20w:nonpub-cti_rimuovi_archi_polilinea () (cti20w:run 'cti20w:cmd-rimuovi-archi))

(defun cti20w:cmd-segnala-aperte (/ ss out e pts r ht)
  (prompt "\nSeleziona polilinee da controllare: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) out (ssadd) r (getdist "\nRaggio marcatori <1.0>: ")) (if (not r) (setq r 1.0))
  (foreach e (cti20w:ss-list ss) (if (not (cti20w:lw-closed-p e)) (progn (ssadd e out) (setq pts (cti20w:lwverts e)) (if pts (progn (cti20w:add-circle (car pts) r "CTI-APERTURE") (cti20w:add-circle (car (last pts)) r "CTI-APERTURE"))))))
  (if (> (sslength out) 0) (sssetfirst nil out)) (princ (strcat "\nPolilinee aperte: " (itoa (sslength out)) ".")) (princ))
(defun cti20w:nonpub-cti_segnala_polilinee_aperte () (cti20w:run 'cti20w:cmd-segnala-aperte))

(defun cti20w:cmd-aggiungi-vertici (/ ss n e pts new i a b k frac p closed segcount)
  (setq n (getint "\nNuovi vertici per segmento: "))
  (prompt "\nSeleziona LWPOLYLINE rettilinee: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if (and n (> n 0))
    (foreach e (cti20w:ss-list ss)
      (if (not (cti20w:lw-has-bulge-p e))
        (progn
          (setq pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e)
                new nil i 0 segcount (if closed (length pts) (1- (length pts))))
          (while (< i segcount)
            (setq a (nth i pts) b (nth (rem (1+ i) (length pts)) pts)
                  new (append new (list a)) k 1)
            (while (<= k n)
              (setq frac (/ (float k) (1+ n))
                    p (mapcar (function (lambda (x y) (+ x (* frac (- y x))))) a b)
                    new (append new (list p)) k (1+ k)))
            (setq i (1+ i)))
          (if (not closed) (setq new (append new (list (car (last pts))))))
          (cti20w:rebuild-lw-straight e new)))))
  (princ))
(defun c:CTI_AGGIUNGI_VERTICI () (cti20w:run 'cti20w:cmd-aggiungi-vertici))

(defun cti20w:cmd-quota-segmenti (/ e pts i a b p len ht closed segcount)
  (setq e (car (entsel "\nSeleziona una polilinea: "))
        ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (if e
    (progn
      (setq pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e) i 0
            segcount (if closed (length pts) (1- (length pts))))
      (while (< i segcount)
        (setq a (nth i pts) b (nth (rem (1+ i) (length pts)) pts)
              p (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b) len (distance a b))
        (cti20w:add-text p (rtos len 2 3) ht "CTI-LUNGHEZZE-SEGMENTI")
        (setq i (1+ i)))))
  (princ))
(defun c:CTI_QUOTA_SEGMENTI () (cti20w:run 'cti20w:cmd-quota-segmenti))

(defun cti20w:intersections (e1 e2 / r vals out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list (vlax-ename->vla-object e1) 'IntersectWith (vlax-ename->vla-object e2) 0)))
  (if (vl-catch-all-error-p r) nil (progn (setq vals (cti20w:in-lista r) out nil) (while (and vals (>= (length vals) 3)) (setq out (cons (list (car vals) (cadr vals) (caddr vals)) out) vals (cdddr vals))) (reverse out))))

(defun cti20w:cmd-intersezioni-layer (/ base ss e pts p ht lay)
  (setq base (car (entsel "\nSeleziona la polilinea base: "))) (prompt "\nSeleziona le curve da confrontare: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE"))) ht 2.5)
  (if (and base ss) (foreach e (cti20w:ss-list ss) (if (/= e base) (progn (setq pts (cti20w:intersections base e) lay (cdr (assoc 8 (entget e)))) (foreach p pts (cti20w:add-circle p 0.5 "CTI-INTERSEZIONI-LAYER") (cti20w:add-text p lay ht "CTI-INTERSEZIONI-LAYER")))))) (princ))
(defun c:CTI_INTERSEZIONI_PER_LAYER () (cti20w:run 'cti20w:cmd-intersezioni-layer))

(defun cti20w:cmd-angoli-polilinea (/ e pts i a b c v1 v2 ang p ht)
  (setq e (car (entsel "\nSeleziona polilinea: ")) ht (getreal "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5))
  (if e (progn (setq pts (cti20w:lwverts e) i 1) (while (< i (1- (length pts))) (setq a (nth (1- i) pts) b (nth i pts) c (nth (1+ i) pts) v1 (angle b a) v2 (angle b c) ang (* (abs (- v2 v1)) (/ 180.0 pi))) (if (> ang 180.0) (setq ang (- 360.0 ang))) (cti20w:add-text b (strcat (rtos ang 2 2) "°") ht "CTI-ANGOLI") (setq i (1+ i))))) (princ))
(defun c:CTI_ANGOLI_POLILINEA () (cti20w:run 'cti20w:cmd-angoli-polilinea))

(defun cti20w:cmd-offset-doppio (/ ss dl dr e o r)
  (setq dl (getdist "\nDistanza lato sinistro: ") dr (getdist "\nDistanza lato destro: ")) (prompt "\nSeleziona le curve: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,SPLINE"))))
  (if (and ss dl dr) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (> dl 0) (vl-catch-all-apply 'vla-Offset (list o dl))) (if (> dr 0) (vl-catch-all-apply 'vla-Offset (list o (- dr)))))) (princ))
(defun c:CTI_OFFSET_DOPPIO () (cti20w:run 'cti20w:cmd-offset-doppio))

(defun cti20w:segment-cross-p (a b c d / cross sub r s den qp ta ub)
  (setq sub '(lambda (p q) (list (- (car p) (car q)) (- (cadr p) (cadr q)))) cross '(lambda (p q) (- (* (car p) (cadr q)) (* (cadr p) (car q)))))
  (setq r (apply sub (list b a)) s (apply sub (list d c)) den (apply cross (list r s)) qp (apply sub (list c a)))
  (if (< (abs den) 1e-12) nil (progn (setq ta (/ (apply cross (list qp s)) den) ub (/ (apply cross (list qp r)) den)) (and (> ta 1e-8) (< ta (- 1.0 1e-8)) (> ub 1e-8) (< ub (- 1.0 1e-8))))))

(defun cti20w:self-intersect-p (pts closed / segs i j a b c d found n)
  (setq n (length pts) segs nil i 0 found nil)
  (while (< i (1- n)) (setq segs (append segs (list (list (nth i pts) (nth (1+ i) pts)))) i (1+ i)))
  (if closed (setq segs (append segs (list (list (nth (1- n) pts) (car pts))))))
  (setq i 0)
  (while (and (< i (length segs)) (not found)) (setq j (+ i 2)) (while (and (< j (length segs)) (not found)) (if (not (and (= i 0) (= j (1- (length segs))))) (progn (setq a (car (nth i segs)) b (cadr (nth i segs)) c (car (nth j segs)) d (cadr (nth j segs))) (if (cti20w:segment-cross-p a b c d) (setq found T)))) (setq j (1+ j))) (setq i (1+ i))) found)

(defun cti20w:cmd-controllo-poligoni (/ ss e pts closed bad n)
  (prompt "\nSeleziona poligoni LWPOLYLINE: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) bad (ssadd) n 0)
  (foreach e (cti20w:ss-list ss) (setq pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e)) (if (or (not closed) (< (length pts) 3) (cti20w:self-intersect-p pts closed)) (progn (ssadd e bad) (setq n (1+ n)))))
  (if (> n 0) (sssetfirst nil bad)) (princ (strcat "\nPoligoni con anomalie semplici: " (itoa n) ".")) (princ))
(defun c:CTI_CONTROLLO_POLIGONI () (cti20w:run 'cti20w:cmd-controllo-poligoni))

(defun cti20w:cmd-poligono-orario (/ ss e pts area closed)
  (prompt "\nSeleziona poligoni chiusi rettilinei: ") (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (foreach e (cti20w:ss-list ss) (if (and (cti20w:lw-closed-p e) (not (cti20w:lw-has-bulge-p e))) (progn (setq pts (cti20w:lwverts e) area (cti20w:poly-area2 pts)) (if (> area 0.0) (cti20w:rebuild-lw-straight e (reverse pts)))))) (princ))
(defun cti20w:nonpub-cti_poligono_orario () (cti20w:run 'cti20w:cmd-poligono-orario))

(defun cti20w:cmd-liscia-sezione (/ e n len i pts p)
  (setq e (car (entsel "\nSeleziona linea di sezione: ")) n (getint "\nNumero campioni <60>: ")) (if (not n) (setq n 60))
  (if (and e (> n 2)) (progn (setq len (cti20w:curve-length e) i 0 pts nil) (while (<= i n) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) (* len (/ (float i) n))) pts (append pts (list p)) i (1+ i))) (cti20w:make-lwpoly pts "CTI-SEZIONE-LISCIA" nil))) (princ))
(defun cti20w:nonpub-cti_liscia_sezione () (cti20w:run 'cti20w:cmd-liscia-sezione))

(defun cti20w:cmd-testo-su-polilinea (/ e ss te o p q)
  (setq e (car (entsel "\nSeleziona polilinea di destinazione: "))) (prompt "\nSeleziona testi da spostare: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if (and e ss) (foreach te (cti20w:ss-list ss) (setq o (vlax-ename->vla-object te) p (cti20w:inspt o) q (cti20w:closest e p)) (if q (vla-Move o (vlax-3d-point p) (vlax-3d-point q))))) (princ))
(defun c:CTI_TESTO_SU_POLILINEA () (cti20w:run 'cti20w:cmd-testo-su-polilinea))

(setq *CTI-WEB-EXTRA-LOADED* T)
(princ "\nCAD Tools Italiano 2.0 Fase 2A: 30 strumenti Web MIT caricati in modulo isolato.")
(princ)
