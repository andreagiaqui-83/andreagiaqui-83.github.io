; CAD Tools Italiano 2.0 - FASE 2B - successivi 30 strumenti Web MIT
; Modulo incrementale di sviluppo: richiede prima cti_web_phase2a_2_0.lsp.
; NON sostituisce la golden 1.9.
; Sorgenti concettuali/adattamento: BGol CAD Lisps (MIT).
; Commit sorgente verificato: 3acbe32f71b489f4c81dcd9372f989591a9be858
;
; Regole obbligatorie:
; - entrypoint CTI italiani;
; - ESC/Annulla centralizzato e silenzioso tramite cti20w:run;
; - un unico gruppo UNDO per comando (infrastruttura Phase 2A);
; - ripristino centralizzato variabili AutoCAD;
; - errori reali visibili;
; - niente command/command-s/vl-cmdf nei 30 strumenti;
; - correzioni conservative senza alterare l'obiettivo della routine originale.
;
; Licenza/provenienza: vedere LICENZA_BGOL_MIT.txt e MANIFEST_FASE2B_30.csv.

(vl-load-com)
(if (not (and (fboundp 'cti20w:run) (boundp '*CTI-WEB-EXTRA-LOADED*)))
  (progn
    (princ "\nCAD Tools Italiano 2.0 Fase 2B richiede il modulo Fase 2A caricato prima.")
    (princ)))
(setq *CTI-WEB-PHASE2B-VERSION* "2.0-phase2b")
(setq *CTI-WEB-PHASE2B-COUNT* 30)
(setq *CTI-WEB-PHASE2B-LOADED* nil)

(defun cti20w:cmd-polilinee-corte (/ ss lim e len o n checked)
  (setq lim (getdist "\nLunghezza massima da considerare corta: "))
  (if lim
    (progn
      (prompt "\nSeleziona polilinee/linee da controllare: ")
      (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE,LINE"))) n 0 checked 0)
      (if ss
        (progn
          (cti20w:ensure-layer "CTI-REVISIONE-CORTE" 1)
          (foreach e (cti20w:ss-list ss)
            (setq len (cti20w:curve-length e) checked (1+ checked))
            (if (and len (< len lim))
              (progn
                (setq o (vlax-ename->vla-object e))
                (if (not (vl-catch-all-error-p
                           (vl-catch-all-apply 'vla-put-Layer (list o "CTI-REVISIONE-CORTE"))))
                  (setq n (1+ n))))))
          (princ (strcat "\nControllati " (itoa checked) " oggetti; " (itoa n)
                         " spostati sul layer CTI-REVISIONE-CORTE.")))
        (princ "\nNessun oggetto selezionato."))))
  (princ))
(defun c:CTI_POLILINEE_CORTE () (cti20w:run 'cti20w:cmd-polilinee-corte))

; ----------------------------------------------------------------------
; 3D / BLOCCHI
; ----------------------------------------------------------------------
(defun cti20w:cmd-rettangolo3p (/ p1 p2 p3 vx vy len ux uy wx wy proj q3 q4)
  (setq p1 (getpoint "\nPrimo punto: ") p2 (getpoint p1 "\nSecondo punto (lato base): ") p3 (getpoint p2 "\nTerzo punto (definisce larghezza): "))
  (if (and p1 p2 p3) (progn (setq vx (- (car p2) (car p1)) vy (- (cadr p2) (cadr p1)) len (sqrt (+ (* vx vx) (* vy vy))))
    (if (> len 1e-9) (progn (setq ux (/ vx len) uy (/ vy len) wx (- (car p3) (car p2)) wy (- (cadr p3) (cadr p2)) proj (- (* wx (- uy)) (* wy (- ux)))) ; signed projection on perpendicular
      (setq q3 (list (+ (car p2) (* (- uy) proj)) (+ (cadr p2) (* ux proj)) (if (caddr p1) (caddr p1) 0.0))
            q4 (list (+ (car p1) (* (- uy) proj)) (+ (cadr p1) (* ux proj)) (if (caddr p1) (caddr p1) 0.0)))
      (cti20w:make-lwpoly (list p1 p2 q3 q4) "CTI-RETTANGOLI" T))))) (princ))
(defun c:CTI_RETTANGOLO_3P () (cti20w:run 'cti20w:cmd-rettangolo3p))

(defun cti20w:stl-normal (a b c / u v nx ny nz l)
  (setq u (mapcar '- b a) v (mapcar '- c a) nx (- (* (cadr u) (caddr v)) (* (caddr u) (cadr v))) ny (- (* (caddr u) (car v)) (* (car u) (caddr v))) nz (- (* (car u) (cadr v)) (* (cadr u) (car v))) l (sqrt (+ (* nx nx) (* ny ny) (* nz nz))))
  (if (> l 1e-12) (list (/ nx l) (/ ny l) (/ nz l)) '(0.0 0.0 0.0)))
(defun cti20w:stl-facet (f a b c / n p)
  (setq n (cti20w:stl-normal a b c)) (write-line (strcat "  facet normal " (rtos (car n) 2 8) " " (rtos (cadr n) 2 8) " " (rtos (caddr n) 2 8)) f) (write-line "    outer loop" f)
  (foreach p (list a b c) (write-line (strcat "      vertex " (rtos (car p) 2 8) " " (rtos (cadr p) 2 8) " " (rtos (caddr p) 2 8)) f)) (write-line "    endloop" f) (write-line "  endfacet" f))
(defun cti20w:cmd-3dface-stl (/ ss path f e ed a b c d n)
  (prompt "\nSeleziona 3DFACE da esportare: ")
  (setq ss (ssget '((0 . "3DFACE")))
        path (getfiled "Salva STL ASCII" "modello" "stl" 1))
  (if (and ss path)
    (progn
      (setq f (open path "w"))
      (if f
        (progn
          (setq n 0)
          (write-line "solid CADToolsItaliano" f)
          (foreach e (cti20w:ss-list ss)
            (setq ed (entget e) a (cdr (assoc 10 ed)) b (cdr (assoc 11 ed))
                  c (cdr (assoc 12 ed)) d (cdr (assoc 13 ed)))
            (cti20w:stl-facet f a b c)
            (setq n (1+ n))
            (if (and d (not (equal c d 1e-9)))
              (progn (cti20w:stl-facet f a c d) (setq n (1+ n)))))
          (write-line "endsolid CADToolsItaliano" f)
          (close f)
          (princ (strcat "\nTriangoli STL esportati: " (itoa n) ".")))
        (princ "\nImpossibile creare il file STL."))))
  (princ))
(defun c:CTI_3DFACE_IN_STL () (cti20w:run 'cti20w:cmd-3dface-stl))

(defun cti20w:cmd-quote-polilinea3d (/ ss ht e p n)
  (setq ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (prompt "\nSeleziona polilinee da cui leggere le quote Z: ")
  (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (foreach p (cti20w:lwverts e)
      (cti20w:add-text p (rtos (if (caddr p) (caddr p) 0.0) 2 3) ht "CTI-QUOTE-3D")
      (setq n (1+ n))))
  (princ (strcat "\nEtichette quota create: " (itoa n) "."))
  (princ))
(defun c:CTI_QUOTE_DA_POLILINEA3D () (cti20w:run 'cti20w:cmd-quote-polilinea3d))

(defun cti20w:cmd-testo-quota-z (/ ss e o p v q n)
  (prompt "\nSeleziona testi numerici da portare alla propria quota: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (foreach e (cti20w:ss-list ss) (if (and (setq v (cti20w:num-text e)) (setq p (cti20w:inspt e))) (progn (setq o (vlax-ename->vla-object e) q (list (car p) (cadr p) v)) (vla-Move o (vlax-3d-point p) (vlax-3d-point q)) (setq n (1+ n)))))
  (princ (strcat "\nTesti elevati: " (itoa n) ".")) (princ))
(defun c:CTI_TESTO_DA_QUOTA_Z () (cti20w:run 'cti20w:cmd-testo-quota-z))

(defun cti20w:cmd-interpola-z (/ e o z1 z2 ep total i d p z ht n)
  (setq e (car (entsel "\nSeleziona polilinea da interpolare: ")))
  (if e
    (progn
      (setq z1 (getreal "\nQuota nota al primo vertice: ")
            z2 (getreal "\nQuota nota all'ultimo vertice: "))
      (if (and z1 z2)
        (progn
          (setq o (vlax-ename->vla-object e)
                ep (vl-catch-all-apply 'vlax-curve-getEndParam (list o))
                ht (getreal "\nAltezza testo <2.5>: "))
          (if (not ht) (setq ht 2.5))
          (if (not (vl-catch-all-error-p ep))
            (progn
              (setq total (vl-catch-all-apply 'vlax-curve-getDistAtParam (list o ep)))
              (if (and (numberp total) (> total 1e-9))
                (progn
                  (setq i 0 n 0)
                  (while (<= i (fix ep))
                    (setq p (vlax-curve-getPointAtParam o i)
                          d (vlax-curve-getDistAtParam o i)
                          z (+ z1 (* (/ d total) (- z2 z1))))
                    (cti20w:add-text p (rtos z 2 3) ht "CTI-Z-INTERPOLATE")
                    (setq n (1+ n) i (1+ i)))
                  (princ (strcat "\nQuote interpolate su " (itoa n)
                                 " vertici, proporzionalmente alla distanza reale lungo la polilinea.")))
                (princ "\nLa polilinea ha lunghezza nulla."))))))))
  (princ))
(defun c:CTI_INTERPOLA_Z_VERTICI () (cti20w:run 'cti20w:cmd-interpola-z))

(defun cti20w:cmd-etichetta-z (/ ss ht e p n)
  (setq ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (prompt "\nSeleziona polilinee da etichettare con Z=: ")
  (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (foreach p (cti20w:lwverts e)
      (cti20w:add-text p (strcat "Z=" (rtos (if (caddr p) (caddr p) 0.0) 2 3)) ht "CTI-Z-VERTICI")
      (setq n (1+ n))))
  (princ (strcat "\nEtichette Z create: " (itoa n) "."))
  (princ))
(defun c:CTI_ETICHETTA_Z_VERTICI () (cti20w:run 'cti20w:cmd-etichetta-z))

(defun cti20w:cmd-offset-z-vertici (/ ss dz e typ v ed p o elev r n vcount)
  (setq dz (getreal "\nOffset Z (+ alza / - abbassa): "))
  (if dz
    (progn
      (prompt "\nSeleziona polilinee 3D o LWPOLYLINE: ")
      (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0 vcount 0)
      (foreach e (cti20w:ss-list ss)
        (setq typ (cdr (assoc 0 (entget e))))
        (cond
          ((= typ "POLYLINE")
           (if (= 8 (logand 8 (cdr (assoc 70 (entget e)))))
             (progn
               (setq v (entnext e))
               (while (and v (= (cdr (assoc 0 (entget v))) "VERTEX"))
                 (setq ed (entget v) p (cdr (assoc 10 ed)))
                 (if (and p (caddr p))
                   (progn
                     (entmod (subst (cons 10 (list (car p) (cadr p) (+ (caddr p) dz)))
                                    (assoc 10 ed) ed))
                     (entupd v)
                     (setq vcount (1+ vcount))))
                 (setq v (entnext v)))
               (entupd e)
               (setq n (1+ n)))))
          ((= typ "LWPOLYLINE")
           (setq o (vlax-ename->vla-object e)
                 elev (vl-catch-all-apply 'vla-get-Elevation (list o)))
           (if (numberp elev)
             (progn
               (setq r (vl-catch-all-apply 'vla-put-Elevation (list o (+ elev dz))))
               (if (not (vl-catch-all-error-p r)) (setq n (1+ n))))))))
      (princ (strcat "\nPolilinee modificate: " (itoa n)
                     "; vertici 3D aggiornati: " (itoa vcount) "."))))
  (princ))
(defun c:CTI_OFFSET_Z_VERTICI () (cti20w:run 'cti20w:cmd-offset-z-vertici))

(defun cti20w:cmd-blocco-quota-testo (/ ss data e o p near q n)
  (prompt "\nSeleziona blocchi da elevare: ") (setq ss (ssget '((0 . "INSERT"))) data (cti20w:find-numeric-texts) n 0)
  (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e) p (cti20w:inspt o) near (if p (cti20w:nearest-num-text p data) nil)) (if near (progn (setq q (list (car p) (cadr p) (cadr near))) (vla-Move o (vlax-3d-point p) (vlax-3d-point q)) (setq n (1+ n)))))
  (princ (strcat "\nBlocchi elevati: " (itoa n) ".")) (princ))
(defun c:CTI_BLOCCO_A_QUOTA_TESTO () (cti20w:run 'cti20w:cmd-blocco-quota-testo))

(defun cti20w:cmd-blocchi-mezzerie (/ name ss e pts p n)
  (setq name (cti20w:ask-block-name)) (prompt "\nSeleziona polilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) n 0)
  (if name (foreach e (cti20w:ss-list ss) (foreach p (cti20w:poly-segment-midpoints (cti20w:lwverts e) (cti20w:lw-closed-p e)) (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))))) (princ (strcat "\nBlocchi inseriti: " (itoa n) ".")) (princ))
(defun c:CTI_BLOCCHI_SU_MEZZERIE () (cti20w:run 'cti20w:cmd-blocchi-mezzerie))

(defun cti20w:cmd-blocchi-testi (/ name ss e p n)
  (setq name (cti20w:ask-block-name)) (prompt "\nSeleziona testi: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (if name (foreach e (cti20w:ss-list ss) (if (setq p (cti20w:inspt e)) (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))))) (princ (strcat "\nBlocchi inseriti: " (itoa n) ".")) (princ))
(defun c:CTI_BLOCCHI_SU_TESTI () (cti20w:run 'cti20w:cmd-blocchi-testi))

(defun cti20w:cmd-blocchi-vertici (/ name ss e p n)
  (setq name (cti20w:ask-block-name)) (prompt "\nSeleziona polilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) n 0)
  (if name (foreach e (cti20w:ss-list ss) (foreach p (cti20w:lwverts e) (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))))) (princ (strcat "\nBlocchi inseriti: " (itoa n) ".")) (princ))
(defun c:CTI_BLOCCHI_SU_VERTICI () (cti20w:run 'cti20w:cmd-blocchi-vertici))

(defun cti20w:cmd-ruota-blocchi (/ ss p1 p2 ang e o)
  (prompt "\nSeleziona blocchi da ruotare: ") (setq ss (ssget '((0 . "INSERT"))) p1 (getpoint "\nPrimo punto direzione: ") p2 (getpoint p1 "\nSecondo punto direzione: "))
  (if (and ss p1 p2) (progn (setq ang (angle p1 p2)) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (vlax-property-available-p o 'Rotation T) (vla-put-Rotation o ang))))) (princ))
(defun c:CTI_RUOTA_BLOCCHI_2P () (cti20w:run 'cti20w:cmd-ruota-blocchi))

(defun cti20w:cmd-attributi-testo (/ ss e o arr a p h n)
  (prompt "\nSeleziona blocchi con attributi: ") (setq ss (ssget '((0 . "INSERT"))) h (getreal "\nAltezza testo <2.5>: ")) (if (not h) (setq h 2.5)) (setq n 0)
  (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (= :vlax-true (vla-get-HasAttributes o)) (foreach a (cti20w:in-lista (vla-GetAttributes o)) (setq p (cti20w:point-list (vla-get-InsertionPoint a))) (cti20w:add-text p (vla-get-TextString a) h "CTI-ATTRIBUTI-TEXT") (setq n (1+ n)))))
  (princ (strcat "\nAttributi convertiti in testi: " (itoa n) ".")) (princ))
(defun c:CTI_ATTRIBUTI_IN_TESTO () (cti20w:run 'cti20w:cmd-attributi-testo))

; ----------------------------------------------------------------------
; TESTO / DATI
; ----------------------------------------------------------------------
(defun cti20w:nearest-curve-data (p refs / e q d best bestd)
  (setq best nil bestd nil)
  (foreach e refs
    (setq q (cti20w:closest e p))
    (if q
      (progn
        (setq d (distance p q))
        (if (or (null bestd) (< d bestd)) (setq best (list e q) bestd d)))))
  best)

(defun cti20w:cmd-allinea-testo-rif (/ refs ss e o p near ang n)
  (prompt "\nSeleziona LINEE/POLILINEE di riferimento: ")
  (setq refs (cti20w:ss-list (ssget '((0 . "LINE,LWPOLYLINE,POLYLINE,ARC,SPLINE")))))
  (if refs
    (progn
      (prompt "\nSeleziona testi da orientare: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (setq o (vlax-ename->vla-object e) p (cti20w:inspt o) near (and p (cti20w:nearest-curve-data p refs)))
        (if near
          (progn
            (setq ang (cti20w:curve-angle-at (car near) (cadr near)))
            (if (vlax-property-available-p o 'Rotation T)
              (progn (vla-put-Rotation o ang) (setq n (1+ n)))))))
      (princ (strcat "\nTesti orientati alla geometria di riferimento più vicina: " (itoa n) "."))))
  (princ))
(defun c:CTI_ALLINEA_TESTO_RIFERIMENTO () (cti20w:run 'cti20w:cmd-allinea-testo-rif))

(defun cti20w:cmd-decimali-testo (/ ss dec e v n)
  (setq dec (getint "\nNumero di decimali [0-8] <2>: ")) (if (not dec) (setq dec 2)) (setq dec (max 0 (min 8 dec)))
  (prompt "\nSeleziona testi numerici: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (foreach e (cti20w:ss-list ss) (if (setq v (cti20w:num-text e)) (if (cti20w:text-set e (rtos v 2 dec)) (setq n (1+ n))))) (princ (strcat "\nTesti riformattati: " (itoa n) ".")) (princ))
(defun c:CTI_DECIMALI_TESTO () (cti20w:run 'cti20w:cmd-decimali-testo))

(defun cti20w:cmd-cerchia-testo (/ ss e mn mx o r c dx dy)
  (prompt "\nSeleziona testi da cerchiare: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list o 'mn 'mx)))) (progn (setq mn (vlax-safearray->list mn) mx (vlax-safearray->list mx) c (mapcar '(lambda (a b) (/ (+ a b) 2.0)) mn mx) dx (- (car mx) (car mn)) dy (- (cadr mx) (cadr mn)) r (* 0.6 (sqrt (+ (* dx dx) (* dy dy))))) (cti20w:add-circle c r "CTI-CERCHI-TESTO")))) (princ))
(defun cti20w:nonpub-cti_cerchia_testo () (cti20w:run 'cti20w:cmd-cerchia-testo))

(defun cti20w:strip-mtext (s / r)
  ; Appiattisce i separatori e rimuove i delimitatori di formattazione più comuni.
  (setq r (if s s ""))
  (setq r (cti20w:str-replace-all " " "\P" r))
  (setq r (cti20w:str-replace-all " " "\p" r))
  (setq r (cti20w:str-replace-all " " "\~" r))
  (setq r (cti20w:str-replace-all "" "{" r))
  (setq r (cti20w:str-replace-all "" "}" r))
  r)

(defun cti20w:text-height-vla (o / h)
  (setq h (vl-catch-all-apply 'vla-get-TextHeight (list o)))
  (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0))
    (progn
      (setq h (vl-catch-all-apply 'vla-get-Height (list o)))
      (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0))
        (setq h (getvar "TEXTSIZE")))))
  (if (and (numberp h) (> h 0.0)) h 2.5))

(defun cti20w:cmd-mtext-testo (/ ss e o p s h rot layer new n)
  (prompt "\nSeleziona MTEXT da convertire: ")
  (setq ss (ssget '((0 . "MTEXT"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e)
          p (cti20w:inspt o)
          s (cti20w:strip-mtext (vla-get-TextString o))
          h (cti20w:text-height-vla o)
          rot (vla-get-Rotation o)
          layer (vla-get-Layer o))
    (if (and p (/= s ""))
      (progn
        (setq new (cti20w:add-text p s h layer))
        (vla-put-Rotation new rot)
        ; Elimina l'originale soltanto dopo la creazione riuscita del TEXT.
        (vla-Delete o)
        (setq n (1+ n)))))
  (princ (strcat "\nMTEXT convertiti: " (itoa n) "."))
  (princ))
(defun c:CTI_MTEXT_IN_TESTO () (cti20w:run 'cti20w:cmd-mtext-testo))

(defun cti20w:cmd-copia-contenuto (/ src s ss e n)
  (setq src (car (entsel "\nSeleziona testo sorgente: ")))
  (if (and src (setq s (cti20w:text-get src))) (progn (prompt "\nSeleziona testi destinazione: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0) (foreach e (cti20w:ss-list ss) (if (/= e src) (if (cti20w:text-set e s) (setq n (1+ n))))) (princ (strcat "\nTesti aggiornati: " (itoa n) ".")))) (princ))
(defun c:CTI_COPIA_CONTENUTO_TESTO () (cti20w:run 'cti20w:cmd-copia-contenuto))

(defun cti20w:cmd-esporta-testi-xyz (/ ss path f e p s n)
  (prompt "\nSeleziona testi da esportare: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT")))
        path (getfiled "Salva testi XYZ" "testi_xyz" "csv" 1)
        n 0)
  (if (and ss path)
    (progn
      (setq f (open path "w"))
      (if f
        (progn
          (write-line "Testo;X;Y;Z" f)
          (foreach e (cti20w:ss-list ss)
            (setq p (cti20w:inspt e) s (cti20w:text-get e))
            (if p
              (progn
                (write-line (strcat (cti20w:csv-quote s) ";" (rtos (car p) 2 4) ";"
                                    (rtos (cadr p) 2 4) ";"
                                    (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
                (setq n (1+ n)))))
          (close f)
          (princ (strcat "\nTesti esportati: " (itoa n) ".")))
        (princ "\nImpossibile creare il file CSV."))))
  (princ))
(defun c:CTI_ESPORTA_TESTI_XYZ () (cti20w:run 'cti20w:cmd-esporta-testi-xyz))

(defun cti20w:cmd-testi-sovrapposti (/ ss tol lst i j a b pa pb bad n tab)
  (setq tol (getdist "\nTolleranza posizione <0.01>: "))
  (if (not tol) (setq tol 0.01))
  (prompt "\nSeleziona testi <Invio=tutti nella scheda corrente>: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if (not ss)
    (progn (setq tab (getvar "CTAB")) (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab))))))
  (setq lst (cti20w:ss-list ss) bad (ssadd) n 0 i 0)
  (while (< i (length lst))
    (setq j (1+ i) a (nth i lst) pa (cti20w:inspt a))
    (while (< j (length lst))
      (setq b (nth j lst) pb (cti20w:inspt b))
      (if (and pa pb (< (distance pa pb) tol))
        (progn (if (not (ssmemb a bad)) (ssadd a bad)) (if (not (ssmemb b bad)) (ssadd b bad))))
      (setq j (1+ j)))
    (setq i (1+ i)))
  (setq n (sslength bad))
  (if (> n 0) (sssetfirst nil bad))
  (princ (strcat "\nTesti sovrapposti/selezionati: " (itoa n) "."))
  (princ))
(defun c:CTI_TESTI_SOVRAPPOSTI () (cti20w:run 'cti20w:cmd-testi-sovrapposti))

(defun cti20w:add-text-color (pt str ht layer color / o)
  (setq o (cti20w:add-text pt str ht layer))
  (vla-put-Color o color)
  o)

(defun cti20w:cmd-diff-testi (/ ss tol lst used i j a b pa pb va vb ht diff n)
  (setq tol (getdist "\nTolleranza posizione <0.01>: "))
  (if (not tol) (setq tol 0.01))
  (prompt "\nSeleziona testi numerici: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT"))) lst (cti20w:ss-list ss) used nil n 0 i 0)
  (while (< i (length lst))
    (setq a (nth i lst))
    (if (not (member a used))
      (progn
        (setq pa (cti20w:inspt a) va (cti20w:num-text a) j (1+ i))
        (while (< j (length lst))
          (setq b (nth j lst))
          (if (and (not (member b used)) pa va)
            (progn
              (setq pb (cti20w:inspt b) vb (cti20w:num-text b))
              (if (and pb vb (< (distance pa pb) tol))
                (progn
                  (setq diff (- vb va)
                        ht (cti20w:text-height-vla (vlax-ename->vla-object a)))
                  (cti20w:add-text-color (polar pa 0.0 (* ht 1.2))
                                         (strcat "Δ=" (rtos diff 2 3)) ht
                                         "CTI-DIFFERENZE-TESTO" (if (>= diff 0.0) 3 1))
                  (setq used (cons a (cons b used)) n (1+ n) j (length lst)))))
          (setq j (1+ j)))))
    (setq i (1+ i)))
  (princ (strcat "\nCoppie sovrapposte elaborate: " (itoa n) "."))
  (princ)))
(defun c:CTI_DIFFERENZA_TESTI_SOVRAPPOSTI () (cti20w:run 'cti20w:cmd-diff-testi))

(defun cti20w:cmd-minmax (/ b poly all e p v minv maxv mine maxe tab h r c x)
  (setq b (car (entsel "\nSeleziona contorno LWPOLYLINE chiuso e rettilineo: ")))
  (cond
    ((not b) nil)
    ((not (cti20w:lw-closed-p b)) (princ "\nIl contorno deve essere chiuso."))
    ((cti20w:lw-has-bulge-p b) (princ "\nIl contorno contiene archi: usa un contorno rettilineo per un test interno affidabile."))
    (T
     (setq poly (cti20w:lwverts b) tab (getvar "CTAB")
           all (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab)))
           minv nil maxv nil)
     (foreach e (cti20w:ss-list all)
       (setq p (cti20w:inspt e) v (cti20w:num-text e))
       (if (and p v (cti20w:point-in-poly p poly))
         (progn
           (if (or (null minv) (< v minv)) (setq minv v mine e))
           (if (or (null maxv) (> v maxv)) (setq maxv v maxe e)))))
     (if minv
       (progn
         (sssetfirst nil (ssadd mine (ssadd maxe)))
         (foreach x (list (list mine 5) (list maxe 1))
           (setq e (car x) c (cadr x) p (cti20w:inspt e)
                 h (cti20w:text-height-vla (vlax-ename->vla-object e))
                 r (* 1.2 h))
           (cti20w:add-circle p r "CTI-MINMAX")
           (vla-put-Color (vlax-ename->vla-object (entlast)) c))
         (princ (strcat "\nMin=" (rtos minv 2 4) "  Max=" (rtos maxv 2 4) ".")))
       (princ "\nNessun testo numerico nel contorno."))))
  (princ))
(defun c:CTI_MINMAX_NEL_CONTORNO () (cti20w:run 'cti20w:cmd-minmax))


(defun cti20w:cmd-importa-punti (/ path f line sep vals x y z lab ht n p sx sy sz)
  (setq path (getfiled "Seleziona CSV/TXT punti (X,Y,Z,Testo)" "" "csv;txt" 0)
        ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (if path
    (progn
      (setq f (open path "r"))
      (if f
        (progn
          (cti20w:ensure-layer "CTI-PUNTI-IMPORT" 7)
          (setq n 0)
          (while (setq line (read-line f))
            (setq sep (cti20w:csv-sep line) vals (cti20w:csv-split line sep))
            (if (>= (length vals) 2)
              (progn
                (setq sx (vl-string-translate "," "." (vl-string-trim " \t" (nth 0 vals)))
                      sy (vl-string-translate "," "." (vl-string-trim " \t" (nth 1 vals)))
                      sz (if (> (length vals) 2) (vl-string-translate "," "." (vl-string-trim " \t" (nth 2 vals))) "0")
                      x (distof sx 2) y (distof sy 2) z (distof sz 2)
                      lab (if (> (length vals) 3) (nth 3 vals) ""))
                (if (and x y)
                  (progn
                    (if (not z) (setq z 0.0))
                    (setq p (list x y z))
                    (entmakex (list '(0 . "POINT") (cons 8 "CTI-PUNTI-IMPORT") (cons 10 p)))
                    (if (/= lab "") (cti20w:add-text p lab ht "CTI-PUNTI-IMPORT"))
                    (setq n (1+ n)))))))
          (close f)
          (princ (strcat "\nPunti importati: " (itoa n) ".")))
        (princ "\nImpossibile aprire il file selezionato."))))
  (princ))
(defun c:CTI_IMPORTA_PUNTI_TESTO () (cti20w:run 'cti20w:cmd-importa-punti))

(defun cti20w:cmd-scambia-testi (/ a b sa sb)
  (setq a (car (entsel "\nPrimo testo: ")) b (car (entsel "\nSecondo testo: ")))
  (if (and a b (setq sa (cti20w:text-get a)) (setq sb (cti20w:text-get b))) (progn (cti20w:text-set a sb) (cti20w:text-set b sa))) (princ))
(defun c:CTI_SCAMBIA_TESTI () (cti20w:run 'cti20w:cmd-scambia-testi))

(defun cti20w:rotate-text-selection (ang / ss e o)
  (prompt "\nSeleziona testi da ruotare: ") (setq ss (ssget '((0 . "TEXT,MTEXT")))) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (vlax-property-available-p o 'Rotation T) (vla-put-Rotation o ang))))
(defun cti20w:cmd-ruota-testo2p (/ p1 p2) (setq p1 (getpoint "\nPrimo punto direzione: ") p2 (getpoint p1 "\nSecondo punto direzione: ")) (if (and p1 p2) (cti20w:rotate-text-selection (angle p1 p2))) (princ))
(defun c:CTI_RUOTA_TESTO_2P () (cti20w:run 'cti20w:cmd-ruota-testo2p))
(defun cti20w:layout-app () "CTI20W-TESTO-LAYOUT")
(defun cti20w:layout-ensure-app (/ a) (setq a (cti20w:layout-app)) (if (not (tblsearch "APPID" a)) (regapp a)) a)
(defun cti20w:layout-set-ref (e ang / ed xd newxd)
  (cti20w:layout-ensure-app)
  (setq ed (entget e (list (cti20w:layout-app)))
        xd (assoc -3 ed)
        newxd (list -3 (list (cti20w:layout-app) (cons 1040 ang))))
  (entmod (if xd (subst newxd xd ed) (append ed (list newxd)))))
(defun cti20w:layout-get-ref (e / ed xd rec)
  (setq ed (entget e (list (cti20w:layout-app))) xd (assoc -3 ed))
  (if xd
    (progn (setq rec (assoc (cti20w:layout-app) (cdr xd)))
           (if rec (cdr (assoc 1040 (cdr rec))) nil))
    nil))

(defun cti20w:cmd-ruota-testo-layout (/ mode ss e o ang twist ref new n)
  (initget "Memorizza Applica")
  (setq mode (getkword "\nOperazione [Memorizza/Applica] <Memorizza>: "))
  (if (not mode) (setq mode "Memorizza"))
  (cond
    ((= mode "Memorizza")
     (prompt "\nSeleziona testi di cui memorizzare l'angolo di riferimento: ")
     (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
     (foreach e (cti20w:ss-list ss)
       (setq o (vlax-ename->vla-object e)
             ang (if (vlax-property-available-p o 'Rotation) (vla-get-Rotation o) 0.0))
       (if (cti20w:layout-set-ref e ang) (setq n (1+ n))))
     (princ (strcat "\nAngolo di riferimento memorizzato su " (itoa n) " testi.")))
    (T
     (setq twist (getreal "\nAngolo di rotazione viewport/layout in gradi <0>: "))
     (if (not twist) (setq twist 0.0))
     (setq twist (* twist (/ pi 180.0)))
     (prompt "\nSeleziona testi da copiare e compensare: ")
     (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
     (cti20w:ensure-layer "CTI-TESTO-LAYOUT" 5)
     (foreach e (cti20w:ss-list ss)
       (setq o (vlax-ename->vla-object e)
             ref (cti20w:layout-get-ref e))
       (if (not ref) (setq ref (if (vlax-property-available-p o 'Rotation) (vla-get-Rotation o) 0.0)))
       (setq new (vl-catch-all-apply 'vla-Copy (list o)))
       (if (not (vl-catch-all-error-p new))
         (progn
           (if (vlax-property-available-p new 'Rotation T) (vla-put-Rotation new (- ref twist)))
           (if (vlax-property-available-p new 'Layer T) (vla-put-Layer new "CTI-TESTO-LAYOUT"))
           (setq n (1+ n)))))
     (princ (strcat "\nCopie testo compensate per il layout: " (itoa n) "."))))
  (princ))
(defun c:CTI_RUOTA_TESTO_LAYOUT () (cti20w:run 'cti20w:cmd-ruota-testo-layout))

(defun cti20w:round-nearest (v step / q)
  (setq q (/ v step))
  (* step (fix (+ q (if (minusp q) -0.5 0.5)))))
(defun cti20w:cmd-arrotonda-testi (/ step ss e v q n)
  (setq step (getreal "\nPasso di arrotondamento <0.005>: "))
  (if (not step) (setq step 0.005))
  (if (> step 0.0)
    (progn
      (prompt "\nSeleziona testi numerici: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (if (setq v (cti20w:num-text e))
          (progn
            (setq q (cti20w:round-nearest v step))
            (cti20w:text-set e (rtos q 2 6))
            (setq n (1+ n)))))
      (princ (strcat "\nTesti arrotondati: " (itoa n) ".")))
    (princ "\nIl passo deve essere maggiore di zero."))
  (princ))
(defun c:CTI_ARROTONDA_TESTI () (cti20w:run 'cti20w:cmd-arrotonda-testi))

(defun cti20w:cmd-cerca-testi (/ mode pat ss out e s)
  (initget "Inizia Finisce Contiene") (setq mode (getkword "\nCriterio [Inizia/Finisce/Contiene] <Contiene>: ")) (if (not mode) (setq mode "Contiene")) (setq pat (strcase (getstring T "\nTesto da cercare: ")) ss (ssget "_X" '((0 . "TEXT,MTEXT"))) out (ssadd))
  (foreach e (cti20w:ss-list ss) (setq s (strcase (cti20w:text-get e))) (if (cond ((= mode "Inizia") (= 0 (vl-string-search pat s))) ((= mode "Finisce") (and (>= (strlen s) (strlen pat)) (= pat (substr s (1+ (- (strlen s) (strlen pat))))))) (T (vl-string-search pat s))) (ssadd e out)))
  (if (> (sslength out) 0) (sssetfirst nil out)) (princ (strcat "\nTesti trovati: " (itoa (sslength out)) ".")) (princ))
(defun c:CTI_CERCA_TESTI () (cti20w:run 'cti20w:cmd-cerca-testi))

(defun cti20w:cmd-testi-altezza (/ mn mx ss out e o h)
  (setq mn (getreal "\nAltezza minima: ") mx (getreal "\nAltezza massima: ") ss (ssget "_X" '((0 . "TEXT,MTEXT"))) out (ssadd))
  (if (and mn mx) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e) h (vl-catch-all-apply 'vlax-get (list o 'Height))) (if (and (numberp h) (>= h mn) (<= h mx)) (ssadd e out))))
  (if (> (sslength out) 0) (sssetfirst nil out)) (princ (strcat "\nTesti selezionati: " (itoa (sslength out)) ".")) (princ))
(defun c:CTI_TESTI_PER_ALTEZZA () (cti20w:run 'cti20w:cmd-testi-altezza))

(defun cti20w:nodi-endpoints (curves / out e o)
  (setq out nil)
  (foreach e curves
    (setq o (vlax-ename->vla-object e))
    (setq out (cons (vlax-curve-getStartPoint o) out))
    (setq out (cons (vlax-curve-getEndPoint o) out)))
  out)
(defun cti20w:nodo-nearest (p nodes radius / q d best bestd)
  (setq best nil bestd nil)
  (foreach q nodes
    (setq d (distance p q))
    (if (and (<= d radius) (or (null bestd) (< d bestd))) (setq best q bestd d)))
  best)
(defun cti20w:point-count (p lst tol / n q)
  (setq n 0)
  (foreach q lst (if (equal p q tol) (setq n (1+ n)))) n)

(defun cti20w:cmd-testo-su-nodo (/ curves ss radius nodes te p q targets targetpts pair o moved flagged)
  (prompt "\nSeleziona linee/polilinee che definiscono i nodi: ")
  (setq curves (cti20w:ss-list (ssget '((0 . "LINE,LWPOLYLINE,POLYLINE")))))
  (if curves
    (progn
      (prompt "\nSeleziona testi da agganciare: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))))
      (setq radius (getdist "\nRaggio massimo di ricerca <5.0>: "))
      (if (not radius) (setq radius 5.0))
      (setq nodes (cti20w:nodi-endpoints curves) targets nil targetpts nil)
      (foreach te (cti20w:ss-list ss)
        (setq p (cti20w:inspt te) q (and p (cti20w:nodo-nearest p nodes radius)))
        (setq targets (cons (list te q p) targets))
        (if q (setq targetpts (cons q targetpts))))
      (cti20w:ensure-layer "CTI-NODI-AMBIGUI" 1)
      (setq moved 0 flagged 0)
      (foreach pair targets
        (setq te (car pair) q (cadr pair) p (caddr pair))
        (if q
          (if (> (cti20w:point-count q targetpts 1e-6) 1)
            (progn
              (setq o (vlax-ename->vla-object te))
              (if (vlax-property-available-p o 'Layer T) (vla-put-Layer o "CTI-NODI-AMBIGUI"))
              (if (vlax-property-available-p o 'Color T) (vla-put-Color o 1))
              (setq flagged (1+ flagged)))
            (progn
              (setq o (vlax-ename->vla-object te))
              (vla-Move o (vlax-3d-point p) (vlax-3d-point q))
              (setq moved (1+ moved))))))
      (princ (strcat "\nTesti agganciati: " (itoa moved)
                     "; ambigui lasciati in posizione e segnalati: " (itoa flagged) "."))))
  (princ))
(defun c:CTI_TESTO_SU_NODO () (cti20w:run 'cti20w:cmd-testo-su-nodo))

(setq *CTI-WEB-PHASE2B-LOADED* T)
(princ "\nCAD Tools Italiano 2.0 Fase 2B: altri 30 strumenti Web MIT caricati (60 nuovi cumulativi con la Fase 2A).")
(princ)
