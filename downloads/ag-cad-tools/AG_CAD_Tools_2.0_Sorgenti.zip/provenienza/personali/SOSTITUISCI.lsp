lisp
(defun c:SOSTITUISCI (/ ss refEnt refObj refPt i ent entObj entPt copia)

;; Selezione oggetti da sostituire
  (prompt "\nSeleziona gli oggetti da sostituire: ")
  (setq ss (ssget))

  (if ss
    (progn
;; Selezione oggetto sostitutivo
      (prompt "\nSeleziona l'oggetto che li sostituirà: ")
      (setq refEnt (car (entsel)))

      (if refEnt
        (progn
          (setq refObj (vlax-ename->vla-object refEnt))

;; Ottieni bounding box centroide come punto di riferimento
          (vla-getboundingbox refObj 'minPt 'maxPt)
          (setq minPt (vlax-safearray->list minPt))
          (setq maxPt (vlax-safearray->list maxPt))
          (setq refPt (mapcar '(lambda (a b) (/ (+ a b) 2.0)) minPt maxPt))

;; Ciclo su ogni oggetto da sostituire
          (setq i 0)
          (while (< i (sslength ss))
            (setq ent (ssname ss i))
            (setq entObj (vlax-ename->vla-object ent))

;; Ottieni centroide dell'oggetto da sostituire
            (vla-getboundingbox entObj 'minPt2 'maxPt2)
            (setq minPt2 (vlax-safearray->list minPt2))
            (setq maxPt2 (vlax-safearray->list maxPt2))
            (setq entPt (mapcar '(lambda (a b) (/ (+ a b) 2.0)) minPt2 maxPt2))

;; Copia e sposta
            (setq copia (vla-copy refObj))
            (vla-move copia
                      (vlax-3d-point refPt)
                      (vlax-3d-point entPt))

;; Cancella oggetto originale
            (vla-delete entObj)

            (setq i (1+ i))
)
          (prompt "\nSostituzione completata.")
)
        (prompt "\nOggetto sostitutivo non valido.")
)
)
    (prompt "\nNessun oggetto selezionato.")
)
  (princ)
)
