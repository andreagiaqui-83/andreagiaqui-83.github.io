(defun c:ALLINEATESTI ( / modello ptmod altri scelta i ent dati pt)
  (prompt "\n>>> Seleziona il testo modello: ")
  (setq modello (car (entsel)))
  (if modello
    (progn
      (setq ptmod (cdr (assoc 10 (entget modello)))) ; punto inserimento modello
      (prompt "\n>>> Seleziona i testi da allineare: ")
      (setq altri (ssget '((0 . "TEXT,MTEXT"))))
      (if altri
        (progn
          ;; Chiede opzione O/V
          (setq scelta (strcase (getstring "\n>>> Digita O per Orizzontale o V per Verticale: ")))
          (cond
            ((= scelta "O")
             (repeat (setq i (sslength altri))
               (setq ent (ssname altri (setq i (1- i))))
               (setq dati (entget ent))
               (setq pt (cdr (assoc 10 dati)))
               ;; Mantiene X, cambia Y
               (setq pt (list (car pt) (cadr ptmod)))
               (entmod (subst (cons 10 pt) (assoc 10 dati) dati))
             )
             (prompt "\n>>> Allineamento orizzontale completato.")
            )
            ((= scelta "V")
             (repeat (setq i (sslength altri))
               (setq ent (ssname altri (setq i (1- i))))
               (setq dati (entget ent))
               (setq pt (cdr (assoc 10 dati)))
               ;; Mantiene Y, cambia X
               (setq pt (list (car ptmod) (cadr pt)))
               (entmod (subst (cons 10 pt) (assoc 10 dati) dati))
             )
             (prompt "\n>>> Allineamento verticale completato.")
            )
            (T (prompt "\n>>> Opzione non valida. Usa O o V."))
          )
        )
        (prompt "\n>>> Nessun testo selezionato.")
      )
    )
    (prompt "\n>>> Nessun testo modello selezionato.")
  )
  (princ)
)
``