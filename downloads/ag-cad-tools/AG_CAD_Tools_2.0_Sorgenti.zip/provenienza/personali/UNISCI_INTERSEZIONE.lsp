(defun c:UNISCI_INTERSEZIONE (/ ss)
  (setvar "cmdecho" 0)
  (setvar "FILLETRAD" 0) ; Imposta il raggio di raccordo a zero
  (princ "\n--- COMANDO UNISCI INTERSEZIONE ATTIVO ---")
  (princ "\nSeleziona le coppie di linee. Premi INVIO o ESC per uscire.")
  
  (while t
    (setq ss (ssget '((0 . "LINE,LWPOLYLINE"))))
    (if (and ss (= (sslength ss) 2))
      (progn
        (command "_.fillet" (ssname ss 0) (ssname ss 1))
        (princ "\nProssima coppia (o premi Invio per finire): ")
      )
      (if (not ss)
        (exit) ; Esce se non viene selezionato nulla (Invio)
        (princ "\nErrore: Seleziona esattamente 2 linee con il riquadro.")
      )
    )
  )
  (princ)
)
