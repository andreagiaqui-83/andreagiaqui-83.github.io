(defun c:MURO_STRATIGRAFIA ( / sel l p1 p2 dx dy lung n
                                 d1 d2 d3 punto lato
                                 np1 np2 np3 np4 np5 np6
                                 line1 line2 line3 line4)

  (vl-load-com)

  ;; Chiedi distanze UNA SOLA VOLTA
  (setq d1 (getreal "\nInserisci distanza prima linea parallela: "))
  (setq d2 (getreal "\nInserisci distanza seconda linea parallela: "))
  (setq d3 (getreal "\nInserisci distanza terza linea parallela: "))

  (princ "\nSeleziona una linea (INVIO per terminare)...")

  ;; Ciclo continuo finché selezioni linee
  (while (setq sel (ssget '((0 . "LINE"))))

    (setq l (ssname sel 0))
    (setq line4 (vlax-ename->vla-object l))

    ;; Punti start e end
    (setq p1 (vlax-get line4 'StartPoint))
    (setq p2 (vlax-get line4 'EndPoint))

    ;; Vettore linea
    (setq dx (- (car p2) (car p1)))
    (setq dy (- (cadr p2) (cadr p1)))

    (setq lung (sqrt (+ (* dx dx) (* dy dy))))

    ;; Vettore perpendicolare unitario
    (setq n (list (/ (- dy) lung)
                  (/ dx lung)
                  0))

    ;; Clic lato
    (setq punto (getpoint "\nClicca sul lato dove creare le parallele: "))
    (setq lato (mapcar '- punto p1))

    ;; Se prodotto scalare negativo, inverti direzione
    (if (< (+ (* (car lato) (car n)) (* (cadr lato) (cadr n))) 0)
      (setq n (mapcar '- n))
    )

    ;; Calcolo punti nuove linee
    (setq np1 (mapcar '+ p1 (mapcar '* n (list d1 d1 d1))))
    (setq np2 (mapcar '+ p2 (mapcar '* n (list d1 d1 d1))))
    (setq np3 (mapcar '+ p1 (mapcar '* n (list d2 d2 d2))))
    (setq np4 (mapcar '+ p2 (mapcar '* n (list d2 d2 d2))))
    (setq np5 (mapcar '+ p1 (mapcar '* n (list d3 d3 d3))))
    (setq np6 (mapcar '+ p2 (mapcar '* n (list d3 d3 d3))))

    ;; Creazione linee
    (setq line1 (vlax-ename->vla-object (entmakex (list (cons 0 "LINE") (cons 10 np1) (cons 11 np2)))))
    (setq line2 (vlax-ename->vla-object (entmakex (list (cons 0 "LINE") (cons 10 np3) (cons 11 np4)))))
    (setq line3 (vlax-ename->vla-object (entmakex (list (cons 0 "LINE") (cons 10 np5) (cons 11 np6)))))

    ;; Assegnazione layer
    (vlax-put line4 'Layer "Muro_Finitura_1_Num_Penna__156")
    (vlax-put line1 'Layer "Muro_Finitura_2_Num_Penna__148")
    (vlax-put line2 'Layer "Muro_Portante_1_Num_Penna__148")
    (vlax-put line3 'Layer "Muro_Portante_2_Num_Penna__149")

    (princ "\nLinee create. Seleziona un'altra linea (INVIO per uscire)...")
  )

  (princ "\nComando terminato.")
  (princ)
)
