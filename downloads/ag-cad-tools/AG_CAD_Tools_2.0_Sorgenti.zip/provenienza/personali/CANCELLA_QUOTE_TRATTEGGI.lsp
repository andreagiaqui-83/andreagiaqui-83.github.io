(defun c:CANCELLA_QUOTE_TRATTEGGI (/ ss i ent)
  (vl-load-com)

  ;; Seleziona tutte le quote (DIMENSION) e tratteggi (HATCH)
  (setq ss (ssget "X" '((0 . "DIMENSION,HATCH"))))

  (if ss
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (entdel ent)
        (setq i (1+ i))
      )
      (prompt "\nQuote e tratteggi cancellati.")
    )
    (prompt "\nNessuna quota o tratteggio trovato.")
  )
  (princ)
)