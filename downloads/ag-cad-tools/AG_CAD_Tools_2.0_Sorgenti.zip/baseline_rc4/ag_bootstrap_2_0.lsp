; AG CAD Tools 2.0 RC4 - unico punto di caricamento per documento.
(vl-load-com)
(setq *CTI2-LOAD-COMPLETE* nil *CTI2-LOAD-ERRORS* nil *CTI2-RUNTIME-OK* nil
      *CTI-WEB-2-0-LOADED* nil *CTI-ANDREA-LOADED* nil *CTI-UI-2-0-COUNT* nil
      *CTI2-DIAGNOSTICA-OK* nil)
(setq *CTI2-DIRECTORY*
  (strcat (vl-filename-directory (findfile "ag_bootstrap_2_0.lsp")) "\\"))
(defun cti2:carica-modulo (nome / p r)
  (setq p (strcat *CTI2-DIRECTORY* nome))
  (if (findfile p)
    (progn
      (setq r (vl-catch-all-apply 'load (list p)))
      (if (vl-catch-all-error-p r)
        (setq *CTI2-LOAD-ERRORS* (cons (strcat nome ": " (vl-catch-all-error-message r)) *CTI2-LOAD-ERRORS*))))
    (setq *CTI2-LOAD-ERRORS* (cons (strcat nome ": file mancante") *CTI2-LOAD-ERRORS*)))
  (princ))
(progn
  (cti2:carica-modulo "ag_runtime_2_0.lsp")
  (cti2:carica-modulo "ag_cad_tools.lsp")
  (cti2:carica-modulo "ag_web_2_0.lsp")
  (cti2:carica-modulo "ag_andrea_2_0.lsp")
  (cti2:carica-modulo "ag_catalogo_2_0.lsp")
  (cti2:carica-modulo "ag_diagnostica_2_0.lsp")
  (cti2:carica-modulo "ag_compatibilita.lsp"))
; Migrazione del gruppo parziale precedente; nessun file Autodesk viene modificato.
(defun ag:aggiorna-interfaccia (/ gruppi vecchio nuovo percorso)
  (setq gruppi (vla-get-MenuGroups (vlax-get-acad-object)))
  ; Rimuove il vecchio gruppo solo dopo avere disponibile il nuovo.
  (if (not (menugroup "AGCADTOOLS"))
    (progn
      (setq percorso (findfile (strcat *CTI2-DIRECTORY* "AGCADTools.cuix")))
      (if percorso (vla-Load gruppi percorso))))
  (if (and (menugroup "AGCADTOOLS") (menugroup "CADTOOLSITALIANO"))
    (progn
      (setq vecchio (vla-Item gruppi "CADTOOLSITALIANO"))
      (vla-Unload vecchio)))
  (princ))

(if *CTI-LOAD-COMPLETE* (cti:startup-call "Interfaccia AG CAD Tools" 'ag:aggiorna-interfaccia))
(setq *CTI2-LOAD-COMPLETE*
  (and (null *CTI2-LOAD-ERRORS*) *CTI2-RUNTIME-OK* *CTI-LOAD-COMPLETE*
       *CTI-WEB-2-0-LOADED* *CTI-ANDREA-LOADED* *CTI2-DIAGNOSTICA-OK*
       (= *CTI-UI-2-0-COUNT* 200)
       (null (cti2:comandi-mancanti *CTI2-COMANDI-PUBBLICI*))))
(if *CTI2-LOAD-COMPLETE*
  (princ "\nAG CAD Tools 2.0 RC4 caricato: 93 core + 100 Web + 5 personali. Digita AGCADTOOLS.")
  (princ "\nAG CAD Tools: caricamento incompleto. Digita AG_DIAGNOSTICA."))
(princ)
