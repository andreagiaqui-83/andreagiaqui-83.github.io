; AG CAD Tools 2.0 RC4 - 100 strumenti Web MIT
; 100 strumenti Web MIT, 12 alias storici; consolidato Fase 2D.
; Provenienza, licenze e limiti: LICENZE_TERZE_PARTI.txt e MANIFEST_100_WEB_FASE2D.csv.

(vl-load-com)
(setq *CTI-WEB-2-0-LOADED* nil)
; Runtime comune caricato dal bootstrap.

(if (not (boundp '*CTI20X-CARTIGLIO-ATTRIBUTI*)) (setq *CTI20X-CARTIGLIO-ATTRIBUTI* nil))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:BLOCCHI_SU_NODI () (c:AG_BLOCCHI_SU_NODI))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:CONTROLLA_NUMERAZIONE () (c:AG_CONTROLLA_NUMERAZIONE))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:COPIA_SU_LAYOUT () (c:AG_COPIA_SU_LAYOUT))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:CSV_IN_TABELLA () (c:AG_CSV_IN_TABELLA))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_3DFACE_IN_STL () (cti2:esegui-comando "AG_3DFACE_IN_STL" 'cti20w:cmd-3dface-stl))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_AGGIORNA_CARTIGLIO () (cti2:esegui-comando "AG_AGGIORNA_CARTIGLIO" 'cti20x:cmd-aggiorna-cartiglio))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_AGGIUNGI_VERTICI () (cti2:esegui-comando "AG_AGGIUNGI_VERTICI" 'cti20w:cmd-aggiungi-vertici))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_ALLINEA_TESTO_RIFERIMENTO () (cti2:esegui-comando "AG_ALLINEA_TESTO_RIFERIMENTO" 'cti20w:cmd-allinea-testo-rif))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_ANGOLI_POLILINEA () (cti2:esegui-comando "AG_ANGOLI_POLILINEA" 'cti20w:cmd-angoli-polilinea))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_ARCO_IN_SEGMENTI () (cti2:esegui-comando "AG_ARCO_IN_SEGMENTI" 'cti20c:cmd-arco-segmenti))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_AREA_MULTIUNITA () (cti2:esegui-comando "AG_AREA_MULTIUNITA" 'cti20w:cmd-area-multiunita))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_AREE_MULTIPLE () (cti2:esegui-comando "AG_AREE_MULTIPLE" 'cti20w:cmd-aree-multiple))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_ARROTONDA_TESTI () (cti2:esegui-comando "AG_ARROTONDA_TESTI" 'cti20w:cmd-arrotonda-testi))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_ASSE_TRA_BORDI () (cti2:esegui-comando "AG_ASSE_TRA_BORDI" 'cti20w:cmd-asse-bordi))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_ATTRIBUTI_IN_TESTO () (cti2:esegui-comando "AG_ATTRIBUTI_IN_TESTO" 'cti20w:cmd-attributi-testo))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_BLOCCA_VALORE_QUOTA () (cti2:esegui-comando "AG_BLOCCA_VALORE_QUOTA" 'cti20c:cmd-blocca-quota))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_BLOCCHI_SU_ALLINEAMENTO () (cti2:esegui-comando "AG_BLOCCHI_SU_ALLINEAMENTO" 'cti20w:cmd-blocchi-su-allineamento))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_BLOCCHI_SU_MEZZERIE () (cti2:esegui-comando "AG_BLOCCHI_SU_MEZZERIE" 'cti20w:cmd-blocchi-mezzerie))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_BLOCCHI_SU_NODI () (cti2:esegui-comando "AG_BLOCCHI_SU_NODI" 'cti2c:cmd-blocchi-su-nodi))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_BLOCCHI_SU_TESTI () (cti2:esegui-comando "AG_BLOCCHI_SU_TESTI" 'cti20w:cmd-blocchi-testi))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_BLOCCHI_SU_VERTICI () (cti2:esegui-comando "AG_BLOCCHI_SU_VERTICI" 'cti20w:cmd-blocchi-vertici))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_BLOCCO_A_QUOTA_TESTO () (cti2:esegui-comando "AG_BLOCCO_A_QUOTA_TESTO" 'cti20w:cmd-blocco-quota-testo))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_CALCOLA_TESTI_NUMERICI () (cti2:esegui-comando "AG_CALCOLA_TESTI_NUMERICI" 'cti20c:cmd-calcola-testi))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_CANCELLA_DENTRO () (cti2:esegui-comando "AG_CANCELLA_DENTRO" 'cti20c:cmd-cancella-dentro))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_CERCA_TESTI () (cti2:esegui-comando "AG_CERCA_TESTI" 'cti20w:cmd-cerca-testi))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_CONTROLLA_NUMERAZIONE () (cti2:esegui-comando "AG_CONTROLLA_NUMERAZIONE" 'cti2c:cmd-controlla-numerazione))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_CONTROLLO_POLIGONI () (cti2:esegui-comando "AG_CONTROLLO_POLIGONI" 'cti20w:cmd-controllo-poligoni))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_COPIA_CONTENUTO_TESTO () (cti2:esegui-comando "AG_COPIA_CONTENUTO_TESTO" 'cti20w:cmd-copia-contenuto))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_COPIA_POLIGONI_CHIUSI () (cti2:esegui-comando "AG_COPIA_POLIGONI_CHIUSI" 'cti20x:cmd-copia-poligoni-chiusi))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_COPIA_SU_LAYOUT () (cti2:esegui-comando "AG_COPIA_SU_LAYOUT" 'cti2c:cmd-copia-su-layout))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_CREA_LAYER_RAPIDO () (cti2:esegui-comando "AG_CREA_LAYER_RAPIDO" 'cti20c:cmd-layer-rapido))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_CSV_IN_TABELLA () (cti2:esegui-comando "AG_CSV_IN_TABELLA" 'cti2c:cmd-csv-in-tabella))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_DECIMALI_TESTO () (cti2:esegui-comando "AG_DECIMALI_TESTO" 'cti20w:cmd-decimali-testo))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_DETTAGLI_CURVE () (cti2:esegui-comando "AG_DETTAGLI_CURVE" 'cti20w:cmd-dettagli-curve))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_DETTAGLI_LOTTO () (cti2:esegui-comando "AG_DETTAGLI_LOTTO" 'cti20x:cmd-dettagli-lotto))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_DIFFERENZA_TESTI_SOVRAPPOSTI () (cti2:esegui-comando "AG_DIFFERENZA_TESTI_SOVRAPPOSTI" 'cti20w:cmd-diff-testi))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_DISTANZA_SU_POLILINEA () (cti2:esegui-comando "AG_DISTANZA_SU_POLILINEA" 'cti20w:cmd-distanza-su-polilinea))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_DIVIDI_LUNGHEZZE () (cti2:esegui-comando "AG_DIVIDI_LUNGHEZZE" 'cti20x:cmd-dividi-lunghezze))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_ESPORTA_DATI_LOTTI () (cti2:esegui-comando "AG_ESPORTA_DATI_LOTTI" 'cti20x:cmd-esporta-dati-lotti))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_ESPORTA_TESTI_XYZ () (cti2:esegui-comando "AG_ESPORTA_TESTI_XYZ" 'cti20w:cmd-esporta-testi-xyz))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_ESPORTA_VERTICI_CSV () (cti2:esegui-comando "AG_ESPORTA_VERTICI_CSV" 'cti2c:cmd-esporta-vertici-csv))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_ETICHETTA_Z_VERTICI () (cti2:esegui-comando "AG_ETICHETTA_Z_VERTICI" 'cti20w:cmd-etichetta-z))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_FACCIA3D_IN_POLILINEA () (cti2:esegui-comando "AG_FACCIA3D_IN_POLILINEA" 'cti20w:cmd-faccia3d-polilinea))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_GENERA_LOTTIZZAZIONE () (cti2:esegui-comando "AG_GENERA_LOTTIZZAZIONE" 'cti20x:cmd-genera-lottizzazione))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_GRIGLIA_COORDINATE () (cti2:esegui-comando "AG_GRIGLIA_COORDINATE" 'cti20w:cmd-griglia-coordinate))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_IMPORTA_PUNTI_TESTO () (cti2:esegui-comando "AG_IMPORTA_PUNTI_TESTO" 'cti20w:cmd-importa-punti))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_INSERISCI_DWG_CARTELLA () (cti2:esegui-comando "AG_INSERISCI_DWG_CARTELLA" 'cti20c:cmd-inserisci-dwg-cartella))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_INTERPOLA_QUOTE_NUMERO () (cti2:esegui-comando "AG_INTERPOLA_QUOTE_NUMERO" 'cti20w:cmd-interpola-quote-numero))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_INTERPOLA_QUOTE_PASSO () (cti2:esegui-comando "AG_INTERPOLA_QUOTE_PASSO" 'cti20w:cmd-interpola-quote-passo))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_INTERPOLA_Z_VERTICI () (cti2:esegui-comando "AG_INTERPOLA_Z_VERTICI" 'cti20w:cmd-interpola-z))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_INTERSEZIONI () (cti2:esegui-comando "AG_INTERSEZIONI" 'cti2c:cmd-intersezioni))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_INTERSEZIONI_PER_LAYER () (cti2:esegui-comando "AG_INTERSEZIONI_PER_LAYER" 'cti20w:cmd-intersezioni-layer))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_LEGENDA_LAYER () (cti2:esegui-comando "AG_LEGENDA_LAYER" 'cti20x:cmd-legenda-layer))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_LINEA_PENDENZA () (cti2:esegui-comando "AG_LINEA_PENDENZA" 'cti20w:cmd-linea-pendenza))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_LUNGHEZZE_PER_LAYER () (cti2:esegui-comando "AG_LUNGHEZZE_PER_LAYER" 'cti20w:cmd-lunghezze-layer))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_MANTIENI_DENTRO () (cti2:esegui-comando "AG_MANTIENI_DENTRO" 'cti20c:cmd-mantieni-dentro))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_MINMAX_NEL_CONTORNO () (cti2:esegui-comando "AG_MINMAX_NEL_CONTORNO" 'cti20w:cmd-minmax))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_MTEXT_IN_TESTO () (cti2:esegui-comando "AG_MTEXT_IN_TESTO" 'cti20w:cmd-mtext-testo))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_NORMALIZZA_ESTRUSIONE () (cti2:esegui-comando "AG_NORMALIZZA_ESTRUSIONE" 'cti20c:cmd-normalizza-estrusione))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_NUMERA_LOTTI () (cti2:esegui-comando "AG_NUMERA_LOTTI" 'cti20x:cmd-numera-lotti))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_NUMERA_VERTICI () (cti2:esegui-comando "AG_NUMERA_VERTICI" 'cti2c:cmd-numera-vertici))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_OFFSET_DOPPIO () (cti2:esegui-comando "AG_OFFSET_DOPPIO" 'cti20w:cmd-offset-doppio))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_OFFSET_QUOTA () (cti2:esegui-comando "AG_OFFSET_QUOTA" 'cti20w:cmd-offset-quota))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_OFFSET_Z_VERTICI () (cti2:esegui-comando "AG_OFFSET_Z_VERTICI" 'cti20w:cmd-offset-z-vertici))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_PICCHETTAMENTO_PILASTRI () (cti2:esegui-comando "AG_PICCHETTAMENTO_PILASTRI" 'cti20w:cmd-picchettamento-pilastri))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_PLOTTA_QUOTE_DA_CSV () (cti2:esegui-comando "AG_PLOTTA_QUOTE_DA_CSV" 'cti20c:cmd-plotta-quote-csv))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_POLIGONO_DA_AREA () (cti2:esegui-comando "AG_POLIGONO_DA_AREA" 'cti20x:cmd-poligono-da-area))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_POLILINEA_DA_TESTI () (cti2:esegui-comando "AG_POLILINEA_DA_TESTI" 'cti20w:cmd-polilinea-da-testi))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_POLILINEA_LISCIA_IN_SEGMENTI () (cti2:esegui-comando "AG_POLILINEA_LISCIA_IN_SEGMENTI" 'cti20w:cmd-curva-segmenti))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_POLILINEE_APERTE () (cti2:esegui-comando "AG_POLILINEE_APERTE" 'cti2c:cmd-polilinee-aperte))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_POLILINEE_CORTE () (cti2:esegui-comando "AG_POLILINEE_CORTE" 'cti20w:cmd-polilinee-corte))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_PREFISSO_SUFFISSO () (cti2:esegui-comando "AG_PREFISSO_SUFFISSO" 'cti2c:cmd-prefisso-suffisso))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_PROGRESSIVE_ALLINEAMENTO () (cti2:esegui-comando "AG_PROGRESSIVE_ALLINEAMENTO" 'cti20w:cmd-progressive))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_PUNTI_CODIFICATI_CSV () (cti2:esegui-comando "AG_PUNTI_CODIFICATI_CSV" 'cti20w:cmd-punti-codificati-csv))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_QUOTA_AUTOMATICA () (cti2:esegui-comando "AG_QUOTA_AUTOMATICA" 'cti20x:cmd-quota-automatica))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_QUOTA_INTERMEDIA () (cti2:esegui-comando "AG_QUOTA_INTERMEDIA" 'cti20w:cmd-quota-intermedia))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_QUOTA_PORTA () (cti2:esegui-comando "AG_QUOTA_PORTA" 'cti20x:cmd-quota-porta))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_QUOTA_SEGMENTI () (cti2:esegui-comando "AG_QUOTA_SEGMENTI" 'cti20w:cmd-quota-segmenti))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_QUOTA_STANZA () (cti2:esegui-comando "AG_QUOTA_STANZA" 'cti20x:cmd-quota-stanza))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_QUOTE_DA_POLILINEA3D () (cti2:esegui-comando "AG_QUOTE_DA_POLILINEA3D" 'cti20w:cmd-quote-polilinea3d))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_RETTANGOLO_3P () (cti2:esegui-comando "AG_RETTANGOLO_3P" 'cti20w:cmd-rettangolo3p))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_RIDUCI_VERTICI () (cti2:esegui-comando "AG_RIDUCI_VERTICI" 'cti2c:cmd-riduci-vertici))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_RUOTA_BLOCCHI_2P () (cti2:esegui-comando "AG_RUOTA_BLOCCHI_2P" 'cti20w:cmd-ruota-blocchi))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_RUOTA_COME_RIFERIMENTO () (cti2:esegui-comando "AG_RUOTA_COME_RIFERIMENTO" 'cti20x:cmd-ruota-riferimento))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_RUOTA_TESTO_2P () (cti2:esegui-comando "AG_RUOTA_TESTO_2P" 'cti20w:cmd-ruota-testo2p))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_RUOTA_TESTO_LAYOUT () (cti2:esegui-comando "AG_RUOTA_TESTO_LAYOUT" 'cti20w:cmd-ruota-testo-layout))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_SCALA_IMMAGINE_CONTORNO () (cti2:esegui-comando "AG_SCALA_IMMAGINE_CONTORNO" 'cti20x:cmd-scala-immagine-contorno))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_SCALA_LINEE_CENTRO () (cti2:esegui-comando "AG_SCALA_LINEE_CENTRO" 'cti20c:cmd-scala-linee-centro))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_SCALA_PER_RIFERIMENTO () (cti2:esegui-comando "AG_SCALA_PER_RIFERIMENTO" 'cti20x:cmd-scala-riferimento))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_SCAMBIA_TESTI () (cti2:esegui-comando "AG_SCAMBIA_TESTI" 'cti20w:cmd-scambia-testi))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_SPEZZAINCROCI () (cti2:esegui-comando "AG_SPEZZAINCROCI" 'cti2c:cmd-spezzaincroci))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_SPOSTA_LAYER_CORRENTE () (cti2:esegui-comando "AG_SPOSTA_LAYER_CORRENTE" 'cti20c:cmd-layer-corrente))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:AG_TABELLA_VERTICI () (cti2:esegui-comando "AG_TABELLA_VERTICI" 'cti2c:cmd-tabella-vertici))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_TAGLIA_ALLINEAMENTO_PROGRESSIVE () (cti2:esegui-comando "AG_TAGLIA_ALLINEAMENTO_PROGRESSIVE" 'cti20w:cmd-taglia-allineamento))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_TESTI_PER_ALTEZZA () (cti2:esegui-comando "AG_TESTI_PER_ALTEZZA" 'cti20w:cmd-testi-altezza))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_TESTI_SOVRAPPOSTI () (cti2:esegui-comando "AG_TESTI_SOVRAPPOSTI" 'cti20w:cmd-testi-sovrapposti))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_TESTO_DA_QUOTA_Z () (cti2:esegui-comando "AG_TESTO_DA_QUOTA_Z" 'cti20w:cmd-testo-quota-z))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_TESTO_SU_GRIGLIA () (cti2:esegui-comando "AG_TESTO_SU_GRIGLIA" 'cti20w:cmd-testo-su-griglia))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun c:AG_TESTO_SU_NODO () (cti2:esegui-comando "AG_TESTO_SU_NODO" 'cti20w:cmd-testo-su-nodo))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_TESTO_SU_POLILINEA () (cti2:esegui-comando "AG_TESTO_SU_POLILINEA" 'cti20w:cmd-testo-su-polilinea))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_TROVA_TAG () (cti2:esegui-comando "AG_TROVA_TAG" 'cti20x:cmd-trova-tag))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun c:AG_VERTICE_IMMAGINARIO_ARCO () (cti2:esegui-comando "AG_VERTICE_IMMAGINARIO_ARCO" 'cti20c:cmd-vertice-arco))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_VERTICI_ALLINEAMENTO () (cti2:esegui-comando "AG_VERTICI_ALLINEAMENTO" 'cti20w:cmd-vertici-allineamento))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun c:AG_VERTICI_SU_ALLINEAMENTO () (cti2:esegui-comando "AG_VERTICI_SU_ALLINEAMENTO" 'cti20w:cmd-vertici-su-allineamento))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:ESPORTA_VERTICI_CSV () (c:AG_ESPORTA_VERTICI_CSV))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:INTERSEZIONI () (c:AG_INTERSEZIONI))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:NUMERA_VERTICI () (c:AG_NUMERA_VERTICI))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:POLILINEE_APERTE () (c:AG_POLILINEE_APERTE))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:PREFISSO_SUFFISSO () (c:AG_PREFISSO_SUFFISSO))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:RIDUCI_VERTICI () (c:AG_RIDUCI_VERTICI))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:SPEZZAINCROCI () (c:AG_SPEZZAINCROCI))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun c:TABELLA_VERTICI () (c:AG_TABELLA_VERTICI))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:band-color (z zmin zmax bands / span idx)
  (setq span (- zmax zmin))
  (if (<= span 1e-12) 1
    (progn (setq idx (fix (* bands (/ (- z zmin) span)))) (if (>= idx bands) (setq idx (1- bands))) (1+ (rem idx 9)))))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:ceil-pos (x / n)
  (setq n (fix x)) (if (> x n) (1+ n) n))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-arco-segmenti (/ e typ o len step n i d pts p layer closed)
  (setq e (car (entsel "\nSeleziona ARCO o CERCHIO: ")))
  (if (and e (member (setq typ (cdr (assoc 0 (entget e)))) '("ARC" "CIRCLE")))
    (progn
      (setq step (getdist "\nLunghezza massima del segmento <1.0>: "))
      (if (not step) (setq step 1.0))
      (if (> step 0.0)
        (progn
          (setq o (vlax-ename->vla-object e) len (cti20w:curve-length o)
                n (max (if (= typ "CIRCLE") 8 1) (cti20c:ceil-pos (/ len step)))
                layer (cdr (assoc 8 (entget e))) closed (= typ "CIRCLE") pts nil i 0)
          (if closed
            (while (< i n)
              (setq d (* len (/ (float i) n)) p (vlax-curve-getPointAtDist o d) pts (append pts (list p)) i (1+ i)))
            (while (<= i n)
              (setq d (* len (/ (float i) n)) p (vlax-curve-getPointAtDist o d) pts (append pts (list p)) i (1+ i))))
          (cti20w:make-lwpoly pts layer closed)
          (princ (strcat "\nCreata polilinea segmentata con " (itoa n) " segmenti; originale preservato.")))
        (princ "\nLa lunghezza massima deve essere maggiore di zero."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-blocca-quota (/ ss e o m n r)
  (prompt "\nSeleziona quote da congelare come testo: ") (setq ss (ssget '((0 . "DIMENSION"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e) m (vl-catch-all-apply 'vla-get-Measurement (list o)))
    (if (numberp m)
      (progn (setq r (vl-catch-all-apply 'vla-put-TextOverride (list o (rtos m 2 (getvar "DIMDEC")))))
             (if (not (vl-catch-all-error-p r)) (setq n (1+ n))))))
  (princ (strcat "\nQuote congelate: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-calcola-testi (/ op k ss e v n new)
  (initget "Somma Sottrai Moltiplica Dividi")
  (setq op (getkword "\nOperazione [Somma/Sottrai/Moltiplica/Dividi] <Moltiplica>: "))
  (if (not op) (setq op "Moltiplica"))
  (setq k (getreal "\nValore: "))
  (cond
    ((not k) nil)
    ((and (= op "Dividi") (equal k 0.0 1e-12)) (princ "\nDivisione per zero non consentita."))
    (T
      (prompt "\nSeleziona TESTO/TESTOM numerici: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (if (setq v (cti20w:num-text e))
          (progn
            (setq new (cond ((= op "Somma") (+ v k)) ((= op "Sottrai") (- v k))
                            ((= op "Dividi") (/ v k)) (T (* v k))))
            (if (cti20w:text-set e (rtos new 2 6)) (setq n (1+ n))))))
      (princ (strcat "\nTesti numerici modificati: " (itoa n) "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20c:cmd-cancella-dentro () (cti2:cancella-classificati 'interno))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-inserisci-dwg-cartella (/ sample dir files base gap i file p n r)
  (setq sample (getfiled "Scegli un DWG della cartella da inserire" "" "dwg" 0))
  (if sample
    (progn
      (setq dir (vl-filename-directory sample) files (cti20c:list-dwg dir)
            base (cti2:punto-wcs (getpoint "\nPunto base del primo inserimento <0,0,0>: ")))
      (if (not base) (setq base '(0.0 0.0 0.0)))
      (setq gap (getdist "\nPasso X tra i DWG <1000>: ")) (if (not gap) (setq gap 1000.0))
      (setq i 0 n 0)
      (foreach file files
        (setq p (list (+ (car base) (* i gap)) (cadr base) (if (caddr base) (caddr base) 0.0))
              r (vl-catch-all-apply 'vla-InsertBlock
                    (list (cti20w:space) (vlax-3d-point p) (strcat dir "\\" file) 1.0 1.0 1.0 0.0)))
        (if (not (vl-catch-all-error-p r)) (setq n (1+ n)))
        (setq i (1+ i)))
      (princ (strcat "\nDWG inseriti: " (itoa n) " su " (itoa (length files)) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-layer-corrente (/ ss e o lay n)
  (setq lay (getvar "CLAYER")) (prompt "\nSeleziona oggetti da spostare sul layer corrente: ") (setq ss (ssget) n 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e))
    (if (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-put-Layer (list o lay)))) (setq n (1+ n))))
  (princ (strcat "\nOggetti spostati su " lay ": " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-layer-rapido (/ name color)
  (setq name (vl-string-trim " " (getstring T "\nNome nuovo layer: "))
        color (getint "\nColore ACI [1-255] <7>: "))
  (if (not color) (setq color 7))
  (if (or (< color 1) (> color 255)) (setq color 7))
  (if (/= name "")
    (progn (cti20w:ensure-layer name color) (cti2:setvar-finale "CLAYER" name) (princ (strcat "\nLayer corrente: " name "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20c:cmd-mantieni-dentro () (cti2:cancella-classificati 'esterno))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-normalizza-estrusione (/ ss affected e ed ep ans fixed skipped r)
  (setq ss (ssget "_X") affected nil)
  (foreach e (cti20w:ss-list ss)
    (setq ed (entget e) ep (assoc 210 ed))
    (if (and ep (not (cti20c:estrusione-standard-p (cdr ep)))) (setq affected (cons e affected))))
  (if affected
    (progn
      (princ (strcat "\nEntità con estrusione non standard: " (itoa (length affected)) "."))
      (princ "\nAttenzione: normalizzare DXF 210 può spostare alcune entità. UNDO ripristina l'operazione.")
      (initget "Si No") (setq ans (getkword "\nNormalizzare a (0,0,1)? [Si/No] <No>: "))
      (if (= ans "Si")
        (progn
          (setq fixed 0 skipped 0)
          (foreach e affected
            (setq ed (entget e) ep (assoc 210 ed)
                  r (vl-catch-all-apply 'entmod (list (subst (cons 210 '(0.0 0.0 1.0)) ep ed))))
            (if (vl-catch-all-error-p r) (setq skipped (1+ skipped))
              (progn (entupd e) (setq fixed (1+ fixed)))))
          (princ (strcat "\nEstrusione normalizzata su " (itoa fixed) " entità; non modificabili: " (itoa skipped) ".")))))
    (princ "\nNessuna estrusione non standard trovata."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-plotta-quote-csv (/ path f line sep vals x y z pts minz maxz ht bands p color legend rowh sw i lo hi y0)
  (setq path (getfiled "CSV/TXT quote X,Y,Z" "" "csv;txt" 0))
  (if path
    (progn
      (setq f (cti2:apri-file path "r") pts nil minz nil maxz nil)
      (if f
        (progn
          (while (setq line (read-line f))
            (if (> (strlen (vl-string-trim " \t" line)) 0)
              (progn
                (setq sep (cti20w:csv-sep line) vals (cti20w:csv-split line sep))
                (if (>= (length vals) 3)
                  (progn
                    (setq x (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 0 vals))) 2)
                          y (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 1 vals))) 2)
                          z (distof (vl-string-translate "," "." (vl-string-trim " \t" (nth 2 vals))) 2))
                    (if (and x y z)
                      (progn (setq p (list x y z) pts (cons p pts))
                             (if (or (null minz) (< z minz)) (setq minz z))
                             (if (or (null maxz) (> z maxz)) (setq maxz z)))))))))
          (cti2:chiudi-file f)
          (if pts
            (progn
              (setq bands (getint "\nNumero bande colore [1-9] <5>: ")) (if (not bands) (setq bands 5))
              (setq bands (max 1 (min 9 bands)) ht (getreal "\nAltezza testo quote <2.5>: ")) (if (not ht) (setq ht 2.5))
              (cti20w:ensure-layer "AG CAD Tools-QUOTE-CSV" 7)
              (foreach p (reverse pts)
                (setq color (cti20c:band-color (caddr p) minz maxz bands))
                (vla-put-Color (cti20w:add-text p (rtos (caddr p) 2 3) ht "AG CAD Tools-QUOTE-CSV") color))
              (setq legend (cti2:punto-wcs (getpoint "\nPunto inserimento legenda <Invio per saltare>: ")))
              (if legend
                (progn
                  (setq rowh (* ht 1.8) sw (* ht 3.0) i 0 y0 (cadr legend))
                  (while (< i bands)
                    (setq lo (+ minz (* (- maxz minz) (/ (float i) bands)))
                          hi (+ minz (* (- maxz minz) (/ (float (1+ i)) bands))) color (1+ (rem i 9))
                          p (list (car legend) (- y0 (* i rowh)) (if (caddr legend) (caddr legend) 0.0)))
                    (cti20c:swatch p sw color)
                    (cti20w:add-text (list (+ (car p) sw (* ht 0.5)) (- (cadr p) (* ht 0.35)) (caddr p))
                                     (strcat (rtos lo 2 2) " - " (rtos hi 2 2)) (* ht 0.85) "AG CAD Tools-QUOTE-CSV")
                    (setq i (1+ i)))))
              (princ (strcat "\nQuote importate: " (itoa (length pts)) ". Min=" (rtos minz 2 3) " Max=" (rtos maxz 2 3) ".")))
            (princ "\nNessuna riga X,Y,Z valida trovata.")))
        (princ "\nImpossibile aprire il file selezionato."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:cmd-scala-linee-centro (/ factor ss e o c n r)
  (setq factor (getreal "\nFattore scala linee (>0): "))
  (if (and factor (> factor 0.0))
    (progn
      (prompt "\nSeleziona LINEE da scalare rispetto al proprio punto medio: ")
      (setq ss (ssget '((0 . "LINE"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (setq o (vlax-ename->vla-object e) c (cti20w:bbox-center o)
              r (if c (vl-catch-all-apply 'vla-ScaleEntity (list o (vlax-3d-point c) factor)) nil))
        (if (and c (not (vl-catch-all-error-p r))) (setq n (1+ n))))
      (princ (strcat "\nLinee scalate: " (itoa n) "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20c:cmd-vertice-arco (/ e ed c a1 a2 r mid den inter)
  (setq e (car (entsel "\nSeleziona un ARCO: ")))
  (if (and e (= (cdr (assoc 0 (entget e))) "ARC"))
    (progn
      ; Le tangenti si intersecano nel piano OCS dell'arco.
      (setq ed (entget e) c (cdr (assoc 10 ed)) r (cdr (assoc 40 ed))
            a1 (cdr (assoc 50 ed)) a2 (cdr (assoc 51 ed))
            mid (/ (+ a1 a2) 2.0) den (cos (/ (- a2 a1) 2.0)))
      (if (> (abs den) 1e-10)
        (progn
          (setq inter (trans (cti2:polare-xy c mid (/ r den)) e 0))
          (cti20w:add-circle inter (max (* r 0.03) 0.01) "AG CAD Tools-VERTICI-IMMAGINARI")
          (princ (strcat "\nVertice immaginario: " (rtos (car inter) 2 4) ", "
                         (rtos (cadr inter) 2 4) ", " (rtos (caddr inter) 2 4) ".")))
        (princ "\nLe tangenti risultano parallele: vertice non determinabile."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20c:contorno-valido-p (b / pts)
  (and b (= (cdr (assoc 0 (entget b))) "LWPOLYLINE")
       (cti20w:lw-closed-p b) (not (cti20w:lw-has-bulge-p b))
       (setq pts (cti20w:lwverts b)) (>= (length pts) 3)
       (cti2:orizzontale-p pts) (> (abs (cti20w:poly-area2 pts)) 1e-8)
       (not (cti20w:self-intersect-p pts T))))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:estrusione-standard-p (v)
  (and v (< (abs (car v)) 1e-8) (< (abs (cadr v)) 1e-8) (< (abs (- (caddr v) 1.0)) 1e-8)))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:list-dwg (dir) (vl-sort (vl-directory-files dir "*.dwg" 1) '<))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20c:swatch (p len color / o)
  (setq o (cti20w:add-line p (list (+ (car p) len) (cadr p) (if (caddr p) (caddr p) 0.0)) "AG CAD Tools-QUOTE-CSV"))
  (vla-put-Color o color) o)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:add-circle (p r layer / o)
  (cti20w:ensure-layer layer 1)
  (setq o (vla-AddCircle (cti20w:space) (vlax-3d-point p) r))
  (vla-put-Layer o layer) o)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:add-line (p1 p2 layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddLine (cti20w:space) (vlax-3d-point p1) (vlax-3d-point p2)))
  (vla-put-Layer o layer) o)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:add-text (pt str ht layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddText (cti20w:space) str (vlax-3d-point pt) ht))
  (vla-put-Layer o layer) o)

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:add-text-color (pt str ht layer color / o)
  (setq o (cti20w:add-text pt str ht layer))
  (vla-put-Color o color)
  o)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:add-vertices-from-points (e points tol / pts p q d pairs new added)
  (if (or (cti20w:lw-has-bulge-p e) (not (= (cdr (assoc 0 (entget e))) "LWPOLYLINE"))) nil
    (progn
      (setq pts (cti20w:lwverts e) pairs nil added 0)
      (foreach p points
        (setq q (cti20w:closest e p))
        (if (and q (<= (distance p q) tol))
          (progn
            (setq d (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q)
                  pairs (cons (cons d q) pairs) added (1+ added)))))
      ; Ricostruzione conservativa: vertici originali + soli marker realmente vicini.
      (foreach p pts
        (setq d (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) p)
              pairs (cons (cons d p) pairs)))
      (setq pairs (vl-sort pairs '(lambda (a b) (< (car a) (car b))))
            new (mapcar 'cdr pairs))
      (if (> added 0) (cti20w:rebuild-lw-straight e new))
      added)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:ask-block-name (/ n)
  (setq n (getstring T "\nNome del blocco già definito nel disegno: "))
  (if (and n (/= n "") (tblsearch "BLOCK" n)) n (progn (princ "\nBlocco non trovato.") nil)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:assoc-add (key val alist / p) (if (setq p (assoc key alist)) (subst (cons key (+ val (cdr p))) p alist) (cons (cons key val) alist)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:bbox-center (e / o mn mx r a b)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-GetBoundingBox (list o 'mn 'mx)))
  (if (vl-catch-all-error-p r) nil
    (progn (setq a (vlax-safearray->list mn) b (vlax-safearray->list mx))
           (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:bulge-at (e i / o r)
  (setq o (vlax-ename->vla-object e)
        r (vl-catch-all-apply 'vla-GetBulge (list o i)))
  (if (vl-catch-all-error-p r) 0.0 r))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:closest (e p / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vlax-curve-getClosestPointTo (list o p)))
  (if (vl-catch-all-error-p r) nil r))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-3dface-stl (/ ss path f e ed a b c d n)
  (prompt "\nSeleziona 3DFACE da esportare: ")
  (setq ss (ssget '((0 . "3DFACE")))
        path (getfiled "Salva STL ASCII" "modello" "stl" 1))
  (if (and ss path)
    (progn
      (setq f (cti2:apri-file path "w"))
      (if f
        (progn
          (setq n 0)
          (write-line "solid AGCADTools" f)
          (foreach e (cti20w:ss-list ss)
            (setq ed (entget e) a (cdr (assoc 10 ed)) b (cdr (assoc 11 ed))
                  c (cdr (assoc 12 ed)) d (cdr (assoc 13 ed)))
            (cti20w:stl-facet f a b c)
            (setq n (1+ n))
            (if (and d (not (equal c d 1e-9)))
              (progn (cti20w:stl-facet f a c d) (setq n (1+ n)))))
          (write-line "endsolid AGCADTools" f)
          (cti2:chiudi-file f)
          (princ (strcat "\nTriangoli STL esportati: " (itoa n) ".")))
        (princ "\nImpossibile creare il file STL."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-aggiungi-vertici (/ ss n e pts new i a b k frac p closed segcount)
  (setq n (getint "\nNuovi vertici per segmento: "))
  (prompt "\nSeleziona LWPOLYLINE rettilinee: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if (and n (> n 0))
    (foreach e (cti20w:ss-list ss)
      (if (not (cti20w:lw-has-bulge-p e))
        (progn
          (setq pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e)
                new nil i 0 segcount (if closed (length pts) (1- (length pts))))
          (while (< i segcount)
            (setq a (nth i pts) b (nth (rem (1+ i) (length pts)) pts)
                  new (append new (list a)) k 1)
            (while (<= k n)
              (setq frac (/ (float k) (1+ n))
                    p (mapcar (function (lambda (x y) (+ x (* frac (- y x))))) a b)
                    new (append new (list p)) k (1+ k)))
            (setq i (1+ i)))
          (if (not closed) (setq new (append new (list (last pts)))))
          (cti20w:rebuild-lw-straight e new)))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-allinea-testo-rif (/ refs ss e o p near ang n)
  (prompt "\nSeleziona LINEE/POLILINEE di riferimento: ")
  (setq refs (cti20w:ss-list (ssget '((0 . "LINE,LWPOLYLINE,POLYLINE,ARC,SPLINE")))))
  (if refs
    (progn
      (prompt "\nSeleziona testi da orientare: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (setq o (vlax-ename->vla-object e) p (cti20w:inspt o) near (if p (cti20w:nearest-curve-data p refs) nil))
        (if near
          (progn
            (setq ang (cti20w:curve-angle-at (car near) (cadr near)))
            (if (vlax-property-available-p o 'Rotation T)
              (progn (vla-put-Rotation o ang) (setq n (1+ n)))))))
      (princ (strcat "\nTesti orientati alla geometria di riferimento più vicina: " (itoa n) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-angoli-polilinea (/ e pts i a b c v1 v2 ang p ht)
  (setq e (car (entsel "\nSeleziona polilinea: ")) ht (getreal "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5))
  (if e (progn (setq pts (cti20w:lwverts e) i 1) (while (< i (1- (length pts))) (setq a (nth (1- i) pts) b (nth i pts) c (nth (1+ i) pts) v1 (cti2:angolo-xy b a) v2 (cti2:angolo-xy b c) ang (* (abs (- v2 v1)) (/ 180.0 pi))) (if (> ang 180.0) (setq ang (- 360.0 ang))) (cti20w:add-text b (strcat (rtos ang 2 2) "°") ht "AG CAD Tools-ANGOLI") (setq i (1+ i))))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-area-multiunita (/ e o a f m2)
  (setq e (car (entsel "\nSeleziona una polilinea chiusa: ")))
  (if (and e (cti20w:lw-closed-p e)) (progn (setq o (vlax-ename->vla-object e) a (vla-get-Area o) f (cti20w:insunit-to-m (getvar "INSUNITS")))
    (princ (strcat "\nArea disegno: " (rtos a 2 4) " unita^2"))
    (if f (progn (setq m2 (* a f f)) (princ (strcat "\nArea: " (rtos m2 2 4) " m² | " (rtos (* m2 10.7639104167) 2 4) " ft² | " (rtos (/ m2 10000.0) 2 6) " ha."))) (princ "\nINSUNITS non consente una conversione affidabile in metri.")))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-aree-multiple (/ ss e o a total c ht n)
  (prompt "\nSeleziona polilinee chiuse: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) total 0.0 n 0 ht (getreal "\nAltezza etichetta <2.5>: ")) (if (not ht) (setq ht 2.5))
  (foreach e (cti20w:ss-list ss) (if (cti20w:lw-closed-p e) (progn (setq o (vlax-ename->vla-object e) a (vla-get-Area o) c (cti20w:poly-centroid (cti20w:lwverts e))) (cti20w:add-text c (strcat "A=" (rtos a 2 2)) ht "AG CAD Tools-AREE") (setq total (+ total a) n (1+ n)))))
  (princ (strcat "\nPoligoni: " (itoa n) "  Area totale: " (rtos total 2 3) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-arrotonda-testi (/ step ss e v q n)
  (setq step (getreal "\nPasso di arrotondamento <0.005>: "))
  (if (not step) (setq step 0.005))
  (if (> step 0.0)
    (progn
      (prompt "\nSeleziona testi numerici: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (if (setq v (cti20w:num-text e))
          (progn
            (setq q (cti20w:round-nearest v step))
            (cti20w:text-set e (rtos q 2 6))
            (setq n (1+ n)))))
      (princ (strcat "\nTesti arrotondati: " (itoa n) ".")))
    (princ "\nIl passo deve essere maggiore di zero."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-asse-bordi (/ e1 e2 n i l1 l2 p1 p2 pts o1 o2 s1 s2 e2p invert frac)
  (setq e1 (car (entsel "\nSeleziona primo bordo: "))
        e2 (car (entsel "\nSeleziona secondo bordo: "))
        n (getint "\nNumero campioni <50>: "))
  (if (not n) (setq n 50))
  (if (and e1 e2 (> n 1))
    (progn
      (setq l1 (cti20w:curve-length e1) l2 (cti20w:curve-length e2)
            o1 (vlax-ename->vla-object e1) o2 (vlax-ename->vla-object e2))
      (if (and l1 l2 (> l1 1e-9) (> l2 1e-9))
        (progn
          (setq s1 (vlax-curve-getStartPoint o1)
                s2 (vlax-curve-getStartPoint o2)
                e2p (vlax-curve-getEndPoint o2)
                invert (> (distance s1 s2) (distance s1 e2p))
                i 0 pts nil)
          (while (<= i n)
            (setq frac (/ (float i) n)
                  p1 (vlax-curve-getPointAtDist o1 (* l1 frac))
                  p2 (vlax-curve-getPointAtDist o2 (* l2 (if invert (- 1.0 frac) frac))))
            (if (and p1 p2)
              (setq pts (append pts (list (mapcar '(lambda (a b) (/ (+ a b) 2.0)) p1 p2)))))
            (setq i (1+ i)))
          (if (> (length pts) 1) (cti20w:make-lwpoly pts "AG CAD Tools-ASSE-MEDIO" nil))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-attributi-testo (/ ss e o arr a p h n)
  (prompt "\nSeleziona blocchi con attributi: ") (setq ss (ssget '((0 . "INSERT"))) h (getreal "\nAltezza testo <2.5>: ")) (if (not h) (setq h 2.5)) (setq n 0)
  (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (= :vlax-true (vla-get-HasAttributes o)) (foreach a (cti20w:in-lista (vla-GetAttributes o)) (setq p (cti20w:point-list (vla-get-InsertionPoint a))) (cti20w:add-text p (vla-get-TextString a) h "AG CAD Tools-ATTRIBUTI-TEXT") (setq n (1+ n)))))
  (princ (strcat "\nAttributi convertiti in testi: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-blocchi-mezzerie (/ name ss e o n i count p d1 d2)
  (setq name (cti20w:ask-block-name))
  (prompt "\nSeleziona polilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) n 0)
  (if name
    (foreach e (cti20w:ss-list ss)
      (setq o (vlax-ename->vla-object e) i 0 count (fix (vlax-curve-getEndParam o)))
      (while (< i count)
        (setq d1 (vlax-curve-getDistAtParam o i) d2 (vlax-curve-getDistAtParam o (1+ i))
              p (vlax-curve-getPointAtDist o (/ (+ d1 d2) 2.0)))
        (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))
        (setq i (1+ i)))))
  (princ (strcat "\nBlocchi inseriti: " (itoa n) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-blocchi-su-allineamento (/ e name step start len d p ang cnt)
  (setq e (car (entsel "\nSeleziona allineamento/curva: ")) name (cti20w:ask-block-name) step (getdist "\nPasso inserimento: ") start (getdist "\nProgressiva iniziale <0>: ")) (if (not start) (setq start 0.0))
  (if (and e name step (> step 0)) (progn (setq len (cti20w:curve-length e) d start cnt 0) (cti20w:ensure-layer "AG CAD Tools-BLOCCHI-ALLINEAMENTO" 3)
    (while (and len (<= d len)) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d) ang (cti20w:curve-angle-at e p)) (cti20w:insert-block name p 1.0 ang "AG CAD Tools-BLOCCHI-ALLINEAMENTO") (setq cnt (1+ cnt) d (+ d step))) (princ (strcat "\nBlocchi inseriti: " (itoa cnt) ".")))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-blocchi-testi (/ name ss e p n)
  (setq name (cti20w:ask-block-name)) (prompt "\nSeleziona testi: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (if name (foreach e (cti20w:ss-list ss) (if (setq p (cti20w:inspt e)) (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))))) (princ (strcat "\nBlocchi inseriti: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-blocchi-vertici (/ name ss e p n)
  (setq name (cti20w:ask-block-name)) (prompt "\nSeleziona polilinee: ") (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) n 0)
  (if name (foreach e (cti20w:ss-list ss) (foreach p (cti20w:lwverts e) (if (cti20w:insert-block name p 1.0 0.0 nil) (setq n (1+ n)))))) (princ (strcat "\nBlocchi inseriti: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-blocco-quota-testo (/ ss data e o p near q n)
  (prompt "\nSeleziona blocchi da elevare: ") (setq ss (ssget '((0 . "INSERT"))) data (cti20w:find-numeric-texts) n 0)
  (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e) p (cti20w:inspt o) near (if p (cti20w:nearest-num-text p data) nil)) (if near (progn (setq q (list (car p) (cadr p) (cadr near))) (vla-Move o (vlax-3d-point p) (vlax-3d-point q)) (setq n (1+ n)))))
  (princ (strcat "\nBlocchi elevati: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-cerca-testi (/ mode pat ss out e s)
  (initget "Inizia Finisce Contiene") (setq mode (getkword "\nCriterio [Inizia/Finisce/Contiene] <Contiene>: ")) (if (not mode) (setq mode "Contiene")) (setq pat (strcase (getstring T "\nTesto da cercare: ")) ss (ssget "_X" '((0 . "TEXT,MTEXT"))) out (ssadd))
  (foreach e (cti20w:ss-list ss) (setq s (strcase (cti20w:text-get e))) (if (cond ((= mode "Inizia") (= 0 (vl-string-search pat s))) ((= mode "Finisce") (and (>= (strlen s) (strlen pat)) (= pat (substr s (1+ (- (strlen s) (strlen pat))))))) (T (vl-string-search pat s))) (ssadd e out)))
  (if (> (sslength out) 0) (sssetfirst nil out)) (princ (strcat "\nTesti trovati: " (itoa (sslength out)) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-controllo-poligoni (/ ss e pts closed bad n)
  (prompt "\nSeleziona poligoni LWPOLYLINE: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) bad (ssadd) n 0)
  (foreach e (cti20w:ss-list ss) (setq pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e)) (if (or (not closed) (< (length pts) 3) (cti20w:self-intersect-p pts closed)) (progn (ssadd e bad) (setq n (1+ n)))))
  (if (> n 0) (sssetfirst nil bad)) (princ (strcat "\nPoligoni con anomalie semplici: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-copia-contenuto (/ src s ss e n)
  (setq src (car (entsel "\nSeleziona testo sorgente: ")))
  (if (and src (setq s (cti20w:text-get src))) (progn (prompt "\nSeleziona testi destinazione: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0) (foreach e (cti20w:ss-list ss) (if (/= e src) (if (cti20w:text-set e s) (setq n (1+ n))))) (princ (strcat "\nTesti aggiornati: " (itoa n) ".")))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-curva-segmenti (/ e step len d pts p layer)
  (setq e (car (entsel "\nSeleziona curva/polilinea da campionare: "))
        step (getdist "\nPasso segmentazione <1.0>: "))
  (if (not step) (setq step 1.0))
  (if (and e (> step 0.0))
    (progn
      (setq len (cti20w:curve-length e)
            d 0.0
            pts nil
            layer (cdr (assoc 8 (entget e))))
      (if len
        (progn
          (while (< d len)
            (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d))
            (if p (setq pts (append pts (list p))))
            (setq d (+ d step)))
          (setq p (vlax-curve-getEndPoint (vlax-ename->vla-object e)))
          (if p (setq pts (append pts (list p))))
          (if (> (length pts) 1)
            (cti20w:make-lwpoly pts layer nil))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-decimali-testo (/ ss dec e v n)
  (setq dec (getint "\nNumero di decimali [0-8] <2>: ")) (if (not dec) (setq dec 2)) (setq dec (max 0 (min 8 dec)))
  (prompt "\nSeleziona testi numerici: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (foreach e (cti20w:ss-list ss) (if (setq v (cti20w:num-text e)) (if (cti20w:text-set e (rtos v 2 dec)) (setq n (1+ n))))) (princ (strcat "\nTesti riformattati: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-dettagli-curve (/ e pts i b p1 p2 chord theta rad arc ins y ht count)
  (setq e (car (entsel "\nSeleziona LWPOLYLINE con tratti curvi: ")) ins (cti2:punto-wcs (getpoint "\nPunto per il rapporto: ")) ht 2.5)
  (if (and e (= (cdr (assoc 0 (entget e))) "LWPOLYLINE") ins)
    (progn
      (setq pts (cti20w:lwverts e) i 0 y 0.0
            count (if (cti20w:lw-closed-p e) (length pts) (1- (length pts))))
      (cti20w:add-text ins "CURVE ALLINEAMENTO" ht "AG CAD Tools-DETTAGLI-CURVE")
      (while (< i count)
        (setq b (cti20w:bulge-at e i))
        (if (> (abs b) 1e-10)
          (progn
            (setq p1 (nth i pts) p2 (nth (rem (1+ i) (length pts)) pts) chord (distance p1 p2))
            (if (> chord 1e-12)
              (progn
                (setq theta (* 4.0 (atan (abs b))) rad (/ chord (* 2.0 (sin (/ theta 2.0))))
                      arc (* rad theta) y (- y (* 1.6 ht)))
                (cti20w:add-text (list (car ins) (+ (cadr ins) y) (caddr ins))
                  (strcat "Curva " (itoa (1+ i)) "  R=" (rtos rad 2 3)
                          "  Ang=" (rtos (* theta (/ 180.0 pi)) 2 3) "°  L=" (rtos arc 2 3)) ht "AG CAD Tools-DETTAGLI-CURVE")))))
        (setq i (1+ i)))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-diff-testi (/ ss tol lst used i j a b pa pb va vb ht diff n)
  (setq tol (getdist "\nTolleranza posizione <0.01>: "))
  (if (not tol) (setq tol 0.01))
  (prompt "\nSeleziona testi numerici: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT"))) lst (cti20w:ss-list ss) used nil n 0 i 0)
  (while (< i (length lst))
    (setq a (nth i lst))
    (if (not (member a used))
      (progn
        (setq pa (cti20w:inspt a) va (cti20w:num-text a) j (1+ i))
        (while (< j (length lst))
          (setq b (nth j lst))
          (if (and (not (member b used)) pa va)
            (progn
              (setq pb (cti20w:inspt b) vb (cti20w:num-text b))
              (if (and pb vb (< (distance pa pb) tol))
                (progn
                  (setq diff (- vb va)
                        ht (cti20w:text-height-vla (vlax-ename->vla-object a)))
                  (cti20w:add-text-color (cti2:polare-xy pa 0.0 (* ht 1.2))
                                         (strcat "Δ=" (rtos diff 2 3)) ht
                                         "AG CAD Tools-DIFFERENZE-TESTO" (if (>= diff 0.0) 3 1))
                  (setq used (cons a (cons b used)) n (1+ n) j (length lst)))))
          (setq j (1+ j)))))
    (setq i (1+ i)))
  (princ (strcat "\nCoppie sovrapposte elaborate: " (itoa n) "."))
  (princ)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-distanza-su-polilinea (/ e p1 p2 q1 q2 d1 d2)
  (setq e (car (entsel "\nSeleziona la curva: ")))
  (if e (progn (setq p1 (cti2:punto-wcs (getpoint "\nPrimo punto sulla curva: ")) p2 (cti2:punto-wcs (getpoint "\nSecondo punto sulla curva: "))
                     q1 (cti20w:closest e p1) q2 (cti20w:closest e p2))
    (if (and q1 q2) (progn (setq d1 (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q1) d2 (vlax-curve-getDistAtPoint (vlax-ename->vla-object e) q2))
                           (princ (strcat "\nDistanza lungo curva: " (rtos (abs (- d2 d1)) 2 4) ".")))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-esporta-testi-xyz (/ ss path f e p s n)
  (prompt "\nSeleziona testi da esportare: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT")))
        path (getfiled "Salva testi XYZ" "testi_xyz" "csv" 1)
        n 0)
  (if (and ss path)
    (progn
      (setq f (cti2:apri-file path "w"))
      (if f
        (progn
          (write-line "Testo;X;Y;Z" f)
          (foreach e (cti20w:ss-list ss)
            (setq p (cti20w:inspt e) s (cti20w:text-get e))
            (if p
              (progn
                (write-line (strcat (cti20w:csv-quote s) ";" (rtos (car p) 2 4) ";"
                                    (rtos (cadr p) 2 4) ";"
                                    (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
                (setq n (1+ n)))))
          (cti2:chiudi-file f)
          (princ (strcat "\nTesti esportati: " (itoa n) ".")))
        (princ "\nImpossibile creare il file CSV."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-etichetta-z (/ ss ht e p n)
  (setq ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (prompt "\nSeleziona polilinee da etichettare con Z=: ")
  (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (foreach p (cti20w:lwverts e)
      (cti20w:add-text p (strcat "Z=" (rtos (if (caddr p) (caddr p) 0.0) 2 3)) ht "AG CAD Tools-Z-VERTICI")
      (setq n (1+ n))))
  (princ (strcat "\nEtichette Z create: " (itoa n) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-faccia3d-polilinea (/ e ed pts p4 layer)
  (setq e (car (entsel "\nSeleziona una 3DFACE: ")))
  (if (and e (= (cdr (assoc 0 (entget e))) "3DFACE")) (progn (setq ed (entget e) pts (list (cdr (assoc 10 ed)) (cdr (assoc 11 ed)) (cdr (assoc 12 ed))) p4 (cdr (assoc 13 ed))) (if (and p4 (not (equal p4 (nth 2 pts) 1e-9))) (setq pts (append pts (list p4)))) (setq layer (cdr (assoc 8 ed))) (cti20w:make-3dpoly pts layer T))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-griglia-coordinate (/ p1 p2 sx sy x y xmin xmax ymin ymax ht)
  (setq p1 (cti2:punto-wcs (getpoint "\nPrimo angolo della griglia: ")) p2 (cti2:punto-wcs (getcorner (cti2:punto-ucs p1) "\nAngolo opposto: ")) sx (getdist "\nPasso X: ") sy (getdist "\nPasso Y <uguale a X>: "))
  (if (not sy) (setq sy sx))
  (if (and p1 p2 sx sy (> sx 0) (> sy 0))
    (progn (cti20w:ensure-layer "AG CAD Tools-GRIGLIA" 8) (setq xmin (min (car p1) (car p2)) xmax (max (car p1) (car p2)) ymin (min (cadr p1) (cadr p2)) ymax (max (cadr p1) (cadr p2)) ht (* 0.25 (min sx sy)) x xmin)
      (while (<= x (+ xmax 1e-8)) (cti20w:add-line (list x ymin 0) (list x ymax 0) "AG CAD Tools-GRIGLIA") (cti20w:add-text (list x ymin 0) (rtos x 2 2) ht "AG CAD Tools-GRIGLIA") (setq x (+ x sx)))
      (setq y ymin) (while (<= y (+ ymax 1e-8)) (cti20w:add-line (list xmin y 0) (list xmax y 0) "AG CAD Tools-GRIGLIA") (cti20w:add-text (list xmin y 0) (rtos y 2 2) ht "AG CAD Tools-GRIGLIA") (setq y (+ y sy))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-importa-punti (/ path f line sep vals x y z lab ht n p sx sy sz)
  (setq path (getfiled "Seleziona CSV/TXT punti (X,Y,Z,Testo)" "" "csv;txt" 0)
        ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (if path
    (progn
      (setq f (cti2:apri-file path "r"))
      (if f
        (progn
          (cti20w:ensure-layer "AG CAD Tools-PUNTI-IMPORT" 7)
          (setq n 0)
          (while (setq line (read-line f))
            (setq sep (cti20w:csv-sep line) vals (cti20w:csv-split line sep))
            (if (>= (length vals) 2)
              (progn
                (setq sx (vl-string-translate "," "." (vl-string-trim " \t" (nth 0 vals)))
                      sy (vl-string-translate "," "." (vl-string-trim " \t" (nth 1 vals)))
                      sz (if (> (length vals) 2) (vl-string-translate "," "." (vl-string-trim " \t" (nth 2 vals))) "0")
                      x (distof sx 2) y (distof sy 2) z (distof sz 2)
                      lab (if (> (length vals) 3) (nth 3 vals) ""))
                (if (and x y)
                  (progn
                    (if (not z) (setq z 0.0))
                    (setq p (list x y z))
                    (cti2:crea-entita (list '(0 . "POINT") (cons 8 "AG CAD Tools-PUNTI-IMPORT") (cons 10 p)))
                    (if (/= lab "") (cti20w:add-text p lab ht "AG CAD Tools-PUNTI-IMPORT"))
                    (setq n (1+ n)))))))
          (cti2:chiudi-file f)
          (princ (strcat "\nPunti importati: " (itoa n) ".")))
        (princ "\nImpossibile aprire il file selezionato."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-interpola-quote-numero (/ d n)
  (if (setq d (cti20w:two-num-texts)) (progn (setq n (getint "\nNumero di quote intermedie: ")) (if (and n (> n 0)) (cti20w:interp-texts d n)))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-interpola-quote-passo (/ d step len va vb pa pb dist frac p v ht count)
  ; Inserisce le quote esattamente a step, 2*step, 3*step... lungo il segmento.
  (if (setq d (cti20w:two-num-texts))
    (progn
      (setq step (getdist "\nPasso fra le quote: ")
            len  (distance (nth 4 d) (nth 5 d)))
      (if (and step (> step 0.0) (> len step))
        (progn
          (setq va (nth 2 d) vb (nth 3 d)
                pa (nth 4 d) pb (nth 5 d)
                ht (getreal "\nAltezza testo <2.5>: "))
          (if (not ht) (setq ht 2.5))
          (setq dist step count 0)
          (while (< dist (- len 1e-8))
            (setq frac (/ dist len)
                  p (mapcar (function (lambda (a b) (+ a (* frac (- b a))))) pa pb)
                  v (+ va (* frac (- vb va))))
            (cti20w:add-text p (rtos v 2 3) ht "AG CAD Tools-QUOTE-INTERPOLATE")
            (setq count (1+ count) dist (+ dist step)))
          (princ (strcat "\nQuote intermedie create: " (itoa count) ".")))
        (princ "\nIl passo deve essere positivo e minore della distanza fra le due quote."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-interpola-z (/ e o z1 z2 ep total i d p z ht n)
  (setq e (car (entsel "\nSeleziona polilinea da interpolare: ")))
  (if e
    (progn
      (setq z1 (getreal "\nQuota nota al primo vertice: ")
            z2 (getreal "\nQuota nota all'ultimo vertice: "))
      (if (and z1 z2)
        (progn
          (setq o (vlax-ename->vla-object e)
                ep (vl-catch-all-apply 'vlax-curve-getEndParam (list o))
                ht (getreal "\nAltezza testo <2.5>: "))
          (if (not ht) (setq ht 2.5))
          (if (not (vl-catch-all-error-p ep))
            (progn
              (setq total (vl-catch-all-apply 'vlax-curve-getDistAtParam (list o ep)))
              (if (and (numberp total) (> total 1e-9))
                (progn
                  (setq i 0 n 0)
                  (while (<= i (fix ep))
                    (setq p (vlax-curve-getPointAtParam o i)
                          d (vlax-curve-getDistAtParam o i)
                          z (+ z1 (* (/ d total) (- z2 z1))))
                    (cti20w:add-text p (rtos z 2 3) ht "AG CAD Tools-Z-INTERPOLATE")
                    (setq n (1+ n) i (1+ i)))
                  (princ (strcat "\nQuote interpolate su " (itoa n)
                                 " vertici, proporzionalmente alla distanza reale lungo la polilinea.")))
                (princ "\nLa polilinea ha lunghezza nulla."))))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-intersezioni-layer (/ base ss e pts p ht lay)
  (setq base (car (entsel "\nSeleziona la polilinea base: "))) (prompt "\nSeleziona le curve da confrontare: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE"))) ht 2.5)
  (if (and base ss) (foreach e (cti20w:ss-list ss) (if (/= e base) (progn (setq pts (cti20w:intersections base e) lay (cdr (assoc 8 (entget e)))) (foreach p pts (cti20w:add-circle p 0.5 "AG CAD Tools-INTERSEZIONI-LAYER") (cti20w:add-text p lay ht "AG CAD Tools-INTERSEZIONI-LAYER")))))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-linea-pendenza (/ p1 p2 n mode len dx dy ux uy dz end)
  (setq p1 (cti2:punto-wcs (getpoint "\nPunto iniziale: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nDirezione/orizzontale di riferimento: ")) n (getreal "\nPendenza 1:N, inserisci N: "))
  (initget "Sale Scende") (setq mode (getkword "\nDirezione verticale [Sale/Scende] <Scende>: ")) (if (not mode) (setq mode "Scende"))
  (if (and p1 p2 n (> n 0)) (progn (setq len (distance p1 p2) dx (- (car p2) (car p1)) dy (- (cadr p2) (cadr p1)) dz (/ len n)) (if (= mode "Scende") (setq dz (- dz)))
    (setq end (list (car p2) (+ (cadr p2) dz) (if (caddr p2) (caddr p2) 0.0))) (cti20w:add-line p1 end "AG CAD Tools-PENDENZA"))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-lunghezze-layer (/ ss sums e l len p ht y x)
  (prompt "\nSeleziona curve da sommare: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,POLYLINE,SPLINE"))) sums nil)
  (foreach e (cti20w:ss-list ss) (setq l (cdr (assoc 8 (entget e))) len (cti20w:curve-length e)) (if len (setq sums (cti20w:assoc-add l len sums))))
  (if sums (progn (setq p (cti2:punto-wcs (getpoint "\nPunto per tabella testuale: ")) ht (getreal "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5)) (setq y 0.0)
    (foreach x (vl-sort sums '(lambda (a b) (< (strcase (car a)) (strcase (car b))))) (cti20w:add-text (list (car p) (- (cadr p) y) 0) (strcat (car x) " = " (rtos (cdr x) 2 3)) ht "AG CAD Tools-LUNGHEZZE-LAYER") (setq y (+ y (* ht 1.5)))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-minmax (/ b poly all e p v minv maxv mine maxe tab h r c x)
  (setq b (car (entsel "\nSeleziona contorno LWPOLYLINE chiuso e rettilineo: ")))
  (cond
    ((not b) nil)
    ((not (cti20w:lw-closed-p b)) (princ "\nIl contorno deve essere chiuso."))
    ((cti20w:lw-has-bulge-p b) (princ "\nIl contorno contiene archi: usa un contorno rettilineo per un test interno affidabile."))
    (T
     (setq poly (cti20w:lwverts b) tab (cti2:scheda-attiva)
           all (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab)))
           minv nil maxv nil)
     (foreach e (cti20w:ss-list all)
       (setq p (cti20w:inspt e) v (cti20w:num-text e))
       (if (and p v (cti20w:point-in-poly p poly))
         (progn
           (if (or (null minv) (< v minv)) (setq minv v mine e))
           (if (or (null maxv) (> v maxv)) (setq maxv v maxe e)))))
     (if minv
       (progn
         (sssetfirst nil (ssadd mine (ssadd maxe)))
         (foreach x (list (list mine 5) (list maxe 1))
           (setq e (car x) c (cadr x) p (cti20w:inspt e)
                 h (cti20w:text-height-vla (vlax-ename->vla-object e))
                 r (* 1.2 h))
           (cti20w:add-circle p r "AG CAD Tools-MINMAX")
           (vla-put-Color (vlax-ename->vla-object (entlast)) c))
         (princ (strcat "\nMin=" (rtos minv 2 4) "  Max=" (rtos maxv 2 4) ".")))
       (princ "\nNessun testo numerico nel contorno."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-mtext-testo (/ ss e o p s h rot layer new n skipped)
  (prompt "\nSeleziona MTEXT da convertire: ")
  (setq ss (ssget '((0 . "MTEXT"))) n 0 skipped 0)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e) p (cti20w:inspt o)
          s (cti20w:strip-mtext (vla-get-TextString o)))
    (if (and p s (/= s ""))
      (progn
        (setq h (cti20w:text-height-vla o) rot (vla-get-Rotation o) layer (vla-get-Layer o)
              new (cti20w:add-text p s h layer))
        (vla-put-StyleName new (vla-get-StyleName o))
        (vla-put-Rotation new rot)
        (vla-put-Color new (vla-get-Color o))
        (vla-Delete o)
        (setq n (1+ n)))
      (setq skipped (1+ skipped))))
  (princ (strcat "\nMTEXT convertiti: " (itoa n) "; originali conservati per contenuto non convertibile: " (itoa skipped) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-offset-doppio (/ ss dl dr e o r)
  (setq dl (getdist "\nDistanza lato sinistro: ") dr (getdist "\nDistanza lato destro: ")) (prompt "\nSeleziona le curve: ") (setq ss (ssget '((0 . "LINE,ARC,LWPOLYLINE,SPLINE"))))
  (if (and ss dl dr) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (> dl 0) (vl-catch-all-apply 'vla-Offset (list o dl))) (if (> dr 0) (vl-catch-all-apply 'vla-Offset (list o (- dr)))))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-offset-quota (/ ss dz e o n)
  (prompt "\nSeleziona gli oggetti da spostare in quota Z: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq dz (getreal "\nOffset Z (positivo o negativo): ")
            n 0)
      (if dz
        (progn
          (foreach e (cti20w:ss-list ss)
            (setq o (vlax-ename->vla-object e))
            (if (not (vl-catch-all-error-p (cti20w:move-z o dz)))
              (setq n (1+ n))))
          (princ (strcat "\nOggetti spostati in Z: " (itoa n) "."))))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-offset-z-vertici (/ ss dz e typ flags o n skipped)
  (setq dz (getreal "\nOffset Z (+ alza / - abbassa): "))
  (if dz
    (progn
      (prompt "\nSeleziona polilinee 3D o LWPOLYLINE: ")
      (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0 skipped 0)
      (foreach e (cti20w:ss-list ss)
        (setq typ (cdr (assoc 0 (entget e))) flags (cdr (assoc 70 (entget e))))
        (if (or (= typ "LWPOLYLINE") (and (= 8 (logand 8 flags)) (= 0 (logand 80 flags))))
          (progn
            (setq o (vlax-ename->vla-object e))
            (vla-Move o (vlax-3d-point '(0.0 0.0 0.0)) (vlax-3d-point (list 0.0 0.0 dz)))
            (setq n (1+ n)))
          (setq skipped (1+ skipped))))
      (princ (strcat "\nPolilinee spostate in Z mondiale: " (itoa n) "; escluse: " (itoa skipped) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-picchettamento-pilastri (/ ss path f idx e pts c p ht)
  (prompt "\nSeleziona polilinee chiuse dei pilastri/fondazioni: ")
  (setq ss (ssget '((0 . "LWPOLYLINE")))
        path (getfiled "Salva picchettamento" "picchettamento" "csv" 1)
        ht 2.0)
  (if (and ss path)
    (progn
      (setq f (cti2:apri-file path "w"))
      (if f
        (progn
          (setq idx 1)
          (write-line "N;X;Y;Z;Tipo" f)
          (foreach e (cti20w:ss-list ss)
            (if (cti20w:lw-closed-p e)
              (progn
                (setq pts (cti20w:lwverts e) c (cti20w:poly-centroid pts))
                (foreach p (append pts (list c))
                  (cti20w:add-text p (itoa idx) ht "AG CAD Tools-PICCHETTAMENTO")
                  (write-line (strcat (itoa idx) ";" (rtos (car p) 2 4) ";"
                                      (rtos (cadr p) 2 4) ";"
                                      (rtos (if (caddr p) (caddr p) 0.0) 2 4) ";"
                                      (if (equal p c 1e-8) "CENTRO" "VERTICE")) f)
                  (setq idx (1+ idx))))))
          (cti2:chiudi-file f)
          (princ (strcat "\nPunti esportati: " (itoa (1- idx)) ".")))
        (princ "\nImpossibile creare il file CSV."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-polilinea-da-testi (/ ss pts e)
  (prompt "\nSeleziona TESTO/TESTOM nell'ordine desiderato: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) pts nil)
  (foreach e (cti20w:ss-list ss) (if (cti20w:inspt e) (setq pts (append pts (list (cti20w:inspt e))))))
  (if (> (length pts) 1) (cti20w:make-lwpoly pts "AG CAD Tools-POLILINEA-TESTI" nil)) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-polilinee-corte (/ ss lim e len o n checked)
  (setq lim (getdist "\nLunghezza massima da considerare corta: "))
  (if lim
    (progn
      (prompt "\nSeleziona polilinee/linee da controllare: ")
      (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE,LINE"))) n 0 checked 0)
      (if ss
        (progn
          (cti20w:ensure-layer "AG CAD Tools-REVISIONE-CORTE" 1)
          (foreach e (cti20w:ss-list ss)
            (setq len (cti20w:curve-length e) checked (1+ checked))
            (if (and len (< len lim))
              (progn
                (setq o (vlax-ename->vla-object e))
                (if (not (vl-catch-all-error-p
                           (vl-catch-all-apply 'vla-put-Layer (list o "AG CAD Tools-REVISIONE-CORTE"))))
                  (setq n (1+ n))))))
          (princ (strcat "\nControllati " (itoa checked) " oggetti; " (itoa n)
                         " spostati sul layer AG CAD Tools-REVISIONE-CORTE.")))
        (princ "\nNessun oggetto selezionato."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-progressive (/ e step start len d p ang n p1 p2 ht)
  (setq e (car (entsel "\nSeleziona allineamento: ")) step (getdist "\nIntervallo progressive: ") start (getreal "\nProgressiva iniziale <0>: ") ht (getreal "\nAltezza testo <2.5>: "))
  (if (not start) (setq start 0.0)) (if (not ht) (setq ht 2.5))
  (if (and e step (> step 0)) (progn (setq len (cti20w:curve-length e) d 0.0)
    (while (and len (<= d len)) (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d) ang (cti20w:curve-angle-at e p) n (list (* -1.0 (sin ang)) (cos ang) 0.0) p1 (mapcar '(lambda (a b) (+ a (* b 2.0))) p n) p2 (mapcar '(lambda (a b) (- a (* b 2.0))) p n)) (cti20w:add-line p1 p2 "AG CAD Tools-PROGRESSIVE") (cti20w:add-text p1 (rtos (+ start d) 2 2) ht "AG CAD Tools-PROGRESSIVE") (setq d (+ d step))))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-punti-codificati-csv (/ lay ss path f i e p code)
  (setq lay (getstring T "\nLayer dei testi codificati <Code>: "))
  (if (= lay "") (setq lay "Code"))
  (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 8 lay) (cons 410 (cti2:scheda-attiva)))))
  (if ss
    (progn
      (setq path (getfiled "Salva elenco punti codificati" "punti_codificati" "csv" 1))
      (if path
        (progn
          (setq f (cti2:apri-file path "w"))
          (if f
            (progn
              (write-line "N;Codice;X;Y;Z" f)
              (setq i 1)
              (foreach e (cti20w:ss-list ss)
                (setq p (cti20w:inspt e)
                      code (cti20w:text-get e))
                (if p
                  (write-line
                    (strcat (itoa i) ";" (cti20w:csv-quote code) ";"
                            (rtos (car p) 2 4) ";"
                            (rtos (cadr p) 2 4) ";"
                            (rtos (if (caddr p) (caddr p) 0.0) 2 4))
                    f))
                (setq i (1+ i)))
              (cti2:chiudi-file f)
              (princ (strcat "\nEsportati " (itoa (1- i)) " punti in " path ".")))
            (princ "\nImpossibile creare il file CSV.")))))
    (princ "\nNessun testo trovato sul layer indicato."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-quota-intermedia (/ d p v ht)
  (if (setq d (cti20w:two-num-texts))
    (progn (setq p (mapcar '(lambda (a b) (/ (+ a b) 2.0)) (nth 4 d) (nth 5 d)) v (/ (+ (nth 2 d) (nth 3 d)) 2.0) ht (getreal "\nAltezza testo <2.5>: "))
           (if (not ht) (setq ht 2.5)) (cti20w:add-text p (rtos v 2 3) ht "AG CAD Tools-QUOTE-INTERPOLATE"))) (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-quota-segmenti (/ e o pts i a b p len ht closed segcount d1 d2)
  (setq e (car (entsel "\nSeleziona una polilinea: ")) ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (if (and e (> ht 0) (member (cdr (assoc 0 (entget e))) '("LWPOLYLINE" "POLYLINE")))
    (progn
      (setq o (vlax-ename->vla-object e) pts (cti20w:lwverts e) closed (cti20w:lw-closed-p e)
            i 0 segcount (if closed (length pts) (1- (length pts))))
      (while (< i segcount)
        (setq d1 (vlax-curve-getDistAtParam o i) d2 (vlax-curve-getDistAtParam o (1+ i))
              len (- d2 d1) p (vlax-curve-getPointAtDist o (/ (+ d1 d2) 2.0)))
        (cti20w:add-text p (rtos len 2 3) ht "AG CAD Tools-LUNGHEZZE-SEGMENTI")
        (setq i (1+ i)))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-quote-polilinea3d (/ ss ht e p n)
  (setq ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (prompt "\nSeleziona polilinee da cui leggere le quote Z: ")
  (setq ss (ssget '((0 . "POLYLINE,LWPOLYLINE"))) n 0)
  (foreach e (cti20w:ss-list ss)
    (foreach p (cti20w:lwverts e)
      (cti20w:add-text p (rtos (if (caddr p) (caddr p) 0.0) 2 3) ht "AG CAD Tools-QUOTE-3D")
      (setq n (1+ n))))
  (princ (strcat "\nEtichette quota create: " (itoa n) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-rettangolo3p (/ p1 p2 p3 vx vy len ux uy wx wy proj q3 q4)
  (setq p1 (cti2:punto-wcs (getpoint "\nPrimo punto: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nSecondo punto (lato base): ")) p3 (cti2:punto-wcs (getpoint (cti2:punto-ucs p2) "\nTerzo punto (definisce larghezza): ")))
  (if (and p1 p2 p3) (progn (setq vx (- (car p2) (car p1)) vy (- (cadr p2) (cadr p1)) len (sqrt (+ (* vx vx) (* vy vy))))
    (if (> len 1e-9) (progn (setq ux (/ vx len) uy (/ vy len) wx (- (car p3) (car p2)) wy (- (cadr p3) (cadr p2)) proj (- (* wx (- uy)) (* wy (- ux)))) ; signed projection on perpendicular
      (setq q3 (list (+ (car p2) (* (- uy) proj)) (+ (cadr p2) (* ux proj)) (if (caddr p1) (caddr p1) 0.0))
            q4 (list (+ (car p1) (* (- uy) proj)) (+ (cadr p1) (* ux proj)) (if (caddr p1) (caddr p1) 0.0)))
      (cti20w:make-lwpoly (list p1 p2 q3 q4) "AG CAD Tools-RETTANGOLI" T))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-ruota-blocchi (/ ss p1 p2 ang e o)
  (prompt "\nSeleziona blocchi da ruotare: ") (setq ss (ssget '((0 . "INSERT"))) p1 (cti2:punto-wcs (getpoint "\nPrimo punto direzione: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nSecondo punto direzione: ")))
  (if (and ss p1 p2) (progn (setq ang (cti2:angolo-xy p1 p2)) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (vlax-property-available-p o 'Rotation T) (vla-put-Rotation o ang))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-ruota-testo-layout (/ mode ss e o ang twist ref new n)
  (initget "Memorizza Applica")
  (setq mode (getkword "\nOperazione [Memorizza/Applica] <Memorizza>: "))
  (if (not mode) (setq mode "Memorizza"))
  (cond
    ((= mode "Memorizza")
     (prompt "\nSeleziona testi di cui memorizzare l'angolo di riferimento: ")
     (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
     (foreach e (cti20w:ss-list ss)
       (setq o (vlax-ename->vla-object e)
             ang (if (vlax-property-available-p o 'Rotation) (vla-get-Rotation o) 0.0))
       (if (cti20w:layout-set-ref e ang) (setq n (1+ n))))
     (princ (strcat "\nAngolo di riferimento memorizzato su " (itoa n) " testi.")))
    (T
     (setq twist (getreal "\nAngolo di rotazione viewport/layout in gradi <0>: "))
     (if (not twist) (setq twist 0.0))
     (setq twist (* twist (/ pi 180.0)))
     (prompt "\nSeleziona testi da copiare e compensare: ")
     (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
     (cti20w:ensure-layer "AG CAD Tools-TESTO-LAYOUT" 5)
     (foreach e (cti20w:ss-list ss)
       (setq o (vlax-ename->vla-object e)
             ref (cti20w:layout-get-ref e))
       (if (not ref) (setq ref (if (vlax-property-available-p o 'Rotation) (vla-get-Rotation o) 0.0)))
       (setq new (vl-catch-all-apply 'vla-Copy (list o)))
       (if (not (vl-catch-all-error-p new))
         (progn
           (if (vlax-property-available-p new 'Rotation T) (vla-put-Rotation new (- ref twist)))
           (if (vlax-property-available-p new 'Layer T) (vla-put-Layer new "AG CAD Tools-TESTO-LAYOUT"))
           (setq n (1+ n)))))
     (princ (strcat "\nCopie testo compensate per il layout: " (itoa n) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-ruota-testo2p (/ p1 p2) (setq p1 (cti2:punto-wcs (getpoint "\nPrimo punto direzione: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nSecondo punto direzione: "))) (if (and p1 p2) (cti20w:rotate-text-selection (cti2:angolo-xy p1 p2))) (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-scambia-testi (/ a b sa sb oa ob r rollback)
  (setq a (car (entsel "\nPrimo testo: ")) b (car (entsel "\nSecondo testo: ")))
  (if (and a b (not (eq a b)) (setq sa (cti20w:text-get a)) (setq sb (cti20w:text-get b)))
    (progn
      (setq oa (vlax-ename->vla-object a) ob (vlax-ename->vla-object b))
      (vla-put-TextString oa sb)
      (setq r (vl-catch-all-apply 'vla-put-TextString (list ob sa)))
      (if (vl-catch-all-error-p r)
        (progn
          (setq rollback (vl-catch-all-apply 'vla-put-TextString (list oa sa)))
          (if (vl-catch-all-error-p rollback)
            (princ "\nRipristino del primo testo non riuscito: usare UNDO."))
          (cti2:interrompi (strcat "Scambio non completato: " (vl-catch-all-error-message r)))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-taglia-allineamento (/ e len d1 d2 step pts layer)
  (setq e (car (entsel "\nSeleziona l'allineamento: ")))
  (if e (progn (setq len (cti20w:curve-length e) d1 (getreal "\nProgressiva iniziale: ") d2 (getreal "\nProgressiva finale: "))
    (if (and len d1 d2 (> d2 d1) (>= d1 0) (<= d2 len)) (progn (setq step (max (/ (- d2 d1) 100.0) 0.01) layer (cdr (assoc 8 (entget e))) pts (cti20w:sample-curve-range e d1 d2 step)) (cti20w:make-lwpoly pts layer nil) (princ "\nCreato nuovo tratto campionato; originale preservato."))))) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-testi-altezza (/ mn mx ss out e o h)
  (setq mn (getreal "\nAltezza minima: ") mx (getreal "\nAltezza massima: ") ss (ssget "_X" '((0 . "TEXT,MTEXT"))) out (ssadd))
  (if (and mn mx) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e) h (vl-catch-all-apply 'vlax-get (list o 'Height))) (if (and (numberp h) (>= h mn) (<= h mx)) (ssadd e out))))
  (if (> (sslength out) 0) (sssetfirst nil out)) (princ (strcat "\nTesti selezionati: " (itoa (sslength out)) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-testi-sovrapposti (/ ss tol lst i j a b pa pb bad n tab)
  (setq tol (getdist "\nTolleranza posizione <0.01>: "))
  (if (not tol) (setq tol 0.01))
  (prompt "\nSeleziona testi <Invio=tutti nella scheda corrente>: ")
  (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if (not ss)
    (progn (setq tab (cti2:scheda-attiva)) (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab))))))
  (setq lst (cti20w:ss-list ss) bad (ssadd) n 0 i 0)
  (while (< i (length lst))
    (setq j (1+ i) a (nth i lst) pa (cti20w:inspt a))
    (while (< j (length lst))
      (setq b (nth j lst) pb (cti20w:inspt b))
      (if (and pa pb (< (distance pa pb) tol))
        (progn (if (not (ssmemb a bad)) (ssadd a bad)) (if (not (ssmemb b bad)) (ssadd b bad))))
      (setq j (1+ j)))
    (setq i (1+ i)))
  (setq n (sslength bad))
  (if (> n 0) (sssetfirst nil bad))
  (princ (strcat "\nTesti sovrapposti/selezionati: " (itoa n) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-testo-quota-z (/ ss e o p v q n)
  (prompt "\nSeleziona testi numerici da portare alla propria quota: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
  (foreach e (cti20w:ss-list ss) (if (and (setq v (cti20w:num-text e)) (setq p (cti20w:inspt e))) (progn (setq o (vlax-ename->vla-object e) q (list (car p) (cadr p) v)) (vla-Move o (vlax-3d-point p) (vlax-3d-point q)) (setq n (1+ n)))))
  (princ (strcat "\nTesti elevati: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:cmd-testo-su-griglia (/ ss sx sy e o p q n)
  (setq sx (getdist "\nPasso griglia X: ") sy (getdist "\nPasso griglia Y <uguale a X>: "))
  (if (not sy) (setq sy sx))
  (if (and sx sy (> sx 0) (> sy 0))
    (progn
      (prompt "\nSeleziona TESTO/TESTOM da agganciare alla griglia: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))) n 0)
      (foreach e (cti20w:ss-list ss)
        (setq o (vlax-ename->vla-object e) p (cti20w:inspt o))
        (if p
          (progn
            (setq q (list (cti20w:round-nearest (car p) sx)
                          (cti20w:round-nearest (cadr p) sy) (caddr p)))
            (vla-Move o (vlax-3d-point p) (vlax-3d-point q))
            (setq n (1+ n)))))
      (princ (strcat "\nTesti agganciati alla griglia: " (itoa n) ".")))
    (princ "\nI passi della griglia devono essere positivi."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:cmd-testo-su-nodo (/ curves ss radius nodes te p q targets targetpts pair o moved flagged)
  (prompt "\nSeleziona linee/polilinee che definiscono i nodi: ")
  (setq curves (cti20w:ss-list (ssget '((0 . "LINE,LWPOLYLINE,POLYLINE")))))
  (if curves
    (progn
      (prompt "\nSeleziona testi da agganciare: ")
      (setq ss (ssget '((0 . "TEXT,MTEXT"))))
      (setq radius (getdist "\nRaggio massimo di ricerca <5.0>: "))
      (if (not radius) (setq radius 5.0))
      (setq nodes (cti20w:nodi-endpoints curves) targets nil targetpts nil)
      (foreach te (cti20w:ss-list ss)
        (setq p (cti20w:inspt te) q (if p (cti20w:nodo-nearest p nodes radius) nil))
        (setq targets (cons (list te q p) targets))
        (if q (setq targetpts (cons q targetpts))))
      (cti20w:ensure-layer "AG CAD Tools-NODI-AMBIGUI" 1)
      (setq moved 0 flagged 0)
      (foreach pair targets
        (setq te (car pair) q (cadr pair) p (caddr pair))
        (if q
          (if (> (cti20w:point-count q targetpts 1e-6) 1)
            (progn
              (setq o (vlax-ename->vla-object te))
              (if (vlax-property-available-p o 'Layer T) (vla-put-Layer o "AG CAD Tools-NODI-AMBIGUI"))
              (if (vlax-property-available-p o 'Color T) (vla-put-Color o 1))
              (setq flagged (1+ flagged)))
            (progn
              (setq o (vlax-ename->vla-object te))
              (vla-Move o (vlax-3d-point p) (vlax-3d-point q))
              (setq moved (1+ moved))))))
      (princ (strcat "\nTesti agganciati: " (itoa moved)
                     "; ambigui lasciati in posizione e segnalati: " (itoa flagged) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-testo-su-polilinea (/ e ss te o p q)
  (setq e (car (entsel "\nSeleziona polilinea di destinazione: "))) (prompt "\nSeleziona testi da spostare: ") (setq ss (ssget '((0 . "TEXT,MTEXT"))))
  (if (and e ss) (foreach te (cti20w:ss-list ss) (setq o (vlax-ename->vla-object te) p (cti20w:inspt o) q (cti20w:closest e p)) (if q (vla-Move o (vlax-3d-point p) (vlax-3d-point q))))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-vertici-allineamento (/ ss e pts i p ht)
  (prompt "\nSeleziona gli allineamenti: ") (setq ss (ssget '((0 . "LWPOLYLINE"))) ht (getreal "\nAltezza numero <2.5>: ")) (if (not ht) (setq ht 2.5))
  (foreach e (cti20w:ss-list ss) (setq pts (cti20w:lwverts e) i 1) (foreach p (if (> (length pts) 2) (cdr (reverse (cdr (reverse pts)))) nil) (cti20w:add-circle p (* ht 0.5) "AG CAD Tools-APICI") (cti20w:add-text p (itoa i) ht "AG CAD Tools-APICI") (setq i (1+ i)))) (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:cmd-vertici-su-allineamento (/ e lay tol ss pts x n)
  (setq e (car (entsel "\nSeleziona l'allineamento LWPOLYLINE rettilineo: "))
        lay (getstring T "\nLayer dei testi marker <Extra>: "))
  (if (= lay "") (setq lay "Extra"))
  (setq tol (getdist "\nDistanza massima marker-allineamento <1.0>: "))
  (if (not tol) (setq tol 1.0))
  (setq ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 8 lay) (cons 410 (cti2:scheda-attiva)))) pts nil)
  (foreach x (cti20w:ss-list ss)
    (if (cti20w:inspt x) (setq pts (cons (cti20w:inspt x) pts))))
  (if (and e pts (> tol 0.0))
    (progn
      (setq n (cti20w:add-vertices-from-points e pts tol))
      (cond
        ((null n) (princ "\nSono supportate solo LWPOLYLINE rettilinee senza archi."))
        ((= n 0) (princ "\nNessun marker entro la tolleranza indicata."))
        (T (princ (strcat "\nMarker trasformati in vertici: " (itoa n) "."))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:csv-quote (s)
  (strcat "\"" (cti20w:str-replace-all "\"\"" "\"" (if s s "")) "\""))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:csv-sep (s) (cti2c:separatore-csv s))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:csv-split (s sep / out fld i q c)
  (setq out nil fld "" i 1 q nil)
  (while (<= i (strlen s))
    (setq c (substr s i 1))
    (cond ((= c "\"")
           (if (and q (< i (strlen s)) (= (substr s (1+ i) 1) "\""))
             (progn (setq fld (strcat fld "\"")) (setq i (1+ i)))
             (setq q (not q))))
          ((and (not q) (= c sep)) (setq out (append out (list fld)) fld ""))
          (T (setq fld (strcat fld c))))
    (setq i (1+ i)))
  (append out (list fld)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:curve-angle-at (e p / o q par der)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        q (cti20w:closest o p))
  (if q
    (progn
      (setq par (vl-catch-all-apply 'vlax-curve-getParamAtPoint (list o q)))
      (if (vl-catch-all-error-p par) 0.0
        (progn (setq der (vl-catch-all-apply 'vlax-curve-getFirstDeriv (list o par)))
               (if (vl-catch-all-error-p der) 0.0 (cti2:angolo-xy '(0.0 0.0 0.0) der)))))
    0.0))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:curve-length (e / o ep r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        ep (vl-catch-all-apply 'vlax-curve-getEndParam (list o)))
  (if (vl-catch-all-error-p ep) nil
    (progn (setq r (vl-catch-all-apply 'vlax-curve-getDistAtParam (list o ep)))
           (if (vl-catch-all-error-p r) nil r))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:doc () (vla-get-ActiveDocument (vlax-get-acad-object)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:ensure-layer (name color /)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord") '(100 . "AcDbLayerTableRecord")
                   (cons 2 name) '(70 . 0) (cons 62 color) '(6 . "Continuous"))))
  name)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:find-numeric-texts (/ ss out e v tab)
  ; Cerca soltanto nello spazio/layout corrente, evitando riferimenti incrociati fra schede.
  (setq tab (cti2:scheda-attiva)
        ss (ssget "_X" (list '(0 . "TEXT,MTEXT") (cons 410 tab)))
        out nil)
  (foreach e (cti20w:ss-list ss)
    (if (setq v (cti20w:num-text e))
      (setq out (cons (list e v (cti20w:inspt e)) out))))
  out)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:in-lista (v / r)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond ((listp v) v)
        (T (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
           (if (vl-catch-all-error-p r) nil r))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:insert-block (name pt scale rot layer / o)
  (if (tblsearch "BLOCK" name)
    (progn
      (setq o (vla-InsertBlock (cti20w:space) (vlax-3d-point pt) name scale scale scale rot))
      (if layer (vla-put-Layer o layer)) o)
    nil))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:inspt (e / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vlax-get (list o 'InsertionPoint)))
  (if (vl-catch-all-error-p r) nil (cti20w:point-list r)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:insunit-to-m (u)
  (cond ((= u 1) 0.0254) ((= u 2) 0.3048) ((= u 4) 0.001) ((= u 5) 0.01) ((= u 6) 1.0) ((= u 7) 1000.0) (T nil)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:interp-texts (data n / va vb pa pb i frac p v ht)
  (setq va (nth 2 data) vb (nth 3 data) pa (nth 4 data) pb (nth 5 data) ht (getreal "\nAltezza testo <2.5>: "))
  (if (not ht) (setq ht 2.5))
  (setq i 1)
  (while (<= i n)
    (setq frac (/ (float i) (1+ n)) p (mapcar (function (lambda (a b) (+ a (* frac (- b a))))) pa pb) v (+ va (* frac (- vb va))))
    (cti20w:add-text p (rtos v 2 3) ht "AG CAD Tools-QUOTE-INTERPOLATE") (setq i (1+ i))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:intersections (e1 e2 / r vals out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list (vlax-ename->vla-object e1) 'IntersectWith (vlax-ename->vla-object e2) 0)))
  (if (vl-catch-all-error-p r) nil (progn (setq vals (cti20w:in-lista r) out nil) (while (and vals (>= (length vals) 3)) (setq out (cons (list (car vals) (cadr vals) (caddr vals)) out) vals (cdddr vals))) (reverse out))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:join (lst sep / out x)
  (setq out "")
  (foreach x lst
    (setq out (strcat out (if (= out "") "" sep) x)))
  out)

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:layout-app () "CTI20W-TESTO-LAYOUT")

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:layout-ensure-app (/ a) (setq a (cti20w:layout-app)) (if (not (tblsearch "APPID" a)) (regapp a)) a)

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:layout-get-ref (e / ed xd rec)
  (setq ed (entget e (list (cti20w:layout-app))) xd (assoc -3 ed))
  (if xd
    (progn (setq rec (assoc (cti20w:layout-app) (cdr xd)))
           (if rec (cdr (assoc 1040 (cdr rec))) nil))
    nil))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:layout-set-ref (e ang / ed xd newxd)
  (cti20w:layout-ensure-app)
  (setq ed (entget e (list (cti20w:layout-app)))
        xd (assoc -3 ed)
        newxd (list -3 (list (cti20w:layout-app) (cons 1040 ang))))
  (entmod (if xd (subst newxd xd ed) (append ed (list newxd)))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:lw-closed-p (e / ed) (setq ed (entget e)) (= 1 (logand 1 (if (assoc 70 ed) (cdr (assoc 70 ed)) 0))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:lw-has-bulge-p (e / x yes) (setq yes nil) (foreach x (entget e) (if (and (= (car x) 42) (> (abs (cdr x)) 1e-10)) (setq yes T))) yes)

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:lwverts (e / ed typ flags z out x v vd p)
  (setq ed (entget e) typ (cdr (assoc 0 ed)) out nil)
  (cond
    ((= typ "LWPOLYLINE")
     (setq z (if (assoc 38 ed) (cdr (assoc 38 ed)) 0.0))
     (foreach x ed
       (if (= (car x) 10)
         (setq out (cons (trans (list (cadr x) (caddr x) z) e 0) out))))
     (reverse out))
    ((= typ "POLYLINE")
     (setq flags (cdr (assoc 70 ed)))
     (if (= 0 (logand flags 80))
       (progn
         (setq v (entnext e) z (caddr (cdr (assoc 10 ed))))
         (if (not z) (setq z 0.0))
         (while (and v (= (cdr (assoc 0 (entget v))) "VERTEX"))
           (setq vd (entget v) p (cdr (assoc 10 vd)))
           (if (= 0 (logand 8 flags))
             (setq p (trans (list (car p) (cadr p) z) e 0)))
           (setq out (cons p out) v (entnext v)))
         (reverse out))
       nil))
    (T nil)))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:make-3dpoly (pts layer closed / flat arr obj)
  (if (> (length pts) 1)
    (progn
      (cti20w:ensure-layer layer 7)
      (setq flat (apply 'append pts)
            arr (vlax-make-safearray vlax-vbDouble (cons 0 (1- (length flat)))))
      (vlax-safearray-fill arr flat)
      (setq obj (vla-Add3DPoly (cti20w:space) arr))
      (vla-put-Layer obj layer)
      (vla-put-Closed obj (if closed :vlax-true :vlax-false))
      (vlax-vla-object->ename obj))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:make-lwpoly (pts layer closed / data p z samez)
  (cti20w:ensure-layer layer 7)
  (setq z (if (and pts (caddr (car pts))) (caddr (car pts)) 0.0) samez T)
  (foreach p pts
    (if (> (abs (- (if (caddr p) (caddr p) 0.0) z)) 1e-9) (setq samez nil)))
  (if (not samez)
    (cti20w:make-3dpoly pts layer closed)
    (progn
      (setq data (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") (cons 8 layer)
                       '(100 . "AcDbPolyline") (cons 90 (length pts))
                       (cons 70 (if closed 1 0)) (cons 38 z)))
      (foreach p pts
        (setq data (append data (list (cons 10 (list (car p) (cadr p)))))))
      (cti2:crea-entita data))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:move-z (o dz / p1 p2)
  (setq p1 (vlax-3d-point '(0.0 0.0 0.0)) p2 (vlax-3d-point (list 0.0 0.0 dz)))
  (vl-catch-all-apply 'vla-Move (list o p1 p2)))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:nearest-curve-data (p refs / e q d best bestd)
  (setq best nil bestd nil)
  (foreach e refs
    (setq q (cti20w:closest e p))
    (if q
      (progn
        (setq d (distance p q))
        (if (or (null bestd) (< d bestd)) (setq best (list e q) bestd d)))))
  best)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:nearest-num-text (pt data / best bd d x)
  (setq best nil bd nil)
  (foreach x data
    (if (caddr x)
      (progn (setq d (distance pt (caddr x))) (if (or (null bd) (< d bd)) (setq bd d best x))))) best)

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:nodi-endpoints (curves / out e o)
  (setq out nil)
  (foreach e curves
    (setq o (vlax-ename->vla-object e))
    (setq out (cons (vlax-curve-getStartPoint o) out))
    (setq out (cons (vlax-curve-getEndPoint o) out)))
  out)

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:nodo-nearest (p nodes radius / q d best bestd)
  (setq best nil bestd nil)
  (foreach q nodes
    (setq d (distance p q))
    (if (and (<= d radius) (or (null bestd) (< d bestd))) (setq best q bestd d)))
  best)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:num-text (e / s n)
  (setq s (cti20w:text-get e))
  (if (and s (/= (vl-string-trim " \t" s) ""))
    (progn (setq n (distof (vl-string-translate "," "." (vl-string-trim " \t" s)) 2)) n)
    nil))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:point-count (p lst tol / n q)
  (setq n 0)
  (foreach q lst (if (equal p q tol) (setq n (1+ n)))) n)

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:point-in-poly (pt poly / x y inside i j vi vj xi yi xj yj)
  (setq x (car pt) y (cadr pt) inside nil i 0 j (1- (length poly)))
  (while (< i (length poly))
    (setq vi (nth i poly) vj (nth j poly) xi (car vi) yi (cadr vi) xj (car vj) yj (cadr vj))
    (if (and (not (eq (> yi y) (> yj y)))
             (< x (+ xi (* (/ (- y yi) (- yj yi)) (- xj xi)))))
      (setq inside (not inside)))
    (setq j i i (1+ i)))
  inside)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:point-list (v / r)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond ((listp v) v)
        (T (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
           (if (vl-catch-all-error-p r) nil r))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:poly-area2 (pts / a i n p q)
  (setq a 0.0 n (length pts) i 0)
  (while (< i n)
    (setq p (nth i pts) q (nth (rem (1+ i) n) pts)
          a (+ a (- (* (car p) (cadr q)) (* (car q) (cadr p)))) i (1+ i)))
  (/ a 2.0))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:poly-centroid (pts / a cx cy i n p q cross z)
  (setq n (length pts))
  (if (< n 3) (cti2:interrompi "Servono almeno tre vertici per calcolare il centro."))
  (if (not (cti2:orizzontale-p pts))
    (cti2:interrompi "Il calcolo planimetrico richiede un contorno orizzontale; originale conservato."))
  (setq a (cti20w:poly-area2 pts) z (caddr (car pts)) cx 0.0 cy 0.0 i 0)
  (if (< (abs a) 1e-12)
    (list (/ (apply '+ (mapcar 'car pts)) n) (/ (apply '+ (mapcar 'cadr pts)) n) z)
    (progn
      (while (< i n)
        (setq p (nth i pts) q (nth (rem (1+ i) n) pts)
              cross (- (* (car p) (cadr q)) (* (car q) (cadr p)))
              cx (+ cx (* (+ (car p) (car q)) cross))
              cy (+ cy (* (+ (cadr p) (cadr q)) cross)) i (1+ i)))
      (list (/ cx (* 6.0 a)) (/ cy (* 6.0 a)) z))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:rebuild-lw-straight (e pts / o arr flat p ed)
  (setq ed (entget e))
  (if (or (/= (cdr (assoc 0 ed)) "LWPOLYLINE") (cti20w:lw-has-bulge-p e))
    (cti2:interrompi "La ricostruzione richiede una LWPOLYLINE rettilinea."))
  ; Le larghezze per vertice non possono essere ridistribuite implicitamente.
  (foreach p ed
    (if (and (member (car p) '(40 41)) (/= (cdr p) 0.0))
      (cti2:interrompi "Polilinea con larghezze variabili: originale conservato.")))
  (setq flat nil)
  (foreach p pts
    (setq p (trans p 0 e) flat (append flat (list (car p) (cadr p)))))
  (if (> (length flat) 3)
    (progn
      (setq arr (vlax-make-safearray vlax-vbDouble (cons 0 (1- (length flat)))))
      (vlax-safearray-fill arr flat)
      (setq o (vlax-ename->vla-object e))
      (vla-put-Coordinates o arr)
      o)))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:rotate-text-selection (ang / ss e o)
  (prompt "\nSeleziona testi da ruotare: ") (setq ss (ssget '((0 . "TEXT,MTEXT")))) (foreach e (cti20w:ss-list ss) (setq o (vlax-ename->vla-object e)) (if (vlax-property-available-p o 'Rotation T) (vla-put-Rotation o ang))))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:round-nearest (v step / q)
  (setq q (/ v step))
  (* step (fix (+ q (if (minusp q) -0.5 0.5)))))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:sample-curve-range (e d1 d2 step / out d p)
  (setq out nil d d1)
  (while (< d d2) (if (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d)) (setq out (append out (list p)))) (setq d (+ d step)))
  (if (setq p (vlax-curve-getPointAtDist (vlax-ename->vla-object e) d2)) (setq out (append out (list p)))) out)

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:self-intersect-p (pts closed / segs i j n found a b)
  (setq segs (cti2:bordi pts) found nil i 0)
  (if (not closed) (setq segs (reverse (cdr (reverse segs)))))
  (setq n (length segs))
  (while (< i n)
    (setq a (nth i segs) j (+ i 2))
    (if (equal (car a) (cadr a) 1e-8) (setq found T))
    (while (< j n)
      (if (not (and closed (= i 0) (= j (1- n))))
        (progn
          (setq b (nth j segs))
          (if (cti2:segmenti-toccano-p (car a) (cadr a) (car b) (cadr b)) (setq found T))))
      (setq j (1+ j)))
    (setq i (1+ i)))
  found)

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:space (/ d) (setq d (cti20w:doc)) (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace d) (vla-get-ModelSpace d)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:ss-list (ss / out i)
  (setq out nil i 0)
  (if ss (repeat (sslength ss) (setq out (cons (ssname ss i) out) i (1+ i))))
  (reverse out))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:stl-facet (f a b c / n p)
  (setq n (cti20w:stl-normal a b c)) (write-line (strcat "  facet normal " (cti2:rtos-stabile (car n) 8) " " (cti2:rtos-stabile (cadr n) 8) " " (cti2:rtos-stabile (caddr n) 8)) f) (write-line "    outer loop" f)
  (foreach p (list a b c) (write-line (strcat "      vertex " (cti2:rtos-stabile (car p) 8) " " (cti2:rtos-stabile (cadr p) 8) " " (cti2:rtos-stabile (caddr p) 8)) f)) (write-line "    endloop" f) (write-line "  endfacet" f))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:stl-normal (a b c / u v nx ny nz l)
  (setq u (mapcar '- b a) v (mapcar '- c a) nx (- (* (cadr u) (caddr v)) (* (caddr u) (cadr v))) ny (- (* (caddr u) (car v)) (* (car u) (caddr v))) nz (- (* (car u) (cadr v)) (* (cadr u) (car v))) l (sqrt (+ (* nx nx) (* ny ny) (* nz nz))))
  (if (> l 1e-12) (list (/ nx l) (/ ny l) (/ nz l)) '(0.0 0.0 0.0)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:str-replace-all (new old s / pos start out)
  (setq s (if s s "") start 0 out "")
  (while (setq pos (vl-string-search old s start))
    (setq out (strcat out (substr s (1+ start) (- pos start)) new)
          start (+ pos (strlen old))))
  (strcat out (substr s (1+ start))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20w:strip-mtext (s / i n ch nxt out valido)
  ; Non appiattisce campi, frazioni impilate o formati sconosciuti.
  (setq i 1 n (strlen s) out "" valido (not (vl-string-search "%<" s)))
  (while (and valido (<= i n))
    (setq ch (substr s i 1))
    (cond
      ((member ch '("{" "}")) nil)
      ((= ch "\\")
       (setq i (1+ i) nxt (substr s i 1))
       (cond
         ((member nxt '("P" "~")) (setq out (strcat out " ")))
         ((member nxt '("\\" "{" "}")) (setq out (strcat out nxt)))
         ((member nxt '("L" "l" "O" "o" "K" "k")) nil)
         ((member nxt '("A" "C" "c" "F" "f" "H" "Q" "T" "W"))
          (while (and (<= i n) (/= (substr s i 1) ";")) (setq i (1+ i)))
          (if (> i n) (setq valido nil)))
         (T (setq valido nil))))
      (T (setq out (strcat out ch))))
    (setq i (1+ i)))
  (if valido out nil))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:text-get (e / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-get-TextString (list o)))
  (if (vl-catch-all-error-p r) nil r))

; Origine AG CAD Tools: cti_web_phase2b_2_0.lsp
(defun cti20w:text-height-vla (o / h)
  (setq h (vl-catch-all-apply 'vla-get-TextHeight (list o)))
  (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0))
    (progn
      (setq h (vl-catch-all-apply 'vla-get-Height (list o)))
      (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0))
        (setq h (getvar "TEXTSIZE")))))
  (if (and (numberp h) (> h 0.0)) h 2.5))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:text-set (e s / o r)
  (setq o (if (= (type e) 'ENAME) (vlax-ename->vla-object e) e)
        r (vl-catch-all-apply 'vla-put-TextString (list o s)))
  (not (vl-catch-all-error-p r)))

; Origine AG CAD Tools: cti_web_phase2a_2_0.lsp
(defun cti20w:two-num-texts (/ a b va vb pa pb)
  (setq a (car (entsel "\nSeleziona la prima quota testuale: ")) b (car (entsel "\nSeleziona la seconda quota testuale: ")))
  (if (and a b (setq va (cti20w:num-text a)) (setq vb (cti20w:num-text b)) (setq pa (cti20w:inspt a)) (setq pb (cti20w:inspt b)))
    (list a b va vb pa pb) nil))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:block-attrs (obj / out a)
  (setq out nil)
  (if (= :vlax-true (vla-get-HasAttributes obj))
    (foreach a (cti20w:in-lista (vlax-invoke obj 'GetAttributes))
      (setq out (cons (cons (strcase (vla-get-TagString a)) (vla-get-TextString a)) out))))
  (reverse out))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-aggiorna-cartiglio (/ op src dst n)
  (initget "Copia Incolla Pulisci")
  (setq op (getkword "\nOperazione cartiglio [Copia/Incolla/Pulisci] <Copia>: ")) (if (not op) (setq op "Copia"))
  (cond
    ((= op "Copia")
     (if (setq src (cti20x:select-block-ref "\nSeleziona il cartiglio sorgente: "))
       (progn (setq *CTI20X-CARTIGLIO-ATTRIBUTI* (cti20x:block-attrs src))
              (princ (strcat "\nAttributi copiati in memoria: " (itoa (length *CTI20X-CARTIGLIO-ATTRIBUTI*)) ".")))
       (princ "\nSelezione non valida.")))
    ((= op "Incolla")
     (if *CTI20X-CARTIGLIO-ATTRIBUTI*
       (if (setq dst (cti20x:select-block-ref "\nSeleziona il cartiglio destinazione: "))
         (progn (setq n (cti20x:set-block-attrs dst *CTI20X-CARTIGLIO-ATTRIBUTI*)) (princ (strcat "\nAttributi aggiornati: " (itoa n) ".")))
         (princ "\nSelezione non valida."))
       (princ "\nNessun cartiglio è stato copiato in memoria.")))
    ((= op "Pulisci") (setq *CTI20X-CARTIGLIO-ATTRIBUTI* nil) (princ "\nMemoria cartiglio svuotata.")))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-copia-poligoni-chiusi (/ tab ss e o cp n layer)
  (setq tab (cti2:scheda-attiva) layer "AG CAD Tools-POLIGONI-COPIATI" n 0
        ss (ssget "_X" (list '(0 . "LWPOLYLINE") '(-4 . "&") '(70 . 1) (cons 410 tab))))
  (cti20w:ensure-layer layer 5)
  (foreach e (cti20w:ss-list ss)
    (setq o (vlax-ename->vla-object e) cp (vl-catch-all-apply 'vla-Copy (list o)))
    (if (not (vl-catch-all-error-p cp)) (progn (vla-put-Layer cp layer) (setq n (1+ n)))))
  (princ (strcat "\nPoligoni chiusi copiati sul layer " layer ": " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-dettagli-lotto (/ e pts p1 p2 p3 p4 center area ht off ang)
  (setq e (car (entsel "\nSeleziona un lotto rettangolare chiuso: ")))
  (if (setq pts (cti20x:rect-verts e))
    (progn
      (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
            center (cti20x:mid p1 p3) area (vla-get-Area (vlax-ename->vla-object e))
            ht (cti20x:text-height) off (* ht 1.5) ang (cti2:angolo-xy p1 p2))
      (if (and (> ang (/ pi 2.0)) (<= ang (* pi 1.5))) (setq ang (- ang pi)))
      (cti20x:make-centered-text center (strcat "Area: " (rtos area 2 2)) ht ang "AG CAD Tools-DETTAGLI-LOTTO")
      (cti20x:dim-side p1 p2 center off) (cti20x:dim-side p2 p3 center off)
      (cti20x:dim-side p3 p4 center off) (cti20x:dim-side p4 p1 center off)
      (princ "\nArea e quote del lotto create."))
    (princ "\nServe una LWPOLYLINE rettangolare chiusa con quattro vertici."))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20x:cmd-dividi-lunghezze (/ e o maxd cur d p n)
  (setq e (car (entsel "\nSeleziona arco o curva da dividere: ")) n 0)
  (if e
    (progn
      (setq o (vlax-ename->vla-object e) maxd (cti20w:curve-length o) cur 0.0)
      (if maxd
        (progn
          (princ (strcat "\nLunghezza totale: " (rtos maxd 2 3) "."))
          (while (setq d (getreal "\nLunghezza segmento successivo; Invio termina: "))
            (cond
              ((<= d 0.0) (princ "\nLa lunghezza deve essere positiva."))
              ((> (+ cur d) (+ maxd 1e-8)) (princ "\nIl segmento supera la lunghezza residua."))
              (T
               (setq cur (min maxd (+ cur d)) p (vlax-curve-getPointAtDist o cur))
               (if p
                 (progn
                   (cti2:crea-entita (list '(0 . "POINT") (cons 10 p)))
                   (setq n (1+ n)))))))))))
  (princ (strcat "\nPunti di divisione creati: " (itoa n) "."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-esporta-dati-lotti (/ ss pols texts e typ p val path f pts area cen label tdata titem n)
  (prompt "\nSeleziona poligoni chiusi e testi identificativi dei lotti: ")
  (setq ss (ssget '((0 . "LWPOLYLINE,TEXT,MTEXT"))) pols nil texts nil n 0)
  (foreach e (cti20w:ss-list ss)
    (setq typ (cdr (assoc 0 (entget e))))
    (cond
      ((= typ "LWPOLYLINE") (if (and (cti20w:lw-closed-p e) (not (cti20w:lw-has-bulge-p e))) (setq pols (cons e pols))))
      (T (if (setq p (cti20w:inspt e)) (setq texts (cons (list e p (cti20w:text-get e)) texts))))))
  (if pols
    (progn
      (setq path (getfiled "Salva dati lotti" "dati_lotti" "csv" 1))
      (if path
        (progn
          (setq f (cti2:apri-file path "w"))
          (if f
            (progn
              (cti20x:csv-write-row f '("Lotto" "Area" "Centro X" "Centro Y"))
              (foreach e pols
                (setq pts (cti20w:lwverts e) area (vla-get-Area (vlax-ename->vla-object e))
                      cen (cti20w:poly-centroid pts) label "LOTTO_SENZA_NOME")
                (foreach titem texts (if (cti20w:point-in-poly (cadr titem) pts) (setq label (caddr titem))))
                (cti20x:csv-write-row f (list label (rtos area 2 3) (rtos (car cen) 2 3) (rtos (cadr cen) 2 3)))
                (setq n (1+ n)))
              (cti2:chiudi-file f) (princ (strcat "\nLotti esportati: " (itoa n) ". File: " path)))
            (princ "\nImpossibile creare il file CSV."))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-genera-lottizzazione (/ w d cols rows back gap roads rw p bx by bw bd ht i j x1 y1 x2 y2 num rightoff total z)
  (setq w (getdist "\nLarghezza/fronte lotto: ") d (getdist "\nProfondità lotto: ")
        cols (getint "\nNumero colonne per lato: ") rows (getint "\nNumero righe: "))
  (initget "Si No") (setq back (getkword "\nLotti contrapposti schiena-a-schiena [Si/No] <No>: ")) (if (not back) (setq back "No"))
  (setq gap 0.0)
  (if (= back "Si") (progn (setq gap (getdist "\nDistanza/corridoio fra i due lati <0>: ")) (if (not gap) (setq gap 0.0))))
  (initget "Si No") (setq roads (getkword "\nDisegnare strade laterali [Si/No] <Si>: ")) (if (not roads) (setq roads "Si"))
  (setq rw 0.0)
  (if (= roads "Si") (progn (setq rw (getdist "\nLarghezza strada: ")) (if (not rw) (setq rw (* w 1.5)))))
  (setq p (cti2:punto-wcs (getpoint "\nPunto di inserimento inferiore sinistro: ")))
  (if (and w d cols rows p (> w 0) (> d 0) (> cols 0) (> rows 0))
    (progn
      (foreach z '(("AG CAD Tools-LOTTI" 2) ("AG CAD Tools-LOTTI-TESTO" 3) ("AG CAD Tools-LOTTI-BLOCCO" 1) ("AG CAD Tools-LOTTI-STRADA" 4)) (cti20w:ensure-layer (car z) (cadr z)))
      (setq bx (car p) by (cadr p) bw (if (= back "Si") (+ (* 2 cols w) gap) (* cols w)) bd (* rows d) ht (* (min w d) 0.12) num 1)
      (setq j 0)
      (repeat rows
        (setq i 0)
        (repeat cols
          (setq x1 (+ bx (* i w)) y1 (+ by (* j d)) x2 (+ x1 w) y2 (+ y1 d))
          (cti20x:make-rect (list x1 y1) (list x2 y2) "AG CAD Tools-LOTTI")
          (cti20x:make-centered-text (list (/ (+ x1 x2) 2.0) (/ (+ y1 y2) 2.0) 0.0) (strcat "L-" (itoa num)) ht 0.0 "AG CAD Tools-LOTTI-TESTO")
          (setq num (1+ num) i (1+ i)))
        (setq j (1+ j)))
      (if (= back "Si")
        (progn (setq rightoff (+ (* cols w) gap) j 0)
          (repeat rows (setq i 0) (repeat cols
            (setq x1 (+ bx rightoff (* i w)) y1 (+ by (* j d)) x2 (+ x1 w) y2 (+ y1 d))
            (cti20x:make-rect (list x1 y1) (list x2 y2) "AG CAD Tools-LOTTI")
            (cti20x:make-centered-text (list (/ (+ x1 x2) 2.0) (/ (+ y1 y2) 2.0) 0.0) (strcat "L-" (itoa num)) ht 0.0 "AG CAD Tools-LOTTI-TESTO")
            (setq num (1+ num) i (1+ i))) (setq j (1+ j)))))
      (cti20x:make-rect (list bx by) (list (+ bx bw) (+ by bd)) "AG CAD Tools-LOTTI-BLOCCO")
      (if (= roads "Si")
        (progn (cti20x:make-rect (list (- bx rw) by) (list bx (+ by bd)) "AG CAD Tools-LOTTI-STRADA")
               (cti20x:make-rect (list (+ bx bw) by) (list (+ bx bw rw) (+ by bd)) "AG CAD Tools-LOTTI-STRADA")))
      (setq total (1- num)) (princ (strcat "\nLottizzazione generata. Lotti: " (itoa total) "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20x:cmd-legenda-layer (/ p ht len spacing lays lay data name col desc y a b txt n ln tx layerout z)
  (setq p (cti2:punto-wcs (getpoint "\nPunto iniziale della legenda layer: ")) layerout "AG CAD Tools-LEGENDA-LAYER")
  (if p
    (progn
      (setq ht (getdist "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5))
      (setq len (getdist "\nLunghezza campione linea <12 volte altezza testo>: "))
      (if (not len) (setq len (* ht 12.0)))
      (if (or (<= ht 0) (<= len 0)) (cti2:interrompi "Altezza e lunghezza devono essere positive."))
      (cti20w:ensure-layer layerout 7)
      (setq spacing (* ht 1.8) lays nil n 0 z (caddr p))
      (vlax-for lay (vla-get-Layers (cti20w:doc))
        (setq lays (cons (list (vla-get-Name lay) (vla-get-Color lay) (vla-get-Description lay)) lays)))
      (setq lays (vl-sort lays '(lambda (x y) (< (strcase (car x)) (strcase (car y))))))
      (foreach data lays
        (setq name (nth 0 data) col (abs (nth 1 data)) desc (nth 2 data)
              y (- (cadr p) (* n spacing)) a (list (car p) y z) b (list (+ (car p) len) y z)
              txt (strcat name " | " (cti20x:color-label col) (if (= desc "") "" (strcat " | " desc))))
        (setq ln (cti20w:add-line a b layerout))
        (vla-put-Color ln col)
        (setq tx (cti20w:add-text (list (+ (car p) len (* ht 1.5)) (- y (/ ht 2.0)) z) txt ht layerout))
        (vla-put-Color tx 7)
        (setq n (1+ n)))
      (princ (strcat "\nLegenda completata. Layer elencati: " (itoa n) "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20x:cmd-numera-lotti (/ prefix start ht ss e obj guide pols data cen q d sorted n item guides order)
  (setq prefix (getstring T "\nPrefisso lotti <L>: ")) (if (= prefix "") (setq prefix "L"))
  (setq start (getint "\nNumero iniziale <1>: ")) (if (not start) (setq start 1))
  (setq ht (getdist "\nAltezza testo <2.5>: ")) (if (not ht) (setq ht 2.5))
  (if (<= ht 0) (cti2:interrompi "L'altezza deve essere positiva."))
  (prompt "\nSeleziona poligoni chiusi e UNA polilinea aperta guida: ")
  (setq ss (ssget '((0 . "LWPOLYLINE,POLYLINE"))) pols nil guide nil guides 0)
  (foreach e (cti20w:ss-list ss)
    (setq obj (vlax-ename->vla-object e))
    (if (vlax-curve-isClosed obj)
      (setq pols (cons e pols))
      (setq guide obj guides (1+ guides))))
  (if (and (= guides 1) pols)
    (progn
      (setq data nil order 0)
      (foreach e (reverse pols)
        (setq cen (cti20w:bbox-center e) q (vlax-curve-getClosestPointTo guide cen)
              d (vlax-curve-getDistAtPoint guide q)
              data (cons (list d cen order) data) order (1+ order)))
      ; Ordinamento totale: due lotti alla stessa progressiva non vengono eliminati.
      (setq sorted (vl-sort data '(lambda (a b)
          (if (= (car a) (car b)) (< (caddr a) (caddr b)) (< (car a) (car b))))) n start)
      (foreach item sorted
        (cti20x:make-centered-text (cadr item) (strcat prefix (if (and (>= n 0) (< n 10)) "0" "") (itoa n)) ht 0.0 "AG CAD Tools-NUMERI-LOTTI")
        (setq n (1+ n)))
      (princ (strcat "\nLotti numerati: " (itoa (length sorted)) ".")))
    (princ "\nServono almeno un poligono chiuso ed esattamente una guida aperta."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-poligono-da-area (/ layer p before after n _cti_boundary_result)
  (setq layer "AG CAD Tools-POLIGONI-DA-AREA" n 0) (cti20w:ensure-layer layer 4)
  (princ "\nIndica punti interni ad aree chiuse; Invio termina.")
  (while (setq p (cti2:punto-wcs (getpoint "\nPunto interno: ")))
    (setq before (entlast))
    (setq _cti_boundary_result
      (vl-catch-all-apply 'command-s (list "_.-BOUNDARY" "_A" "_O" "_P" "" p "")))
    (setq after (entlast))
    (if (and after (not (eq after before)))
      (progn (vla-put-Layer (vlax-ename->vla-object after) layer) (setq n (1+ n)) (princ "\nPoligono creato."))
      (princ "\nContorno non trovato.")))
  (princ (strcat "\nPoligoni creati: " (itoa n) ".")) (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-quota-automatica (/ e pts p1 p2 p3 p4 d1 d2 len wid ang center ht off olddim)
  (setq e (car (entsel "\nSeleziona un rettangolo chiuso LWPOLYLINE: ")))
  (if (setq pts (cti20x:rect-verts e))
    (progn
      (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
            d1 (distance p1 p2) d2 (distance p2 p3))
      (if (> d1 d2) (setq len d1 wid d2 ang (cti2:angolo-xy p1 p2)) (setq len d2 wid d1 ang (cti2:angolo-xy p2 p3)))
      (if (and (> ang (/ pi 2.0)) (<= ang (* pi 1.5))) (setq ang (- ang pi)))
      (setq center (cti20x:mid p1 p3)
            ht (getreal (strcat "\nAltezza testo/quote <" (rtos (cti20x:text-height) 2 2) ">: ")))
      (if (not ht) (setq ht (cti20x:text-height)))
      (setq off (getdist (strcat "\nDistanza quote dal contorno <" (rtos (* ht 1.5) 2 2) ">: ")))
      (if (not off) (setq off (* ht 1.5)))
      (cti2:setvar-temporanea "DIMTXT" ht)
      (cti20x:make-centered-text center (strcat (cti20x:length-label len) " x " (cti20x:length-label wid)) ht ang "AG CAD Tools-QUOTE-AUTO")
      (cti20x:dim-side p1 p2 center off) (cti20x:dim-side p2 p3 center off)
      (cti20x:dim-side p3 p4 center off) (cti20x:dim-side p4 p1 center off)
      (princ "\nQuotatura automatica completata."))
    (princ "\nServe una LWPOLYLINE chiusa con esattamente quattro vertici."))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-quota-porta (/ p1 p2 h ht side width ang mid normal labpt label)
  (setq p1 (cti2:punto-wcs (getpoint "\nPrimo stipite della porta: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nSecondo stipite della porta: ")))
  (if (and p1 p2 (> (distance p1 p2) 1e-9))
    (progn
      (setq width (distance p1 p2)
            h (getdist (strcat "\nAltezza porta in unità disegno <" (rtos (cond ((= (getvar "INSUNITS") 4) 2100.0) ((= (getvar "INSUNITS") 6) 2.10) (T width)) 2 2) ">: ")))
      (if (not h) (setq h (cond ((= (getvar "INSUNITS") 4) 2100.0) ((= (getvar "INSUNITS") 6) 2.10) (T width))))
      (setq ht (getdist (strcat "\nAltezza testo <" (rtos (cti20x:text-height) 2 2) ">: "))) (if (not ht) (setq ht (cti20x:text-height)))
      (setq side (cti2:punto-wcs (getpoint (cti2:punto-ucs (cti20x:mid p1 p2)) "\nIndica il lato su cui posizionare la sigla: ")) ang (cti2:angolo-xy p1 p2) mid (cti20x:mid p1 p2)
            normal (if side (cti2:angolo-xy mid side) (+ ang (/ pi 2.0))) labpt (cti2:polare-xy mid normal (* ht 2.0))
            label (strcat (cti20x:length-label width) " x " (cti20x:length-label h)))
      (cti20x:make-centered-text labpt label ht ang "AG CAD Tools-QUOTE-PORTE")
      (princ (strcat "\nQuota porta creata: " label "."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20x:cmd-quota-stanza (/ p1 p2 lab dx dy ht txt)
  (setq p1 (cti2:punto-wcs (getpoint "\nPrimo angolo della stanza: ")) p2 (cti2:punto-wcs (getpoint (cti2:punto-ucs p1) "\nAngolo diagonalmente opposto: ")))
  (if (and p1 p2)
    (progn
      (setq lab (cti2:punto-wcs (getpoint "\nPunto per l'etichetta dimensioni: "))
            dx (abs (- (car p2) (car p1))) dy (abs (- (cadr p2) (cadr p1)))
            ht (cti20x:text-height) txt (strcat (cti20x:length-label dx) " x " (cti20x:length-label dy)))
      (if lab (cti20x:make-centered-text lab txt ht 0.0 "AG CAD Tools-QUOTE-STANZE"))
      (princ (strcat "\nDimensioni stanza in XY mondiale: " txt "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-ruota-riferimento (/ ss base a b ref typ refang curang delta e o)
  (prompt "\nSeleziona gli oggetti da ruotare: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq base (cti2:punto-wcs (getpoint "\nPunto base della rotazione: "))
            a (cti2:punto-wcs (getpoint "\nPrimo punto della direzione attuale: ")))
      (if a (setq b (cti2:punto-wcs (getpoint (cti2:punto-ucs a) "\nSecondo punto della direzione attuale: "))))
      (if (and base a b (> (distance a b) 1e-10))
        (progn
          (setq ref (car (entsel "\nSeleziona LINEA/ARCO/POLILINEA di riferimento: ")))
          (if ref (setq typ (cdr (assoc 0 (entget ref)))))
          (if (member typ '("LINE" "ARC" "LWPOLYLINE" "POLYLINE"))
            (progn
              (setq curang (cti2:angolo-xy a b)
                    refang (cti20w:curve-angle-at ref base)
                    delta (- refang curang))
              (foreach e (cti20w:ss-list ss)
                (setq o (vlax-ename->vla-object e))
                (vl-catch-all-apply 'vla-Rotate (list o (vlax-3d-point base) delta)))
              (princ (strcat "\nRotazione applicata: " (rtos (* delta (/ 180.0 pi)) 2 2) "°.")))
            (princ "\nRiferimento non valido: seleziona LINEA, ARCO o POLILINEA."))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-scala-immagine-contorno (/ img box io bo imn imx bmn bmx a b c d iw ih bw bh factor ic bc)
  (setq img (car (entsel "\nSeleziona l'immagine raster: ")) box (car (entsel "\nSeleziona il contorno di destinazione: ")))
  (if (and img box (= (cdr (assoc 0 (entget img))) "IMAGE"))
    (progn
      (setq io (vlax-ename->vla-object img) bo (vlax-ename->vla-object box))
      (if (and (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list io 'imn 'imx))))
               (not (vl-catch-all-error-p (vl-catch-all-apply 'vla-GetBoundingBox (list bo 'bmn 'bmx)))))
        (progn
          (setq a (vlax-safearray->list imn) b (vlax-safearray->list imx) c (vlax-safearray->list bmn) d (vlax-safearray->list bmx)
                iw (- (car b) (car a)) ih (- (cadr b) (cadr a)) bw (- (car d) (car c)) bh (- (cadr d) (cadr c)))
          (if (and (> iw 1e-12) (> ih 1e-12) (> bw 0) (> bh 0))
            (progn
              (setq factor (min (/ bw iw) (/ bh ih)) ic (cti20x:mid a b) bc (cti20x:mid c d))
              (vla-ScaleEntity io (vlax-3d-point ic) factor)
              (vla-Move io (vlax-3d-point ic) (vlax-3d-point bc))
              (princ (strcat "\nImmagine adattata al contorno. Fattore: " (rtos factor 2 5) "."))))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-scala-riferimento (/ ss base a b newlen oldlen factor e o r n)
  (prompt "
Seleziona gli oggetti da scalare: ") (setq ss (ssget))
  (if ss
    (progn
      (setq base (cti2:punto-wcs (getpoint "
Punto base: ")) a (cti2:punto-wcs (getpoint "
Primo punto della lunghezza di riferimento: ")))
      (if a (setq b (cti2:punto-wcs (getpoint (cti2:punto-ucs a) "
Secondo punto della lunghezza di riferimento: "))))
      (setq newlen (getdist "
Nuova lunghezza: "))
      (if (and base a b newlen (> (setq oldlen (distance a b)) 1e-12) (> newlen 0.0))
        (progn
          (setq factor (/ newlen oldlen) n 0)
          (foreach e (cti20w:ss-list ss)
            (setq o (vlax-ename->vla-object e) r (vl-catch-all-apply 'vla-ScaleEntity (list o (vlax-3d-point base) factor)))
            (if (not (vl-catch-all-error-p r)) (setq n (1+ n))))
          (princ (strcat "
Scala per riferimento completata su " (itoa n) " oggetti. Fattore=" (rtos factor 2 6) "."))))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:cmd-trova-tag (/ raw parts a b doc blk obj attrs hit found att val)
  (setq raw (strcase (getstring T "\nTag/attributi da cercare (es. 3/A-5): ")))
  (if (/= raw "")
    (progn
      (setq parts (cti20x:split-slash raw) a (car parts) b (cadr parts) found 0 doc (cti20w:doc) blk (vla-get-Block (vla-get-ActiveLayout doc)))
      (vlax-for obj blk
        (if (and (= (vla-get-ObjectName obj) "AcDbBlockReference") (= :vlax-true (vla-get-HasAttributes obj)))
          (progn
            (setq hit 0 attrs (cti20w:in-lista (vlax-invoke obj 'GetAttributes)) att nil)
            (foreach att attrs
              (setq val (strcase (vla-get-TextString att)))
              (if (= val a) (setq hit (logior hit 1)))
              (if (and b (= val b)) (setq hit (logior hit 2))))
            (if (or (and b (= hit 3)) (and (not b) (= hit 1)))
              (progn
                (setq found (1+ found))
                (cti20x:zoom-object obj)
                (getstring (strcat "\nTrovato #" (itoa found) ". Invio per continuare; ESC interrompe: ")))))))
      (princ (strcat "\nRicerca completata. Tag trovati: " (itoa found) "."))))
  (princ))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:color-label (c)
  (cond ((= c 1) "rosso") ((= c 2) "giallo") ((= c 3) "verde") ((= c 4) "ciano")
        ((= c 5) "blu") ((= c 6) "magenta") ((= c 7) "bianco/nero") (T (strcat "ACI " (itoa c)))))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:csv-write-row (f vals /)
  (write-line (cti20w:join (mapcar 'cti20w:csv-quote vals) ";") f))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:dim-side (a b center offset / mid dir p o)
  (setq mid (cti20x:mid a b) dir (cti2:angolo-xy center mid) p (cti2:polare-xy mid dir offset))
  (setq o (vl-catch-all-apply 'vla-AddDimAligned
            (list (cti20w:space) (vlax-3d-point a) (vlax-3d-point b) (vlax-3d-point p))))
  (if (vl-catch-all-error-p o) nil o))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:dot2 (a b) (+ (* (car a) (car b)) (* (cadr a) (cadr b))))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:length-label (v / f)
  (setq f (cti20x:unit-to-m))
  (if f (strcat (rtos (* v f) 2 2) " m") (rtos v 2 2)))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:make-centered-text (pt str ht ang layer / o)
  (cti20w:ensure-layer layer 7)
  (setq o (vla-AddText (cti20w:space) str (vlax-3d-point pt) ht))
  (vla-put-Layer o layer)
  (vla-put-Alignment o 10) ; acAlignmentMiddleCenter
  (vla-put-TextAlignmentPoint o (vlax-3d-point pt))
  (vla-put-Rotation o ang)
  o)

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:make-rect (p1 p2 layer / x1 y1 x2 y2)
  (setq x1 (car p1) y1 (cadr p1) x2 (car p2) y2 (cadr p2))
  (cti20w:make-lwpoly (list (list x1 y1 0.0) (list x2 y1 0.0) (list x2 y2 0.0) (list x1 y2 0.0)) layer T))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:mid (a b) (mapcar '(lambda (x y) (/ (+ x y) 2.0)) a b))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:near (a b tol) (<= (abs (- a b)) (* tol (max 1.0 (abs a) (abs b)))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti20x:rect-verts (e / pts)
  (if (and e (= (cdr (assoc 0 (entget e))) "LWPOLYLINE")
           (cti20w:lw-closed-p e) (not (cti20w:lw-has-bulge-p e)))
    (progn
      (setq pts (cti20w:lwverts e))
      (if (and (= (length pts) 4) (cti2:orizzontale-p pts) (cti20x:rettangolo-p pts)) pts nil))
    nil))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:rettangolo-p (pts / p1 p2 p3 p4 v1 v2 v3 v4 l1 l2 l3 l4 tol)
  (setq p1 (nth 0 pts) p2 (nth 1 pts) p3 (nth 2 pts) p4 (nth 3 pts)
        v1 (cti20x:vec2 p1 p2) v2 (cti20x:vec2 p2 p3)
        v3 (cti20x:vec2 p3 p4) v4 (cti20x:vec2 p4 p1)
        l1 (distance p1 p2) l2 (distance p2 p3) l3 (distance p3 p4) l4 (distance p4 p1)
        tol 1e-6)
  (and (> l1 1e-9) (> l2 1e-9) (> l3 1e-9) (> l4 1e-9)
       (< (/ (abs (cti20x:dot2 v1 v2)) (* l1 l2)) tol)
       (< (/ (abs (cti20x:dot2 v2 v3)) (* l2 l3)) tol)
       (cti20x:near l1 l3 tol)
       (cti20x:near l2 l4 tol)))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:select-block-ref (msg / e o)
  (setq e (car (entsel msg)))
  (if e (progn (setq o (vlax-ename->vla-object e)) (if (= (vla-get-ObjectName o) "AcDbBlockReference") o nil)) nil))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:set-block-attrs (obj pairs / a p n)
  (setq n 0)
  (if (= :vlax-true (vla-get-HasAttributes obj))
    (foreach a (cti20w:in-lista (vlax-invoke obj 'GetAttributes))
      (if (setq p (assoc (strcase (vla-get-TagString a)) pairs))
        (progn (vla-put-TextString a (cdr p)) (setq n (1+ n))))))
  n)

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:split-slash (s / p)
  (setq p (vl-string-search "/" s))
  (if p (list (substr s 1 p) (substr s (+ p 2))) (list s nil)))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:text-height (/ h)
  (setq h (vl-catch-all-apply 'getvar (list "TEXTSIZE")))
  (if (or (vl-catch-all-error-p h) (not (numberp h)) (<= h 0.0)) 2.5 h))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:unit-to-m (/ u)
  (setq u (getvar "INSUNITS"))
  (cond ((= u 1) 0.0254) ((= u 2) 0.3048) ((= u 4) 0.001)
        ((= u 5) 0.01) ((= u 6) 1.0) ((= u 7) 1000.0) (T nil)))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:vec2 (a b) (list (- (car b) (car a)) (- (cadr b) (cadr a))))

; Origine AG CAD Tools: cti_web_phase2c_2_0.lsp
(defun cti20x:zoom-object (obj / mn mx r a b dx dy p1 p2 app)
  (setq r (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'mn 'mx)))
  (if (vl-catch-all-error-p r) nil
    (progn
      (setq a (vlax-safearray->list mn) b (vlax-safearray->list mx)
            dx (max 1e-6 (- (car b) (car a))) dy (max 1e-6 (- (cadr b) (cadr a)))
            p1 (list (- (car a) (* dx 0.25)) (- (cadr a) (* dy 0.25)) (if (caddr a) (caddr a) 0.0))
            p2 (list (+ (car b) (* dx 0.25)) (+ (cadr b) (* dy 0.25)) (if (caddr b) (caddr b) 0.0))
            app (vlax-get-acad-object))
      (vl-catch-all-apply 'vla-ZoomWindow (list app (vlax-3d-point p1) (vlax-3d-point p2))))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:bordi (pts / out i n)
  (setq out nil i 0 n (length pts))
  (while (< i n)
    (setq out (cons (list (nth i pts) (nth (rem (1+ i) n) pts)) out) i (1+ i)))
  (reverse out))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:cancella-classificati (classe / b poly all targets e result incerti ans n)
  (setq b (car (entsel "\nSeleziona un contorno LWPOLYLINE chiuso, semplice, rettilineo e orizzontale: ")))
  (cond
    ((not b) nil)
    ((not (cti20c:contorno-valido-p b))
     (princ "\nContorno non certificabile: nessun oggetto modificato."))
    (T
     (setq poly (cti20w:lwverts b) all (ssget "_X" (list (cons 410 (cti2:scheda-attiva))))
           targets nil incerti 0)
     (foreach e (cti20w:ss-list all)
       (if (not (eq e b))
         (progn
           (setq result (cti2:classe-entita e poly))
           (cond ((eq result classe) (setq targets (cons e targets)))
                 ((eq result 'incerto) (setq incerti (1+ incerti)))))))
     (princ (strcat "\nOggetti sul bordo, non planari, bloccati o incerti conservati: " (itoa incerti) "."))
     (if targets
       (progn
         (initget "Si No")
         (setq ans (getkword (strcat "\nEliminare " (itoa (length targets))
                 (if (eq classe 'interno) " oggetti certificati interni" " oggetti certificati esterni")
                 " nello spazio corrente? [Si/No] <No>: ")))
         (if (= ans "Si")
           (progn
             (setq n 0)
             (foreach e targets (if (entdel e) (setq n (1+ n))))
             (princ (strcat "\nEliminati: " (itoa n) "; non eliminati: " (itoa (- (length targets) n)) ".")))))
       (princ "\nNessun oggetto eliminabile con certezza."))))
  (princ))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:classe-entita (e poly / mn mx r o flags)
  (setq flags (cdr (assoc 70 (tblsearch "LAYER" (cdr (assoc 8 (entget e)))))))
  (if (or (/= 0 (logand 4 flags)) (= (cdr (assoc 0 (entget e))) "VIEWPORT"))
    'incerto
    (progn
      (setq o (vlax-ename->vla-object e) r (vl-catch-all-apply 'vla-GetBoundingBox (list o 'mn 'mx)))
      (if (vl-catch-all-error-p r) 'incerto
        (cti2:classe-riquadro (vlax-safearray->list mn) (vlax-safearray->list mx) poly)))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:classe-riquadro (mn mx poly / z rect allin anyin anypoly hit p a b)
  (setq z (caddr (car poly)))
  (if (not (and (equal (caddr mn) z 1e-8) (equal (caddr mx) z 1e-8)))
    'incerto
    (progn
      (setq rect (list (list (car mn) (cadr mn) z) (list (car mx) (cadr mn) z)
                       (list (car mx) (cadr mx) z) (list (car mn) (cadr mx) z))
            allin T anyin nil anypoly nil hit nil)
      (foreach p rect
        (if (and (cti20w:point-in-poly p poly) (not (cti2:punto-sul-bordo-p p poly)))
          (setq anyin T) (setq allin nil)))
      (foreach p poly
        (if (and (<= (car mn) (car p) (car mx)) (<= (cadr mn) (cadr p) (cadr mx)))
          (setq anypoly T)))
      (foreach a (cti2:bordi rect)
        (foreach b (cti2:bordi poly)
          (if (cti2:segmenti-toccano-p (car a) (cadr a) (car b) (cadr b)) (setq hit T))))
      (cond
        ((and allin (not anypoly) (not hit)) 'interno)
        ((and (not anyin) (not anypoly) (not hit)) 'esterno)
        (T 'incerto)))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:orientamento (a b c)
  (- (* (- (car b) (car a)) (- (cadr c) (cadr a)))
     (* (- (cadr b) (cadr a)) (- (car c) (car a)))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:punto-su-segmento-p (p a b / tol)
  (setq tol 1e-8)
  (and (<= (abs (cti2:orientamento a b p)) (* tol (max 1.0 (distance a b))))
       (<= (- (min (car a) (car b)) tol) (car p) (+ (max (car a) (car b)) tol))
       (<= (- (min (cadr a) (cadr b)) tol) (cadr p) (+ (max (cadr a) (cadr b)) tol))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:punto-sul-bordo-p (p poly / hit seg)
  (setq hit nil)
  (foreach seg (cti2:bordi poly)
    (if (cti2:punto-su-segmento-p p (car seg) (cadr seg)) (setq hit T)))
  hit)

; Origine AG CAD Tools: correzioni.lsp
(defun cti2:segmenti-toccano-p (a b c d / o1 o2 o3 o4)
  (setq o1 (cti2:orientamento a b c) o2 (cti2:orientamento a b d)
        o3 (cti2:orientamento c d a) o4 (cti2:orientamento c d b))
  (or (and (< (* o1 o2) 0.0) (< (* o3 o4) 0.0))
      (cti2:punto-su-segmento-p a c d) (cti2:punto-su-segmento-p b c d)
      (cti2:punto-su-segmento-p c a b) (cti2:punto-su-segmento-p d a b)))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:aggiungi-parametro (seg tval / ts)
  (setq ts (nth 7 seg))
  (if (not (vl-some '(lambda (x) (< (abs (- x tval)) 1e-8)) ts))
    (setq ts (cons tval ts)))
  (subst ts (nth 7 seg) seg))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:aggiungi-punto-unico (pt pts tol)
  (if (vl-some '(lambda (q) (< (distance pt q) tol)) pts) pts (cons pt pts)))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:assicura-layer (lname color /)
  (if (not (tblsearch "LAYER" lname))
    (entmake
      (list '(0 . "LAYER")
            '(100 . "AcDbSymbolTableRecord")
            '(100 . "AcDbLayerTableRecord")
            (cons 2 lname)
            '(70 . 0)
            (cons 62 color)
            '(6 . "Continuous"))))
  lname)

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-blocchi-su-nodi (/ mode ss blk scale rot i j o1 o2 pts p all layer en)
  (initget "Intersezioni Estremi Entrambi")
  (setq mode (getkword "\nPosizioni [Intersezioni/Estremi/Entrambi] <Entrambi>: "))
  (if (null mode) (setq mode "Entrambi"))
  (setq ss (ssget '((-4 . "<OR") (0 . "LINE") (0 . "ARC") (0 . "LWPOLYLINE") (-4 . "OR>"))))
  (if ss
    (progn
      (setq blk (getstring T "\nNome del blocco gia' definito nel disegno: "))
      (if (tblsearch "BLOCK" blk)
        (progn
          (setq scale (getreal "\nScala blocco <1.0>: "))
          (if (or (null scale) (<= scale 0.0)) (setq scale 1.0))
          (setq rot (cti2:angolo-wcs (getangle "\nRotazione <0>: ")))
          (if (null rot) (setq rot 0.0))
          (setq all nil i 0)
          (if (or (= mode "Estremi") (= mode "Entrambi"))
            (repeat (sslength ss)
              (setq o1 (vlax-ename->vla-object (ssname ss i)))
              (setq all (cti2c:aggiungi-punto-unico (vlax-curve-getStartPoint o1) all 1e-4))
              (setq all (cti2c:aggiungi-punto-unico (vlax-curve-getEndPoint o1) all 1e-4))
              (setq i (1+ i))))
          (if (or (= mode "Intersezioni") (= mode "Entrambi"))
            (progn
              (setq i 0)
              (while (< i (sslength ss))
                (setq o1 (vlax-ename->vla-object (ssname ss i)) j (1+ i))
                (while (< j (sslength ss))
                  (setq o2 (vlax-ename->vla-object (ssname ss j)) pts (cti2c:intersezioni o1 o2))
                  (foreach p pts (setq all (cti2c:aggiungi-punto-unico p all 1e-4)))
                  (setq j (1+ j)))
                (setq i (1+ i)))))
          (setq layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-NODI" 1))
          (foreach p all
            (cti20w:insert-block blk p scale rot layer))
          (princ (strcat "\nInseriti " (itoa (length all)) " blocchi sui nodi.")))
        (princ "\nIl blocco indicato non e' definito nel disegno.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-controlla-numerazione (/ ss i en obj s n vals valid invalid minv maxv k missing seen dupes p layer)
  (princ "\nSeleziona TESTO/TESTOM contenenti numeri interi: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
  (if ss
    (progn
      (setq i 0 vals nil valid nil invalid 0)
      (repeat (sslength ss)
        (setq en (ssname ss i) obj (vlax-ename->vla-object en)
              s (vla-get-TextString obj) n (cti2c:intero-rigoroso s))
        (if n
          (progn (setq vals (cons n vals)) (setq valid (cons (cons n en) valid)))
          (setq invalid (1+ invalid)))
        (setq i (1+ i)))
      (if vals
        (progn
          (setq minv (apply 'min vals) maxv (apply 'max vals) k minv missing nil seen nil dupes nil)
          (while (<= k maxv)
            (if (not (member k vals)) (setq missing (cons k missing)))
            (setq k (1+ k)))
          (foreach n vals
            (if (member n seen)
              (if (not (member n dupes)) (setq dupes (cons n dupes)))
              (setq seen (cons n seen))))
          (setq missing (vl-sort missing '<) dupes (vl-sort dupes '<)
                layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-NUMERAZIONE" 1))
          (foreach p valid
            (if (member (car p) dupes)
              (cti2c:crea-cerchio (vlax-get (vlax-ename->vla-object (cdr p)) 'InsertionPoint) 1.0 layer)))
          (princ (strcat "\nIntervallo: " (itoa minv) " - " (itoa maxv)))
          (princ (strcat "\nMancanti (" (itoa (length missing)) "): " (cti2c:lista-stringa missing)))
          (princ (strcat "\nDuplicati (" (itoa (length dupes)) "): " (cti2c:lista-stringa dupes)))
          (if (> invalid 0) (princ (strcat "\nIgnorati " (itoa invalid) " testi non numerici/non interi."))))
        (princ "\nNessun testo numerico intero valido nella selezione.")))
    (princ "\nNessun testo selezionato."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-copia-su-layout (/ ss doc layouts arr i lay blk res count)
  (princ "\nSeleziona gli oggetti da copiare in tutti i layout di spazio carta: ")
  (setq ss (ssget))
  (if ss
    (progn
      (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
            layouts (vla-get-Layouts doc)
            arr (vlax-make-safearray vlax-vbObject (cons 0 (1- (sslength ss))))
            i 0)
      (repeat (sslength ss)
        (vlax-safearray-put-element arr i (vlax-ename->vla-object (ssname ss i)))
        (setq i (1+ i)))
      (setq count 0)
      (vlax-for lay layouts
        (if (= (vla-get-ModelType lay) :vlax-false)
          (progn
            (setq blk (vla-get-Block lay)
                  res (vl-catch-all-apply 'vla-CopyObjects (list doc arr blk)))
            (if (not (vl-catch-all-error-p res)) (setq count (1+ count))))))
      (princ (strcat "\nCopiati " (itoa (sslength ss)) " oggetti in " (itoa count) " layout.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-csv-in-tabella (/ path f line sep rows row maxcols ins colw rowh doc space tab r c value)
  (setq path (getfiled "Seleziona un file CSV" "" "csv" 0))
  (cond
    ((null path)
     (princ "\nNessun file selezionato."))
    ((null (setq f (cti2:apri-file path "r")))
     (princ "\nImpossibile aprire il file CSV."))
    (T
     (setq rows nil sep nil maxcols 0)
     (while (setq line (read-line f))
       (if (> (strlen (vl-string-trim " \t" line)) 0)
         (progn
           (if (null sep) (setq sep (cti2c:separatore-csv line)))
           (setq row (cti2c:dividi-csv line sep)
                 rows (append rows (list row))
                 maxcols (max maxcols (length row))))))
     (cti2:chiudi-file f)
     (if (null rows)
       (princ "\nIl file CSV non contiene righe utilizzabili.")
       (progn
         (setq ins (cti2:punto-wcs (getpoint "\nIndica il punto di inserimento della tabella: ")))
         (if ins
           (progn
             (setq colw (getdist "\nLarghezza colonna <25.0>: "))
             (if (or (null colw) (<= colw 0.0)) (setq colw 25.0))
             (setq rowh (getdist "\nAltezza riga <8.0>: "))
             (if (or (null rowh) (<= rowh 0.0)) (setq rowh 8.0))
             (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-TABELLE" 5)
             (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
                   space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
                   tab (vla-AddTable space (vlax-3d-point ins) (length rows) maxcols rowh colw))
             (vla-put-Layer tab "AG CAD Tools-COMMUNITY-TABELLE")
             (cti2:sospendi-tabella tab)
             (setq r 0)
             (foreach row rows
               (setq c 0)
               (while (< c maxcols)
                 (setq value (if (< c (length row)) (nth c row) ""))
                 (vla-SetText tab r c value)
                 (setq c (1+ c)))
               (setq r (1+ r)))
             (vla-put-RegenerateTableSuppressed tab :vlax-false)
             (princ (strcat "\nCSV importato come tabella nativa: " (itoa (length rows)) " righe x " (itoa maxcols) " colonne.")))
           (princ "\nInserimento tabella annullato."))))))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-esporta-vertici-csv (/ en verts path f i p)
  (setq en (car (entsel "\nSeleziona una polilinea 2D o 3D da esportare: ")))
  (cond
    ((null en)
     (princ "\nNessun oggetto selezionato."))
    ((null (setq verts (cti2c:vertici-entita en)))
     (princ "\nL'oggetto selezionato non contiene vertici leggibili."))
    ((null (setq path (getfiled "Salva coordinate vertici" "vertici" "csv" 1)))
     (princ "\nEsportazione annullata."))
    ((null (setq f (cti2:apri-file path "w")))
     (princ "\nImpossibile creare il file CSV."))
    (T
     (write-line "Numero;X;Y;Z" f)
     (setq i 1)
     (foreach p verts
       (write-line
         (strcat (itoa i) ";" (rtos (car p) 2 4) ";"
                 (rtos (cadr p) 2 4) ";"
                 (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
       (setq i (1+ i)))
     (cti2:chiudi-file f)
     (princ (strcat "\nEsportati " (itoa (length verts)) " vertici in: " path))))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-intersezioni (/ ss rad i j o1 o2 pts all p layer)
  (setq rad (getdist "\nRaggio dei marcatori <1.5>: "))
  (if (or (null rad) (<= rad 0.0)) (setq rad 1.5))
  (princ "\nSeleziona LINEE, ARCHI e POLILINEE da controllare: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "LINE") (0 . "ARC") (0 . "LWPOLYLINE") (-4 . "OR>"))))
  (if (and ss (>= (sslength ss) 2))
    (progn
      (setq all nil i 0 layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-INTERSEZIONI" 6))
      (while (< i (sslength ss))
        (setq o1 (vlax-ename->vla-object (ssname ss i)) j (1+ i))
        (while (< j (sslength ss))
          (setq o2 (vlax-ename->vla-object (ssname ss j))
                pts (cti2c:intersezioni o1 o2))
          (foreach p pts (setq all (cons p all)))
          (setq j (1+ j)))
        (setq i (1+ i)))
      (setq all (cti2c:punti-unici all 1e-5))
      (foreach p all (cti2c:crea-cerchio p rad layer))
      (princ (strcat "\nIndividuate e marcate " (itoa (length all)) " intersezioni.")))
    (princ "\nServono almeno due oggetti compatibili."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-numera-vertici (/ ss path f ht i en verts p count layer)
  (princ "\nSeleziona le polilinee di cui numerare i vertici: ")
  (setq ss (ssget '((-4 . "<OR") (0 . "LWPOLYLINE") (0 . "POLYLINE") (-4 . "OR>"))))
  (cond
    ((null ss)
     (princ "\nNessuna polilinea selezionata."))
    ((null (setq path (getfiled "Salva elenco numerato vertici" "vertici_numerati" "csv" 1)))
     (princ "\nEsportazione annullata."))
    (T
     (setq ht (getdist "\nAltezza testo numerazione <2.5>: "))
     (if (or (null ht) (<= ht 0.0)) (setq ht 2.5))
     (setq layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-VERTICI" 2)
           f (cti2:apri-file path "w") count 1 i 0)
     (if f
       (progn
         (write-line "Numero;X;Y;Z" f)
         (repeat (sslength ss)
           (setq en (ssname ss i) verts (cti2c:vertici-entita en))
           (foreach p verts
             (cti2c:crea-testo p (itoa count) ht layer)
             (write-line
               (strcat (itoa count) ";" (rtos (car p) 2 4) ";"
                       (rtos (cadr p) 2 4) ";"
                       (rtos (if (caddr p) (caddr p) 0.0) 2 4)) f)
             (setq count (1+ count)))
           (setq i (1+ i)))
         (cti2:chiudi-file f)
         (princ (strcat "\nNumerati ed esportati " (itoa (1- count)) " vertici.")))
       (princ "\nImpossibile creare il file CSV."))))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-polilinee-aperte (/ ss rad i en ed closed verts layer count p1 p2)
  (setq rad (getdist "\nRaggio dei marcatori <1.5>: "))
  (if (or (null rad) (<= rad 0.0)) (setq rad 1.5))
  (princ "\nSeleziona le LWPOLYLINE da controllare: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq i 0 count 0 layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-APERTURE" 1))
      (repeat (sslength ss)
        (setq en (ssname ss i) ed (entget en)
              closed (= 1 (logand 1 (cdr (assoc 70 ed)))))
        (if (not closed)
          (progn
            (setq verts (cti2c:vertici-entita en))
            (if verts
              (progn
                (setq p1 (car verts) p2 (last verts))
                (cti2c:crea-cerchio p1 rad layer)
                (if (> (distance p1 p2) 1e-8) (cti2c:crea-cerchio p2 rad layer))
                (setq count (1+ count))))))
        (setq i (1+ i)))
      (princ (strcat "\nPolilinee aperte trovate: " (itoa count) ". Estremi marcati sul layer " layer ".")))
    (princ "\nNessuna polilinea selezionata."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-prefisso-suffisso (/ pre suf ss i obj old count)
  (setq pre (getstring T "\nPrefisso <nessuno>: ")
        suf (getstring T "\nSuffisso <nessuno>: "))
  (if (and (= pre "") (= suf ""))
    (princ "\nPrefisso e suffisso vuoti: nessuna modifica.")
    (progn
      (princ "\nSeleziona TESTO e TESTOM da modificare: ")
      (setq ss (ssget '((-4 . "<OR") (0 . "TEXT") (0 . "MTEXT") (-4 . "OR>"))))
      (if ss
        (progn
          (setq i 0 count 0)
          (repeat (sslength ss)
            (setq obj (vlax-ename->vla-object (ssname ss i))
                  old (vla-get-TextString obj))
            (vla-put-TextString obj (strcat pre old suf))
            (setq count (1+ count) i (1+ i)))
          (princ (strcat "\nAggiornati " (itoa count) " testi.")))
        (princ "\nNessun testo selezionato."))))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-riduci-vertici (/ d en obj typ len dist pts p layer original)
  (setq d (getdist "\nDistanza di campionamento <30.0>: "))
  (if (or (null d) (<= d 0.0)) (setq d 30.0))
  (setq en (car (entsel "\nSeleziona una polilinea 2D rettilinea da alleggerire: ")))
  (if en
    (progn
      (setq typ (cdr (assoc 0 (entget en))))
      (cond
        ((/= typ "LWPOLYLINE")
         (princ "\nSelezionare una LWPOLYLINE 2D."))
        ((not (cti2c:polilinea-rettilinea-p en))
         (princ "\nLa polilinea contiene archi/bulge: operazione annullata per non alterare la geometria."))
        (T
         (setq obj (vlax-ename->vla-object en)
               original (length (cti2c:vertici-entita en))
               len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj))
               dist 0.0 pts nil)
         (while (< dist len)
           (setq p (vlax-curve-getPointAtDist obj dist))
           (if p (setq pts (cons p pts)))
           (setq dist (+ dist d)))
         (setq p (vlax-curve-getEndPoint obj))
         (if p (setq pts (reverse (cons p pts))))
         (setq layer (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-RIDOTTE" 3))
         (if (> (length pts) 1)
           (progn
             (cti2c:crea-lwpoly pts layer nil)
             (princ (strcat "\nCreata copia alleggerita 2D: " (itoa original) " -> " (itoa (length pts)) " vertici. L'originale e' stato conservato.")))
           (princ "\nCampionamento insufficiente per creare la nuova polilinea.")))))
    (princ "\nNessun oggetto selezionato."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-spezzaincroci (/ ss i en polys skipped segs s1 s2 ti a b allents nmade ts k)
  (princ "\nSeleziona almeno due polilinee rettilinee da spezzare alle intersezioni: ")
  (setq ss (ssget '((0 . "LWPOLYLINE"))))
  (if (and ss (>= (sslength ss) 2))
    (progn
      (setq i 0 polys nil skipped 0 allents nil)
      (repeat (sslength ss)
        (setq en (ssname ss i))
        (if (cti2c:polilinea-rettilinea-p en)
          (progn (setq polys (cons en polys) allents (cons en allents)))
          (setq skipped (1+ skipped)))
        (setq i (1+ i)))
      (setq segs nil)
      (foreach en (reverse polys) (setq segs (append segs (cti2c:segmenti-polilinea en))))
      (setq i 0)
      (while (< i (length segs))
        (setq s1 (nth i segs) k (1+ i))
        (while (< k (length segs))
          (setq s2 (nth k segs))
          (if (/= (car s1) (car s2))
            (progn
              (setq ti (cti2c:parametri-intersezione-segmenti (nth 1 s1) (nth 2 s1) (nth 1 s2) (nth 2 s2)))
              (if ti
                (progn
                  (setq s1 (cti2c:aggiungi-parametro s1 (car ti))
                        s2 (cti2c:aggiungi-parametro s2 (cadr ti))
                        segs (cti2c:imposta-elemento-lista segs i s1)
                        segs (cti2c:imposta-elemento-lista segs k s2))))))
          (setq k (1+ k)))
        (setq i (1+ i)))
      (setq nmade 0)
      (foreach s1 segs
        (setq ts (vl-sort (nth 7 s1) '<) k 0)
        (while (< k (1- (length ts)))
          (setq a (nth k ts) b (nth (1+ k) ts))
          (if (> (- b a) 1e-9)
            (progn (cti2c:crea-linea-da-segmento s1 a b) (setq nmade (1+ nmade))))
          (setq k (1+ k))))
      (foreach en allents (entdel en))
      (princ (strcat "\nCreati " (itoa nmade) " segmenti LINE spezzati alle intersezioni."
                     (if (> skipped 0) (strcat " Ignorate " (itoa skipped) " polilinee con archi.") ""))))
    (princ "\nServono almeno due polilinee."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:cmd-tabella-vertici (/ en verts ins rowh colw doc space tab r p)
  (setq en (car (entsel "\nSeleziona una polilinea 2D o 3D: ")))
  (if en
    (progn
      (setq verts (cti2c:vertici-entita en))
      (if verts
        (progn
          (setq ins (cti2:punto-wcs (getpoint "\nIndica il punto di inserimento della tabella: ")))
          (if ins
            (progn
              (setq rowh (getdist "\nAltezza riga <8.0>: "))
              (if (or (null rowh) (<= rowh 0.0)) (setq rowh 8.0))
              (setq colw (getdist "\nLarghezza colonna <28.0>: "))
              (if (or (null colw) (<= colw 0.0)) (setq colw 28.0))
              (cti2c:assicura-layer "AG CAD Tools-COMMUNITY-TABELLE" 5)
              (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
                    space (if (= (getvar "CVPORT") 1) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
                    tab (vla-AddTable space (vlax-3d-point ins) (+ 2 (length verts)) 4 rowh colw))
              (vla-put-Layer tab "AG CAD Tools-COMMUNITY-TABELLE")
              (cti2:sospendi-tabella tab)
              (vla-SetText tab 0 0 "TABELLA COORDINATE VERTICI")
              (vla-MergeCells tab 0 0 0 3)
              (vla-SetText tab 1 0 "N.")
              (vla-SetText tab 1 1 "X")
              (vla-SetText tab 1 2 "Y")
              (vla-SetText tab 1 3 "Z")
              (setq r 2)
              (foreach p verts
                (vla-SetText tab r 0 (itoa (1- r)))
                (vla-SetText tab r 1 (rtos (car p) 2 4))
                (vla-SetText tab r 2 (rtos (cadr p) 2 4))
                (vla-SetText tab r 3 (rtos (if (caddr p) (caddr p) 0.0) 2 4))
                (setq r (1+ r)))
              (vla-put-RegenerateTableSuppressed tab :vlax-false)
              (princ (strcat "\nTabella creata con " (itoa (length verts)) " vertici."))))
          )
        (princ "\nL'oggetto selezionato non contiene vertici leggibili.")))
    (princ "\nNessun oggetto selezionato."))
  (princ))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:crea-cerchio (pt rad layer /)
  (cti2:crea-entita
    (list '(0 . "CIRCLE") '(100 . "AcDbEntity") (cons 8 layer)
          '(100 . "AcDbCircle") (cons 10 pt) (cons 40 rad))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:crea-linea-da-segmento (seg ta tb / p1 p2 a b data c lt lw)
  (setq p1 (nth 1 seg) p2 (nth 2 seg)
        a (cti2c:somma-vettori-2d p1 (cti2c:scala-vettore-2d (cti2c:sottrai-vettori-2d p2 p1) ta))
        b (cti2c:somma-vettori-2d p1 (cti2c:scala-vettore-2d (cti2c:sottrai-vettori-2d p2 p1) tb))
        data (list '(0 . "LINE") '(100 . "AcDbEntity") (cons 8 (nth 3 seg))
                   '(100 . "AcDbLine") (cons 10 (list (car a) (cadr a) (caddr p1)))
                   (cons 11 (list (car b) (cadr b) (caddr p2))))
        c (nth 4 seg) lt (nth 5 seg) lw (nth 6 seg))
  (if c (setq data (append data (list c))))
  (if lt (setq data (append data (list lt))))
  (if lw (setq data (append data (list lw))))
  (cti2:crea-entita data))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2c:crea-lwpoly (pts layer closed) (cti20w:make-lwpoly pts layer closed))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:crea-testo (pt txt ht layer /)
  (cti2:crea-entita
    (list '(0 . "TEXT") '(100 . "AcDbEntity") (cons 8 layer)
          '(100 . "AcDbText") (cons 10 pt) (cons 40 ht) (cons 1 txt))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:dividi-csv (line sep / i quoted ch field out)
  (setq i 1 quoted nil field "" out nil)
  (while (<= i (strlen line))
    (setq ch (substr line i 1))
    (cond
      ((= ch "\"")
       (if (and quoted (< i (strlen line)) (= (substr line (1+ i) 1) "\""))
         (progn (setq field (strcat field "\"")) (setq i (1+ i)))
         (setq quoted (not quoted))))
      ((and (not quoted) (= ch sep))
       (setq out (cons field out) field ""))
      (T (setq field (strcat field ch))))
    (setq i (1+ i)))
  (reverse (cons field out)))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:imposta-elemento-lista (lst idx val / i out x)
  (setq i 0 out nil)
  (foreach x lst
    (setq out (cons (if (= i idx) val x) out) i (1+ i)))
  (reverse out))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:in-lista (value / v r)
  (setq v value)
  (if (= (type v) 'VARIANT) (setq v (vlax-variant-value v)))
  (cond
    ((listp v) v)
    (T
     (setq r (vl-catch-all-apply 'vlax-safearray->list (list v)))
     (if (vl-catch-all-error-p r) nil r))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:intero-rigoroso (s / t0 n)
  (setq t0 (vl-string-trim " \t" s))
  (if (= t0 "")
    nil
    (progn
      (setq n (distof t0 2))
      (if (and n (= n (fix n))) (fix n) nil))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:intersezioni (o1 o2 / r vals out)
  (setq r (vl-catch-all-apply 'vlax-invoke (list o1 'IntersectWith o2 0)))
  (if (vl-catch-all-error-p r)
    nil
    (progn
      (setq vals (cti2c:in-lista r) out nil)
      (while (and vals (>= (length vals) 3))
        (setq out (cons (list (car vals) (cadr vals) (caddr vals)) out)
              vals (cdddr vals)))
      (reverse out))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:lista-stringa (lst / out x)
  (setq out "")
  (foreach x lst
    (setq out (strcat out (if (= out "") "" ", ") (itoa x))))
  out)

; Origine AG CAD Tools: correzioni.lsp
(defun cti2c:parametri-intersezione-segmenti (p p2 q q2 / r s qp den tv u zp zq)
  (setq r (cti2c:sottrai-vettori-2d p2 p) s (cti2c:sottrai-vettori-2d q2 q)
        qp (cti2c:sottrai-vettori-2d q p) den (cti2c:prodotto-vettoriale-2d r s))
  (if (< (abs den) 1e-12) nil
    (progn
      (setq tv (/ (cti2c:prodotto-vettoriale-2d qp s) den)
            u (/ (cti2c:prodotto-vettoriale-2d qp r) den)
            zp (+ (caddr p) (* tv (- (caddr p2) (caddr p))))
            zq (+ (caddr q) (* u (- (caddr q2) (caddr q)))))
      (if (and (>= tv -1e-9) (<= tv (+ 1.0 1e-9)) (>= u -1e-9) (<= u (+ 1.0 1e-9))
               (equal zp zq 1e-8)) (list tv u) nil))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2c:polilinea-rettilinea-p (ename / ed ok x pts flags)
  (setq ed (entget ename) pts (cti20w:lwverts ename) ok (cti2:orizzontale-p pts)
        flags (cdr (assoc 70 (tblsearch "LAYER" (cdr (assoc 8 ed))))))
  (if (/= 0 (logand 4 flags)) (setq ok nil))
  (foreach x ed
    (if (and (member (car x) '(40 41 42 43)) (> (abs (cdr x)) 1e-12)) (setq ok nil)))
  ok)

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:prodotto-vettoriale-2d (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:punti-unici (pts tol / out p q found)
  (setq out nil)
  (foreach p pts
    (setq found nil)
    (foreach q out
      (if (< (distance p q) tol) (setq found T)))
    (if (not found) (setq out (cons p out))))
  (reverse out))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:scala-vettore-2d (a s) (list (* (car a) s) (* (cadr a) s)))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:segmenti-polilinea (ename / verts ed closed layer color ltype lw out i n p1 p2)
  (setq verts (cti2c:vertici-entita ename)
        ed (entget ename)
        closed (= 1 (logand 1 (cdr (assoc 70 ed))))
        layer (cdr (assoc 8 ed))
        color (assoc 62 ed) ltype (assoc 6 ed) lw (assoc 370 ed)
        out nil n (length verts) i 0)
  (while (< i (1- n))
    (setq p1 (nth i verts) p2 (nth (1+ i) verts)
          out (cons (list ename p1 p2 layer color ltype lw '(0.0 1.0)) out)
          i (1+ i)))
  (if (and closed (> n 2))
    (setq out (cons (list ename (nth (1- n) verts) (car verts) layer color ltype lw '(0.0 1.0)) out)))
  (reverse out))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:separatore-csv (line / i quoted ch commas semis)
  (setq i 1 quoted nil commas 0 semis 0)
  (while (<= i (strlen line))
    (setq ch (substr line i 1))
    (cond
      ((= ch "\"")
       (if (and quoted (< i (strlen line)) (= (substr line (1+ i) 1) "\""))
         (setq i (1+ i))
         (setq quoted (not quoted))))
      ((and (not quoted) (= ch ",")) (setq commas (1+ commas)))
      ((and (not quoted) (= ch ";")) (setq semis (1+ semis))))
    (setq i (1+ i)))
  (if (> semis commas) ";" ","))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:somma-vettori-2d (a b) (list (+ (car a) (car b)) (+ (cadr a) (cadr b))))

; Origine AG CAD Tools: cti_community_1_9.lsp
(defun cti2c:sottrai-vettori-2d (a b) (list (- (car a) (car b)) (- (cadr a) (cadr b))))

; Origine AG CAD Tools: correzioni.lsp
(defun cti2c:vertici-entita (ename) (cti20w:lwverts ename))

(setq *CTI-WEB-2-0-VERSION* "2.0-fase2d" *CTI-WEB-2-0-COUNT* 100 *CTI-WEB-2-0-LOADED* T)
(princ)
