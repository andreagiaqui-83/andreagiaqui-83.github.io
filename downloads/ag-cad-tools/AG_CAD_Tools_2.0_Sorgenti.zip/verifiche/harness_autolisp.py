"""Interprete parziale per test logici del sorgente; ActiveX/AutoCAD sono simulati.
Non certifica il comportamento nativo in AutoCAD, la grafica o i DWG.
"""
from dataclasses import dataclass
import math, re, fnmatch
from functools import lru_cache
from lisp_audit import Sym,parse,plain,definitions

@dataclass
class Pair:
    car: object
    cdr: object
@dataclass
class ErrorValue:
    message: str
class LispError(Exception):pass
class Cancelled(LispError):pass
def truth(x):return x is not None and x is not False and x!=[]
def lb(x):return True if x else None
def seq(x):return [] if x is None else x
def car(x):return None if x is None or x==[] else x.car if isinstance(x,Pair) else x[0]
def cdr(x):return None if x is None or x==[] else x.cdr if isinstance(x,Pair) else (x[1:] or None)
def cons(a,b):return [a]+seq(b) if isinstance(b,list) or b is None else Pair(a,b)
def equal(a,b,tol=0):
    if a is None and b==[] or b is None and a==[]:return True
    if isinstance(a,(float,int)) and not isinstance(a,bool) and isinstance(b,(float,int)) and not isinstance(b,bool):return abs(a-b)<=tol
    if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(equal(x,y,tol) for x,y in zip(a,b))
    return a==b
def quoted(x):
    if isinstance(x,list):
        if len(x)>=3 and x[-2]==Sym('.'):
            r=quoted(x[-1])
            for y in reversed(x[:-2]):r=cons(quoted(y),r)
            return r
        return [quoted(y) for y in x]
    if x==Sym('nil'):return None
    if x==Sym('t'):return True
    return x

@lru_cache(maxsize=4)
def cached_definitions(text):
    return {k:plain(v) for k,v in definitions(parse(text)).items()}

class Lisp:
    def __init__(self,text):
        self.defs=dict(cached_definitions(text))
        self.frames=[{'pi':math.pi,':vlax-true':-1,':vlax-false':0}]
        self.output=[];self.calls=[];self.steps=0;self.limit=1000000
        self.native={}
        self.init_native()
    def get(self,key):
        if key=='nil':return None
        if key=='t':return True
        for frame in reversed(self.frames):
            if key in frame:return frame[key]
        return None
    def put(self,key,v):
        for frame in reversed(self.frames):
            if key in frame:frame[key]=v;return v
        self.frames[0][key]=v;return v
    def ev(self,x):
        self.steps+=1
        if self.steps>self.limit:raise LispError('Limite iterazioni harness')
        if isinstance(x,Sym):return self.get(x)
        if not isinstance(x,list):return x
        if not x:return None
        h=x[0];a=x[1:]
        if h in ('quote','function'):return quoted(a[0])
        if h=='if':return self.ev(a[1]) if truth(self.ev(a[0])) else self.ev(a[2]) if len(a)>2 else None
        if h=='setq':
            r=None
            for i in range(0,len(a),2):r=self.put(a[i],self.ev(a[i+1]))
            return r
        if h=='and':
            for v in a:
                if not truth(self.ev(v)):return None
            return True
        if h=='or':
            for v in a:
                if truth(self.ev(v)):return True
            return None
        if h=='cond':
            for v in a:
                r=self.ev(v[0])
                if truth(r):return self.body(v[1:]) if len(v)>1 else r
            return None
        if h=='progn':return self.body(a)
        if h=='defun':self.defs[a[0]]=x;return a[0]
        if h=='while':
            r=None
            while truth(self.ev(a[0])):r=self.body(a[1:])
            return r
        if h=='repeat':
            r=None
            for _ in range(int(self.ev(a[0]))):r=self.body(a[1:])
            return r
        if h in ('foreach','vlax-for'):
            r=None
            for v in seq(self.ev(a[1])):self.put(a[0],v);r=self.body(a[2:])
            return r
        return self.call(h,[self.ev(v) for v in a])
    def body(self,forms):
        r=None
        for f in forms:r=self.ev(f)
        return r
    def call(self,fn,args):
        if isinstance(fn,list) and fn[0]=='lambda':params=fn[1];body=fn[2:]
        elif fn in self.native:return self.native[fn](*args)
        elif fn in self.defs:
            form=self.defs[fn];params=form[2];body=form[3:]
        else:raise LispError('Funzione non implementata nel harness: '+str(fn))
        slash=params.index('/') if '/' in params else len(params)
        if len(args)!=slash:raise LispError(f'Argomenti {fn}: {len(args)} != {slash}')
        frame={k:None for k in params if k!='/'};frame.update(zip(params[:slash],args))
        self.frames.append(frame)
        try:return self.body(body)
        finally:self.frames.pop()
    def init_native(self):
        def catch(fn,args):
            try:return self.call(fn,seq(args))
            except Exception as e:return ErrorValue(str(e))
        def fail():raise Cancelled('quit / exit abort')
        def arithmetic(op,args):
            if any(isinstance(x,bool) or not isinstance(x,(float,int)) for x in args):raise LispError('Numero atteso')
            if op=='+':return sum(args)
            if op=='*':return math.prod(args)
            if op=='-':return -args[0] if len(args)==1 else args[0]-sum(args[1:])
            r=args[0]
            for x in args[1:]:
                if not x:raise LispError('Divisione per zero')
                r=math.trunc(r/x) if isinstance(r,int) and isinstance(x,int) else r/x
            return r
        def compare(op,args):
            if any(x is None or isinstance(x,bool) or isinstance(x,Sym) for x in args):raise LispError('Confronto numerico/stringa non valido')
            cmp={'=':lambda a,b:a==b,'/=':lambda a,b:a!=b,'<':lambda a,b:a<b,'>':lambda a,b:a>b,'<=':lambda a,b:a<=b,'>=':lambda a,b:a>=b}[op]
            return lb(all(cmp(a,b) for a,b in zip(args,args[1:])))
        def assoc(k,lst):return next((x for x in seq(lst) if equal(car(x),k)),None)
        def substr(s,start,length=None):
            if start<1:raise LispError('Indice stringa non valido')
            return s[start-1:] if length is None else s[start-1:start-1+length]
        def search(sub,s,start=0):
            i=s.find(sub,start);return None if i<0 else i
        def sort(lst,fn):
            import functools
            return sorted(seq(lst),key=functools.cmp_to_key(lambda a,b:-1 if truth(self.call(fn,[a,b])) else 1 if truth(self.call(fn,[b,a])) else 0))
        self.native.update({
            'vl-catch-all-apply':catch,'vl-catch-all-error-p':lambda x:lb(isinstance(x,ErrorValue)),
            'vl-catch-all-error-message':lambda x:x.message,'apply':lambda f,a:self.call(f,seq(a)),
            'quit':fail,'not':lambda x:lb(not truth(x)),'null':lambda x:lb(not truth(x)),
            'eq':lambda a,b:lb(equal(a,b)),'equal':lambda a,b,*t:lb(equal(a,b,t[0] if t else 0)),
            'list':lambda *a:list(a) or None,'cons':cons,'car':car,'cdr':cdr,
            'cadr':lambda x:car(cdr(x)),'caddr':lambda x:car(cdr(cdr(x))),
            'cadddr':lambda x:car(cdr(cdr(cdr(x)))),'cddr':lambda x:cdr(cdr(x)),
            'cdddr':lambda x:cdr(cdr(cdr(x))),
            'last':lambda x:seq(x)[-1] if seq(x) else None,
            'length':lambda x:len(seq(x)),'reverse':lambda x:list(reversed(seq(x))) or None,
            'append':lambda *a:sum([seq(x) for x in a],[]) or None,
            'nth':lambda i,x:seq(x)[i] if 0<=i<len(seq(x)) else None,
            'member':lambda x,a:next((seq(a)[i:] for i,v in enumerate(seq(a)) if equal(v,x)),None),
            'assoc':assoc,'subst':lambda new,old,lst:[new if equal(v,old) else v for v in seq(lst)],
            'vl-remove':lambda x,lst:[v for v in seq(lst) if not equal(v,x)] or None,
            'mapcar':lambda f,*a:[self.call(f,list(v)) for v in zip(*[seq(x) for x in a])] or None,
            'vl-some':lambda f,lst:next((r for x in seq(lst) if truth(r:=self.call(f,[x]))),None),
            'vl-sort':sort,'float':float,'fix':math.trunc,'minusp':lambda x:lb(x<0),
            'abs':abs,'sqrt':math.sqrt,'min':min,'max':max,'rem':lambda a,b:a%b,
            '1+':lambda x:x+1,'1-':lambda x:x-1,'sin':math.sin,'cos':math.cos,
            'atan':lambda a,b=None:math.atan(a) if b is None else math.atan2(a,b),
            'distance':lambda a,b:math.dist(a,b),'logand':lambda a,b:a&b,'logior':lambda a,b:a|b,
            'numberp':lambda x:lb(isinstance(x,(int,float)) and not isinstance(x,bool)),
            'listp':lambda x:lb(x is None or isinstance(x,list)),
            'strcat':lambda *x:''.join(x),'strcase':lambda s,*a:s.lower() if a and a[0] else s.upper(),
            'strlen':len,'substr':substr,'vl-string-search':search,'vl-string-trim':lambda chars,s:s.strip(chars),
            'vl-string-translate':lambda a,b,s:s.translate(str.maketrans(a,b)),
            'vl-string->list':lambda s:[ord(c) for c in s], 'itoa':lambda x:str(int(x)),
            'rtos':lambda x,mode=2,dec=6:f'{x:.{dec}f}',
            'vl-princ-to-string':str,
            'princ':lambda *x:self.output.append(x[0]) if x else None,
            'prompt':lambda x:self.output.append(x),
            'wcmatch':lambda s,p:lb(any(fnmatch.fnmatchcase(s,q) for q in p.split(','))),
            'boundp':lambda s:lb(truth(self.get(s))),
            'trans':lambda p,*a:p,
        })
        for op in ('+','-','*','/'):self.native[op]=lambda *a,op=op:arithmetic(op,a)
        for op in ('=','/=','<','>','<=','>='):self.native[op]=lambda *a,op=op:compare(op,a)
