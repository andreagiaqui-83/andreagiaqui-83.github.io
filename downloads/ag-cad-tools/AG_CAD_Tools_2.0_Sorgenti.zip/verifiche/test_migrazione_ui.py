"""Esegue il MNL reale con MenuGroups simulati; non certifica la Ribbon nativa."""
from pathlib import Path
import json,sys
from lisp_audit import parse,plain
from harness_autolisp import Lisp,LispError
R=Path(__file__).resolve().parents[1];source=(R/'release/AGCADTools.bundle/Contents/Win64/AGCADTools.mnl').read_text();results=[]
for initial,fail in [(set(),False),({'CADTOOLSITALIANO'},False),({'AGCADTOOLS'},False),({'AGCADTOOLS','CADTOOLSITALIANO'},False),({'AGCADTOOLS','CADTOOLSITALIANO'},True)]:
 groups=set(initial);events=[];insertions=[];visible=[False];vm=Lisp(source)
 def insert(menus,name,index):
  assert menus==['root','category'] and name=='&AG CAD Tools' and index==''
  assert not visible[0];visible[0]=True;insertions.append(name)
 def unload(g):
  if fail:raise LispError('Menu occupato')
  groups.remove(g);events.append(g)
 vm.native.update({'vl-load-com':lambda:None,'menugroup':lambda g:g if g in groups else None,'vlax-get-acad-object':lambda:'app','vla-get-menugroups':lambda app:'groups','vla-item':lambda gs,g:g,'vla-unload':unload,'vla-get-menus':lambda g:['root','category'],
  'vla-get-namenomnemonic':lambda m:'AG CAD Tools' if m=='root' else 'Disegno',
  'vla-get-name':lambda m:'&AG CAD Tools','vla-get-onmenubar':lambda m:-1 if visible[0] else 0,
  'vla-insertmenuinmenubar':insert})
 record={'iniziale':sorted(initial),'errore_simulato':fail}
 try:
  for form in parse(source):vm.ev(plain(form))
  expected=set(initial)
  if len(initial)==2 and not fail:expected.remove('CADTOOLSITALIANO')
  assert groups==expected and events==(['CADTOOLSITALIANO'] if len(initial)==2 and not fail else [])
  assert len(insertions)==(1 if 'AGCADTOOLS' in initial else 0)
  for form in parse(source):vm.ev(plain(form))
  assert len(insertions)==(1 if 'AGCADTOOLS' in initial else 0),'Menu duplicato'
  if fail:assert any('Menu occupato' in str(v) for v in vm.output)
  record['stato']='PASS'
 except Exception as e:record.update(stato='FAIL',errore=str(e))
 results.append(record)
out={'ambito':'MNL e MenuGroups simulati, non AutoCAD','pass':sum(r['stato']=='PASS' for r in results),'fail':sum(r['stato']=='FAIL' for r in results),'test':results}
(R/'verifiche/ESITO_MIGRAZIONE_UI.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in out.items() if k!='test'});sys.exit(bool(out['fail']))
