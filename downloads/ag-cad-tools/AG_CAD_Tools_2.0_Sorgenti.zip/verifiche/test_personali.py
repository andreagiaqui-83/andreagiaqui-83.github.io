"""Test del sorgente AutoLISP personale con AutoCAD/ActiveX simulati."""
from pathlib import Path
import json,sys,math
from harness_autolisp import Lisp,Sym,Pair,LispError,Cancelled,equal,car,cdr,truth
ROOT=Path(__file__).resolve().parents[1]
W=ROOT/'release/AGCADTools.bundle/Contents/Win64'
TEXT=(W/'ag_runtime_2_0.lsp').read_text()+'\n'+(W/'ag_web_2_0.lsp').read_text()+'\n'+(W/'ag_andrea_2_0.lsp').read_text()
checks=[]
def expect(a,b):
    if not equal(a,b,1e-7):raise AssertionError(f'{a!r} != {b!r}')
def check(name,fn):
    try:fn();checks.append({'test':name,'stato':'PASS'})
    except Exception as e:checks.append({'test':name,'stato':'FAIL','errore':str(e)})
class Mock:
    def __init__(self):
        self.vm=Lisp(TEXT);self.starts=0;self.ends=0;self.deleted=[];self.created=[];self.moved=[];self.layered=[]
        self.vars={k:1 for k in 'CMDECHO OSMODE PDMODE DIMTXT FILEDIA ORTHOMODE SNAPMODE MIRRTEXT TEXTFILL PEDITACCEPT FILLETRAD BACKGROUNDPLOT DIMZIN HPBOUND TRIMMODE'.split()}
        self.vars.update({'CLAYER':'ORIGINALE','UNDOCTL':1,'FILLETRAD':7.5,'TRIMMODE':0})
        self.vm.native.update({'getvar':lambda k:self.vars[k],'setvar':self.setvar,'vlax-get-acad-object':lambda:'app',
            'vla-get-activedocument':lambda a:'doc','vla-startundomark':self.start,'vla-endundomark':self.end,
            'sslength':len,'ssname':lambda s,i:s[i],'vlax-ename->vla-object':lambda e:e,'vlax-3d-point':lambda p:p,
            'vla-copy':self.copy,'vla-delete':self.delete,'vla-move':self.move,
            'vla-put-layer':lambda e,l:self.layered.append((e,l)),
            'vlax-erased-p':lambda e:True if e in self.deleted else None,
            'initget':lambda *a:None})
    def setvar(self,k,v):self.vars[k]=v;return v
    def start(self,d):self.starts+=1
    def end(self,d):self.ends+=1
    def copy(self,e):
        obj='copia'+str(len(self.created)+1);self.created.append(obj);return obj
    def delete(self,e):self.deleted.append(e)
    def move(self,e,a,b):self.moved.append((e,a,b))
    def run(self,fn):self.vm.call('cti2:esegui-comando',['PROVA',Sym(fn)])
    def output(self):return '\n'.join(str(x) for x in self.vm.output)

def pure(fn,args,expected):expect(Lisp(TEXT).call(fn,args),expected)
for side,out in [([2.,4.,9.],[0.,1.,0.]),([2.,-4.,9.],[0.,-1.,0.]),([2.,0.,9.],None)]:
    check('Normale lato '+str(side),lambda side=side,out=out:pure('ctia:normale-lato',[[0.,0.,5.],[10.,0.,5.],side],out))
check('Linea nulla in pianta rifiutata',lambda:pure('ctia:normale-lato',[[1.,1.,0.],[1.,1.,8.],[2.,2.,0.]],None))
check('Offset preserva Z',lambda:pure('ctia:sposta-punto',[[1.,2.,17.],[0.,-1.,0.],3.],[1.,-1.,17.]))
for ds,out in [([1.,2.,3.],True),([3.,1.,2.],True),([1.,1.,2.],None),([0.,1.,2.],None),([-1.,1.,2.],None),([1.,None,None],None)]:
    check('Distanze '+str(ds),lambda ds=ds,out=out:pure('ctia:distanze-valide-p',ds,out))
for mode,out in [('Orizzontale',[3.,20.,7.]),('Verticale',[10.,4.,7.])]:
    check('Allineamento conserva quota: '+mode,lambda mode=mode,out=out:pure('ctia:punto-allineato',[[3.,4.,7.],[10.,20.,2.],mode],out))

def anchor(typ,h,v,expected,omit=False):
    m=Mock();data=[Pair(0,typ),[10,1.,2.,7.],[11,4.,5.,7.]]
    if not omit:data += [Pair(72,h),Pair(73,v)]
    m.vm.native.update({'entget':lambda e:data,'trans':lambda p,*a:[p[0]+100.,p[1],p[2]]})
    expect(m.vm.call('ctia:ancora-testo',['text']),expected)
for name,args in [('TEXT base',('TEXT',0,0,[101.,2.,7.])),('TEXT centrato',('TEXT',1,0,[104.,5.,7.])),('TEXT allineato',('TEXT',3,0,[101.,2.,7.])),('TEXT verticale',('TEXT',0,2,[104.,5.,7.])),('MTEXT WCS',('MTEXT',0,0,[1.,2.,7.])),('Modello non testo',('LINE',0,0,None)),('Codici opzionali assenti',('TEXT',0,0,[101.,2.,7.],True))]:
    check('Ancora '+name,lambda args=args:anchor(*args))

commands={'AG_SOSTITUISCI_CON_MODELLO':'ctia:cmd-sostituisci-con-modello','AG_MURO_STRATIGRAFICO':'ctia:cmd-muro-stratigrafico','AG_UNISCI_INTERSEZIONE':'ctia:cmd-unisci-intersezione','AG_ALLINEA_TESTI':'ctia:cmd-allinea-testi','AG_ELIMINA_QUOTE_TRATTEGGI':'ctia:cmd-elimina-quote-tratteggi'}
def wrapper(cmd,fn,mode):
    m=Mock();before=dict(m.vars)
    def body():
        m.vm.call('cti2:setvar-temporanea',['FILLETRAD',0.]);m.vm.call('cti2:setvar-temporanea',['TRIMMODE',1])
        if mode=='ESC':raise Cancelled('Function cancelled')
        if mode=='errore':raise LispError('Guasto simulato')
    m.vm.native[fn]=body;m.vm.call('c:'+cmd.lower(),[])
    expect(m.vars,before);expect((m.starts,m.ends),(1,1))
    if mode=='errore':assert 'Guasto simulato' in m.output() and cmd in m.output()
    else:assert 'Errore' not in m.output()
for cmd,fn in commands.items():
    for mode in ['successo','ESC','errore']:check(cmd+' / '+mode,lambda cmd=cmd,fn=fn,mode=mode:wrapper(cmd,fn,mode))

def substitute(mode):
    m=Mock()
    def move(e,a,b):
        if mode=='spostamento fallito':raise LispError('Spostamento negato')
        if mode=='ESC dopo copia':raise Cancelled('Function cancelled')
        m.move(e,a,b)
    def delete(e):
        if mode=='cancellazione originale fallita' and e=='originale':raise LispError('Cancellazione negata')
        m.delete(e)
    def body():m.vm.call('ctia:sostituisci-uno',['modello',[0.,0.,3.],'originale',[10.,20.,9.]])
    m.vm.native.update({'prova':body,'vla-move':move,'vla-delete':delete});m.run('prova')
    expect(m.deleted,['originale'] if mode=='successo' else ['copia1']);expect((m.starts,m.ends),(1,1))
    if mode=='successo':expect(m.moved,[('copia1',[0.,0.,3.],[10.,20.,9.])])
for mode in ['successo','spostamento fallito','cancellazione originale fallita','ESC dopo copia']:check('Sostituzione: '+mode,lambda mode=mode:substitute(mode))

def replacement_selection():
    m=Mock();data={e:[Pair(0,'LINE'),Pair(330,'spazio' if e!='altrospazio' else 'altro')] for e in ['modello','valido','bloccato','altrospazio','senza_bbox']}
    m.vm.native.update({'ssget':lambda *a:list(data),'entsel':lambda *a:['modello'],
        'entget':lambda e:data[e],'ctia:entita-modificabile-p':lambda e:None if e=='bloccato' else True,
        'ctia:centro-bbox':lambda e:None if e=='senza_bbox' else [1.,2.,3.]})
    m.run('ctia:cmd-sostituisci-con-modello');expect(m.deleted,['valido']);assert 'sostituiti: 1; ignorati: 4' in m.output()
check('Sostituzione esclude modello, layer bloccato, altro spazio e bbox assente',replacement_selection)

def wall(mode):
    m=Mock();layers=[];lines=[]
    def assure(name):layers.append(name);return name
    def make(data):
        if mode=='seconda linea fallita' and len(lines)==1:raise LispError('Creazione negata')
        lines.append(data);return 'linea'+str(len(lines))
    def put(e,l):
        if mode=='layer base fallito':raise LispError('Layer negato')
        m.layered.append((e,l))
    m.vm.native.update({'ctia:assicura-layer':assure,'cti2:crea-entita':make,'vla-put-layer':put,
      'prova':lambda:m.vm.call('ctia:crea-strati',['base',[0.,0.,7.],[10.,0.,9.],[0.,1.,0.],[1.,2.,3.]])})
    m.run('prova')
    if mode=='successo':
        expect(m.deleted,[]);expect(len(lines),3);expect(m.layered,[('base','Muro_Finitura_1_Num_Penna__156')])
        for i,data in enumerate(lines):
            by={car(x):cdr(x) for x in data};expect(by[10],[0.,i+1.,7.]);expect(by[11],[10.,i+1.,9.]);expect(by[8],layers[i+1])
    else:expect(set(m.deleted),{'linea1'} if mode=='seconda linea fallita' else {'linea1','linea2','linea3'});expect(m.layered,[])
for mode in ['successo','seconda linea fallita','layer base fallito']:check('Muro: '+mode,lambda mode=mode:wall(mode))

def wall_enter():
    m=Mock();m.vm.native.update({'getdist':lambda *a:None,'entsel':lambda *a:(_ for _ in ()).throw(AssertionError('Selezione non prevista'))})
    m.run('ctia:cmd-muro-stratigrafico');expect(m.created,[]);assert 'Errore' not in m.output()
check('Muro: INVIO alla prima distanza termina senza selezione',wall_enter)

def fillet(mode):
    m=Mock();old=dict(m.vars);selection=iter([['a'],['a','b'],None]);changes=[];calls=[]
    def cmd(*args):
        calls.append(args)
        if mode=='ESC':raise Cancelled('Function cancelled')
        if mode=='errore':raise LispError('Non complanari')
        if mode=='modifica':changes.append('a')
    m.vm.native.update({'ssget':lambda *a:next(selection),'ctia:entita-modificabile-p':lambda e:True,
        'entget':lambda e:[Pair(0,'LINE'),Pair(90,1 if e in changes else 0)],'command-s':cmd})
    m.run('ctia:cmd-unisci-intersezione');expect(calls,[('_.FILLET','a','b')]);expect(m.vars,old);expect((m.starts,m.ends),(1,1))
    if mode=='nessuna modifica':assert 'Nessuna modifica alla coppia' in m.output()
    if mode=='ESC':assert 'Errore' not in m.output()
    if mode=='errore':assert 'Non complanari' in m.output()
for mode in ['modifica','nessuna modifica','ESC','errore']:check('Unisci: '+mode,lambda mode=mode:fillet(mode))

def deletion(answer,failed=False):
    m=Mock();types={'quota':'DIMENSION','tratteggio':'HATCH','bloccato':'HATCH'};deleted=[]
    def remove(e):
        if failed and e=='quota':return None
        deleted.append(e);return e
    m.vm.native.update({'ssget':lambda *a:list(types),'entget':lambda e:[Pair(0,types[e])],
        'ctia:entita-modificabile-p':lambda e:None if e=='bloccato' else True,'getkword':lambda *a:answer,'entdel':remove})
    m.run('ctia:cmd-elimina-quote-tratteggi')
    expect(deleted,(['tratteggio'] if failed else ['quota','tratteggio']) if answer=='Si' else [])
    assert 'modello e tutti i layout' in m.output()
    if failed:assert 'eliminati: 1; non eliminati: 1' in m.output()
for answer in [None,'No','Si']:check('Elimina quote/tratteggi: '+str(answer),lambda answer=answer:deletion(answer))
check('Eliminazione fallita non conteggiata come riuscita',lambda:deletion('Si',True))

def alignment():
    m=Mock();positions={'modello':[10.,20.,5.],'testo':[1.,2.,7.],'mtext':[3.,4.,9.],'locked':[7.,8.,11.]}
    m.vm.native.update({'entsel':lambda *a:['modello'],'ctia:ancora-testo':lambda e:positions[e],
       'ssget':lambda *a:list(positions),'ctia:entita-modificabile-p':lambda e:None if e=='locked' else True,
       'getkword':lambda *a:'Orizzontale'})
    m.run('ctia:cmd-allinea-testi');expect(m.moved,[('testo',[1.,2.,7.],[1.,20.,7.]),('mtext',[3.,4.,9.],[3.,20.,9.])])
check('Allinea testi: modello e bloccati esclusi, quote individuali conservate',alignment)
def locked_model():
    m=Mock()
    m.vm.native.update({'ssget':lambda *a:['target'],'entsel':lambda *a:['modello'],
        'ctia:centro-bbox':lambda e:[0.,0.,0.],'entget':lambda e:[Pair(0,'LINE'),Pair(330,'spazio')],
        'ctia:entita-modificabile-p':lambda e:None})
    m.run('ctia:cmd-sostituisci-con-modello');expect(m.created,[]);expect(m.deleted,[])
    assert 'modello non utilizzabile' in m.output()
check('Modello su layer bloccato: nessuna copia provvisoria creata',locked_model)
result={'tipo':'Esecuzione logica LISP con API simulate; NON collaudo AutoCAD',
 'scenari_wrapper_personali':15,'test':checks,'pass':sum(x['stato']=='PASS' for x in checks),'fail':sum(x['stato']=='FAIL' for x in checks)}
(ROOT/'verifiche/ESITO_TEST_PERSONALI.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
