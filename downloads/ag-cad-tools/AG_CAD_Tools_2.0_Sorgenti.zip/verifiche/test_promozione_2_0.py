"""Confronto con la RC5 approvata: ammesse soltanto le modifiche dichiarate."""
from pathlib import Path
import hashlib,json,re,sys,zipfile
import xml.etree.ElementTree as ET
from lisp_audit import parse,plain
R=Path(__file__).resolve().parents[1];B=R/'baseline_rc5';W=R/'release/AGCADTools.bundle/Contents/Win64';OLD=B/'AGCADTools.bundle/Contents/Win64';checks=[]
def require(v,msg=''):assert v,msg
def test(n,fn):
    try:fn();checks.append({'test':n,'stato':'PASS'})
    except Exception as e:checks.append({'test':n,'stato':'FAIL','errore':str(e)})
def normalize(x):
    if isinstance(x,list):return [normalize(v) for v in x]
    if type(x)==str:return x.replace('2.0 RC5','2.0').replace('RC5 indica','La versione 2.0 indica').replace('Candidata al collaudo nativo.','Versione definitiva 2.0.')
    return x
def lisp():
    old={p.name for p in OLD.glob('*.lsp')}|{'AGCADTools.mnl'}
    new={p.name for p in W.glob('*.lsp')}|{'AGCADTools.mnl'}
    require(old==new)
    for n in old:
        a=normalize([plain(f) for f in parse((OLD/n).read_text())]);b=[plain(f) for f in parse((W/n).read_text())]
        require(a==b,n)
test('Tutte le forme LISP/MNL identiche alla RC5 salvo etichette versione/stato; nessuna logica modificata',lisp)
test('Manuale sorgente identico alla RC5',lambda:require((B/'manuale_comandi.tsv').read_bytes()==(R/'sorgenti/manuale_comandi.tsv').read_bytes()))
def cards():
    a=re.findall(r'<article\b.*?</article>',(OLD/'AG_CAD_Tools_Help.html').read_text(),re.S)
    b=re.findall(r'<article\b.*?</article>',(W/'AG_CAD_Tools_Help.html').read_text(),re.S)
    require(len(a)==200 and a==b)
test('Tutte le 200 schede HTML preservate integralmente',cards)
def installer():
    for n in ['installer_common.go','installer_migration.go','installer_main.go','installer_ui_design.go']:
        expected=(B/n).read_text().replace('AGCADToolsInstaller20RC4','AGCADToolsInstaller20').replace('2.0  ·  RC5','VERSIONE 2.0')
        require(expected==(R/'sorgenti'/n).read_text(),n)
test('Installer RC5 identico salvo badge e nome privato della classe finestra; flussi e motore preservati',installer)
test('Dialogo DCL identico salvo versione',lambda:require((OLD/'ag_cad_tools.dcl').read_text().replace('2.0 RC5','2.0')==(W/'ag_cad_tools.dcl').read_text()))
def ui():
    with zipfile.ZipFile(OLD/'AGCADTools.cuix') as a,zipfile.ZipFile(W/'AGCADTools.cuix') as b:
        require(a.namelist()==b.namelist())
        for n in a.namelist():
            expected=a.read(n).replace(b'2.0 RC5',b'2.0') if n.endswith(('.cui','.xml')) else a.read(n)
            require(expected==b.read(n),n)
    old={p.name:p.read_bytes() for p in OLD.glob('*.png')};new={p.name:p.read_bytes() for p in W.glob('*.png')}
    require(old==new)
test('CUIX e tutte le icone preservati salvo eventuale etichetta versione',ui)
def package():
    a=ET.parse(B/'AGCADTools.bundle/PackageContents.xml').getroot();b=ET.parse(W.parents[1]/'PackageContents.xml').getroot()
    require(a.get('UpgradeCode')==b.get('UpgradeCode'))
    require(tuple(map(int,b.get('AppVersion').split('.')))>tuple(map(int,a.get('AppVersion').split('.'))))
    require(b.get('AppVersion')=='2.0.0.6' and a.get('ProductCode')!=b.get('ProductCode'))
    require(ET.tostring(a.find('Components'))==ET.tostring(b.find('Components')))
test('Metadati release crescenti, UpgradeCode e registrazione comandi preservati',package)
def labels():
    for n in ['ag_bootstrap_2_0.lsp','ag_diagnostica_2_0.lsp','ag_cad_tools.dcl','AG_CAD_Tools_Sostieni.html']:
        s=(W/n).read_text();require(not re.search(r'\bRC[1-5]\b|%20RC[1-5]\b|Candidata al collaudo',s),n)
test('Nessuna etichetta candidata nelle superfici attive; collegamenti supporto aggiornati',labels)
result={'ambito':'Promozione RC5 approvata a versione definitiva 2.0','test':checks,'pass':sum(x['stato']=='PASS' for x in checks),'fail':sum(x['stato']=='FAIL' for x in checks)}
(R/'verifiche/ESITO_PROMOZIONE_2_0.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
