"""Correzioni RC4: LISP reale con geometria/API di test, non AutoCAD nativo."""
from pathlib import Path
import json,sys,math
from harness_autolisp import Lisp,LispError
R=Path(__file__).resolve().parents[1];W=R/'release/AGCADTools.bundle/Contents/Win64'
text='\n'.join(p.read_text() for p in W.glob('*.lsp'));checks=[]
def check(name,fn):
 try:fn();checks.append({'test':name,'stato':'PASS'})
 except Exception as e:checks.append({'test':name,'stato':'FAIL','errore':str(e)})
def overlap(dim,value,expected):
 vm=Lisp(text);got=vm.call('ag:passo-tassello',[dim,value]);assert abs(got-expected)<1e-8,(got,expected)
for dim,ov,expected in [(10,1,9),(10,0,10),(10,10,10),(10,15,10),(10,-1,10),(10,None,10),(.2,.05,.15)]:
 check(f'Passo raster {dim}/{ov}',lambda d=dim,v=ov,e=expected:overlap(d,v,e))

def layouts(model):
 vm=Lisp(text);lays=[{'name':model,'model':-1},{'name':'Tavola 1','model':0},{'name':'Sheet A','model':0}];copied=[]
 vm.native.update({'vlax-get-acad-object':lambda:'app','vla-get-activedocument':lambda a:'doc',
   'vla-get-layouts':lambda d:lays,'vla-get-name':lambda l:l['name'],'vla-get-modeltype':lambda l:l['model'],
   'ssget':lambda *a:['ent'],'sslength':len,'ssname':lambda a,i:a[i],
   'vlax-make-safearray':lambda *a:[None],'vlax-safearray-put-element':lambda arr,i,v:arr.__setitem__(i,v),
   'vlax-ename->vla-object':lambda e:e,'vla-get-block':lambda l:l['name'],
   'vla-copyobjects':lambda d,arr,blk:copied.append(blk) or True})
 assert vm.call('cti:layout-name-list',[])==['Tavola 1','Sheet A']
 vm.call('cti2c:cmd-copia-su-layout',[])
 assert copied==['Tavola 1','Sheet A'],copied
for name in ['Model','Modello','Modell']:
 check('Layout indipendente dalla lingua: '+name,lambda n=name:layouts(n))

# Mirror restituisce nuove entità, conserva le sorgenti finché Delete non è richiesto.
# Verifichiamo cardinalità, coordinate, registrazione temporanei e un errore a metà.
def mirrors(fail=False):
 vm=Lisp(text);entities={'a':[2.,3.,0.],'b':[4.,5.,0.],'estraneo':[9.,9.,0.]};temps=[];seq=0
 def mirror(e,a,b):
  nonlocal seq
  if fail and e=='b':raise LispError('Mirror negato')
  seq+=1;p=entities[e];vx=b[0]-a[0];vy=b[1]-a[1];t=((p[0]-a[0])*vx+(p[1]-a[1])*vy)/(vx*vx+vy*vy)
  q=[2*(a[0]+t*vx)-p[0],2*(a[1]+t*vy)-p[1],p[2]];name='nuovo'+str(seq);entities[name]=q;return name
 def add(e=None,ss=None):
  if ss is None:ss=[]
  if e is not None:ss.append(e)
  return ss
 vm.native.update({'ssadd':add,'sslength':len,'ssname':lambda a,i:a[i],
   'vlax-ename->vla-object':lambda e:e,'vlax-vla-object->ename':lambda e:e,'vlax-3d-point':lambda p:p,
   'vla-mirror':mirror,'vla-delete':lambda e:entities.pop(e),'cti2:oggetto-provvisorio':lambda e:temps.append(e) or e})
 try:r=vm.call('ag:specchia-selezione',[['a','b'],[0.,0.,0.],[0.,10.,0.],True])
 except LispError:
  assert fail
  # Il runtime possiede la copia già creata; quella ancora non specchiata resta intatta.
  assert len(temps)==1 and 'b' in entities and entities['b']==[4.,5.,0.]
  for e in temps:entities.pop(e,None)
  assert set(entities)=={'b','estraneo'};return
 assert not fail and len(r)==2 and set(r)==set(temps)
 assert len(entities)==3 and entities[r[0]]==[-2.,3.,0.] and entities[r[1]]==[-4.,5.,0.]
 final=vm.call('ag:specchia-selezione',[r,[0.,0.,0.],[0.,10.,0.],None])
 assert len(final)==2 and len(entities)==3 and entities[final[0]]==[2.,3.,0.] and entities[final[1]]==[4.,5.,0.]
 assert len(temps)==2 and entities['estraneo']==[9.,9.,0.]
check('WMF: doppia specchiatura senza copie residue e geometria ripristinata',mirrors)
check('WMF: errore parziale conserva sorgente non elaborata e traccia i temporanei',lambda:mirrors(True))
result={'ambito':'LISP reale / API e geometria simulate','test':checks,'pass':sum(x['stato']=='PASS' for x in checks),'fail':sum(x['stato']=='FAIL' for x in checks)}
(R/'verifiche/ESITO_RC4.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
