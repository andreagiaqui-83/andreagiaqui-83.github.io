"""Gate 2.0 documentale e compatibilità statica; non esegue AutoCAD o Windows."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,subprocess,sys,xml.etree.ElementTree as ET
from lisp_audit import parse,definitions,head,Sym
R=Path(__file__).resolve().parents[1];W=R/'release/AGCADTools.bundle/Contents/Win64';V=R/'verifiche'
checks=[]
def check(name,fn):
    try:fn();checks.append({'controllo':name,'stato':'PASS'})
    except Exception as e:checks.append({'controllo':name,'stato':'FAIL','errore':str(e)})
def require(value,detail=''):
    assert value,detail
def nodes(n):
    yield n
    if isinstance(n.value,list):
        for x in n.value:yield from nodes(x)
class Page(HTMLParser):
    def __init__(self,path):
        super().__init__();self.ids=[];self.links=[];self.cards=[];self.card=None;self.scripts=[];self.script=None;self.h4=0;self.feed(path.read_text())
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        for k in ['href','src']:
            if k in a:self.links.append(a[k])
        if tag=='article' and 'card' in a.get('class','').split():self.card={'id':a['id'],'text':'','sections':0};self.cards.append(self.card)
        if tag=='h4' and self.card is not None:self.card['sections']+=1
        if tag=='script':self.script=''
    def handle_data(self,data):
        if self.card is not None:self.card['text']+=data+' '
        if self.script is not None:self.script+=data
    def handle_endtag(self,tag):
        if tag=='article':self.card=None
        if tag=='script' and self.script is not None:self.scripts.append(self.script);self.script=None

reg=json.loads((R/'REGISTRO_UI_2_0.json').read_text());guide=Page(W/'AG_CAD_Tools_Help.html')
check('200 schede, 198 strumenti e 2 servizi; nessun ID duplicato',lambda:require(len(guide.cards)==200 and {c['id'] for c in guide.cards}=={r['command'] for r in reg} and len(guide.ids)==len(set(guide.ids))))
check('Quattro sezioni esplicative presenti in ogni scheda',lambda:require(all(c['sections']==4 for c in guide.cards)))
def manual():
    rows=[x.split('|') for x in (R/'sorgenti/manuale_comandi.tsv').read_text().splitlines()]
    require(len(rows)==200 and {int(r[0]) for r in rows}==set(range(1,201)))
    require(all(len(r)==5 and all(bool(v.strip()) for v in r[1:]) for r in rows),'Sezione mancante')
check('Manuale sorgente: 200 ID univoci, preparazione/procedura/limiti/esempio non vuoti',manual)
def links():
    for f in W.glob('*.html'):
        page=Page(f);require(len(page.ids)==len(set(page.ids)),f.name)
        for raw in page.links:
            u=urlsplit(raw)
            if u.scheme or u.netloc:continue
            target=f.parent/unquote(u.path) if u.path else f
            require(target.is_file(),f'{f.name} -> {raw}')
            if u.fragment and target.suffix=='.html':require(unquote(u.fragment) in Page(target).ids,raw)
check('Guide e supporto: risorse e ancore locali valide',links)
def search():
    # Esegue il vero script di ricerca su un DOM minimo; non verifica layout browser.
    cards=[dict(textContent=c['text'],hidden=False) for c in guide.cards]
    code='''const assert=require('node:assert/strict');
const input={value:'',addEventListener:(e,f)=>input.listener=f,focus:()=>{}};
const clear={addEventListener:(e,f)=>clear.listener=f};const count={textContent:''};
const cdata=CARDS;const categories=[{hidden:false,querySelectorAll:()=>cdata}];
global.document={getElementById:id=>({q:input,clear,count}[id]),querySelectorAll:s=>s==='.card'?cdata:categories};
SCRIPT
for(const term of ['muro stratigrafico','CTI_DIAGNOSTICA','WMF','polilinee','zz_non_esiste_zz']){
 input.value=term;input.listener();const expected=cdata.filter(c=>c.textContent.toLocaleLowerCase('it').includes(term.toLocaleLowerCase('it'))).length;
 assert.equal(cdata.filter(c=>!c.hidden).length,expected);assert.equal(count.textContent,expected+' schede visibili');assert.equal(categories[0].hidden,expected===0);
}
clear.listener();assert.equal(cdata.filter(c=>!c.hidden).length,200);assert.equal(input.value,'');
'''.replace('SCRIPT','\n'.join(guide.scripts)).replace('CARDS',json.dumps(cards,ensure_ascii=False))
    p=subprocess.run(['node','--input-type=commonjs'],input=code,text=True,capture_output=True);require(p.returncode==0,p.stderr)
check('Ricerca reale della guida: nomi, alias, testo, zero risultati e reset (DOM simulato)',search)

D={};S={};F={};calls=[];unprefixed=[];security=[]
native={'command','command-s','vl-cmdf'}
for f in sorted(W.glob('*.lsp')):
    source=f.read_text(encoding='utf-8-sig');forms=parse(source)
    for k,v in definitions(forms).items():D[k]=v;S[k]=source;F[k]=f.name
    for root in forms:
        for n in nodes(root):
            h=head(n);arg=None;kind=None
            if h in native:
                kind='diretta';arg=n.value[1] if len(n.value)>1 else None
            elif h in ('apply','vl-catch-all-apply') and len(n.value)>2:
                fn=n.value[1]
                if head(fn)=='quote' and fn.value[1].value in native:
                    kind='apply';seq=n.value[2]
                    if head(seq)=='list' and len(seq.value)>1:arg=seq.value[1]
                    elif head(seq)=='append' and len(seq.value)>1 and head(seq.value[1])=='list':arg=seq.value[1].value[1]
            if kind:
                literal=arg.value if arg and type(arg.value)==str else None
                calls.append({'file':f.name,'riga':n.line,'tipo':kind,'comando':literal,'codice':source[n.start:n.end]})
                if literal and not literal.startswith(('_.','._')):unprefixed.append(calls[-1])
            if h in ('setvar','cti2:setvar-temporanea') and len(n.value)>1 and type(n.value[1].value)==str and n.value[1].value.upper() in ('SECURELOAD','LISPSYS','TRUSTEDPATHS'):
                security.append(source[n.start:n.end])
(V/'CHIAMATE_NATIVE.txt').write_text('Inventario statico 2.0: chiamate dirette e tramite apply; non esecuzione nativa.\n\n'+'\n\n'.join(f"{c['file']}:{c['riga']} [{c['tipo']}] {c['codice']}" for c in calls))
(V/'INVENTARIO_COMPATIBILITA.json').write_text(json.dumps({'chiamate':calls,'dinamiche':[c for c in calls if c['comando'] is None],'non_internazionali':unprefixed,'modifiche_sicurezza':security,'limite':'Prefissi e sorgenti controllati; sequenze dei prompt e API native da collaudare per versione/lingua.'},ensure_ascii=False,indent=2)+'\n')
check('Tutti i nomi letterali delle chiamate native dirette/apply hanno prefisso internazionale',lambda:require(not unprefixed,unprefixed))
check('Nessuna assegnazione diretta a SECURELOAD, LISPSYS o TRUSTEDPATHS',lambda:require(not security,security))
def manifest():
    root=ET.parse(W.parents[1]/'PackageContents.xml').getroot();req=root.find('.//RuntimeRequirements')
    require(root.get('AppVersion')=='2.0.0.6')
    require(req.get('SeriesMin')=='R24.3' and req.get('SeriesMax')=='R26.0' and req.get('OS')=='Win64' and req.get('Platform')=='AutoCAD',req.attrib)
check('Manifest: 2.0 e perimetro AutoCAD 2024–2027 Win64 completo',manifest)
def snapshots():
    rows=[]
    for r in reg:
        name='c:'+r['command'].lower();n=D[name];wrappers=[x for x in nodes(n) if head(x)=='cti2:esegui-comando']
        targets=[str(x.value) for x in nodes(wrappers[0].value[2]) if isinstance(x.value,Sym) and x.value in D] if wrappers else [name]
        targets=list(dict.fromkeys(targets));rows.append(dict(r,targets=targets,body='\n'.join(S[t][D[t].start:D[t].end] for t in targets),files=[F[t] for t in targets]))
    (V/'COMANDI_REVISIONE.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    require(len(rows)==200 and all(r['body'] for r in rows))
check('Registro della revisione aggiornato ai corpi reali 2.0 dei 200 ingressi',snapshots)
def branding():
    s=(R/'sorgenti/installer_ui_design.go').read_text();require('AG CAD TOOLS' in s and 'andreagiaquinto.it' in s)
    for f in [W/'AG_CAD_Tools_Help.html',W/'AG_CAD_Tools_Compatibilita.html']:
        s=f.read_text();require('2.0' in s and '198' in s and '541' in s,f.name)
check('Testata, sito e documentazione con identità/versione coerenti',branding)
check('La ricerca e tutte le 200 schede precedono installazione e compatibilità', lambda:require((W/'AG_CAD_Tools_Help.html').read_text().index('id="q"') < (W/'AG_CAD_Tools_Help.html').read_text().index('id="cat-0"') < (W/'AG_CAD_Tools_Help.html').read_text().index('id="installazione"') and (W/'AG_CAD_Tools_Help.html').read_text().rindex('</article>') < (W/'AG_CAD_Tools_Help.html').read_text().index('id="installazione"')))
result={'ambito':'Verifica statica/documentale; ricerca JS con DOM simulato','test':checks,'chiamate_native_inventariate':len(calls),'chiamate_dinamiche':sum(c['comando'] is None for c in calls),'pass':sum(c['stato']=='PASS' for c in checks),'fail':sum(c['stato']=='FAIL' for c in checks)}
(V/'ESITO_RELEASE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
