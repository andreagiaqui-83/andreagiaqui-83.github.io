from pathlib import Path
import json,sys
from harness_autolisp import Lisp,Sym,Cancelled,LispError,ErrorValue,truth,equal,Pair,cdr

ROOT=Path(__file__).resolve().parents[1]
W=ROOT/'release/AGCADTools.bundle/Contents/Win64'
TEXT=(W/'ag_runtime_2_0.lsp').read_text()+'\n'+(W/'ag_web_2_0.lsp').read_text()+'\n'+(W/'ag_andrea_2_0.lsp').read_text()
checks=[]
def check(name,fn):
    try:
        fn();checks.append({'test':name,'stato':'PASS'})
    except Exception as e:checks.append({'test':name,'stato':'FAIL','errore':str(e)})
def expect(a,b):
    if not equal(a,b,1e-7):raise AssertionError(f'{a!r} != {b!r}')

class RuntimeMock:
    def __init__(self):
        self.vm=Lisp(TEXT);self.starts=0;self.ends=0
        self.vars={x:0 for x in ('CMDECHO OSMODE PDMODE DIMTXT FILEDIA ORTHOMODE SNAPMODE MIRRTEXT TEXTFILL PEDITACCEPT FILLETRAD BACKGROUNDPLOT DIMZIN HPBOUND').split()}
        self.vars.update({'CLAYER':'ORIGINALE','UNDOCTL':1,'CVPORT':2,'CTAB':'Layout1'})
        self.files={'/export.csv':'PRECEDENTE'};self.handles={};self.counter=0;self.rename_fail=False
        self.vm.native.update({'getvar':lambda k:self.vars[k], 'setvar':self.setvar,
            'vlax-get-acad-object':lambda:'app','vla-get-activedocument':lambda a:'doc',
            'vla-startundomark':self.start,'vla-endundomark':self.end,
            'open':self.open,'close':self.close,'write-line':self.write,
            'vl-filename-directory':lambda p:p.rsplit('/',1)[0] or '/',
            'vl-filename-mktemp':self.temp,'findfile':lambda p:p if p in self.files else None,
            'vl-file-delete':self.delete,'vl-file-rename':self.rename})
    def setvar(self,k,v):self.vars[k]=v;return v
    def start(self,d):self.starts+=1
    def end(self,d):self.ends+=1
    def open(self,p,m):
        self.counter+=1;self.handles[self.counter]=p
        if m=='w':self.files[p]=''
        return self.counter
    def close(self,h):
        if h not in self.handles:raise LispError('File già chiuso')
        del self.handles[h]
    def write(self,s,h):self.files[self.handles[h]]+=s+'\n';return s
    def temp(self,prefix,d,ext):self.counter+=1;return '/'+prefix+str(self.counter)+ext
    def delete(self,p):
        if p in self.files:del self.files[p];return True
        return None
    def rename(self,a,b):
        if self.rename_fail and a.endswith('.tmp'):return None
        if b in self.files or a not in self.files:return None
        self.files[b]=self.files.pop(a);return True
    def body(self,mode):
        def f():
            v=self.vm
            v.call('cti2:setvar-temporanea',['DIMTXT',99.0])
            v.call('cti2:setvar-finale',['CLAYER','NUOVO'])
            h=v.call('cti2:apri-file',['/export.csv','w'])
            v.call('write-line',['NUOVO',h])
            if mode=='cancel':raise Cancelled('Function cancelled')
            if mode=='error':raise LispError('Guasto simulato')
            v.call('cti2:chiudi-file',[h])
            return True
        return f

wrappers=json.loads((ROOT/'provenienza/MAPPA_WEB.json').read_text())['wrapper']
wrappers={('AG_'+k[4:] if k.startswith('CTI_') else k):v for k,v in wrappers.items()}
def wrapper_scenario(cmd,fn,mode):
    m=RuntimeMock(); m.vm.native[fn]=m.body(mode)
    m.vm.call('c:'+cmd.lower(),[])
    expect(m.vars['DIMTXT'],0);expect((m.starts,m.ends),(1,1));expect(m.handles,{})
    expect(m.vars['CLAYER'],'NUOVO' if mode=='success' else 'ORIGINALE')
    expect(m.files,{'/export.csv':'NUOVO\n' if mode=='success' else 'PRECEDENTE'})
    out='\n'.join(str(x) for x in m.vm.output)
    if mode=='error':assert cmd in out and 'Guasto simulato' in out
    else:assert 'Errore' not in out
for mode in ('success','cancel','error'):
    def all_wrappers(mode=mode):
        for cmd,fn in wrappers.items():wrapper_scenario(cmd,fn,mode)
    check('100 wrapper: '+mode,all_wrappers)

def foreign_undo():
    m=RuntimeMock();m.vars['UNDOCTL']=9;m.vm.native['prova']=lambda:True
    m.vm.call('cti2:esegui-comando',['PROVA',Sym('prova')]);expect((m.starts,m.ends),(0,0))
check('Gruppo UNDO esterno non chiuso',foreign_undo)
def disabled_undo():
    m=RuntimeMock();m.vars['UNDOCTL']=0;m.vm.native['prova']=lambda:True
    m.vm.call('cti2:esegui-comando',['PROVA',Sym('prova')]);expect((m.starts,m.ends),(0,0))
check('UNDO disabilitato rispettato',disabled_undo)
def rename_failure():
    m=RuntimeMock();m.rename_fail=True;m.vm.native['prova']=m.body('success')
    m.vm.call('cti2:esegui-comando',['PROVA',Sym('prova')]);expect(m.files,{'/export.csv':'PRECEDENTE'})
    expect(m.vars['CLAYER'],'ORIGINALE');expect(m.handles,{})
    assert any('Pubblicazione' in str(x) for x in m.vm.output)
check('Esportazione fallita ripristina file precedente',rename_failure)
def cleanup_failure():
    m=RuntimeMock()
    def body():
        m.vm.call('cti2:registra-cleanup',[Sym('non_esiste'),None])
        m.vm.call('cti2:setvar-temporanea',['DIMTXT',3])
    m.vm.native['prova']=body
    m.vm.call('cti2:esegui-comando',['PROVA',Sym('prova')]);expect(m.vars['DIMTXT'],0);expect(m.ends,1)
    assert any('Avviso PROVA' in str(x) for x in m.vm.output)
check('Errore cleanup visibile; ripristini successivi eseguiti',cleanup_failure)
def cleanup_idempotent():
    m=RuntimeMock()
    def body():m.vm.call('cti2:cleanup',[None]);m.vm.call('cti2:cleanup',[None])
    m.vm.native['prova']=body;m.vm.call('cti2:esegui-comando',['PROVA',Sym('prova')]);expect(m.ends,1)
check('Cleanup idempotente',cleanup_idempotent)

v=Lisp(TEXT)
check('Ultimo vertice preservato',lambda:expect(v.call('last',[[[0,0,0],[4,5,6]]]),[4,5,6]))
for x,step,out in [(-1.6,1,-2),(-1.4,1,-1),(-1.5,1,-2),(1.5,1,2),(0,0.005,0)]:
    check(f'Arrotondamento {x}/{step}',lambda x=x,step=step,out=out:expect(v.call('cti20w:round-nearest',[x,step]),out))
square=[[0.,0.,7.],[10.,0.,7.],[10.,10.,7.],[0.,10.,7.]]
check('Centroide conserva Z',lambda:expect(v.call('cti20w:poly-centroid',[square]),[5.,5.,7.]))
check('Centroide orientamento inverso',lambda:expect(v.call('cti20w:poly-centroid',[square[::-1]]),[5.,5.,7.]))
check('Punto interno',lambda:expect(v.call('cti20w:point-in-poly',[[5.,5.,7.],square]),True))
check('Punto esterno',lambda:expect(v.call('cti20w:point-in-poly',[[15.,5.,7.],square]),None))
cases=[('interno',[2.,2.,7.],[3.,3.,7.],'interno'),('esterno',[12.,2.,7.],[13.,3.,7.],'esterno'),
       ('bordo',[0.,2.,7.],[3.,3.,7.],'incerto'),('attraversamento',[-1.,2.,7.],[11.,3.,7.],'incerto'),
       ('avvolge',[-1.,-1.,7.],[11.,11.,7.],'incerto'),('quota diversa',[2.,2.,8.],[3.,3.,8.],'incerto'),
       ('punto interno',[2.,2.,7.],[2.,2.,7.],'interno')]
for name,mn,mx,expected in cases:
    check('Classificazione '+name,lambda mn=mn,mx=mx,expected=expected:expect(v.call('cti2:classe-riquadro',[mn,mx,square]),Sym(expected)))
concave=[[0.,0.,0.],[10.,0.,0.],[10.,10.,0.],[6.,10.,0.],[6.,4.,0.],[4.,4.,0.],[4.,10.,0.],[0.,10.,0.]]
check('Concavità non scambiata per interno',lambda:expect(v.call('cti2:classe-riquadro',[[2.,2.,0.],[8.,8.,0.],concave]),Sym('incerto')))
check('Poligono semplice',lambda:expect(v.call('cti20w:self-intersect-p',[square,True]),None))
check('Poligono incrociato',lambda:expect(v.call('cti20w:self-intersect-p',[[[0.,0.,0.],[10.,10.,0.],[0.,10.,0.],[10.,0.,0.]],True]),True))
check('Catena aperta incrocio primo ultimo segmento',lambda:expect(v.call('cti20w:self-intersect-p',[[[0.,0.,0.],[10.,10.,0.],[0.,10.,0.],[10.,0.,0.]],None]),True))
check('CSV separatore ignora virgole quotate',lambda:expect(v.call('cti20w:csv-sep',['"a,b,c,d";1;2']),';'))
check('CSV campi quotati e virgolette',lambda:expect(v.call('cti20w:csv-split',['"a;b";"x""y";3',';']),['a;b','x"y','3']))
check('MTEXT paragrafi/formati',lambda:expect(v.call('cti20w:strip-mtext',['{\\H2.0x;Primo}\\PSecondo']), 'Primo Secondo'))
check('MTEXT campo conservato',lambda:expect(v.call('cti20w:strip-mtext',['%<campo>%']),None))
check('MTEXT frazione complessa conservata',lambda:expect(v.call('cti20w:strip-mtext',['\\S1#2;']),None))
check('Errore EXIT nel nome non nascosto',lambda:expect(v.call('cti2:annullamento-p',['no function definition: EXIT_MANCANTE']),None))
check('Annullamento italiano',lambda:expect(v.call('cti2:annullamento-p',['La funzione è stata annullata']),True))
check('Spazio modello in viewport carta',lambda:expect(RuntimeMock().vm.call('cti2:scheda-attiva',[]),'Model'))
def paper():
    m=RuntimeMock();m.vars['CVPORT']=1;expect(m.vm.call('cti2:scheda-attiva',[]),'Layout1')
check('Spazio carta corretto',paper)

def selected_vm(selections):
    vm=Lisp(TEXT);queue=list(selections)
    vm.native.update({'ssget':lambda *a:queue.pop(0),'sslength':len,'ssname':lambda s,i:s[i],
                      'vlax-ename->vla-object':lambda x:x,'vlax-3d-point':lambda x:x,
                      'vlax-property-available-p':lambda *a:True})
    return vm
def vertices_added():
    vm=selected_vm([['poly']]);saved=[]
    vm.native.update({'getint':lambda *a:1,'cti20w:lw-has-bulge-p':lambda e:None,
        'cti20w:lw-closed-p':lambda e:None,'cti20w:lwverts':lambda e:[[0.,0.,5.],[4.,0.,5.]],
        'cti20w:rebuild-lw-straight':lambda e,p:saved.append(p)})
    vm.call('cti20w:cmd-aggiungi-vertici',[])
    expect(saved,[[[0.,0.,5.],[2.,0.,5.],[4.,0.,5.]]])
check('Aggiungi vertici conserva ultimo punto e Z',vertices_added)
def text_reference():
    vm=selected_vm([['curve'],['text']]);rot=[]
    vm.native.update({'cti20w:inspt':lambda e:[1.,2.,3.],
        'cti20w:closest':lambda e,p:[1.,1.,3.],
        'cti20w:curve-angle-at':lambda e,p:0.75,
        'vla-put-rotation':lambda e,a:rot.append((e,a))})
    vm.call('cti20w:cmd-allinea-testo-rif',[]);expect(rot,[('text',0.75)])
check('Allineamento testo usa i dati geometrici, non T',text_reference)
def node_text():
    vm=selected_vm([['curve'],['text']]);moves=[]
    vm.native.update({'getdist':lambda *a:5.,'cti20w:nodi-endpoints':lambda c:[[1.,0.,0.]],
        'cti20w:inspt':lambda e:[0.,0.,0.],'cti20w:ensure-layer':lambda *a:True,
        'vla-move':lambda e,a,b:moves.append((a,b))})
    vm.call('cti20w:cmd-testo-su-nodo',[]);expect(moves,[([0.,0.,0.],[1.,0.,0.])])
check('Testo su nodo riceve un punto, non T',node_text)
def divide_lengths():
    vm=Lisp(TEXT);distances=iter([3.,8.,2.,None]);points=[]
    vm.native.update({'entsel':lambda *a:['curve'], 'vlax-ename->vla-object':lambda e:e,
        'cti20w:curve-length':lambda e:5.,'getreal':lambda *a:next(distances),
        'vlax-curve-getpointatdist':lambda e,d:[d,0.,0.],
        'cti2:crea-entita':lambda data:points.append(cdr(data[-1]))})
    vm.call('cti20x:cmd-dividi-lunghezze',[]);expect(points,[[3.,0.,0.],[5.,0.,0.]])
check('Divisione lunghezze: ignora segmento oltre limite',divide_lengths)
def number_lots():
    vm=selected_vm([['lot1','guide','lot2']]);labels=[]
    vm.native.update({'getstring':lambda *a:'L','getint':lambda *a:1,'getdist':lambda *a:2.5,
        'vlax-curve-isclosed':lambda e:True if e.startswith('lot') else None,
        'cti20w:bbox-center':lambda e:[2.,1. if e=='lot1' else 2.,0.],
        'vlax-curve-getclosestpointto':lambda e,p:[2.,0.,0.],
        'vlax-curve-getdistatpoint':lambda e,p:2.,
        'cti20x:make-centered-text':lambda p,s,*a:labels.append(s)})
    vm.call('cti20x:cmd-numera-lotti',[]);expect(labels,['L01','L02'])
check('Numerazione lotti conserva parità di progressiva',number_lots)
def legend_custom():
    vm=Lisp(TEXT);ds=iter([2.,20.]);texts=[]
    vm.native.update({'getpoint':lambda *a:[0.,0.,7.],'getdist':lambda *a:next(ds),
        'cti20w:ensure-layer':lambda *a:True,'cti20w:doc':lambda:'doc',
        'vla-get-layers':lambda d:['L1','L2'],'vla-get-name':lambda l:l,
        'vla-get-color':lambda l:1,'vla-get-description':lambda l:'',
        'cti20w:add-line':lambda *a:'line','vla-put-color':lambda *a:None,
        'cti20w:add-text':lambda p,s,*a:texts.append((p,s)) or 'text'})
    vm.call('cti20x:cmd-legenda-layer',[]);expect(len(texts),2)
    expect(texts[0][0][2],7.);expect(texts[1][0][1],-4.6)
check('Legenda: valori personalizzati e quota Z',legend_custom)
def overlap_texts():
    vm=selected_vm([['a','b','c']]);selected=[]
    pts={'a':[0.,0.,0.],'b':[0.,0.,0.],'c':[5.,0.,0.]}
    def ssadd(e=None,s=None):
        s=[] if s is None else s
        if e is not None and e not in s:s.append(e)
        return s
    vm.native.update({'getdist':lambda *a:.01,'cti20w:inspt':lambda e:pts[e],
        'ssadd':ssadd,'ssmemb':lambda e,s:True if e in s else None,
        'sssetfirst':lambda _,s:selected.extend(s)})
    vm.call('cti20w:cmd-testi-sovrapposti',[]);expect(selected,['a','b'])
check('Testi sovrapposti: conteggio senza duplicati',overlap_texts)
check('Incroci a quote differenti esclusi',lambda:expect(v.call('cti2c:parametri-intersezione-segmenti',
      [[0.,0.,0.],[10.,10.,0.],[0.,10.,2.],[10.,0.,2.]]),None))
check('Incroci complanari mantenuti',lambda:expect(v.call('cti2c:parametri-intersezione-segmenti',
      [[0.,0.,0.],[10.,10.,0.],[0.,10.,0.],[10.,0.,0.]]),[.5,.5]))
def arc_apex(end_angle,expected):
    vm=Lisp(TEXT);points=[]
    vm.native.update({'entsel':lambda *a:['arc'],
        'entget':lambda e:[Pair(0,'ARC'),[10,0.,0.,2.],Pair(40,1.),Pair(50,0.),Pair(51,end_angle)],
        'trans':lambda p,src,dst:[p[0]+10.,p[2],p[1]],
        'cti20w:add-circle':lambda p,*a:points.append(p)})
    vm.call('cti20c:cmd-vertice-arco',[]);expect(points,expected)
check('Vertice arco: trasformazione OCS verso WCS',lambda:arc_apex(1.5707963267948966,[[11.,2.,1.]]))
check('Vertice arco: tangenti parallele senza entità spurie',lambda:arc_apex(3.141592653589793,[]))
result={'tipo':'Harness parziale: esecuzione della logica LISP con API AutoCAD/ActiveX simulate; NON collaudo AutoCAD',
        'scenari_wrapper':300,'test':checks,'pass':sum(c['stato']=='PASS' for c in checks),'fail':sum(c['stato']=='FAIL' for c in checks)}
(ROOT/'verifiche/ESITO_TEST_LOGICA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(bool(result['fail']))
