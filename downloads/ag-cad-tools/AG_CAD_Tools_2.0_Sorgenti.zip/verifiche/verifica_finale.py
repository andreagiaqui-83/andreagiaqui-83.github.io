"""Gate completo su codice, registrazioni, UI e provenienza. Non collaudo nativo."""
from pathlib import Path
import collections,csv,hashlib,json,re,sys,zipfile
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'release/AGCADTools.bundle/Contents/Win64';UI=ROOT/'sorgenti_ui/ag_cuix_src'
sys.path.insert(0,str(ROOT/'tools'))
from correzioni_rc4 import CHANGED
from branding import lisp as renamed_lisp, text as renamed_text, COMMANDS, all_nodes
from lisp_audit import parse,definitions,head,walk,plain,lint,Sym
checks=[]
def gate(name,ok,detail=None):checks.append({'controllo':name,'stato':'PASS' if ok else 'FAIL','dettaglio':detail})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
texts={p.name:p.read_text(encoding='utf-8-sig') for p in W.glob('*.lsp')};forms={};defs={};where={};errors=[];dupes=[];nested=[]
for name,text in texts.items():
    try:forms[name]=parse(text)
    except Exception as e:errors.append((name,str(e)));continue
    errors += [(name,e) for e in lint(forms[name]) if not any(e.endswith('espressione inattesa al caricamento: '+x) for x in ['cti:load-module','cti:startup-call'])]
    for n in forms[name]:
        for x in walk(n):
            if head(x)=='defun' and x!=n and x.value[1].value!='*error*':nested.append((name,x.line,str(x.value[1].value)))
    for k,n in definitions(forms[name]).items():
        if k in defs:dupes.append(k)
        defs[k]=n;where[k]=name
gate('Tutti i moduli LISP leggibili, arità strutturali valide',not errors,errors)
gate('Nessuna definizione di comando accidentalmente annidata',not nested,nested)
gate('Definizioni univoche, nessun vecchio modulo Community nel payload',not dupes and 'cti_community_1_9.lsp' not in texts,dupes)
reg=json.loads((ROOT/'REGISTRO_UI_2_0.json').read_text());func=[r for r in reg if r['origin']!='Servizio']
gate('198 funzioni: 93 core, 100 Web, 5 personali',collections.Counter(r['origin'] for r in func)=={'Core':93,'Web':100,'Personale':5} and len({r['command'] for r in func})==198)
bad=[]
for r in func:
    name='c:'+r['command'].lower();n=defs.get(name)
    calls=[x for x in walk(n) if head(x)=='cti2:esegui-comando'] if n else []
    if len(calls)!=1 or calls[0].value[1].value!=r['command']:bad.append(r['command'])
gate('198/198 entrypoint direttamente nel runtime comune con nome corretto',not bad,bad)
public={k for k in defs if k.startswith('c:')}
original_public=set()
for p in (ROOT/'baseline_core').glob('*.lsp'):
    for n in parse(p.read_text(encoding='utf-8-sig')):
        for x in walk(n):
            if head(x)=='defun' and str(x.value[1].value).startswith('c:'):original_public.add(str(x.value[1].value))
gate('Tutti i comandi e alias storici golden preservati',original_public<=public,sorted(original_public-public))
bad=[];canonical={'c:'+r['command'].lower() for r in reg}|{'c:agcadtools','c:ag_diagnostica_2_0'}
for name in public-canonical:
    body=defs[name].value[3:]
    if len(body)!=1 or head(body[0]) not in public:bad.append(name)
gate('Alias storici esclusivamente deleganti a funzioni presenti',not bad,bad)
missing=set()
for n in defs.values():
    for x in walk(n):
        h=head(x)
        if h and h.startswith(('cti:','cti2:','ctia:','cti20w:','c:agcadtools')) and h not in defs:missing.add(h)
gate('Nessuna chiamata CTI a helper non definito',not missing,sorted(missing))
old=definitions(parse(renamed_lisp((ROOT/'sorgenti/web_fase2d.lsp').read_text())));bad=[]
for name,n in old.items():
    if not name.startswith('cti2:') and (name not in defs or plain(n)!=plain(defs[name])):bad.append(name)
gate('Web invariato salvo riconoscimento layout con ModelType, indipendente dalla lingua',set(bad)=={'cti2c:cmd-copia-su-layout'},bad)
old=definitions(parse(renamed_lisp((ROOT/'sorgenti/cti_andrea_2_0.lsp').read_text())))
gate('Tutte le definizioni personali identiche alla Fase 3',all(name in defs and plain(n)==plain(defs[name]) for name,n in old.items()))
gate('Il vecchio wrapper UNDO è sostituito dal ponte al runtime comune',
     not any(head(x) in ('vla-startundomark','vla-endundomark') for x in walk(defs['cti:run'])))
bad=[]
for name,n in defs.items():
    if where[name]=='ag_cad_tools.lsp' or where[name].startswith('ag_05'):
        for x in walk(n):
            if head(x) in ('open','close','setvar','vl-filename-mktemp','entmakex'):bad.append((name,str(head(x))))
gate('File, variabili e temporanei del core gestiti dal runtime',not bad,bad)
gate('SCRIPT e QUIT sono ultima chiamata dopo il cleanup',all(
    head(defs[n].value[-1])=='command' for n in ['cti2:chiudi-autocad','cti2:avvia-script']) and
    all(head(defs[n].value[-1])=='cti2:esegui-differita' for n in ['c:ag_chiudiveloce','c:ag_ripristinadisegno','c:agcadtools']))

pkg=ET.parse(ROOT/'release/AGCADTools.bundle/PackageContents.xml').getroot()
entries=pkg.findall('.//ComponentEntry');lsps=[x for x in entries if x.get('ModuleName','').endswith('.lsp')]
registered={x.get('Global').lower() for x in pkg.findall('.//Command')}
gate('Un solo bootstrap LISP, registrazione esatta di tutti i comandi pubblici',len(lsps)==1 and lsps[0].get('ModuleName').endswith('/ag_bootstrap_2_0.lsp') and registered=={n[2:] for n in public},len(public))
gate('Identità pacchetto 2.0 e UpgradeCode golden preservato',pkg.get('AppVersion')=='2.0.0.6' and pkg.get('UpgradeCode')==ET.parse(ROOT/'baseline_core/PackageContents.xml').getroot().get('UpgradeCode'))
gate('Moduli core risolti nella cartella del bootstrap', '*CTI2-DIRECTORY*' in texts['ag_cad_tools.lsp'][defs['cti:load-module'].start:defs['cti:load-module'].end])

menu=ET.parse(UI/'MenuGroup.cui').getroot();macros=menu.findall('.//MenuMacro')
uids={m.get('UID') for m in macros};ui_cmds={m.findtext('Macro/CLICommand') for m in macros}
gate('CUIX: 200 macro e comandi uguali al registro',len(macros)==200 and len(uids)==200 and ui_cmds=={r['command'] for r in reg})
by_uid={r['uid']:r for r in reg}
gate('Nomi, descrizioni e azioni UI corrispondono al registro',all(
    m.findtext('Macro/Name')==by_uid[m.get('UID')]['name'] and
    m.findtext('Macro/HelpString')==by_uid[m.get('UID')]['tip'] and
    m.findtext('Macro/Command')=='^C^C'+by_uid[m.get('UID')]['command'] for m in macros))
allxml=[]
for p in UI.glob('*.cui'):allxml.append(ET.parse(p).getroot())
panels=[n for t in allxml for n in t.findall('.//RibbonPanelSource')]
gate('Ribbon: 16 pannelli approvati',len(panels)==16)
rb=ET.parse(UI/'RibbonRoot.cui').getroot();pop=ET.parse(UI/'PopMenuRoot.cui').getroot()
cats=[r['Pannello'] for r in csv.DictReader((ROOT/'provenienza/ARCHITETTURA_RIBBON_2.0.csv').open(encoding='utf-8-sig'))]
gate('Categorie nello stesso ordine approvato in Ribbon e menu',
     [p.get('Text') for p in panels]==cats and [m.findtext('Name') for m in pop.findall('PopMenu')[1:]]==cats)
gate('Ogni macro raggiungibile una volta da Ribbon e menu',
     collections.Counter(b.get('MenuMacroID') for b in rb.findall('.//RibbonCommandButton'))==collections.Counter(uids) and
     collections.Counter(b.get('MenuMacroID') for b in pop.findall('.//MacroRef'))==collections.Counter(uids))
gate('Espansione Ribbon e riferimenti ai pannelli coerenti',
     all(len(p.find('RibbonRow').findall('.//RibbonCommandButton'))<=7 for p in panels) and
     {x.get('PanelId') for x in rb.findall('.//RibbonPanelSourceReference')}=={p.get('UID') for p in panels})
bad=[]
for r in reg:
    for key in ('icon16','icon32'):
        p=UI/r[key];q=W/r[key]
        if not p.is_file() or not q.is_file() or sha(p)!=sha(q):bad.append(r[key])
gate('400 PNG di icone presenti e coerenti',not bad,bad)
with zipfile.ZipFile(W/'AGCADTools.cuix') as z:
    gate('CUIX integro e corrispondente alle sorgenti UI',z.testzip() is None and all(z.read(p.relative_to(UI).as_posix())==p.read_bytes() for p in UI.rglob('*') if p.is_file()))
cat=next(n for n in forms['ag_catalogo_2_0.lsp'] if head(n)=='setq' and n.value[1].value=='*cti-launcher*')
rows=cat.value[2].value[1].value
gate('Launcher: 200 voci, nessun comando orfano',len(rows)==200 and {r.value[0].value for r in rows}==ui_cmds)
guide=(W/'AG_CAD_Tools_Help.html').read_text()
gate('Guida: 200 schede, 16 categorie e 198 funzioni documentate',guide.count('<article class="card"')==200 and guide.count('<section class="category"')==16 and all(f'id="{r["command"]}"' in guide for r in func))
gate('Guida e supporto conservano sito e WhatsApp',all(s in guide for s in ['andreagiaquinto.it','3337240544']) and all(s in (W/'AG_CAD_Tools_Sostieni.html').read_text() for s in ['andreagiaquinto.it','3337240544']))
license_text=(W/'LICENZE_TERZE_PARTI.txt').read_text()
gate('Cinque attribuzioni MIT incluse nel bundle',license_text.count('Copyright (c)')==5)
main=(ROOT/'installer_src/main.go').read_text();common=(ROOT/'installer_src/common.go').read_text()
gate('UI moderna RC2 corrispondente alle sorgenti, double buffering preservato',main==(ROOT/'sorgenti/installer_main.go').read_text() and (ROOT/'installer_src/ui_design.go').read_bytes()==(ROOT/'sorgenti/installer_ui_design.go').read_bytes() and all(x in main for x in ['procBitBlt.Call','procCreateCompatibleDC.Call','wmEraseBkgnd','paintButton(&d)','clientW = 920','clientH = 600']))
gate('Motore SHA/staging/backup/rollback invariato salvo identità AG',common==renamed_text((ROOT/'baseline_rc2/installer_common.go').read_text()))
# Rebranding gates compare executable definitions, not just file counts.
expected={}
for p in (ROOT/'baseline_rc2').glob('*.lsp'):
    expected.update(definitions(parse(renamed_lisp(p.read_text(encoding='utf-8-sig')))))
changed=[k for k,n in expected.items() if k not in defs or plain(n)!=plain(defs[k])]
gate('Definizioni RC2 preservate salvo branding e quattro correzioni RC4 dichiarate',set(changed)==CHANGED,changed)
legacy=set(json.loads((ROOT/'baseline_rc2/REGISTRO_PUBBLICO.json').read_text()))
gate('Tutti i 330 nomi pubblici RC2 ancora definiti',len(legacy)==330 and legacy<=public)
bad=[]
for old,new in COMMANDS.items():
    node=defs.get('c:'+old.lower())
    if node is None or len(node.value[3:])!=1 or head(node.value[3])!='c:'+new.lower():bad.append(old)
gate('210 alias CTI delegano esattamente al comando AG corrispondente',len(COMMANDS)==210 and not bad,bad)
gate('541 nomi pubblici registrati nel manifest e nella diagnostica',len(public)==541 and registered=={k[2:] for k in public})
gate('Tutte le 200 azioni visibili usano comandi AG_',all(r['command'].startswith('AG_') for r in reg))
gate('Gruppo, Ribbon, menu e pacchetto identificati AG CAD Tools',pkg.get('Name')=='AG CAD Tools' and pkg.get('Author')=='Andrea Giaquinto' and menu.get('Name')=='AGCADTOOLS' and menu.get('DisplayName')=='AG CAD Tools' and rb.find('.//RibbonTabSource').get('Text')=='AG CAD Tools')
gate('Guida e Sostieni senza vecchio marchio anche nei link codificati',all(x not in guide+(W/'AG_CAD_Tools_Sostieni.html').read_text() for x in ['CAD Tools Italiano','CAD%20Tools%20Italiano','CADToolsItaliano']))
gate('Titolo launcher e logo installer aggiornati', 'AG CAD Tools 2.0' in (W/'ag_cad_tools.dcl').read_text() and 'text("AG", "logo"' in (ROOT/'installer_src/ui_design.go').read_text() and 'text("AG CAD TOOLS", "brand"' in (ROOT/'installer_src/ui_design.go').read_text())
oldreg=json.loads((ROOT/'baseline_rc2/REGISTRO_UI_2_0.json').read_text())
gate('400 immagini preservate pixel per pixel rispetto alla RC2',all(sha(W/new[k])==sha(ROOT/'sorgenti_ui/cuix_src'/old[k]) for old,new in zip(oldreg,reg) for k in ['icon16','icon32']))
oldtext='\n'.join(p.read_text() for p in (ROOT/'baseline_rc2').glob('*.lsp'))
newtext='\n'.join(texts.values())
keys=['CTI_TEXTMASK','CTI_REMOTE_TEXT','CTI_PSTSCALE','CTI_MASK_']
gate('Identificatori DWG e chiave delle impostazioni personali preservati',all(oldtext.count('"'+k+'"')==newtext.count('"'+k+'"')>0 for k in keys) and oldtext.count('HKEY_CURRENT_USER')==newtext.count('HKEY_CURRENT_USER') and 'HKEY_CURRENT_USER' in newtext)
mnl=(W/'AGCADTools.mnl').read_text();parse(mnl)
gate('MNL associato al nuovo CUIX e rimozione condizionata del solo vecchio gruppo', '(menugroup "AGCADTOOLS")' in mnl and '(menugroup "CADTOOLSITALIANO")' in mnl and '(vla-Unload vecchio)' in mnl)
gate('Nessun modulo o risorsa attiva con vecchio nome file',not any('cadtoolsitaliano' in p.name.lower() or 'cad_tools_italiano' in p.name.lower() or p.name.startswith('cti_') for p in W.iterdir()))
parts=ET.parse(UI/'Menu_Package_Info.xml').getroot()
gate('Metadati CUIX senza riferimenti a immagini o parti mancanti',all((UI/x.get('PartData_Name').lstrip('/')).is_file() for x in parts.findall('PartData')))
result={'ambito':'Audit statico versione definitiva 2.0; non collaudo nativo','controlli':checks,
        'pass':sum(x['stato']=='PASS' for x in checks),'fail':sum(x['stato']=='FAIL' for x in checks),'funzioni':len(func),'pubblici':len(public)}
(ROOT/'verifiche/ESITO_AUDIT_FINALE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='controlli'},ensure_ascii=False))
for x in checks:
    if x['stato']=='FAIL':print(x)
sys.exit(bool(result['fail']))
