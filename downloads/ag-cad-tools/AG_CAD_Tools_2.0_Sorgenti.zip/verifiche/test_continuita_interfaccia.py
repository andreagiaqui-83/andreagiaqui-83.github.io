"""Confronto integrale della logica RC4 preservata dalla RC5."""
from pathlib import Path
import json,sys,re
from lisp_audit import parse,definitions,plain,Sym
R=Path(__file__).resolve().parents[1];B=R/'baseline_rc4';W=R/'release/AGCADTools.bundle/Contents/Win64';checks=[]
def test(n,fn):
 try:fn();checks.append({'test':n,'stato':'PASS'})
 except Exception as e:checks.append({'test':n,'stato':'FAIL','errore':str(e)})
def require(x):assert x

def defs(folder):
 return {name:plain(node) for p in folder.glob('*.lsp') for name,node in definitions(parse(p.read_text())).items()}
a=defs(B);b=defs(W)
def norm(x):
 if isinstance(x,list):return [norm(t) for t in x]
 if type(x)==str:return x.replace('2.0 RC4','2.0').replace('RC4 indica','La versione 2.0 indica').replace('Candidata al collaudo nativo.','Versione definitiva 2.0.')
 return x
changed={k for k in a if k not in b or norm(a[k])!=b[k]}
test('Unica definizione esistente modificata: gestione interfaccia, nessun comando geometrico',lambda:require(changed=={'ag:aggiorna-interfaccia'}))
test('Unico nuovo helper privato per inserire il menu; nessun nome pubblico aggiunto/rimosso',lambda:require(set(b)-set(a)=={'ag:assicura-menu-barra'} and {k for k in a if k.startswith('c:')}=={k for k in b if k.startswith('c:')}))
test('Testo delle 200 procedure identico alla RC4',lambda:require((B/'manuale_comandi.tsv').read_bytes()==(R/'sorgenti/manuale_comandi.tsv').read_bytes()))
old_cards=re.findall(r'<article\b.*?</article>',(B/'AG_CAD_Tools_Help.html').read_text(),re.S);new_cards=re.findall(r'<article\b.*?</article>',(W/'AG_CAD_Tools_Help.html').read_text(),re.S)
test('200 schede HTML dei comandi preservate integralmente',lambda:require(len(old_cards)==200 and old_cards==new_cards))
result={'ambito':'Confronto AST RC4/2.0: etichette di versione e stato diagnostico normalizzate','definizioni_rc4':len(a),'definizioni_2_0':len(b),'definizioni_modificate':sorted(changed),'test':checks,'pass':sum(c['stato']=='PASS' for c in checks),'fail':sum(c['stato']=='FAIL' for c in checks)}
(R/'verifiche/ESITO_CONTINUITA_INTERFACCIA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
