"""Reader e controlli strutturali AutoLISP; non sostituisce AutoCAD."""
from dataclasses import dataclass
from pathlib import Path
import re

class Sym(str): pass
@dataclass
class Node:
    value: object
    line: int
    start: int
    end: int

def parse(text):
    i=0; line=1
    def skip():
        nonlocal i,line
        while i<len(text):
            if text[i].isspace():
                line+=text[i]=='\n'; i+=1
            elif text[i]==';':
                while i<len(text) and text[i]!='\n': i+=1
            else: break
    def expr():
        nonlocal i,line
        skip(); start=i; ln=line
        if i>=len(text): raise ValueError(f'EOF inatteso riga {line}')
        ch=text[i]; i+=1
        if ch=='(':
            out=[]
            while True:
                skip()
                if i>=len(text): raise ValueError(f'Lista non chiusa riga {ln}')
                if text[i]==')': i+=1; break
                out.append(expr())
            return Node(out,ln,start,i)
        if ch==')': raise ValueError(f'Chiusura inattesa riga {ln}')
        if ch=="'": return Node([Node(Sym('quote'),ln,start,start+1),expr()],ln,start,i)
        if ch=='"':
            out=''
            while i<len(text):
                ch=text[i]; i+=1
                if ch=='"': return Node(out,ln,start,i)
                if ch=='\\':
                    if i>=len(text): break
                    ch=text[i]; i+=1
                    out+= {'n':'\n','r':'\r','t':'\t','e':'\x1b'}.get(ch,ch)
                else: out+=ch; line+=ch=='\n'
            raise ValueError(f'Stringa non chiusa riga {ln}')
        while i<len(text) and not text[i].isspace() and text[i] not in "();'\"": i+=1
        token=text[start:i]
        try: val=int(token)
        except ValueError:
            try: val=float(token)
            except ValueError: val=Sym(token.lower())
        return Node(val,ln,start,i)
    out=[]
    while True:
        skip()
        if i==len(text): return out
        out.append(expr())

def head(n):
    v=n.value[0].value if isinstance(n.value,list) and n.value else None
    return v if isinstance(v,Sym) else None

def plain(n):
    return [plain(x) for x in n.value] if isinstance(n.value,list) else n.value

def walk(n,quoted=False):
    if not isinstance(n.value,list): return
    yield n
    if head(n)=='quote':
        if len(n.value)==2 and head(n.value[1])=='lambda': yield from walk(n.value[1])
        return
    if head(n)=='defun': children=n.value[3:]
    elif head(n)=='lambda': children=n.value[2:]
    else: children=n.value[1:] if head(n) else n.value
    for x in children: yield from walk(x)

def definitions(forms):
    return {n.value[1].value:n for n in forms if head(n)=='defun'}

def lint(forms):
    errors=[]; defs=definitions(forms)
    def err(n,msg): errors.append(f'riga {n.line}: {msg}')
    arities={'if':(2,3),'quote':(1,1),'function':(1,1),'foreach':(2,None),
             'while':(1,None),'repeat':(1,None),'mapcar':(2,None),'apply':(2,2),
             'vl-catch-all-apply':(2,2),'setq':(2,None),'getvar':(1,1),
             'setvar':(2,2),'cons':(2,2),'subst':(3,3),'inters':(4,5),
             'entget':(1,2),'entmod':(1,1),'entmakex':(1,1),'entmake':(1,1),
             'vlax-3d-point':(1,3),'open':(2,3),'close':(1,1),'initget':(1,2),
             'getpoint':(0,2),'getcorner':(1,2),'getreal':(0,1),'getint':(0,1),
             'getstring':(0,2),'getdist':(0,2),'getkword':(0,1)}
    for name,n in defs.items():
        args=n.value[2].value
        if not isinstance(args,list): err(n,'parametri defun non validi'); continue
        args=[x.value for x in args]
        arities[name]=(args.index('/') if '/' in args else len(args),)*2
    for top in forms:
        if head(top) not in ('defun','setq','vl-load-com','princ','if','progn'):
            err(top,f'espressione inattesa al caricamento: {head(top) or top.value}')
        for n in walk(top):
            h=head(n); vals=n.value[1:]
            if h in arities:
                lo,hi=arities[h]
                if len(vals)<lo or (hi is not None and len(vals)>hi):
                    err(n,f'{h}: {len(vals)} argomenti, attesi {lo}..{hi}')
            if h=='setq':
                if len(vals)%2: err(n,'setq con numero dispari di argomenti')
                for target in vals[::2]:
                    if not isinstance(target.value,Sym): err(target,'destinazione setq non simbolica')
            if h=='defun' and (len(n.value)<4 or not isinstance(n.value[1].value,Sym)):
                err(n,'defun incompleta')
            if h in ('fboundp','exit'): err(n,f'chiamata non ammessa: {h}')
            if h=='cond':
                for branch in vals:
                    if not isinstance(branch.value,list): err(branch,'ramo cond non racchiuso in lista')
    return errors

if __name__=='__main__':
    import sys
    for arg in sys.argv[1:]:
        text=Path(arg).read_text(encoding='utf-8-sig'); forms=parse(text)
        print(arg, 'forme',len(forms),'funzioni',len(definitions(forms)))
        for error in lint(forms): print('FAIL',error)
