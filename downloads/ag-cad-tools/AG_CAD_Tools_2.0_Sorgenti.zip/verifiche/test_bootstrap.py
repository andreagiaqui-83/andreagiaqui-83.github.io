"""Esegue le forme di caricamento nell'ordine reale, con AutoCAD simulato."""
from pathlib import Path
import json,sys
from lisp_audit import parse,plain,Sym
from harness_autolisp import Lisp,truth
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'release/AGCADTools.bundle/Contents/Win64'
class Fn:
    def __init__(self,name):self.name=name
checks=[]
def check(missing=None):
    vm=Lisp('');loaded=[];groups={'CADTOOLSITALIANO'};ui_events=[];menu_visible=[False]
    def load_ui(*args):groups.add('AGCADTOOLS');ui_events.append('load AG')
    def unload_ui(g):groups.remove(g);ui_events.append('unload '+g)
    def filename(p):return p.replace('\\','/').split('/')[-1]
    def find(p):
        f=filename(p)
        return 'C:\\CTI\\'+f if f!=missing and (W/f).exists() else None
    def load(p):
        f=filename(p);loaded.append(f)
        for form in parse((W/f).read_text(encoding='utf-8-sig')):
            try:vm.ev(plain(form))
            except Exception as e:raise RuntimeError(f'{f}:{form.line}: {e}')
        return True
    def ev(x):return Fn(x) if isinstance(x,Sym) and x in vm.defs else vm.ev(x)
    vm.native.update({'vl-load-com':lambda:None,'findfile':find,'vl-filename-directory':lambda p:'C:\\CTI',
        'load':load,'vl-registry-read':lambda *a:None,'ssget':lambda *a:None,
        'eval':ev,'read':lambda s:Sym(s.lower()),'type':lambda x:Sym('usubr') if isinstance(x,Fn) else Sym('str') if type(x)==str else None,
        'getvar':lambda k:1,'vlax-get-acad-object':lambda:'app','vla-get-activedocument':lambda a:'doc',
        'vla-startundomark':lambda d:None,'vla-endundomark':lambda d:None,'setvar':lambda *a:None,
        'menugroup':lambda s:s if s in groups else None,'vla-get-menugroups':lambda app:'groups','vla-load':load_ui,'vla-item':lambda gs,name:name,'vla-unload':unload_ui,
        'vla-get-menus':lambda g:['main'], 'vla-get-namenomnemonic':lambda m:'AG CAD Tools',
        'vla-get-name':lambda m:'&AG CAD Tools','vla-get-onmenubar':lambda m:-1 if menu_visible[0] else 0,
        'vla-insertmenuinmenubar':lambda menus,name,index:menu_visible.__setitem__(0,True)})
    load('ag_bootstrap_2_0.lsp')
    complete=truth(vm.get('*cti2-load-complete*'));assert complete==(missing is None),(complete,vm.output,vm.get('*cti2-load-errors*'),vm.get('*cti-load-warnings*'), {k:v for k,v in vm.frames[0].items() if "loaded" in k or "complete" in k or "ok*" in k})
    public=json.loads((ROOT/'verifiche/REGISTRO_PUBBLICO.json').read_text())
    if missing is None:
        assert set(public)<={str(k) for k in vm.defs}
        assert menu_visible[0]
        assert groups=={'AGCADTOOLS'} and ui_events==['load AG','unload CADTOOLSITALIANO']
        assert not vm.get('*cti2-load-errors*') and not vm.get('*cti-load-warnings*'),vm.output
        assert vm.call('cti2:comandi-mancanti',[vm.get('*cti2-comandi-pubblici*')]) is None
    else:
        assert vm.get('*cti2-load-errors*') or vm.get('*cti-module-failures*')
    vm.call('c:ag_diagnostica',[])
    out='\n'.join(str(x) for x in vm.output)
    assert 'Funzione non implementata' not in out,out
    if missing is None:assert 'Funzioni definite: 198/198' in out and '541/541' in out,out
    assert 'cti_community_1_9.lsp' not in loaded
    return {'moduli_caricati':loaded,'caricamento_completo':complete}
for missing in [None,'ag_web_2_0.lsp','ag_runtime_2_0.lsp','ag_05c_textmask.lsp','ag_catalogo_2_0.lsp','ag_cad_tools.lsp']:
    try:detail=check(missing);checks.append({'test':'Caricamento '+str(missing or 'completo'),'stato':'PASS','dettaglio':detail})
    except Exception as e:checks.append({'test':'Caricamento '+str(missing or 'completo'),'stato':'FAIL','errore':str(e)})
result={'tipo':'Caricamento AutoLISP simulato, non AutoCAD','test':checks,'pass':sum(x['stato']=='PASS' for x in checks),'fail':sum(x['stato']=='FAIL' for x in checks)}
(ROOT/'verifiche/ESITO_BOOTSTRAP.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['fail']))
