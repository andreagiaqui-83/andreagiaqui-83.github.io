"""Esegue LISP reale con API simulate. Non è un collaudo AutoCAD/Windows."""
from pathlib import Path
import json,sys
from lisp_audit import parse,definitions,head,walk,plain,Sym
from harness_autolisp import Lisp,LispError,Cancelled,Pair,truth,equal
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'release/AGCADTools.bundle/Contents/Win64'
SOURCES={p.name:p.read_text(encoding='utf-8-sig') for p in W.glob('*.lsp') if 'community' not in p.name}
TEXT='\n'.join(SOURCES.values());DEFS=definitions(parse(TEXT));CHECKS=[]
REG=json.loads((ROOT/'REGISTRO_UI_2_0.json').read_text())
FUNCTIONAL=[r['command'] for r in REG if r['origin']!='Servizio']
def expect(a,b):
    if not equal(a,b,1e-7):raise AssertionError(f'{a!r} != {b!r}')
def check(name,fn):
    try:fn();CHECKS.append({'test':name,'stato':'PASS'})
    except Exception as e:CHECKS.append({'test':name,'stato':'FAIL','errore':str(e)})
class Mock:
    def __init__(self):
        self.vm=Lisp(TEXT);self.events=[];self.files={'/dest':'VECCHIO\n'};self.handles={};self.seq=0
        self.vars={k:1 for k in 'CMDECHO OSMODE PDMODE DIMTXT FILEDIA ORTHOMODE SNAPMODE MIRRTEXT TEXTFILL PEDITACCEPT FILLETRAD BACKGROUNDPLOT DIMZIN HPBOUND TRIMMODE'.split()}
        self.vars.update(CLAYER='ORIGINE',UNDOCTL=1,IMAGEFRAME=1,WIPEOUTFRAME=0)
        self.vm.native.update({'getvar':lambda k:self.vars[k],'setvar':self.setvar,'vlax-get-acad-object':lambda:'app',
            'vla-get-activedocument':lambda a:'doc','vla-startundomark':lambda d:self.events.append('inizio'),
            'vla-endundomark':lambda d:self.events.append('fine'),'open':self.open,'close':self.close,
            'write-line':self.write,'vl-filename-mktemp':self.temp,'findfile':lambda p:p if p in self.files else None,
            'vl-filename-directory':lambda p:'/', 'vl-file-copy':self.copy,'vl-file-delete':self.delete,
            'vl-file-rename':self.rename,'unload_dialog':lambda i:self.events.append(('unload',i)),
            'initget':lambda *a:None})
    def setvar(self,k,v):self.vars[k]=v;return v
    def open(self,p,mode):
        if mode=='r' and p not in self.files:return None
        self.seq+=1;self.handles[self.seq]=p
        if mode=='w' or p not in self.files:self.files[p]=''
        return self.seq
    def close(self,f):self.events.append(('close',f));del self.handles[f]
    def write(self,s,f):self.files[self.handles[f]]+=s+'\n';return s
    def temp(self,*a):self.seq+=1;return '/'+a[0]+str(self.seq)+a[2]
    def copy(self,a,b):
        if b in self.files:return None
        self.files[b]=self.files[a];return len(self.files[b])
    def rename(self,a,b):
        if a not in self.files or b in self.files:return None
        self.files[b]=self.files.pop(a);return True
    def delete(self,p):
        if p in self.files:del self.files[p];return True
    def output(self):return '\n'.join(str(v) for v in self.vm.output)
    def run(self,fn='prova'):return self.vm.call('cti2:esegui-comando',['PROVA',Sym(fn)])

def wrapper(cmd,mode):
    m=Mock();before=dict(m.vars);pub=DEFS['c:'+cmd.lower()]
    calls=[n for n in walk(pub) if head(n)=='cti2:esegui-comando'];expect(len(calls),1)
    arg=calls[0].value[2];target=plain(arg.value[1])
    # Lambda UCS: si sostituisce solo l'operazione interna; il vero entrypoint resta intatto.
    if isinstance(target,list):target=str(target[2][0])
    def body(*args):
        m.vm.call('cti2:setvar-temporanea',['FILLETRAD',0.])
        m.vm.call('cti2:registra-cleanup',[Sym('unload_dialog'),[7]])
        f=m.vm.call('cti2:apri-core',['/dest','w']);m.write('NUOVO',f)
        if mode=='ESC':raise Cancelled('Function cancelled')
        if mode=='errore':raise LispError('Guasto simulato')
        m.vm.call('cti2:chiudi-core',[f])
    m.vm.native[str(target)]=body;m.vm.call('c:'+cmd.lower(),[])
    expect(m.vars,before);expect(m.handles,{})
    expect(m.files,{'/dest':'NUOVO\n' if mode=='successo' else 'VECCHIO\n'})
    expect([x for x in m.events if x in ('inizio','fine')],['inizio','fine'])
    expect(m.events.count(('unload',7)),1)
    if mode=='errore':assert cmd in m.output() and 'Guasto simulato' in m.output()
    else:assert 'Errore' not in m.output(),m.output()
for cmd in FUNCTIONAL:
    for mode in ['successo','ESC','errore']:check(cmd+' / '+mode,lambda c=cmd,m=mode:wrapper(c,m))

def append_core(mode):
    m=Mock()
    def body():
        f=m.vm.call('cti2:apri-core',['/dest','a']);m.write('AGGIUNTA',f)
        if mode=='ESC':raise Cancelled('Function cancelled')
        m.vm.call('cti2:chiudi-core',[f]);expect(m.files['/dest'],'VECCHIO\nAGGIUNTA\n')
    m.vm.native['prova']=body;m.run();expect(m.files,{'/dest':'VECCHIO\n'+('AGGIUNTA\n' if mode=='successo' else '')})
    expect(m.handles,{})
for mode in ['successo','ESC']:check('Append core '+mode,lambda m=mode:append_core(m))

def deferred(fail=False):
    m=Mock();before=dict(m.vars)
    def action():
        expect(m.vars,before);expect(m.handles,{})
        expect(m.events[-1],'fine');m.events.append('handoff')
    def body():
        m.vm.call('cti2:setvar-temporanea',['FILEDIA',0])
        m.vm.call('cti2:registra-cleanup',[Sym('unload_dialog'),[9]])
        m.vm.call('cti2:differisci',[Sym('azione'),None])
        if fail:raise Cancelled('Function cancelled')
    m.vm.native.update(prova=body,azione=action)
    result=m.run();assert 'handoff' not in m.events
    m.vm.call('cti2:esegui-differita',[result]);expect(m.events.count('handoff'),0 if fail else 1)
check('Handoff dopo UNDO, variabili e DCL',deferred)
check('Handoff non eseguito dopo annullamento',lambda:deferred(True))

def reactor(mode):
    m=Mock()
    def body():
        f=m.vm.call('cti2:apri-core',['/dest','a']);m.write('LOG',f)
        if mode=='errore':raise LispError('Scrittura negata')
        m.vm.call('cti2:chiudi-core',[f])
    m.vm.native['prova']=body;m.vm.call('cti2:esegui-risorse',['REACTOR',Sym('prova'),None])
    expect(m.handles,{});assert 'inizio' not in m.events and 'fine' not in m.events
    expect(m.files,{'/dest':'VECCHIO\n'+('LOG\n' if mode=='successo' else '')})
for mode in ['successo','errore']:check('Risorse reactor '+mode,lambda m=mode:reactor(m))

def intentional(mode):
    m=Mock()
    def body():
        m.vm.call('cti2:setvar-finale',['IMAGEFRAME',2]);m.vm.call('cti2:setvar-finale',['WIPEOUTFRAME',2])
        if mode=='ESC':raise Cancelled('Function cancelled')
    m.vm.native['prova']=body;m.run();expect((m.vars['IMAGEFRAME'],m.vars['WIPEOUTFRAME']),(2,2) if mode=='successo' else (1,0))
for mode in ['successo','ESC']:check('Cornici intenzionali '+mode,lambda m=mode:intentional(m))

def copy_modes(mode):
    m=Mock();vectors=[];pts=iter([[0.,0.,0.],[10.,0.,0.],[0.,5.,0.]])
    m.vm.native.update({'ssget':lambda *a:['ent'],'getpoint':lambda *a:next(pts),'getkword':lambda *a:mode,
        'getint':lambda *a:2,'getdist':lambda *a:2.5,'cti:copy-ss-vector':lambda s,v:vectors.append(v) or 1})
    m.vm.call('c:ag_copiamultipla',[])
    expect(len(vectors),{'Ripeti':2,'Dividi':2,'Misura':4,'Serie':3}[mode]);assert 'Errore' not in m.output(),m.output()
for mode in ['Ripeti','Dividi','Misura','Serie']:check('COPIAMULTIPLA '+mode,lambda m=mode:copy_modes(m))

def rtext(value):
    m=Mock();m.vm.native['cti:rtext-read-file']=lambda p:value
    m.vm.native['type']=lambda x:Sym('str') if isinstance(x,str) else None
    expect(m.vm.call('cti:rtext-content',['FILE|/testo']),'[File non disponibile: /testo]' if value is None else value)
for value in ['Testo reale','',None]:check('Testo remoto restituisce stringa '+repr(value),lambda v=value:rtext(v))

def close_handoff():
    m=Mock();m.vm.native['command']=lambda *a:(expect(m.events[-1],'fine'),m.events.append(a))[-1]
    m.vm.call('c:ag_chiudiveloce',[]);expect(m.events[-1],('_.QUIT',))
check('CHIUDIVELOCE esegue QUIT dopo il cleanup',close_handoff)

def revert(answer):
    m=Mock();m.vars.update(DWGPREFIX='/dwg/',DWGNAME='Pianta prova.dwg',DBMOD=1,TEMPPREFIX='/')
    m.vm.native.update({'getkword':lambda *a:answer,'vl-prin1-to-string':lambda s:json.dumps(s,ensure_ascii=False),
        'command':lambda *a:m.events.append(a)})
    m.vm.call('c:ag_ripristinadisegno',[])
    if answer=='Si':
        cmd,path=m.events[-1];expect(cmd,'_.SCRIPT');assert m.events.index('fine')<len(m.events)-1
        text=m.files[path];assert '_.CLOSE\n_N\n_.OPEN\n"/dwg/Pianta prova.dwg"\n' in text,text
        assert 'vl-file-delete' in text and path in text
        for line in text.splitlines():
            if line.startswith('('):parse(line)
    else:expect(m.files,{'/dest':'VECCHIO\n'});assert not any(isinstance(x,tuple) and x[0]=='_.SCRIPT' for x in m.events)
    expect(m.handles,{})
for answer in [None,'No','Si']:check('RIPRISTINADISEGNO '+str(answer),lambda a=answer:revert(a))

# RC2: execute the actual label formatter, category callback and quiet exits.
def launcher_rc2():
    m=Mock();tiles={}
    pairs=[Pair(r['command'],r['category']+' - '+r['name']) for r in REG]
    m.vm.put('*cti-launcher*',pairs)
    m.vm.native['set_tile']=lambda key,value:tiles.update({key:value})
    for idx,(r,pair) in enumerate(zip(REG,pairs)):
        expect(m.vm.call('cti:launcher-voce',[pair]),r['name']+' ['+r['command']+']')
        m.vm.call('cti:launcher-categoria',[idx])
        expect(tiles['categoria'],'Categoria: '+r['category'])
    assert len(pairs)==200
check('RC2: 200 etichette launcher e categorie associate',launcher_rc2)

def quiet_rc2(mode):
    m=Mock();calls=[];princ=m.vm.native['princ']
    def track(*args):calls.append(args);return princ(*args)
    def body():
        if mode=='ESC':raise Cancelled('Function cancelled')
        if mode=='errore':raise LispError('Guasto simulato')
    m.vm.native.update(princ=track,prova=body)
    m.run();expect(calls[-1],())
for mode in ['successo','ESC','errore']:check('RC2: uscita PRINC senza argomenti / '+mode,lambda mode=mode:quiet_rc2(mode))
def empty_handoff_rc2():
    m=Mock();calls=[];m.vm.native['princ']=lambda *args:calls.append(args)
    m.vm.call('cti2:esegui-differita',[None]);expect(calls,[()])
check('RC2: launcher senza azione termina con PRINC',empty_handoff_rc2)

result={'tipo':'LISP con API simulate, NON collaudo AutoCAD','scenari_wrapper':594,
        'test':CHECKS,'pass':sum(x['stato']=='PASS' for x in CHECKS),'fail':sum(x['stato']=='FAIL' for x in CHECKS)}
(ROOT/'verifiche/ESITO_INTEGRAZIONE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='test'},ensure_ascii=False))
for x in CHECKS:
    if x['stato']=='FAIL':print(x)
sys.exit(bool(result['fail']))
