package main

import (
	"fmt"
	"strings"
)

// Geometry, text and colours are shared by the native painter and the review preview.
const uiBackground uint32 = 0xEEF3FF

type installerView struct {
	Installed, Operating         bool
	InstalledVer, Target, Status string
	AutoCAD                      []string
	Progress                     int
}
type sceneOp struct {
	Kind         string
	Box          [4]int
	Fill, Border uint32
	Radius       int
	Text, Font   string
	Wrap, Center bool
}
type uiButton struct {
	ID    int
	Label string
	Box   [4]int
}

func installerButtons() []uiButton {
	return []uiButton{
		{1003, "Guida", [4]int{32, 514, 136, 558}},
		{1004, "Sostieni", [4]int{148, 514, 256, 558}},
		{1002, "Disinstalla", [4]int{268, 514, 400, 558}},
		{1005, "Chiudi", [4]int{540, 514, 656, 558}},
		{1001, "Installa", [4]int{668, 514, 888, 558}},
	}
}

// Palette specifiche per azione; gli stati disabilitati restano riconoscibili.
func buttonPalette(id int, disabled, pressed bool) (uint32, uint32, uint32) {
	if disabled {
		return 0xE3E9F4, 0xB8C7DE, 0x62738D
	}
	switch id {
	case 1001: // Installa / Aggiorna / Ripara
		if pressed {
			return 0x1743B2, 0x103487, 0xFFFFFF
		}
		return 0x245AE5, 0x1945C4, 0xFFFFFF
	case 1003: // Guida
		if pressed {
			return 0x0A5C61, 0x07484C, 0xFFFFFF
		}
		return 0x087B80, 0x08666B, 0xFFFFFF
	case 1004: // Sostieni
		if pressed {
			return 0x6131AA, 0x482284, 0xFFFFFF
		}
		return 0x7945C8, 0x6333B0, 0xFFFFFF
	case 1002: // Disinstalla: discreto, con contorno rosso
		if pressed {
			return 0xFFD7DE, 0xD94661, 0x98233D
		}
		return 0xFFF0F3, 0xE86881, 0xA52A46
	default: // Chiudi
		if pressed {
			return 0xD7E4FF, 0x4D77CD, 0x244A90
		}
		return 0xE8F0FF, 0x83A6E8, 0x294F93
	}
}
func installerScene(s installerView) []sceneOp {
	var ops []sceneOp
	box := func(x1, y1, x2, y2, r int, fill, border uint32) {
		ops = append(ops, sceneOp{Kind: "box", Box: [4]int{x1, y1, x2, y2}, Radius: r, Fill: fill, Border: border})
	}
	text := func(t, font string, x1, y1, x2, y2 int, col uint32, wrap, center bool) {
		ops = append(ops, sceneOp{Kind: "text", Box: [4]int{x1, y1, x2, y2}, Text: t, Font: font, Fill: col, Wrap: wrap, Center: center})
	}
	const ink = 0x1D2939
	const muted = 0x66758C
	const border = 0x8EAFE9
	box(0, 0, 920, 600, 0, uiBackground, uiBackground)
	box(0, 0, 308, 5, 0, 0x245AE5, 0x245AE5)
	box(308, 0, 612, 5, 0, 0x00B9AF, 0x00B9AF)
	box(612, 0, 920, 5, 0, 0x9560E8, 0x9560E8)
	box(32, 32, 96, 96, 16, 0x245AE5, 0x245AE5)
	text("AG", "logo", 32, 32, 96, 96, 0xFFFFFF, false, true)
	text("AG CAD TOOLS", "brand", 116, 27, 710, 74, ink, false, false)
	text("andreagiaquinto.it", "normal", 118, 77, 306, 100, 0x0067C0, false, false)
	text("AutoCAD · Windows x64", "small", 322, 78, 650, 100, muted, false, false)
	box(770, 43, 888, 79, 18, 0xECE0FF, 0xBE96F0)
	text("2.0  ·  RC5", "small", 770, 43, 888, 79, 0x6531AD, false, true)
	text("Il tuo prossimo progetto, in italiano.", "title", 32, 132, 888, 177, ink, false, false)
	text("198 strumenti, 16 categorie. Tutto a portata di comando.", "normal", 33, 180, 888, 207, muted, false, false)
	box(32, 228, 592, 397, 12, 0xFFFFFF, 0x6C97F0)
	box(47, 246, 51, 275, 2, 0x245AE5, 0x245AE5)
	text("Installazione", "section", 56, 247, 420, 273, ink, false, false)
	installed := "Pronto per la prima installazione"
	statusColor := uint32(0x2457A7)
	if s.Installed {
		v := s.InstalledVer
		if v == "" {
			v = "versione non rilevata"
		}
		installed = "Installato · " + v
		statusColor = 0x167463
	}
	text(installed, "normal", 56, 280, 568, 306, statusColor, false, false)
	text("Cartella del plugin", "small", 56, 316, 568, 337, muted, false, false)
	text(s.Target, "small", 56, 344, 568, 383, muted, true, false)
	box(612, 228, 888, 397, 12, 0xF3FFFC, 0x40B7A8)
	box(627, 246, 631, 275, 2, 0x079989, 0x079989)
	text("AutoCAD rilevato", "section", 636, 247, 866, 273, ink, false, false)
	detected := "Non rilevato nei percorsi standard. Puoi comunque installare il plugin."
	if len(s.AutoCAD) > 0 {
		detected = strings.Join(s.AutoCAD, "\n")
	}
	text(detected, "small", 636, 282, 865, 356, muted, true, false)
	text("Chiudi AutoCAD per procedere.", "small", 636, 367, 865, 387, 0x8D601B, false, false)
	box(32, 415, 888, 483, 12, 0xFFFFFF, border)
	status := s.Status
	if status == "" {
		status = "Pronto per iniziare"
	}
	text(status, "normal", 52, 426, 804, 453, ink, false, false)
	p := s.Progress
	if p < 0 {
		p = 0
	}
	if p > 100 {
		p = 100
	}
	text(fmt.Sprintf("%d%%", p), "small", 814, 426, 868, 453, muted, false, true)
	box(52, 462, 868, 468, 3, 0xDCE6FF, 0xDCE6FF)
	if p > 0 {
		w := 816 * p / 100
		if w < 6 {
			w = 6
		}
		box(52, 462, 52+w, 468, 3, 0x245AE5, 0x245AE5)
	}
	text("Installazione nel tuo profilo · copia di sicurezza automatica in caso di aggiornamento", "small", 32, 574, 888, 594, muted, false, false)
	return ops
}
