package main

import (
	"encoding/xml"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const legacyBundleName = "CADToolsItaliano.bundle"

func legacyTarget(target string) string { return filepath.Join(filepath.Dir(target), legacyBundleName) }
func existsDir(p string) bool           { st, err := os.Stat(p); return err == nil && st.IsDir() }
func existingBundle(target string) string {
	if existsDir(target) {
		return target
	}
	legacy := legacyTarget(target)
	if existsDir(legacy) {
		return legacy
	}
	return ""
}
func existingResource(path string) string {
	if _, err := os.Stat(path); err == nil {
		return path
	}
	old := map[string]string{"AG_CAD_Tools_Help.html": "CAD_Tools_Italiano_Help.html", "AG_CAD_Tools_Sostieni.html": "CAD_Tools_Italiano_Sostieni.html"}
	if n, ok := old[filepath.Base(path)]; ok {
		return filepath.Join(filepath.Dir(path), n)
	}
	return path
}
func recognizeLegacy(path string) error {
	b, err := os.ReadFile(filepath.Join(path, "PackageContents.xml"))
	if err != nil {
		return fmt.Errorf("verifica del plugin precedente: %w", err)
	}
	var p struct {
		Name        string `xml:"Name,attr"`
		UpgradeCode string `xml:"UpgradeCode,attr"`
	}
	if err = xml.Unmarshal(b, &p); err != nil {
		return fmt.Errorf("manifest del plugin precedente non leggibile: %w", err)
	}
	if p.Name != "CAD Tools Italiano" || !strings.EqualFold(p.UpgradeCode, "{0D9E7026-A9CF-4E2B-9C91-54D2416CFE8D}") {
		return fmt.Errorf("la cartella precedente non corrisponde a CAD Tools Italiano; nessun file è stato rimosso")
	}
	return nil
}

// Wrap the unchanged SHA/staging/rollback engine in a reversible identity migration.
// The parked folder has no .bundle suffix, so it is not a second active package.
func installWithMigration(target, dataRoot string, cb ProgressFunc) (InstallResult, error) {
	legacy := legacyTarget(target)
	parked := legacy + ".ag-migrazione"
	if existsDir(parked) {
		if existsDir(legacy) {
			return InstallResult{}, fmt.Errorf("migrazione precedente da recuperare: presenti %s e %s", legacy, parked)
		}
		if err := recognizeLegacy(parked); err != nil {
			return InstallResult{}, err
		}
		if err := os.Rename(parked, legacy); err != nil {
			return InstallResult{}, fmt.Errorf("ripristino della migrazione interrotta: %w", err)
		}
	}
	if !existsDir(legacy) {
		return installWithProgress(target, dataRoot, cb)
	}
	if filepath.Clean(legacy) == filepath.Clean(target) {
		return InstallResult{}, fmt.Errorf("destinazione di migrazione non valida")
	}
	if err := recognizeLegacy(legacy); err != nil {
		return InstallResult{}, err
	}
	if dataRoot == "" {
		return InstallResult{}, fmt.Errorf("cartella locale di backup non disponibile: migrazione annullata")
	}
	backup := filepath.Join(dataRoot, "BackupCADToolsItaliano.bundle")
	reportProgress(cb, "Conservazione del plugin precedente...", 0)
	if err := copyDirVerified(legacy, backup); err != nil {
		return InstallResult{}, fmt.Errorf("backup prima della migrazione: %w", err)
	}
	if err := os.Rename(legacy, parked); err != nil {
		return InstallResult{}, fmt.Errorf("preparazione della migrazione: %w", err)
	}
	result, err := installWithProgress(target, dataRoot, cb)
	if err != nil {
		if restore := os.Rename(parked, legacy); restore != nil {
			return result, fmt.Errorf("%v; ripristino del nome precedente fallito: %v; backup in %s", err, restore, backup)
		}
		return result, err
	}
	result.Updated = true
	if result.BackupPath == "" {
		result.BackupPath = backup
	}
	if err = os.RemoveAll(parked); err != nil {
		return result, fmt.Errorf("AG CAD Tools installato; impossibile eliminare la copia temporanea disattivata %s: %w", parked, err)
	}
	return result, nil
}
func uninstallAll(target string) error {
	legacy := legacyTarget(target)
	if existsDir(legacy) {
		if err := recognizeLegacy(legacy); err != nil {
			return err
		}
	}
	if err := uninstall(target); err != nil {
		return err
	}
	if existsDir(legacy) {
		return uninstall(legacy)
	}
	return nil
}
