package main

import (
	"crypto/sha256"
	"embed"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

//go:embed bundle/**
var bundleFS embed.FS

const (
	version     = "2.0"
	productName = "AG CAD Tools"
)

type ProgressFunc func(stage string, percent int)

type InstallResult struct {
	Updated    bool
	BackupPath string
	Files      int
}

type bundleEntry struct {
	rel  string
	data []byte
	hash [32]byte
}

func targetDir() (string, error) {
	a := os.Getenv("APPDATA")
	if a == "" {
		return "", fmt.Errorf("variabile APPDATA non disponibile")
	}
	return filepath.Join(a, "Autodesk", "ApplicationPlugins", "AGCADTools.bundle"), nil
}

func installerDataDir() (string, error) {
	a := os.Getenv("LOCALAPPDATA")
	if a == "" {
		return "", fmt.Errorf("variabile LOCALAPPDATA non disponibile")
	}
	return filepath.Join(a, "AGCADTools", "Installer"), nil
}

func installedVersion(target string) string {
	b, err := os.ReadFile(filepath.Join(target, "PackageContents.xml"))
	if err != nil {
		return ""
	}
	re := regexp.MustCompile(`AppVersion="([0-9]+\.[0-9]+)(?:\.[0-9]+\.[0-9]+)?"`)
	m := re.FindSubmatch(b)
	if len(m) != 2 {
		return ""
	}
	return string(m[1])
}

func embeddedEntries() ([]bundleEntry, error) {
	var entries []bundleEntry
	err := fs.WalkDir(bundleFS, "bundle", func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		data, e := bundleFS.ReadFile(path)
		if e != nil {
			return e
		}
		rel := filepath.FromSlash(strings.TrimPrefix(path, "bundle/"))
		entries = append(entries, bundleEntry{rel: rel, data: data, hash: sha256.Sum256(data)})
		return nil
	})
	if err != nil {
		return nil, err
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].rel < entries[j].rel })
	if len(entries) == 0 {
		return nil, fmt.Errorf("payload incorporato vuoto")
	}
	return entries, nil
}

func reportProgress(cb ProgressFunc, stage string, percent int) {
	if cb == nil {
		return
	}
	if percent < 0 {
		percent = 0
	}
	if percent > 100 {
		percent = 100
	}
	cb(stage, percent)
}

func verifyEntries(root string, entries []bundleEntry, cb ProgressFunc, base, span int, stage string) error {
	for i, e := range entries {
		data, err := os.ReadFile(filepath.Join(root, e.rel))
		if err != nil {
			return fmt.Errorf("lettura %s: %w", e.rel, err)
		}
		if sha256.Sum256(data) != e.hash {
			return fmt.Errorf("verifica SHA-256 fallita: %s", e.rel)
		}
		p := base + ((i + 1) * span / len(entries))
		reportProgress(cb, stage, p)
	}
	return nil
}

func copyFileVerified(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err = os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	h1 := sha256.New()
	_, copyErr := io.Copy(out, io.TeeReader(in, h1))
	closeErr := out.Close()
	if copyErr != nil {
		return copyErr
	}
	if closeErr != nil {
		return closeErr
	}
	written, err := os.ReadFile(dst)
	if err != nil {
		return err
	}
	if !strings.EqualFold(fmt.Sprintf("%x", h1.Sum(nil)), fmt.Sprintf("%x", sha256.Sum256(written))) {
		return fmt.Errorf("verifica copia fallita: %s", filepath.Base(src))
	}
	return nil
}

func copyDirVerified(src, dst string) error {
	_ = os.RemoveAll(dst)
	if err := os.MkdirAll(dst, 0755); err != nil {
		return err
	}
	return filepath.WalkDir(src, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		if rel == "." {
			return nil
		}
		out := filepath.Join(dst, rel)
		if d.IsDir() {
			return os.MkdirAll(out, 0755)
		}
		return copyFileVerified(path, out)
	})
}

func install(target string) error {
	dataRoot, _ := installerDataDir()
	_, err := installWithProgress(target, dataRoot, nil)
	return err
}

func installWithProgress(target, dataRoot string, cb ProgressFunc) (InstallResult, error) {
	var result InstallResult
	entries, err := embeddedEntries()
	if err != nil {
		return result, err
	}
	result.Files = len(entries)

	if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
		return result, err
	}

	staging := target + ".staging"
	rollback := target + ".rollback"
	_ = os.RemoveAll(staging)
	_ = os.RemoveAll(rollback)
	if err := os.MkdirAll(staging, 0755); err != nil {
		return result, err
	}

	reportProgress(cb, "Preparazione dei file...", 2)
	for i, e := range entries {
		out := filepath.Join(staging, e.rel)
		if err := os.MkdirAll(filepath.Dir(out), 0755); err != nil {
			_ = os.RemoveAll(staging)
			return result, err
		}
		if err := os.WriteFile(out, e.data, 0644); err != nil {
			_ = os.RemoveAll(staging)
			return result, err
		}
		reportProgress(cb, "Estrazione del plugin...", 5+((i+1)*40/len(entries)))
	}
	if err := verifyEntries(staging, entries, cb, 45, 20, "Verifica SHA-256..."); err != nil {
		_ = os.RemoveAll(staging)
		return result, err
	}

	_, statErr := os.Stat(target)
	hasOld := statErr == nil
	result.Updated = hasOld

	if hasOld && dataRoot != "" {
		backupPath := filepath.Join(dataRoot, "BackupPrecedente.bundle")
		reportProgress(cb, "Conservazione della versione precedente...", 68)
		if err := os.MkdirAll(dataRoot, 0755); err != nil {
			_ = os.RemoveAll(staging)
			return result, err
		}
		if err := copyDirVerified(target, backupPath); err != nil {
			_ = os.RemoveAll(staging)
			return result, fmt.Errorf("backup della versione precedente: %w", err)
		}
		result.BackupPath = backupPath
	}

	reportProgress(cb, "Attivazione atomica...", 74)
	if hasOld {
		if err := os.Rename(target, rollback); err != nil {
			_ = os.RemoveAll(staging)
			return result, fmt.Errorf("impossibile preparare l'aggiornamento: %w", err)
		}
	}

	activateErr := os.Rename(staging, target)
	if activateErr != nil {
		if hasOld {
			if restoreErr := os.Rename(rollback, target); restoreErr != nil {
				return result, fmt.Errorf("attivazione fallita: %v; ripristino automatico fallito: %v; copia di sicurezza: %s", activateErr, restoreErr, result.BackupPath)
			}
		}
		_ = os.RemoveAll(staging)
		return result, fmt.Errorf("attivazione fallita: %w", activateErr)
	}

	reportProgress(cb, "Verifica dell'installazione attiva...", 84)
	if err := verifyEntries(target, entries, cb, 84, 15, "Verifica finale..."); err != nil {
		_ = os.RemoveAll(target)
		if hasOld {
			if restoreErr := os.Rename(rollback, target); restoreErr != nil {
				return result, fmt.Errorf("verifica finale fallita: %v; ripristino automatico fallito: %v; copia di sicurezza: %s", err, restoreErr, result.BackupPath)
			}
		}
		return result, fmt.Errorf("verifica finale fallita: %w", err)
	}

	if hasOld {
		_ = os.RemoveAll(rollback)
	}
	reportProgress(cb, "Installazione completata.", 100)
	return result, nil
}

func uninstall(target string) error {
	if err := os.RemoveAll(target); err != nil {
		return err
	}
	return nil
}
