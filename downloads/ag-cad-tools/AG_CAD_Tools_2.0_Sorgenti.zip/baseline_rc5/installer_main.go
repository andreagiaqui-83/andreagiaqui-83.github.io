//go:build windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"syscall"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	procRegisterClassExW   = user32.NewProc("RegisterClassExW")
	procCreateWindowExW    = user32.NewProc("CreateWindowExW")
	procDefWindowProcW     = user32.NewProc("DefWindowProcW")
	procShowWindow         = user32.NewProc("ShowWindow")
	procUpdateWindow       = user32.NewProc("UpdateWindow")
	procGetMessageW        = user32.NewProc("GetMessageW")
	procTranslateMessage   = user32.NewProc("TranslateMessage")
	procDispatchMessageW   = user32.NewProc("DispatchMessageW")
	procPostQuitMessage    = user32.NewProc("PostQuitMessage")
	procLoadCursorW        = user32.NewProc("LoadCursorW")
	procLoadIconW          = user32.NewProc("LoadIconW")
	procGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	procSetWindowPos       = user32.NewProc("SetWindowPos")
	procAdjustWindowRectEx = user32.NewProc("AdjustWindowRectEx")
	procSetWindowTextW     = user32.NewProc("SetWindowTextW")
	procEnableWindow       = user32.NewProc("EnableWindow")
	procInvalidateRect     = user32.NewProc("InvalidateRect")
	procSendMessageW       = user32.NewProc("SendMessageW")
	procPostMessageW       = user32.NewProc("PostMessageW")
	procDestroyWindow      = user32.NewProc("DestroyWindow")
	procBeginPaint         = user32.NewProc("BeginPaint")
	procEndPaint           = user32.NewProc("EndPaint")
	procFillRect           = user32.NewProc("FillRect")
	procDrawTextW          = user32.NewProc("DrawTextW")
	procSetProcessDPIAware = user32.NewProc("SetProcessDPIAware")
	procMessageBoxW        = user32.NewProc("MessageBoxW")

	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")

	procGetModuleHandleW       = kernel32.NewProc("GetModuleHandleW")
	procCreateToolhelpSnapshot = kernel32.NewProc("CreateToolhelp32Snapshot")
	procProcess32FirstW        = kernel32.NewProc("Process32FirstW")
	procProcess32NextW         = kernel32.NewProc("Process32NextW")
	procCloseHandle            = kernel32.NewProc("CloseHandle")
	procRtlMoveMemory          = kernel32.NewProc("RtlMoveMemory")

	procShellExecuteW         = shell32.NewProc("ShellExecuteW")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	procGetFocus              = user32.NewProc("GetFocus")
	procSetFocus              = user32.NewProc("SetFocus")
	procIsWindowEnabled       = user32.NewProc("IsWindowEnabled")
)

const (
	wsOverlapped    = 0x00000000
	wsCaption       = 0x00C00000
	wsSysMenu       = 0x00080000
	wsMinimizeBox   = 0x00020000
	wsChild         = 0x40000000
	wsVisible       = 0x10000000
	wsClipChildren  = 0x02000000
	wsClipSiblings  = 0x04000000
	wsTabStop       = 0x00010000
	bsPushButton    = 0x00000000
	bsDefPushButton = 0x00000001

	wmDestroy     = 0x0002
	wmPaint       = 0x000F
	wmEraseBkgnd  = 0x0014
	wmClose       = 0x0010
	wmDrawItem    = 0x002B
	wmCommand     = 0x0111
	wmSetFont     = 0x0030
	wmApp         = 0x8000
	wmAppProgress = wmApp + 1
	wmAppDone     = wmApp + 2

	swShow         = 5
	swShNormal     = 1
	colorWindow    = 5
	idcArrow       = 32512
	idiApplication = 32512

	dtLeft        = 0x0000
	dtCenter      = 0x0001
	dtVCenter     = 0x0004
	dtWordBreak   = 0x0010
	dtSingleLine  = 0x0020
	dtEndEllipsis = 0x8000

	transparent      = 1
	fwNormal         = 400
	fwSemiBold       = 600
	fwBold           = 700
	defaultCharset   = 1
	clearTypeQuality = 5

	psSolid = 0
	srcCopy = 0x00CC0020

	smCxScreen = 0
	smCyScreen = 1

	pbmSetRange32 = 0x0400 + 6
	pbmSetPos     = 0x0400 + 2
	pbsSmooth     = 0x01

	iccProgressClass = 0x00000020

	th32csSnapProcess = 0x00000002
	invalidHandle     = ^uintptr(0)

	mbOK           = 0x00000000
	mbOKCancel     = 0x00000001
	mbYesNo        = 0x00000004
	mbIconInfo     = 0x00000040
	mbIconQuestion = 0x00000020
	mbIconWarning  = 0x00000030
	idOK           = 1
	idYes          = 6

	idInstall   = 1001
	idUninstall = 1002
	idGuide     = 1003
	idSupport   = 1004
	idClose     = 1005
)

const (
	clientW = 920
	clientH = 600
)

type wndClassEx struct {
	Size, Style              uint32
	WndProc                  uintptr
	ClsExtra, WndExtra       int32
	Instance                 uintptr
	Icon, Cursor, Background uintptr
	MenuName, ClassName      *uint16
	IconSm                   uintptr
}

type msg struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             struct{ X, Y int32 }
	Private        uint32
}

type rect struct{ Left, Top, Right, Bottom int32 }

type paintStruct struct {
	Hdc                uintptr
	Erase              int32
	RcPaint            rect
	Restore, IncUpdate int32
	RgbReserved        [32]byte
}

type initCommonControlsEx struct {
	Size uint32
	ICC  uint32
}

type processEntry32 struct {
	Size            uint32
	CntUsage        uint32
	ProcessID       uint32
	DefaultHeapID   uintptr
	ModuleID        uint32
	CntThreads      uint32
	ParentProcessID uint32
	PriClassBase    int32
	Flags           uint32
	ExeFile         [260]uint16
}

type uiSnapshot struct {
	Status       string
	Progress     int
	Operating    bool
	Installed    bool
	InstalledVer string
	AutoCAD      []string
	Target       string
	LastBackup   string
}

var (
	hwndMain                                                           uintptr
	btnInstall, btnUninstall, btnGuide, btnSupport, btnClose           uintptr
	fontNormal, fontSmall, fontSection, fontTitle, fontBrand, fontLogo uintptr
	stateMu                                                            sync.Mutex
	state                                                              uiSnapshot
	opMu                                                               sync.Mutex
	opErr                                                              error
	opKind                                                             string
	opInstallResult                                                    InstallResult
)

func utf16Ptr(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

func messageBox(title, text string, flags uintptr) int {
	r, _, _ := procMessageBoxW.Call(hwndMain, uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(unsafe.Pointer(utf16Ptr(title))), flags)
	return int(r)
}

func setText(hwnd uintptr, s string) {
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(utf16Ptr(s))))
}
func enable(hwnd uintptr, yes bool) {
	v := uintptr(0)
	if yes {
		v = 1
	}
	procEnableWindow.Call(hwnd, v)
}

func loword(v uintptr) uint16 { return uint16(v & 0xffff) }

func setUIFont(hwnd, font uintptr) { procSendMessageW.Call(hwnd, wmSetFont, font, 1) }

var uiFontFace = "Segoe UI"

func createFont(height int32, weight int32) uintptr {
	r, _, _ := procCreateFontW.Call(
		uintptr(int64(height)), 0, 0, 0, uintptr(weight), 0, 0, 0,
		defaultCharset, 0, 0, clearTypeQuality, 0,
		uintptr(unsafe.Pointer(utf16Ptr(uiFontFace))),
	)
	return r
}

func selectFont(hdc, font uintptr) uintptr {
	old, _, _ := procSelectObject.Call(hdc, font)
	return old
}

func drawText(hdc uintptr, text string, rc rect, color uintptr, font uintptr, flags uintptr) {
	old := selectFont(hdc, font)
	procSetBkMode.Call(hdc, transparent)
	procSetTextColor.Call(hdc, color)
	p := utf16Ptr(text)
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(p)), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), flags)
	procSelectObject.Call(hdc, old)
}

func fillRect(hdc uintptr, rc rect, color uintptr) {
	b, _, _ := procCreateSolidBrush.Call(color)
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), b)
	procDeleteObject.Call(b)
}

func roundedRect(hdc uintptr, rc rect, fill, border uintptr, radius int32) {
	b, _, _ := procCreateSolidBrush.Call(fill)
	p, _, _ := procCreatePen.Call(psSolid, 1, border)
	oldB, _, _ := procSelectObject.Call(hdc, b)
	oldP, _, _ := procSelectObject.Call(hdc, p)
	procRoundRect.Call(hdc, uintptr(rc.Left), uintptr(rc.Top), uintptr(rc.Right), uintptr(rc.Bottom), uintptr(radius), uintptr(radius))
	procSelectObject.Call(hdc, oldB)
	procSelectObject.Call(hdc, oldP)
	procDeleteObject.Call(b)
	procDeleteObject.Call(p)
}

func line(hdc uintptr, x1, y1, x2, y2 int32, color uintptr, width int) {
	p, _, _ := procCreatePen.Call(psSolid, uintptr(width), color)
	old, _, _ := procSelectObject.Call(hdc, p)
	procMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	procSelectObject.Call(hdc, old)
	procDeleteObject.Call(p)
}

func snapshot() uiSnapshot {
	stateMu.Lock()
	defer stateMu.Unlock()
	cp := state
	cp.AutoCAD = append([]string(nil), state.AutoCAD...)
	return cp
}

func displayTarget(path string) string {
	appdata := os.Getenv("APPDATA")
	if appdata != "" {
		cleanPath := filepath.Clean(path)
		cleanApp := filepath.Clean(appdata)
		if strings.HasPrefix(strings.ToLower(cleanPath), strings.ToLower(cleanApp)+strings.ToLower(string(os.PathSeparator))) {
			rel, err := filepath.Rel(cleanApp, cleanPath)
			if err == nil {
				return filepath.Join("%APPDATA%", rel)
			}
		}
	}
	return path
}

func invalidateRegion(rc *rect) {
	if hwndMain == 0 {
		return
	}
	if rc == nil {
		procInvalidateRect.Call(hwndMain, 0, 0)
		return
	}
	procInvalidateRect.Call(hwndMain, uintptr(unsafe.Pointer(rc)), 0)
}

func setProgress(stage string, percent int) {
	stateMu.Lock()
	changed := state.Status != stage || state.Progress != percent
	state.Status = stage
	state.Progress = percent
	stateMu.Unlock()
	if changed && hwndMain != 0 {
		procPostMessageW.Call(hwndMain, wmAppProgress, 0, 0)
	}
}

func refreshState() {
	s := snapshot()
	if s.Target == "" {
		return
	}
	installedPath := existingBundle(s.Target)
	_, err := os.Stat(installedPath)
	inst := err == nil
	ver := ""
	if inst {
		ver = installedVersion(installedPath)
	}
	stateMu.Lock()
	state.Installed = inst
	state.InstalledVer = ver
	state.AutoCAD = detectAutoCAD()
	stateMu.Unlock()
	updateButtons()
}

func updateButtons() {
	s := snapshot()
	if btnInstall == 0 {
		return
	}
	if s.Installed {
		if s.InstalledVer == version && existingBundle(s.Target) == s.Target {
			setText(btnInstall, "Ripara")
		} else {
			setText(btnInstall, "Aggiorna")
		}
	} else {
		setText(btnInstall, "Installa")
	}
	enable(btnInstall, !s.Operating)
	enable(btnUninstall, !s.Operating && s.Installed)
	enable(btnGuide, !s.Operating && s.Installed)
	enable(btnSupport, !s.Operating && s.Installed)
	enable(btnClose, !s.Operating)
}

func detectAutoCAD() []string {
	roots := []string{os.Getenv("ProgramW6432"), os.Getenv("ProgramFiles")}
	seen := map[string]bool{}
	var out []string
	for year := 2024; year <= 2027; year++ {
		label := fmt.Sprintf("AutoCAD %d", year)
		for _, root := range roots {
			if root == "" {
				continue
			}
			p := filepath.Join(root, "Autodesk", label, "acad.exe")
			if _, err := os.Stat(p); err == nil && !seen[label] {
				seen[label] = true
				out = append(out, label)
			}
		}
	}
	sort.Strings(out)
	return out
}

func autoCADRunning() bool {
	snap, _, _ := procCreateToolhelpSnapshot.Call(th32csSnapProcess, 0)
	if snap == 0 || snap == invalidHandle {
		return false
	}
	defer procCloseHandle.Call(snap)
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	r, _, _ := procProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	for r != 0 {
		exe := syscall.UTF16ToString(pe.ExeFile[:])
		if strings.EqualFold(exe, "acad.exe") {
			return true
		}
		r, _, _ = procProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	}
	return false
}

func openFile(path string) error {
	if _, err := os.Stat(path); err != nil {
		return err
	}
	r, _, _ := procShellExecuteW.Call(hwndMain, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr(path))), 0, 0, swShNormal)
	if r <= 32 {
		return fmt.Errorf("ShellExecute ha restituito %d", r)
	}
	return nil
}

func startInstall() {
	s := snapshot()
	if s.Operating {
		return
	}
	if autoCADRunning() {
		messageBox(productName+" "+version, "AutoCAD risulta in esecuzione.\n\nChiudi tutte le istanze di AutoCAD prima di installare o aggiornare il plugin.", mbOK|mbIconWarning)
		return
	}
	stateMu.Lock()
	state.Operating = true
	state.Status = "Avvio installazione..."
	state.Progress = 0
	stateMu.Unlock()
	updateButtons()
	invalidateRegion(nil)
	go func() {
		dataRoot, _ := installerDataDir()
		res, err := installWithMigration(s.Target, dataRoot, func(stage string, p int) { setProgress(stage, p) })
		opMu.Lock()
		opErr = err
		opKind = "install"
		opInstallResult = res
		opMu.Unlock()
		procPostMessageW.Call(hwndMain, wmAppDone, 0, 0)
	}()
}

func startUninstall() {
	s := snapshot()
	if s.Operating || !s.Installed {
		return
	}
	if autoCADRunning() {
		messageBox(productName+" "+version, "AutoCAD risulta in esecuzione.\n\nChiudi tutte le istanze di AutoCAD prima della disinstallazione.", mbOK|mbIconWarning)
		return
	}
	if messageBox(productName+" "+version, "Disinstallare AG CAD Tools?\n\nVerrà rimosso soltanto il bundle del plugin dal profilo utente.", mbYesNo|mbIconQuestion) != idYes {
		return
	}
	stateMu.Lock()
	state.Operating = true
	state.Status = "Disinstallazione..."
	state.Progress = 20
	stateMu.Unlock()
	updateButtons()
	invalidateRegion(nil)
	go func() {
		err := uninstallAll(s.Target)
		setProgress("Disinstallazione completata.", 100)
		opMu.Lock()
		opErr = err
		opKind = "uninstall"
		opInstallResult = InstallResult{}
		opMu.Unlock()
		procPostMessageW.Call(hwndMain, wmAppDone, 0, 0)
	}()
}

func handleDone() {
	opMu.Lock()
	err := opErr
	kind := opKind
	res := opInstallResult
	opMu.Unlock()
	stateMu.Lock()
	state.Operating = false
	stateMu.Unlock()
	refreshState()
	if err != nil {
		stateMu.Lock()
		state.Status = "Operazione non completata."
		state.Progress = 0
		stateMu.Unlock()
		messageBox(productName, "Operazione non riuscita:\n\n"+err.Error(), mbOK|mbIconWarning)
	} else if kind == "install" {
		stateMu.Lock()
		state.Status = "Installazione verificata e completata."
		state.Progress = 100
		state.LastBackup = res.BackupPath
		stateMu.Unlock()
		msg := "Installazione completata e verificata.\n\nAvvia o riavvia AutoCAD e digita AGCADTOOLS."
		if res.BackupPath != "" {
			msg += "\n\nLa versione precedente è stata conservata come copia di sicurezza."
		}
		invalidateRegion(nil)
		procUpdateWindow.Call(hwndMain)
		if messageBox(productName+" "+version, msg, mbOK|mbIconInfo) == idOK {
			procDestroyWindow.Call(hwndMain)
			return
		}
	} else {
		stateMu.Lock()
		state.Status = "Plugin disinstallato."
		state.Progress = 100
		stateMu.Unlock()
		messageBox(productName+" "+version, "Disinstallazione completata.", mbOK|mbIconInfo)
	}
	updateButtons()
	invalidateRegion(nil)
}

func paintCanvas(hdc uintptr, s uiSnapshot) {
	model := installerView{Installed: s.Installed, InstalledVer: s.InstalledVer, Operating: s.Operating,
		AutoCAD: s.AutoCAD, Target: displayTarget(s.Target), Status: s.Status, Progress: s.Progress}
	for _, op := range installerScene(model) {
		r := rect{int32(op.Box[0]), int32(op.Box[1]), int32(op.Box[2]), int32(op.Box[3])}
		if op.Kind == "box" {
			if op.Radius == 0 {
				fillRect(hdc, r, hexColor(op.Fill))
			} else {
				roundedRect(hdc, r, hexColor(op.Fill), hexColor(op.Border), int32(op.Radius*2))
			}
		} else {
			font := fontNormal
			switch op.Font {
			case "small":
				font = fontSmall
			case "section":
				font = fontSection
			case "title":
				font = fontTitle
			case "brand":
				font = fontBrand
			case "logo":
				font = fontLogo
			}
			flags := uintptr(dtLeft | dtVCenter | dtSingleLine | dtEndEllipsis)
			if op.Wrap {
				flags = dtLeft | dtWordBreak
			} else if op.Center {
				flags = dtCenter | dtVCenter | dtSingleLine
			}
			drawText(hdc, op.Text, r, hexColor(op.Fill), font, flags)
		}
	}
}

func hexColor(c uint32) uintptr { return rgb(byte(c>>16), byte(c>>8), byte(c)) }

type drawItemStruct struct {
	CtlType, CtlID, ItemID, ItemAction, ItemState uint32
	HwndItem, Hdc                                 uintptr
	RcItem                                        rect
	ItemData                                      uintptr
}

func paintButton(d *drawItemStruct) {
	disabled := d.ItemState&4 != 0
	pressed := d.ItemState&1 != 0
	fill, border, ink := buttonPalette(int(d.CtlID), disabled, pressed)
	fillRect(d.Hdc, d.RcItem, hexColor(uiBackground))
	r := d.RcItem
	r.Left++
	r.Top++
	r.Right--
	r.Bottom--
	roundedRect(d.Hdc, r, hexColor(fill), hexColor(border), 12)
	if d.ItemState&16 != 0 {
		r.Left += 3
		r.Top += 3
		r.Right -= 3
		r.Bottom -= 3
		focus := uint32(0x154C83)
		if d.CtlID == idInstall || d.CtlID == idGuide || d.CtlID == idSupport {
			focus = 0xFFFFFF
		}
		roundedRect(d.Hdc, r, hexColor(fill), hexColor(focus), 8)
	}
	var label [128]uint16
	procGetWindowTextW.Call(d.HwndItem, uintptr(unsafe.Pointer(&label[0])), uintptr(len(label)))
	drawText(d.Hdc, syscall.UTF16ToString(label[:]), d.RcItem, hexColor(ink), fontNormal, dtCenter|dtVCenter|dtSingleLine)
}

func paint(hwnd uintptr) {
	var ps paintStruct
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	// Paint the complete client area off-screen and present it in one BitBlt.
	// Together with WS_CLIPCHILDREN and WM_ERASEBKGND suppression this removes
	// the visible white flashes that occurred while progress updates arrived.
	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	if memDC == 0 {
		paintCanvas(hdc, snapshot())
		return
	}
	defer procDeleteDC.Call(memDC)
	bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, clientW, clientH)
	if bmp == 0 {
		paintCanvas(hdc, snapshot())
		return
	}
	oldBmp, _, _ := procSelectObject.Call(memDC, bmp)
	paintCanvas(memDC, snapshot())
	procBitBlt.Call(hdc, 0, 0, clientW, clientH, memDC, 0, 0, srcCopy)
	procSelectObject.Call(memDC, oldBmp)
	procDeleteObject.Call(bmp)
}

func wndProc(hwnd uintptr, message uint32, wParam, lParam uintptr) uintptr {
	switch message {
	case wmDrawItem:
		if lParam != 0 {
			// LPARAM also carries integers in other messages. Keep the callback
			// argument scalar and copy only this documented native structure.
			var d drawItemStruct
			procRtlMoveMemory.Call(uintptr(unsafe.Pointer(&d)), lParam, unsafe.Sizeof(d))
			if d.CtlType == 4 {
				paintButton(&d)
				return 1
			}
		}
	case wmCommand:
		switch int(loword(wParam)) {
		case idInstall:
			startInstall()
		case idUninstall:
			startUninstall()
		case idGuide:
			p := filepath.Join(existingBundle(snapshot().Target), "Contents", "Win64", "AG_CAD_Tools_Help.html")
			p = existingResource(p)
			if err := openFile(p); err != nil {
				messageBox(productName, "Impossibile aprire la Guida:\n"+err.Error(), mbOK|mbIconWarning)
			}
		case idSupport:
			p := filepath.Join(existingBundle(snapshot().Target), "Contents", "Win64", "AG_CAD_Tools_Sostieni.html")
			p = existingResource(p)
			if err := openFile(p); err != nil {
				messageBox(productName, "Impossibile aprire la pagina Sostieni:\n"+err.Error(), mbOK|mbIconWarning)
			}
		case idClose:
			if !snapshot().Operating {
				procDestroyWindow.Call(hwnd)
			}
		}
		return 0
	case wmAppProgress:
		rc := rect{30, 410, 890, 490}
		invalidateRegion(&rc)
		return 0
	case wmAppDone:
		handleDone()
		return 0
	case wmPaint:
		paint(hwnd)
		return 0
	case wmEraseBkgnd:
		// The parent is fully painted in WM_PAINT using an off-screen buffer.
		return 1
	case wmClose:
		if snapshot().Operating {
			messageBox(productName, "Attendi il completamento dell'operazione in corso.", mbOK|mbIconInfo)
			return 0
		}
		procDestroyWindow.Call(hwnd)
		return 0
	case wmDestroy:
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(message), wParam, lParam)
	return r
}

func createButton(parent uintptr, id int, text string, x, y, w, h int32) uintptr {
	const bsOwnerDraw = 0x0000000B
	style := uintptr(wsChild | wsVisible | wsTabStop | wsClipSiblings | bsOwnerDraw)
	r, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr("BUTTON"))), uintptr(unsafe.Pointer(utf16Ptr(text))), style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), parent, uintptr(id), 0, 0)
	setUIFont(r, fontNormal)
	return r
}

func main() {
	runtime.LockOSThread()
	procSetProcessDPIAware.Call()

	target, err := targetDir()
	if err != nil {
		messageBox(productName, "Installazione non possibile: "+err.Error(), mbOK|mbIconWarning)
		return
	}
	state.Target = target
	state.Status = "Pronto per iniziare"
	state.AutoCAD = detectAutoCAD()
	if existing := existingBundle(target); existing != "" {
		state.Installed = true
		state.InstalledVer = installedVersion(existing)
	}

	if _, err := os.Stat(filepath.Join(os.Getenv("WINDIR"), "Fonts", "SegUIVar.ttf")); err == nil {
		uiFontFace = "Segoe UI Variable"
	}
	fontNormal = createFont(-16, fwNormal)
	fontSmall = createFont(-14, fwNormal)
	fontSection = createFont(-18, fwSemiBold)
	fontTitle = createFont(-30, fwSemiBold)
	fontBrand = createFont(-34, fwBold)
	fontLogo = createFont(-24, fwBold)
	defer func() {
		for _, f := range []uintptr{fontNormal, fontSmall, fontSection, fontTitle, fontBrand, fontLogo} {
			if f != 0 {
				procDeleteObject.Call(f)
			}
		}
	}()

	inst, _, _ := procGetModuleHandleW.Call(0)
	className := utf16Ptr("AGCADToolsInstaller20RC4")
	cursor, _, _ := procLoadCursorW.Call(0, idcArrow)
	icon, _, _ := procLoadIconW.Call(0, idiApplication)
	bg, _, _ := procCreateSolidBrush.Call(rgb(255, 255, 255))
	defer procDeleteObject.Call(bg)
	wc := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), WndProc: syscall.NewCallback(wndProc), Instance: inst, Icon: icon, Cursor: cursor, Background: bg, ClassName: className, IconSm: icon}
	if r, _, e := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		messageBox(productName, "Impossibile inizializzare l'interfaccia: "+e.Error(), mbOK|mbIconWarning)
		return
	}

	style := uintptr(wsOverlapped | wsCaption | wsSysMenu | wsMinimizeBox | wsClipChildren)
	wr := rect{0, 0, clientW, clientH}
	procAdjustWindowRectEx.Call(uintptr(unsafe.Pointer(&wr)), style, 0, 0)
	outerW := wr.Right - wr.Left
	outerH := wr.Bottom - wr.Top
	hwnd, _, e := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(utf16Ptr(productName+" "+version+" - Installazione"))), style, 0, 0, uintptr(outerW), uintptr(outerH), 0, 0, inst, 0)
	if hwnd == 0 {
		messageBox(productName, "Impossibile creare la finestra: "+e.Error(), mbOK|mbIconWarning)
		return
	}
	hwndMain = hwnd
	// Optional Windows 11 decoration; unsupported attributes are harmless on Windows 10.
	if procDwmSetWindowAttribute.Find() == nil {
		corners := uint32(2)
		procDwmSetWindowAttribute.Call(hwnd, 33, uintptr(unsafe.Pointer(&corners)), unsafe.Sizeof(corners))
		caption := uint32(hexColor(uiBackground))
		procDwmSetWindowAttribute.Call(hwnd, 35, uintptr(unsafe.Pointer(&caption)), unsafe.Sizeof(caption))
	}

	sw, _, _ := procGetSystemMetrics.Call(smCxScreen)
	sh, _, _ := procGetSystemMetrics.Call(smCyScreen)
	x := (int32(sw) - outerW) / 2
	y := (int32(sh) - outerH) / 2
	procSetWindowPos.Call(hwnd, 0, uintptr(x), uintptr(y), uintptr(outerW), uintptr(outerH), 0x0004)

	// Creation order matches the visual order for keyboard navigation.
	for _, b := range installerButtons() {
		h := createButton(hwnd, b.ID, b.Label, int32(b.Box[0]), int32(b.Box[1]), int32(b.Box[2]-b.Box[0]), int32(b.Box[3]-b.Box[1]))
		switch b.ID {
		case idInstall:
			btnInstall = h
		case idUninstall:
			btnUninstall = h
		case idGuide:
			btnGuide = h
		case idSupport:
			btnSupport = h
		case idClose:
			btnClose = h
		}
	}
	updateButtons()

	procShowWindow.Call(hwnd, swShow)
	procUpdateWindow.Call(hwnd)
	procSetFocus.Call(btnInstall)

	var m msg
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if m.Message == 0x0100 && m.WParam == 13 {
			focus, _, _ := procGetFocus.Call()
			enabled, _, _ := procIsWindowEnabled.Call(focus)
			if enabled != 0 && (focus == btnInstall || focus == btnUninstall || focus == btnGuide || focus == btnSupport || focus == btnClose) {
				procSendMessageW.Call(focus, 0x00F5, 0, 0) // BM_CLICK
				continue
			}
		}
		if m.Message == 0x0100 && m.WParam == 27 {
			procSendMessageW.Call(hwnd, wmClose, 0, 0)
			continue
		}
		if handled, _, _ := procIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&m))); handled != 0 {
			continue
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}
