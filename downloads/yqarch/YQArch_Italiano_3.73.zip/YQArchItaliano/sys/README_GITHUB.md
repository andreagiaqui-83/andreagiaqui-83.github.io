# YQArch Italiano 3.73

Questa cartella contiene il runtime consolidato di YQArch Italiano 3.73. La release deriva dalla 3.71 collaudata sul PC di riferimento e conserva le correzioni a Ribbon e inserimento blocchi.

## Componenti principali
- `YQArchItaliano_Bootstrap.lsp`: avvio conservativo del runtime.
- `YQArchItaliano_Menu_372.*`: menu italiano e risorse.
- `YQArchItaliano_Ribbon_372.*`: Ribbon parziale con identificatori stabili.
- `YQArchItaliano_Library_372.lsp/.dcl`: catalogo e inserimento blocchi.
- `YQArchItaliano_Catalogo_372.*` + `blocks/`: 195 blocchi e anteprime.
- `YQArch_Italiano_Guida.html`: guida consultabile con 646 schede.

## Regole di integrazione
Il pacchetto non deve sostituire il CUI principale, azzerare profili o aree di lavoro, né interferire con Express Tools o BlockHub CAD. Gli identificatori Ribbon con suffisso storico sono intenzionalmente stabili e non rappresentano la versione installata.

I file del core storico vengono preservati quando non è necessario modificarli. Le correzioni 3.73 sono additive e includono il controllo del formato DWG prima dell'inserimento su versioni AutoCAD troppo vecchie.

Per installazione, compatibilità e limiti consultare `INSTALLAZIONE_LEGACY.md` e `COMPATIBILITA_AUTOCAD_WINDOWS.md`.
