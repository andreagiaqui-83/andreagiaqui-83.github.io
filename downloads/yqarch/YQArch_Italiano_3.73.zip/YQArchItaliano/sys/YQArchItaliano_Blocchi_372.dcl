yqit372_quickblocks : dialog {
 label = "YQArch Italiano - Strumenti rapidi per blocchi";
 : column {
  : text { label = "I comandi del menu conservano le opzioni complete del core."; }
  : text { label = "Questi editor rapidi sono alternative per operazioni mirate."; }
  : boxed_column { label = "Scegli un'operazione";
   : button { key = "rename"; label = "Rinomina con anteprima: trova, sostituisci, prefisso e suffisso"; }
   : button { key = "scale"; label = "Scala XYZ dei riferimenti: relativa o assoluta"; }
   : button { key = "values"; label = "Assegna o sostituisci i valori degli attributi per tag"; }
   : button { key = "props"; label = "Imposta DaLayer / layer 0 sugli oggetti interni"; }
  }
  : text { label = "Le definizioni condivise influiscono su tutte le loro istanze."; }
 }
 : button { key = "cancel"; label = "Chiudi"; is_cancel = true; width = 12; fixed_width = true; alignment = centered; }
}
