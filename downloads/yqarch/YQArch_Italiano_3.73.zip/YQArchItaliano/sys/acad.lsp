;;; YQArch Italiano 3.73 - ingresso idempotente per documento.
(if (findfile "YQArchItaliano_Bootstrap.lsp") (load "YQArchItaliano_Bootstrap.lsp"))
(princ)
