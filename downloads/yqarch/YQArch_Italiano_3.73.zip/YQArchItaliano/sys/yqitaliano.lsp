;;; Caricamento italiano una volta per documento.
(if (/= *YQIT-LOADED-VERSION* "3.73")
(progn
;;; YQArch Italiano 3.73 - bootstrap e localizzazione
(vl-load-com)

(defun yqit-sysdir (/ p)
  (if (and (boundp '*yqit-install-dir*) *yqit-install-dir*)
    *yqit-install-dir*
    (progn
      (setq p (findfile "YQArchItaliano.version"))
      (if p (vl-filename-directory p) nil))))

(defun yqit-version (/ d f h s)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\YQArchItaliano.version"))
      (if (and (findfile f) (setq h (open f "r")))
        (progn (setq s (read-line h)) (close h) s)
        "3.73"))
    "3.73"))

(defun yqit-menu-group (/ app groups grp)
  (setq app (vlax-get-acad-object))
  (setq groups (vla-get-MenuGroups app))
  (setq grp (vl-catch-all-apply 'vla-Item (list groups "yqarch")))
  (if (vl-catch-all-error-p grp) nil grp))

(defun yqit-menu-on-bar-p (/ app bar i item found)
  (setq app (vlax-get-acad-object))
  (setq bar (vla-get-MenuBar app))
  (setq i 0 found nil)
  (while (and (< i (vla-get-Count bar)) (not found))
    (setq item (vla-Item bar i))
    (if (= (strcase (vla-get-Name item)) "YQARCH ITALIANO") (setq found T))
    (setq i (1+ i)))
  found)

(defun yqit-hide-toolbars (/ grp bars i tb)
  (setq grp (yqit-menu-group))
  (if grp
    (progn
      (setq bars (vl-catch-all-apply 'vla-get-Toolbars (list grp)))
      (if (not (vl-catch-all-error-p bars))
        (progn
          (setq i 0)
          (while (< i (vla-get-Count bars))
            (setq tb (vla-Item bars i))
            (vl-catch-all-apply 'vla-put-Visible (list tb :vlax-false))
            (setq i (1+ i)))))))
  (princ))

(defun yqit-load-menu () (yqit372-menu-ensure nil) (princ))

(defun yqit-read-lines (f / h out s)
  (setq out nil)
  (if (and f (setq h (open f "r")))
    (progn
      (while (setq s (read-line h)) (setq out (cons s out)))
      (close h)
      (reverse out))
    nil))

(defun yqit-load-labels (/ d f h line p cmd label out)
  (setq d (yqit-sysdir))
  (setq out nil)
  (if d
    (progn
      (setq f (strcat d "\\YQArchItaliano_labels.tsv"))
      (if (and (findfile f) (setq h (open f "r")))
        (progn
          (while (setq line (read-line h))
            (setq p (vl-string-search (chr 9) line))
            (if p
              (progn
                (setq cmd (strcase (substr line 1 p) T))
                (setq label (substr line (+ p 2)))
                (setq out (cons (cons cmd label) out)))))
          (close h)))))
  out)

(defun yqit-label-for (cmd labels / x)
  (setq x (assoc (strcase cmd T) labels))
  (if x (cdr x) nil))

(defun yqit-sanitize-shortcut-line (line labels / low p first q cmdstart cmdend cmd label rest)
  ;; Ripara solo righe comando note. Mantiene categoria, comando e scorciatoie personali.
  (setq low (strcase line T))
  (setq p (vl-string-search ",yq_" low))
  (if (and p labels)
    (progn
      (setq first (vl-string-search "," line))
      (setq cmdstart (+ p 2)) ; indice 1-based del comando dopo la virgola
      (setq cmdend (vl-string-search "," line (+ p 1)))
      (if (and first cmdend (> cmdend p))
        (progn
          (setq cmd (substr line (+ p 2) (- cmdend p 1)))
          (setq label (yqit-label-for cmd labels))
          (if label
            (progn
              (setq rest (substr line (+ cmdend 2)))
              (strcat (substr line 1 first) "," label "," cmd "," rest))
            line))
        line))
    line))

(defun yqit-sanitize-shortcut-file (f labels / lines h changed fixed out)
  (setq lines (yqit-read-lines f))
  (if lines
    (progn
      (setq changed nil out nil)
      (foreach line lines
        (setq fixed (yqit-sanitize-shortcut-line line labels))
        (if (/= fixed line) (setq changed T))
        (setq out (cons fixed out)))
      (setq out (reverse out))
      (if changed
        (if (setq h (open f "w"))
          (progn
            (foreach line out (write-line line h))
            (close h)
            T)
          nil)
        nil))
    nil))

(defun yqit-sanitize-shortcuts (/ d labels folders f n)
  (setq d (yqit-sysdir))
  (setq labels (yqit-load-labels))
  (setq n 0)
  (if (and d labels)
    (foreach u '("user1" "user2" "userCCD" "userHBA")
      (setq f (strcat d "\\" u "\\shortcut.yqs"))
      (if (and (findfile f) (yqit-sanitize-shortcut-file f labels))
        (setq n (1+ n)))))
  (if (> n 0)
    (princ (strcat "\nYQArch Italiano: riparati " (itoa n) " file delle scorciatoie provenienti da versioni precedenti.")))
  (princ))

;;; YQArch Italiano 2.22 - pulizia helper UI obsoleti.
(defun yqit-clean-obsolete-ui (/ d pat f p)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (foreach pat '("YQArchItaliano_UI*_*.exe" "YQArchItaliano_UI_*.status.txt")
        (foreach f (vl-directory-files d pat 1)
          (setq p (strcat d "\\" f))
          (vl-file-delete p)))
      (setq p (strcat d "\\YQArchItaliano_UI.exe"))
      (if (findfile p) (vl-file-delete p))))
  (princ))

;;; YQArch Italiano 3.73 - prerequisito tecnico per YQ_GRIDAXIS.
;;; CENTER e il nome del tipo di linea richiesto dal profilo YQArch
;;; YQArch Italiano 3.73 - prerequisito tecnico robusto per YQ_GRIDAXIS.
;;; CENTER e un NOME TECNICO di tipo linea e non deve essere tradotto.
;;; Prima usa la nostra definizione LIN locale; poi verifica realmente la tabella LTYPE.
(defun yqit-ensure-center-linetype ( / app doc lts f res )
  (vl-load-com)
  (if (not (tblsearch "LTYPE" "CENTER"))
    (progn
      (setq f (findfile "YQArchItaliano_CENTER.lin"))
      (if f
        (progn
          (setq app (vlax-get-acad-object))
          (setq doc (vla-get-ActiveDocument app))
          (setq lts (vla-get-Linetypes doc))
          (setq res (vl-catch-all-apply 'vla-Load (list lts "CENTER" f)))
        )
      )
    )
  )
  (if (tblsearch "LTYPE" "CENTER")
    (princ)
    (princ "\nYQArch Italiano 3.73: ATTENZIONE - tipo linea CENTER non disponibile.")
  )
  (princ)
)

(defun yqit-ui-helper (/ d exe arch)
  (yqit-clean-obsolete-ui)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq arch (strcase (getenv "PROCESSOR_ARCHITECTURE")))
      (setq exe (strcat d "\\" (if (= arch "X86") "YQArchItaliano_UI32.exe" "YQArchItaliano_UI64.exe")))
      (if (findfile exe)
        (startapp exe)
        (princ "\nYQArch Italiano: helper UI nativo non trovato."))))
  (princ))

(defun c:YQIT_HELP (/ d f)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\YQArch_Italiano_Guida.html"))
      (if (findfile f) (startapp "explorer.exe" f) (alert "Guida italiana di YQArch non trovata.")))
    (alert "Cartella YQArch Italiano non trovata."))
  (princ))




(defun c:YQ_HELP () (c:YQIT_HELP))
(defun c:YQIT_GUIDA () (c:YQIT_HELP))
(defun c:YQIT_DONATE_ORIGINAL (/ d f)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\YQArch_Sostegno_Originale.html"))
      (if (findfile f) (startapp "explorer.exe" f) (alert "Pagina italiana di sostegno al progetto YQArch originale non trovata.")))
    (alert "Cartella YQArch Italiano non trovata."))
  (princ))

(defun c:YQIT_DONATE_ITALIANO (/ d f)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\YQArch_Sostegno_Italiano.html"))
      (if (findfile f) (startapp "explorer.exe" f) (alert "Pagina di sostegno a YQArch Italiano non trovata.")))
    (alert "Cartella YQArch Italiano non trovata."))
  (princ))
(defun c:YQIT_ABOUT (/ v)
  (setq v (yqit-version))
  (alert (strcat
    "YQArch Italiano " v "\n\n"
    "Versione 3.73 da collaudare in AutoCAD Windows. Fasce previste: 2004-2027; vedere compatibilita.\n\n"
    "YQArch Italiano usa un runtime italiano autonomo per i comandi gi� ricostruiti.\n"
    "Il motore storico resta solo come compatibilit� per le funzioni non ancora migrate.\n\n"
    "Le risorse Web rimandano al progetto YQArch originale\n"
    "e alcune pagine possono essere disponibili in cinese.\n\n"
    "Le barre degli strumenti YQArch restano nascoste\n"
    "per impostazione predefinita."))
  (princ))

(defun yqit-read-first-line (f / h s)
  (if (and f (setq h (open f "r")))
    (progn (setq s (read-line h)) (close h) s)
    nil))

(defun c:YQIT_CONFIG (/ d uf user cfg)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq uf (strcat d "\\yquser.txt"))
      (setq user (yqit-read-first-line uf))
      (if (or (null user) (= user "")) (setq user "user1"))
      (setq cfg (strcat d "\\" user "\\config.txt"))
      (if (findfile cfg) (startapp "notepad.exe" cfg) (alert "File config.txt dell'utente corrente non trovato.")))
    (alert "Cartella YQArch Italiano non trovata."))
  (princ))

(defun yqit-set-toolbars-visible (flag / grp bars i tb result count)
  (setq count 0)
  (setq grp (yqit-menu-group))
  (if grp
    (progn
      (setq bars (vl-catch-all-apply 'vla-get-Toolbars (list grp)))
      (if (not (vl-catch-all-error-p bars))
        (progn
          (setq i 0)
          (while (< i (vla-get-Count bars))
            (setq tb (vla-Item bars i))
            (setq result (vl-catch-all-apply 'vla-put-Visible (list tb (if flag :vlax-true :vlax-false))))
            (if (not (vl-catch-all-error-p result)) (setq count (1+ count)))
            (setq i (1+ i)))))))
  count)

(defun c:YQ_TOOLBARSON (/ n)
  (setq n (yqit-set-toolbars-visible T))
  (princ (strcat "\nYQArch Italiano: barre strumenti visualizzate: " (itoa n) "."))
  (princ))

(defun c:YQ_TOOLBARSOFF (/ n)
  (setq n (yqit-set-toolbars-visible nil))
  (princ (strcat "\nYQArch Italiano: barre strumenti nascoste: " (itoa n) "."))
  (princ))



;;; -----------------------------------------------------------------------------
;;; Comandi italiani sicuri per impostazioni di sistema
;;; -----------------------------------------------------------------------------
(defun yqit-write-lines (f lines / h)
  (if (setq h (open f "w"))
    (progn (foreach x lines (write-line x h)) (close h) T)
    nil))

(defun yqit-temp-dcl (name text / f h)
  (setq f (strcat (getvar "TEMPPREFIX") name))
  (if (setq h (open f "w"))
    (progn (write-line text h) (close h) f)
    nil))

(defun yqit-user-dirs (/ d all out x)
  (setq d (yqit-sysdir) out nil)
  (if d
    (progn
      (setq all (vl-directory-files d "user*" -1))
      (foreach x all
        (if (and (> (strlen x) 4) (= (strcase (substr x 1 4)) "USER"))
          (setq out (cons x out))))))
  (reverse out))

(defun yqit-cmd-setuser (/ d users cur idx f dcl id sel n)
  (setq d (yqit-sysdir))
  (setq users (yqit-user-dirs))
  (setq cur (if d (yqit-read-first-line (strcat d "\\yquser.txt")) nil))
  (if (and d users)
    (progn
      (setq f (yqit-temp-dcl "YQArchItaliano_user.dcl"
        "yqit_user:dialog{label=\"YQArch - Seleziona utente\";:text{label=\"Utente corrente:\";} :text{key=\"cur\";label=\"\";} :list_box{key=\"lst\";label=\"Profili utente YQArch\";width=34;height=12;} spacer;ok_cancel;}"))
      (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_user" id))
        (progn
          (set_tile "cur" (if cur cur "user1"))
          (start_list "lst") (foreach x users (add_list x)) (end_list)
          (setq idx 0)
          (if cur
            (progn
              (setq n 0)
              (foreach x users (if (= (strcase x) (strcase cur)) (setq idx n)) (setq n (1+ n)))))
          (set_tile "lst" (itoa idx))
          (action_tile "accept" "(setq sel (nth (atoi (get_tile \"lst\")) users))(done_dialog 1)")
          (action_tile "cancel" "(done_dialog 0)")
          (if (= (start_dialog) 1)
            (if (and sel (yqit-write-lines (strcat d "\\yquser.txt") (list sel)))
              (progn
                (setq yq_user sel)
                (alert (strcat "Utente YQArch impostato su <" sel ">.\n\nLa selezione sar� applicata completamente al prossimo avvio di AutoCAD.")))
              (alert "Impossibile salvare l'utente YQArch selezionato.")))
          (unload_dialog id)
          (vl-file-delete f))
        (alert "Impossibile aprire la finestra Seleziona utente.")))
    (alert "Profili utente YQArch non trovati."))
  (princ))

(defun yqit-cmd-lang (/ f id)
  ;; La versione italiana usa internamente la lingua compatibile del motore originale,
  ;; ma espone Italiano come lingua effettiva dell'interfaccia localizzata.
  (setq f (yqit-temp-dcl "YQArchItaliano_lang.dcl"
    "yqit_lang:dialog{label=\"[YQArch Italiano] - Lingua dell'interfaccia\";:text{label=\"Lingua dell'interfaccia e dei comandi YQArch\";} :list_box{key=\"lst\";width=34;height=6;} :text{label=\"Italiano � la lingua predefinita di questa installazione.\";} spacer;ok_cancel;}"))
  (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_lang" id))
    (progn
      (start_list "lst") (add_list "Italiano") (end_list)
      (set_tile "lst" "0")
      (action_tile "accept" "(done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (start_dialog)
      (unload_dialog id)
      (vl-file-delete f))
    (alert "Impossibile aprire la finestra Seleziona la lingua."))
  (princ))





(defun yqit-ensure-menu-safe () (yqit372-menu-ensure *YQIT-FORCE-MENU-RELOAD*))

(defun yqit-ensure-menu-safe-force (menufile grp v) (yqit372-menu-ensure T))

(defun yqit-cmd-menu ()
  (setq *YQIT-FORCE-MENU-RELOAD* T)
  (if (yqit-ensure-menu-safe)
    (princ "\nMenu YQArch Italiano ricaricato correttamente.")
    (princ "\nYQArch Italiano: impossibile ricaricare il menu; � stato mantenuto o ripristinato il menu precedente."))
  (setq *YQIT-FORCE-MENU-RELOAD* nil)
  (princ))

(defun c:YQIT_UIWATCH () (princ "\nYQArch Italiano 3.73: helper runtime disattivato; UI nativa DCL.") (princ))

;;; -----------------------------------------------------------------------------
;;; YQArch Italiano 3.73 - selettore linguistico centrale del core storico.
;;; YQArch usa YQ_EC come punto di scelta fra testo inglese e cinese. Invece di
;;; inseguire ogni prompt con patch separate, questo hook rende l'italiano la
;;; terza lingua sorgente del dispatcher centrale. Se una frase non � ancora
;;; censita, conserva l'inglese originale per non alterare la logica del comando.
;;; -----------------------------------------------------------------------------
(setq *YQIT-CORE-LABELS* (yqit-load-labels))

(defun yqit-core-label-exact (s / x)
  (if (and s *YQIT-CORE-LABELS*)
    (progn
      (setq x (assoc (strcase s T) *YQIT-CORE-LABELS*))
      (if x (cdr x) nil))
    nil))

(defun yqit-core-localize (s / x p n tail)
  (if (not (= (type s) 'STR))
    s
    (progn
      (setq x (yqit-core-label-exact s))
      (if x
        x
        (cond
          ;; Varianti di prompt presenti nel FAS con i due punti finali.
          ((= s "Seleziona oggetti o [Blocks(B)]:")
            "Seleziona oggetti oppure [Blocchi(B)]:")
          ((= s "Primo punto porta o [Style]: <Esci>")
            "Primo punto della porta oppure [Stile]: <Esci>")
          ((= s "Secondo punto della porta:")
            "Secondo punto della porta:")
          ((= s "Spostare il mouse per ruotare oppure [Ruota di 90 gradi attorno all'asse Z]:")
            "Spostare il mouse per ruotare oppure [Ruota di 90 gradi attorno all'asse Z]:")
          ;; Messaggio dinamico: <N> serial numbers be created!
          ((and (> (strlen s) 27)
                (setq p (vl-string-search " numeri di serie creati." s)))
            (strcat (substr s 1 p) " numeri di serie creati!"))
          ;; Titoli/prompt costruiti concatenando prefissi al testo inglese.
          ((setq p (vl-string-search "Numerazione automatica" s))
            (strcat (substr s 1 p) "Numerazione automatica"
                    (substr s (+ p (strlen "Numerazione automatica") 1))))
          ((setq p (vl-string-search "Stampa multipla" s))
            (strcat (substr s 1 p) "Stampa multipla"
                    (substr s (+ p (strlen "Stampa multipla") 1))))
          (T s))))))

(defun yqit-install-core-language-hook ( / )
  (defun yq_ec (english chinese / it)
    (setq it (yqit-core-localize english))
    (if it it english))
  (princ))


;; 1) carica il motore originale, 2) ripara eventuali dati corrotti delle vecchie release,
;; 3) carica/mostra esplicitamente il menu italiano, 4) avvia il localizzatore nativo.
(if (and (null c:yq_about) (findfile "yqstart.lsp")) (load "yqstart.lsp"))
(if c:yq_about (yqit-install-core-language-hook))



;; I richiami storici a YQ_DONATE restano associati al sostegno del progetto originale.
;; Il sostegno allo sviluppo italiano usa invece YQIT_DONATE_ITALIANO.
(defun yqit-donate-original-legacy (/ d f)
  (setq d (yqit-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\YQArch_Sostegno_Originale.html"))
      (if (findfile f)
        (startapp "explorer.exe" f)
        (alert "Pagina di sostegno YQArch non trovata.")))
    (alert "Cartella YQArch Italiano non trovata."))
  (princ))

;; Sovrascrive i tre comandi originali solo DOPO il caricamento del motore VLX.
(defun c:YQ_SETUSER () (yqit-cmd-setuser))
(defun c:YQ_LANG () (yqit-cmd-lang))
(defun c:YQ_MENU () (yqit-cmd-menu))
;; Alias storico associato alla pagina locale del solo progetto originale.
(defun c:YQ_DONATE () (yqit-donate-original-legacy))
(load "YQArchItaliano_Menu.lsp")
(if c:yq_about
  (progn
    (yqit-ensure-center-linetype)
    (yqit-load-menu)
    (princ)
    (princ))
  (princ "\nYQArch Italiano: ATTENZIONE - motore YQArch non caricato."))
(princ)

;;; -----------------------------------------------------------------------------
;;; YQArch Italiano 3.73 - pulizia degli esperimenti YQ_WALL delle release 1.64/1.65
;;; Il comando torna a essere YQ_WALL originale; i prompt italiani sono ora nel FAS compilato.
;;; Se la 1.65 era gi� caricata nella sessione corrente, rimuove il vecchio reactor.
;;; -----------------------------------------------------------------------------
(if (and (boundp '*YQIT-WALL-REACTOR*) *YQIT-WALL-REACTOR*)
  (progn
    (vl-catch-all-apply 'vlr-remove (list *YQIT-WALL-REACTOR*))
    (setq *YQIT-WALL-REACTOR* nil)))
(princ)
(princ)


;;; YQArch Italiano 3.73 - compatibilit� DIMSTYLE sicura per routine YQArch storiche.
;;; RESTORE/YQ100 possono arrivare come comandi separati dal motore originale.
;;; Li registriamo nello stack AutoCAD e NON usiamo (command), cosi la correzione
;;; YQArch Italiano 3.73 - compatibilit� DIMSTYLE atomica per routine YQArch storiche.
;;; Il motore originale puo inviare RESTORE e YQ100 come comandi separati.
;;; RESTORE viene registrato nello stack AutoCAD e completa in UNA sola command-s
;;; la sequenza globale -DIMSTYLE / Restore / YQ100, evitando desincronizzazioni.
(defun yqit-dimstyle-restore-yq100 ( / )
  (if (tblsearch "DIMSTYLE" "YQ100")
    (vl-catch-all-apply 'command-s (list "_.-DIMSTYLE" "_Restore" "YQ100"))
  )
  (princ)
)

(defun yqit-yq100-noop ( / ) (princ))

(defun yqit-register-dimstyle-compat ( / )
  (vl-load-com)
  (vl-catch-all-apply 'vlax-remove-cmd (list "RESTORE"))
  (vl-catch-all-apply 'vlax-remove-cmd (list "YQ100"))
  (vl-catch-all-apply 'vlax-add-cmd
    (list "RESTORE" 'yqit-dimstyle-restore-yq100 "RESTORE" 0))
  (vl-catch-all-apply 'vlax-add-cmd
    (list "YQ100" 'yqit-yq100-noop "YQ100" 0))
  (princ)
)

(yqit-register-dimstyle-compat)

;;; Carica il runtime italiano autonomo DOPO il motore storico.
;;; Da questo punto i comandi migrati sono implementati in sorgente italiana.
(if (findfile "YQArchItaliano_Runtime.lsp")
  (load "YQArchItaliano_Runtime.lsp")
  (princ "\nYQArch Italiano 3.73: ATTENZIONE - runtime italiano non trovato."))

;;; Override Griglia assi 3.00: caricato dopo il runtime per evitare regressioni.
(if (findfile "YQArchItaliano_GridFix.lsp")
  (load "YQArchItaliano_GridFix.lsp")
  (princ "\nYQArch Italiano 3.73: ATTENZIONE - correzione Griglia assi non trovata."))

;;; 3.00: nessun hook esterno di traduzione UI. Le UI migrate sono native.
(princ)


;;; YQArch Italiano 3.73 - INFO ORIGINALE E PROMPT CORE

(defun yqit-open-url-native (url)
  ;; Evita il comando AutoCAD _BROWSER e quindi i relativi prompt inglesi.
  (if (and url (/= url ""))
    (startapp "explorer.exe" url))
  (princ))

(defun yqit-original-version-dialog (/ d id r)
  (setq d (findfile "YQArchItaliano_Info295.dcl"))
  (setq id (if d (load_dialog d) -1))
  (if (and (> id 0) (new_dialog "yqit_original_version" id))
    (progn
      (action_tile "site" "(done_dialog 2)")
      (action_tile "support" "(done_dialog 3)")
      (setq r (start_dialog))
      (unload_dialog id)
      (cond
        ((= r 2) (yqit-open-url-native "http://yqarch.cn"))
        ((= r 3) (c:YQIT_DONATE_ORIGINAL))))
    (progn
      (if (> id 0) (unload_dialog id))
      (alert "YQArch originale - Versione 6.7.4 - 07/04/2022")))
  (princ))

(defun yqit-original-about-dialog (/ d id r)
  (setq d (findfile "YQArchItaliano_Info295.dcl"))
  (setq id (if d (load_dialog d) -1))
  (if (and (> id 0) (new_dialog "yqit_original_about" id))
    (progn
      (action_tile "site" "(done_dialog 2)")
      (action_tile "support" "(done_dialog 3)")
      (setq r (start_dialog))
      (unload_dialog id)
      (cond
        ((= r 2) (yqit-open-url-native "http://yqarch.cn"))
        ((= r 3) (c:YQIT_DONATE_ORIGINAL))))
    (alert "YQArch originale 6.7.4 - Walter Lam - 07/04/2022"))
  (princ))

(defun c:YQ_VER ()
  (princ "\nYQArch originale: versione 6.7.4 - 07/04/2022.")
  (yqit-original-version-dialog))

(defun c:YQ_ABOUT () (yqit-original-about-dialog))
(defun c:YQ_WEBSITE ()
  (princ "\nApertura del sito ufficiale di YQArch...")
  (yqit-open-url-native "http://yqarch.cn"))

(defun c:YQIT_ORIGINAL_RESOURCES ()
  (princ "\nApertura delle risorse originali di YQArch...")
  (yqit-open-url-native "http://bigd.ys168.com"))

;;; Localizzazione aggiuntiva dei prompt costruiti dal core.
(setq *YQIT-PROMPT-REPLACEMENTS*
  (list
    (cons "Sito ufficiale di YQArch" "Sito ufficiale di YQArch")
    (cons "Nota: se il browser non apre la pagina al primo tentativo, riprovare."
          "Nota: se il browser non apre la pagina al primo tentativo, riprovare.")
    (cons "Informazioni sulla versione originale di YQArch"
          "Informazioni sulla versione originale di YQArch")
    (cons "Ricerca comandi YQArch" "Ricerca comandi YQArch")
    (cons "Inserisci le parole chiave, separate da virgole:"
          "Inserisci le parole chiave, separate da virgole:")
    (cons "Numerazione automatica" "Numerazione automatica")
    (cons "Seleziona oggetti o [Blocks(B)]:" "Seleziona oggetti oppure [Blocchi(B)]:")
    (cons "Primo punto porta o [Style]: <Esci>"
          "Primo punto della porta oppure [Stile]: <Esci>")
    (cons "Secondo punto della porta:" "Secondo punto della porta:")
    (cons "Spostare il mouse per ruotare oppure [Ruota di 90 gradi attorno all'asse Z]:"
          "Sposta il mouse per ruotare oppure [Ruota di 90 gradi attorno all'asse Z]:")
    (cons "Stampa multipla" "Stampa multipla")
    (cons "Dizionario utente YQArch" "Dizionario utente YQArch")
    (cons "Indice delle statistiche" "Indice delle statistiche")
    (cons "Disegna simboli e quote lungo gli assi"
          "Disegna simboli degli assi e quote lungo l'asse")
    (cons "Seleziona il punto finale del primo asse:"
          "Seleziona il punto finale del primo asse:")
  ))

(defun yqit-replace-all (s old new / p from out)
  (if (or (= old "") (= old new)) s
    (progn
      (setq from 0 out "")
      (while (setq p (vl-string-search old s from))
        (setq out (strcat out (substr s (1+ from) (- p from)) new)
              from (+ p (strlen old))))
      (strcat out (substr s (1+ from))))))

(defun yqit-core-localize-295 (s / x pair p)
  (if (not (= (type s) 'STR))
    s
    (progn
      (setq x (yqit-core-label-exact s))
      (if x
        x
        (progn
          (setq x s)
          (foreach pair *YQIT-PROMPT-REPLACEMENTS*
            (setq x (yqit-replace-all x (car pair) (cdr pair))))
          ;; Messaggi dinamici della numerazione automatica.
          (if (setq p (vl-string-search " numeri di serie creati." x))
            (setq x (strcat (substr x 1 p) " numeri progressivi creati!")))
          x)))))

(defun yqit-install-core-language-hook-295 ()
  (defun yq_ec (english chinese / it)
    (setq it (yqit-core-localize-295 english))
    (if it it english))
  (princ))

(if c:yq_about (yqit-install-core-language-hook-295))

;;; Sovrascritture finali DOPO il core: impediscono che i comandi originali
;;; riaprano finestre/prompt inglesi.
(defun c:YQ_VER ()
  (princ "\nYQArch originale: versione 6.7.4 - 07/04/2022.")
  (yqit-original-version-dialog))
(defun c:YQ_ABOUT () (yqit-original-about-dialog))
(defun c:YQ_WEBSITE ()
  (princ "\nApertura del sito ufficiale di YQArch...")
  (yqit-open-url-native "http://yqarch.cn"))

(princ)


;;; YQArch Italiano 3.73 - DIAGNOSTICA PROMPT CORE
(setq *YQIT-DIRECT-CORE-PROMPTS* nil)

(defun c:YQIT_PROMPT_STATUS (/ x)
  (princ "\nYQArch Italiano - stato prompt core: Porta � gestita dal runtime italiano nativo; Numerazione automatica usa nuovamente il motore originale YQArch.")
  (foreach x *YQIT-DIRECT-CORE-PROMPTS*
    (princ (strcat "\n - " (car x) ": " (cadr x))))
  (princ "\nUsa YQ_AUTOSERIALNUMBER per verificare il motore originale ripristinato e YQ_DOOR per il percorso nativo della porta.")
  (princ))

(princ)


;;; YQArch Italiano 3.73 - COMANDI NATIVI NUMERAZIONE E PORTA
;;; Migrazione strutturale: nessun prompt inglese del core viene richiamato.

(defun yqit-pt2d (p)
  (if (and (listp p) (numberp (car p)) (numberp (cadr p)))
    (list (car p) (cadr p) 0.0)
    nil))

(defun yqit-safe-entmakex (data / r)
  (setq r (vl-catch-all-apply 'entmakex (list data)))
  (if (vl-catch-all-error-p r) nil r))

;;; ---------------- NUMERAZIONE AUTOMATICA ----------------
;;; 3.00: nessun override.
;;; Il comando C:YQ_AUTOSERIALNUMBER resta quello originale registrato da yqarch.vlx.
;;; Questo preserva integralmente ordinamento, offset, cornici, modalit� circolare,
;;; gestione blocchi/testi, righe/colonne e tutte le impostazioni della finestra originale.

;;; ---------------- PORTA A DUE PUNTI ----------------
(defun yqit-door-default-width ()
  (if (and (boundp '*YQIT-DOOR-WIDTH*) (numberp *YQIT-DOOR-WIDTH*) (> *YQIT-DOOR-WIDTH* 0.0))
    *YQIT-DOOR-WIDTH*
    900.0))

(defun yqit-door-default-depth ()
  (if (and (boundp '*YQIT-DOOR-DEPTH*) (numberp *YQIT-DOOR-DEPTH*) (> *YQIT-DOOR-DEPTH* 0.0))
    *YQIT-DOOR-DEPTH*
    100.0))

(defun yqit-door-make (p1 p2 depth / dx dy len ux uy px py p3 p4 lay)
  (setq p1 (yqit-pt2d p1)
        p2 (yqit-pt2d p2))
  (if (and p1 p2)
    (progn
      (setq dx (- (car p2) (car p1))
            dy (- (cadr p2) (cadr p1))
            len (sqrt (+ (* dx dx) (* dy dy))))
      (if (> len 1e-9)
        (progn
          (setq ux (/ dx len)
                uy (/ dy len)
                px (* (- uy) depth)
                py (* ux depth)
                p3 (list (+ (car p2) px) (+ (cadr p2) py) 0.0)
                p4 (list (+ (car p1) px) (+ (cadr p1) py) 0.0)
                lay (getvar "CLAYER"))
          ;; Telaio/anta semplice e robusto, tutto 2D.
          (yqit-safe-entmakex
            (list '(0 . "LWPOLYLINE")
                  '(100 . "AcDbEntity")
                  (cons 8 lay)
                  '(100 . "AcDbPolyline")
                  '(90 . 4)
                  '(70 . 1)
                  (cons 10 (list (car p1) (cadr p1)))
                  (cons 10 (list (car p2) (cadr p2)))
                  (cons 10 (list (car p3) (cadr p3)))
                  (cons 10 (list (car p4) (cadr p4)))))
          ;; Linea dell'anta.
          (yqit-safe-entmakex
            (list '(0 . "LINE")
                  '(100 . "AcDbEntity")
                  (cons 8 lay)
                  '(100 . "AcDbLine")
                  (cons 10 p1)
                  (cons 11 p2)))
          T)
        nil))
    nil))

(defun yqit-door-native (/ p1 p2 depth ans)
  (princ "\n****[YQArch Italiano]-Inserisci porta con 2 punti")
  (setq depth (yqit-door-default-depth))
  (setq p1 (getpoint "\nPrimo punto della porta: "))
  (if p1
    (progn
      (setq p2 (getpoint p1 "\nSecondo punto della porta: "))
      (if p2
        (progn
          (initget 6)
          (setq ans (getreal
            (strcat "\nProfondit� simbolica del telaio <"
                    (rtos depth 2 2) ">: ")))
          (if ans (setq depth ans))
          (setq *YQIT-DOOR-DEPTH* depth)
          (if (yqit-door-make p1 p2 depth)
            (princ "\nPorta creata.")
            (princ "\nImpossibile creare la porta: i due punti devono essere distinti."))))))
  (princ))

;;; 3.27: YQ_DOOR non viene ridefinito.
;;; Il comando deve restare quello originale caricato da yqarch.vlx.
;;; Il vecchio helper italiano resta disponibile solo come test esplicito YQIT_TEST_PORTA.


;;; Alias di test espliciti.
(defun c:YQIT_TEST_PORTA () (yqit-door-native))

(princ)

(princ)

;;; YQArch Italiano 3.73 - caricamento isolato dei comandi nativi.
;;; Il core storico viene sempre caricato prima. Un eventuale errore nel modulo nativo
;;; viene intercettato e non puo' impedire il funzionamento di YQArch storico.
(setq *YQIT-NATIVE-356-LOAD* nil)
(if (findfile "YQArchItaliano_NativeCommands_372.lsp")
  (progn
    (setq *YQIT-NATIVE-356-LOAD*
      (vl-catch-all-apply 'load (list "YQArchItaliano_NativeCommands_372.lsp")))
    (if (vl-catch-all-error-p *YQIT-NATIVE-356-LOAD*)
      (princ
        (strcat "\nYQArch Italiano 3.73: modulo comandi nativi non caricato: "
                (vl-catch-all-error-message *YQIT-NATIVE-356-LOAD*)))
      (princ)))
  (princ "\nYQArch Italiano 3.73: modulo comandi nativi non trovato."))
(princ)


))
(princ)
