// YQArch Italiano 3.73 - interfacce native professionali
// AutoCAD 2021-2027: anteprime tecniche dinamiche, terminologia italiana coerente.

yqit_stair_plan : dialog {
 label = "YQArch Italiano - Pianta vano scala";
 : row {
  : boxed_column { label = "Anteprima tecnica";
   : image { key = "SP_VIEW"; width = 86; aspect_ratio = 0.58; color = -2; }
   : text { key = "SP_SUMMARY"; label = ""; width = 80; alignment = centered; }
   : text { key = "SP_STATUS"; label = ""; width = 80; alignment = centered; }
   : text { label = "Ciano: gradini  |  Verde: direzione di salita  |  Giallo: quote  |  Magenta: interruzioni"; width = 80; alignment = centered; }
   : boxed_radio_row { label = "Configurazione";
    : radio_button { key = "SP_DOUBLE"; label = "Doppia rampa"; }
    : radio_button { key = "SP_SINGLE"; label = "Rampa singola"; }
    : radio_button { key = "SP_SCISSOR"; label = "Scala a forbice"; }
   }
   : boxed_radio_row { label = "Piano rappresentato";
    : radio_button { key = "SP_FIRST"; label = "Primo piano"; }
    : radio_button { key = "SP_MIDDLE"; label = "Piano intermedio"; }
    : radio_button { key = "SP_TOP"; label = "Ultimo piano"; }
   }
   : boxed_radio_row { label = "Direzione della prima rampa";
    : radio_button { key = "SP_LEFT"; label = "Verso sinistra"; }
    : radio_button { key = "SP_RIGHT"; label = "Verso destra"; }
   }
  }
  : column {
   : boxed_column { label = "Geometria in pianta";
    : row { : edit_box { key = "SP_ZW"; label = "Larghezza complessiva:"; edit_width = 9; } : button { key = "SP_MEAS_ZW"; label = "Misura"; width = 8; } }
    : row { : edit_box { key = "SP_PTW"; label = "Profondit� del pianerottolo:"; edit_width = 9; } : button { key = "SP_MEAS_PTW"; label = "Misura"; width = 8; } }
    : row { : edit_box { key = "SP_DW"; label = "Larghezza della rampa:"; edit_width = 9; } : button { key = "SP_MEAS_DW"; label = "Misura"; width = 8; } }
    : edit_box { key = "SP_JW"; label = "Larghezza del vano scala:"; edit_width = 9; }
    : edit_box { key = "SP_WT"; label = "Spessore del muro:"; edit_width = 9; }
   }
   : boxed_column { label = "Gradini e altezze";
    : edit_box { key = "SP_TREAD"; label = "Pedata:"; edit_width = 9; }
    : edit_box { key = "SP_N"; label = "Numero di gradini:"; edit_width = 9; }
    : edit_box { key = "SP_N1"; label = "Numero iniziale dei gradini:"; edit_width = 9; }
    : row { : edit_box { key = "SP_FLH"; label = "Altezza di piano:"; edit_width = 9; } : button { key = "SP_MEAS_FLH"; label = "Misura"; width = 8; } }
    : text { key = "SP_RISE"; label = "Alzata calcolata:"; }
   }
   : boxed_column { label = "Inserimento nel disegno";
    : row { : edit_box { key = "SP_ANGLE"; label = "Angolo di rotazione [gradi]:"; edit_width = 9; } : button { key = "SP_PICK_ANGLE"; label = "Indica"; width = 8; } }
    : toggle { key = "SP_GROUP"; label = "Raggruppa gli oggetti creati"; }
   }
  }
 }
 : row { : button { key = "SP_RESET"; label = "Ripristina valori predefiniti"; width = 30; } spacer; ok_cancel; }
}

yqit_stair_section : dialog {
 label = "YQArch Italiano - Sezione scala";
 : row {
  : boxed_column { label = "Anteprima tecnica";
   : image { key = "SS_VIEW"; width = 88; aspect_ratio = 0.58; color = -2; }
   : text { key = "SS_SUMMARY"; label = ""; width = 82; alignment = centered; }
   : text { key = "SS_STATUS"; label = ""; width = 82; alignment = centered; }
   : text { label = "Ciano: gradini  |  Verde: parapetto/salita  |  Giallo: soletta e quote  |  Magenta: seconda rampa"; width = 82; alignment = centered; }
   : boxed_radio_row { label = "Configurazione";
    : radio_button { key = "SS_DOUBLE"; label = "Doppia rampa"; }
    : radio_button { key = "SS_SINGLE"; label = "Rampa singola"; }
    : radio_button { key = "SS_SCISSOR"; label = "Scala a forbice"; }
   }
   : boxed_radio_row { label = "Direzione della prima rampa";
    : radio_button { key = "SS_LEFT"; label = "Verso sinistra"; }
    : radio_button { key = "SS_RIGHT"; label = "Verso destra"; }
   }
  }
  : column {
   : boxed_column { label = "Scala e livelli";
    : row { : edit_box { key = "SS_FLH"; label = "Altezza di piano:"; edit_width = 9; } : button { key = "SS_MEAS_FLH"; label = "Misura"; width = 8; } }
    : edit_box { key = "SS_FLOORS"; label = "Numero di piani:"; edit_width = 9; }
    : edit_box { key = "SS_TREAD"; label = "Pedata:"; edit_width = 9; }
    : edit_box { key = "SS_N"; label = "Numero di gradini:"; edit_width = 9; }
    : edit_box { key = "SS_N1"; label = "Numero iniziale dei gradini:"; edit_width = 9; }
    : text { key = "SS_RISE"; label = "Alzata calcolata:"; }
    : edit_box { key = "SS_BOARD"; label = "Spessore della soletta:"; edit_width = 9; }
    : edit_box { key = "SS_RAIL"; label = "Altezza del parapetto:"; edit_width = 9; }
   }
   : boxed_column { label = "Pianerottoli e travi";
    : row { : edit_box { key = "SS_PTW1"; label = "Larghezza del pianerottolo 1:"; edit_width = 9; } : button { key = "SS_MEAS_PTW1"; label = "Misura"; width = 8; } }
    : row { : edit_box { key = "SS_PTW2"; label = "Larghezza del pianerottolo 2:"; edit_width = 9; } : button { key = "SS_MEAS_PTW2"; label = "Misura"; width = 8; } }
    : row { : edit_box { key = "SS_ZLH"; label = "Altezza della trave 1:"; edit_width = 9; } : edit_box { key = "SS_ZLW"; label = "Larghezza della trave 1:"; edit_width = 9; } }
    : row { : edit_box { key = "SS_TLH"; label = "Altezza della trave 2:"; edit_width = 9; } : edit_box { key = "SS_TLW"; label = "Larghezza della trave 2:"; edit_width = 9; } }
    : row { : toggle { key = "SS_BEAM1"; label = "Disegna trave 1"; } : toggle { key = "SS_BEAM2"; label = "Disegna trave 2"; } }
    : toggle { key = "SS_GROUP"; label = "Raggruppa gli oggetti creati"; }
   }
  }
 }
 : row { : button { key = "SS_RESET"; label = "Ripristina valori predefiniti"; width = 30; } spacer; ok_cancel; }
}

yqit_pocketdoor : dialog {
 label = "YQArch Italiano - Porta scorrevole a scomparsa";
 : row {
  : boxed_column { label = "Anteprima tecnica";
   : image { key = "PD_VIEW"; width = 72; aspect_ratio = 0.48; color = -2; }
   : text { key = "PD_SUMMARY"; label = ""; width = 66; alignment = centered; }
   : text { key = "PD_DETAIL"; label = ""; width = 66; alignment = centered; }
   : text { key = "PD_STATUS"; label = ""; width = 66; alignment = centered; }
   : text { label = "Ciano: controtelaio  |  Verde: verso di scorrimento  |  Giallo: luce  |  Grigio: parete"; width = 66; alignment = centered; }
  }
  : column {
   : boxed_column { label = "Configurazioni YQArch originali";
    : list_box { key = "PD_STYLE"; height = 12; width = 47; }
    : text { key = "PD_FAMILY"; label = ""; width = 47; }
    : edit_box { key = "PD_THK"; label = "Spessore del muro:"; edit_width = 9; }
   }
   : boxed_column { label = "Posizionamento";
    : text { label = "La luce effettiva � determinata dai due punti indicati nel disegno."; width = 47; }
    : text { label = "L'ordine dei punti determina il verso di inserimento della porta."; width = 47; }
    : text { label = "Dopo l'inserimento il comando resta attivo per creare altre porte."; width = 47; }
   }
  }
 }
 : row { spacer; ok_cancel; }
}


yqit_banister : dialog {
 label = "YQArch Italiano - Parapetto in prospetto";
 : row {
  : boxed_column { label = "Anteprima tecnica";
   : image { key = "BAN_VIEW"; width = 64; aspect_ratio = 0.58; color = -2; }
   : text { key = "BAN_SUMMARY"; label = ""; width = 62; alignment = centered; }
   : text { key = "BAN_STATUS"; label = ""; width = 62; alignment = centered; }
   : text { label = "Ciano: montanti  |  Verde: correnti  |  Giallo: quote  |  Grigio: riferimento"; width = 62; alignment = centered; }
  }
  : column {
   : boxed_column { label = "Layer e colore";
    : row { : edit_box { key = "BAN_LAYER"; label = "Layer del parapetto:"; edit_width = 12; } : button { key = "BAN_PICK_LAYER"; label = "Seleziona"; width = 9; } }
    : edit_box { key = "BAN_COLOR"; label = "Colore ACI:"; edit_width = 7; }
   }
   : boxed_column { label = "Corrimano e correnti";
    : edit_box { key = "BAN_H"; label = "Altezza complessiva:"; edit_width = 9; }
    : edit_box { key = "BAN_HR_DIA"; label = "Diametro corrimano:"; edit_width = 9; }
    : edit_box { key = "BAN_EXT"; label = "Estensione corrimano:"; edit_width = 9; }
    : edit_box { key = "BAN_RAIL_DIA"; label = "Diametro correnti:"; edit_width = 9; }
    : edit_box { key = "BAN_TOP"; label = "Spazio superiore:"; edit_width = 9; }
    : edit_box { key = "BAN_BOTTOM"; label = "Spazio inferiore:"; edit_width = 9; }
   }
   : boxed_column { label = "Colonne e montanti";
    : edit_box { key = "BAN_COL_DIA"; label = "Diametro colonne:"; edit_width = 9; }
    : edit_box { key = "BAN_COL_STEP"; label = "Passo massimo colonne:"; edit_width = 9; }
    : toggle { key = "BAN_LATERAL"; label = "Disegna montanti intermedi"; }
    : edit_box { key = "BAN_BAL_DIA"; label = "Diametro montanti:"; edit_width = 9; }
    : edit_box { key = "BAN_BAL_STEP"; label = "Passo massimo montanti:"; edit_width = 9; }
   }
   : toggle { key = "BAN_GROUP"; label = "Raggruppa gli oggetti creati"; }
  }
 }
 : row { : button { key = "BAN_RESET"; label = "Ripristina valori predefiniti"; width = 28; } spacer; ok_cancel; }
}


// -------------------- RINOMINA IN SERIE 3.59 --------------------
yqit_batch_layer : dialog {
 label = "YQArch Italiano - Rinomina layer in serie";
 : row {
  : boxed_column { label = "Layer disponibili";
   : list_box { key = "BR_LIST"; width = 42; height = 18; multiple_select = true; }
   : row { : button { key = "BR_ALL"; label = "Seleziona tutti"; width = 14; } : button { key = "BR_NONE"; label = "Deseleziona"; width = 12; } }
  }
  : boxed_column { label = "Regole di rinomina";
   : edit_box { key = "BR_FIND"; label = "Trova testo:"; edit_width = 22; }
   : edit_box { key = "BR_REPL"; label = "Sostituisci con:"; edit_width = 22; }
   : edit_box { key = "BR_PREFIX"; label = "Prefisso:"; edit_width = 22; }
   : edit_box { key = "BR_SUFFIX"; label = "Suffisso:"; edit_width = 22; }
   : boxed_column { label = "Anteprima";
    : list_box { key = "BR_PREVIEW"; width = 48; height = 10; }
    : text { key = "BR_STATUS"; label = "Seleziona uno o pi� layer."; width = 48; }
   }
  }
 }
 : row { : button { key = "BR_RESET"; label = "Azzera regole"; width = 18; } spacer; ok_cancel; }
}

yqit_batch_block : dialog {
 label = "YQArch Italiano - Rinomina blocchi in serie";
 : row {
  : boxed_column { label = "Blocchi disponibili";
   : list_box { key = "BR_LIST"; width = 42; height = 18; multiple_select = true; }
   : row { : button { key = "BR_ALL"; label = "Seleziona tutti"; width = 14; } : button { key = "BR_NONE"; label = "Deseleziona"; width = 12; } }
  }
  : boxed_column { label = "Regole di rinomina";
   : edit_box { key = "BR_FIND"; label = "Trova testo:"; edit_width = 22; }
   : edit_box { key = "BR_REPL"; label = "Sostituisci con:"; edit_width = 22; }
   : edit_box { key = "BR_PREFIX"; label = "Prefisso:"; edit_width = 22; }
   : edit_box { key = "BR_SUFFIX"; label = "Suffisso:"; edit_width = 22; }
   : boxed_column { label = "Anteprima";
    : list_box { key = "BR_PREVIEW"; width = 48; height = 10; }
    : text { key = "BR_STATUS"; label = "Seleziona uno o pi� blocchi."; width = 48; }
   }
  }
 }
 : row { : button { key = "BR_RESET"; label = "Azzera regole"; width = 18; } spacer; ok_cancel; }
}

yqit_batch_layout : dialog {
 label = "YQArch Italiano - Rinomina layout in serie";
 : row {
  : boxed_column { label = "Layout disponibili";
   : list_box { key = "BR_LIST"; width = 42; height = 18; multiple_select = true; }
   : row { : button { key = "BR_ALL"; label = "Seleziona tutti"; width = 14; } : button { key = "BR_NONE"; label = "Deseleziona"; width = 12; } }
  }
  : boxed_column { label = "Regole di rinomina";
   : edit_box { key = "BR_FIND"; label = "Trova testo:"; edit_width = 22; }
   : edit_box { key = "BR_REPL"; label = "Sostituisci con:"; edit_width = 22; }
   : edit_box { key = "BR_PREFIX"; label = "Prefisso:"; edit_width = 22; }
   : edit_box { key = "BR_SUFFIX"; label = "Suffisso:"; edit_width = 22; }
   : boxed_column { label = "Anteprima";
    : list_box { key = "BR_PREVIEW"; width = 48; height = 10; }
    : text { key = "BR_STATUS"; label = "Seleziona uno o pi� layout."; width = 48; }
   }
  }
 }
 : row { : button { key = "BR_RESET"; label = "Azzera regole"; width = 18; } spacer; ok_cancel; }
}


// -------------------- UTILITA' PROFESSIONALI 3.59 --------------------
yqit_blockscale : dialog {
 label = "YQArch Italiano - Scala riferimenti di blocco";
 : boxed_column { label = "Riferimenti selezionati";
  : text { key = "BS_COUNT"; label = ""; width = 54; }
 }
 : boxed_column { label = "Fattori di scala";
  : toggle { key = "BS_UNIFORM"; label = "Scala uniforme sui tre assi"; value = "1"; }
  : row { : edit_box { key = "BS_X"; label = "Fattore X:"; edit_width = 10; } : edit_box { key = "BS_Y"; label = "Fattore Y:"; edit_width = 10; } : edit_box { key = "BS_Z"; label = "Fattore Z:"; edit_width = 10; } }
  : boxed_radio_row { label = "Modalita'";
   : radio_button { key = "BS_REL"; label = "Moltiplica la scala attuale"; value = "1"; }
   : radio_button { key = "BS_ABS"; label = "Imposta scala assoluta"; }
  }
  : text { label = "Suggerimento: usa la modalita' relativa per conservare eventuali proporzioni gia' presenti."; width = 58; }
 }
 : row { : button { key = "BS_RESET"; label = "Ripristina 1.000"; width = 18; } spacer; ok_cancel; }
}

yqit_clearz : dialog {
 label = "YQArch Italiano - Azzera quota Z";
 : boxed_column { label = "Oggetti selezionati";
  : text { key = "CZ_COUNT"; label = ""; width = 58; }
  : text { label = "La coordinata Z viene portata a 0 mantenendo inalterate X e Y."; width = 58; }
 }
 : boxed_column { label = "Elementi collegati";
  : toggle { key = "CZ_VERT"; label = "Includi vertici di polilinee 2D/3D"; value = "1"; }
  : toggle { key = "CZ_ATTR"; label = "Includi attributi dei blocchi selezionati"; value = "1"; }
 }
 : text { label = "Entita' tridimensionali non compatibili vengono ignorate e riportate nel riepilogo."; width = 62; }
 : row { spacer; ok_cancel; }
}

yqit_rotateeach : dialog {
 label = "YQArch Italiano - Ruota singolarmente";
 : boxed_column { label = "Rotazione";
  : edit_box { key = "RE_ANGLE"; label = "Angolo [gradi]:"; edit_width = 12; }
  : boxed_radio_row { label = "Punto base di ogni oggetto";
   : radio_button { key = "RE_CENTER"; label = "Centro del riquadro di ingombro"; value = "1"; }
   : radio_button { key = "RE_INSERT"; label = "Punto di inserimento, se disponibile"; }
  }
  : text { key = "RE_COUNT"; label = ""; width = 58; }
 }
 : row { : button { key = "RE_RESET"; label = "Azzera angolo"; width = 16; } spacer; ok_cancel; }
}

yqit_findtext : dialog {
 label = "YQArch Italiano - Cerca testo";
 : boxed_column { label = "Criterio di ricerca";
  : edit_box { key = "FT_FIND"; label = "Testo da cercare:"; edit_width = 34; }
  : boxed_radio_row { label = "Confronto";
   : radio_button { key = "FT_CONTAINS"; label = "Contiene"; value = "1"; }
   : radio_button { key = "FT_EXACT"; label = "Corrispondenza esatta"; }
  }
  : toggle { key = "FT_CASE"; label = "Distingui maiuscole/minuscole"; }
  : toggle { key = "FT_ATTR"; label = "Cerca anche negli attributi dei blocchi"; value = "1"; }
 }
 : boxed_radio_row { label = "Ambito";
  : radio_button { key = "FT_CURRENT"; label = "Spazio/layout corrente"; value = "1"; }
  : radio_button { key = "FT_SELECT"; label = "Selezione manuale"; }
 }
 : text { label = "Gli oggetti trovati vengono selezionati nel disegno."; width = 58; }
 : row { spacer; ok_cancel; }
}

yqit_replacetext : dialog {
 label = "YQArch Italiano - Sostituisci testo";
 : boxed_column { label = "Sostituzione";
  : edit_box { key = "RT_FIND"; label = "Trova:"; edit_width = 34; }
  : edit_box { key = "RT_REPL"; label = "Sostituisci con:"; edit_width = 34; }
  : toggle { key = "RT_CASE"; label = "Distingui maiuscole/minuscole"; }
  : toggle { key = "RT_ATTR"; label = "Modifica anche gli attributi dei blocchi"; value = "1"; }
 }
 : text { label = "La sostituzione viene applicata soltanto agli oggetti selezionati."; width = 58; }
 : row { spacer; ok_cancel; }
}

yqit_ltswitch : dialog {
 label = "YQArch Italiano - Cambia tipo di linea";
 : boxed_column { label = "Tipo di linea";
  : list_box { key = "LT_LIST"; width = 46; height = 14; }
  : text { key = "LT_COUNT"; label = ""; width = 52; }
 }
 : text { label = "Sono elencati i tipi di linea gia' caricati nel disegno, oltre a DaLayer e DaBlocco."; width = 58; }
 : row { spacer; ok_cancel; }
}

yqit_attributes : dialog {
 label = "YQArch Italiano - Modifica attributi";
 : row {
  : boxed_column { label = "Tag disponibili";
   : list_box { key = "AT_TAGS"; width = 28; height = 13; }
   : text { key = "AT_COUNT"; label = ""; width = 30; }
  }
  : boxed_column { label = "Operazione";
   : boxed_radio_row {
    : radio_button { key = "AT_SET"; label = "Imposta valore"; value = "1"; }
    : radio_button { key = "AT_REPLMODE"; label = "Trova e sostituisci"; }
   }
   : edit_box { key = "AT_A"; label = "Valore / Trova:"; edit_width = 28; }
   : edit_box { key = "AT_B"; label = "Sostituisci con:"; edit_width = 28; }
   : edit_box { key = "AT_PREFIX"; label = "Prefisso:"; edit_width = 20; }
   : edit_box { key = "AT_SUFFIX"; label = "Suffisso:"; edit_width = 20; }
   : toggle { key = "AT_CASE"; label = "Distingui maiuscole/minuscole"; }
  }
 }
 : text { label = "Seleziona <Tutti i tag> per applicare l'operazione a tutti gli attributi dei blocchi selezionati."; width = 66; }
 : row { spacer; ok_cancel; }
}

yqit_blockbylayer : dialog {
 label = "YQArch Italiano - Normalizza proprieta' nei blocchi";
 : boxed_column { label = "Proprieta' delle definizioni selezionate";
  : toggle { key = "BL_COLOR"; label = "Colore = DaLayer"; value = "1"; }
  : toggle { key = "BL_LTYPE"; label = "Tipo di linea = DaLayer"; value = "1"; }
  : toggle { key = "BL_LW"; label = "Spessore di linea = DaLayer"; value = "1"; }
  : toggle { key = "BL_LAYER0"; label = "Sposta gli oggetti interni sul layer 0"; }
  : text { key = "BL_COUNT"; label = ""; width = 58; }
 }
 : text { label = "Attenzione: la modifica agisce sulla definizione del blocco e quindi su tutte le sue istanze."; width = 64; }
 : row { spacer; ok_cancel; }
}

yqit_matchcontent : dialog {
 label = "YQArch Italiano - Uniforma contenuto testo";
 : boxed_column { label = "Contenuto sorgente";
  : text { key = "MC_TEXT"; label = ""; width = 64; }
  : text { key = "MC_COUNT"; label = ""; width = 64; }
 }
 : text { label = "Il contenuto del testo sorgente verra' copiato in tutti i testi di destinazione selezionati."; width = 64; }
 : row { spacer; ok_cancel; }
}

yqit_matchwidth : dialog {
 label = "YQArch Italiano - Uniforma larghezza polilinee";
 : boxed_column { label = "Larghezza sorgente";
  : text { key = "MW_WIDTH"; label = ""; width = 52; }
  : text { key = "MW_COUNT"; label = ""; width = 52; }
 }
 : text { label = "La larghezza costante della polilinea sorgente verra' applicata alle polilinee di destinazione."; width = 64; }
 : row { spacer; ok_cancel; }
}
