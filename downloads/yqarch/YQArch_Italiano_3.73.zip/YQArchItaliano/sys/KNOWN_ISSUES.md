# Limiti e attività aperte — 3.73

- La regressione installer multi-profilo della 3.72 è corretta nella 3.73; la 3.72 non va pubblicata né usata come baseline.
- Localizzazione totale di ogni ramo UI, prompt e anteprima: NON conclusa. Vedere inventario CORE_LETTERALI.tsv.
- Finestra completa di navigazione blocchi: conserva nomi fisici dei file, cartelle #U e testo delle miniature originali. L'accesso iniziale per categorie è italiano.
- Non tradurre nomi di cartelle generali di Windows, filtri DXF, API, identificatori di blocchi o contenuto dei DWG dell'utente.
- Il nucleo può ancora passare attraverso il ponte linguistico ereditato; questa release non aggiunge hook di traduzione e non ne dichiara completata l'eliminazione.
- La dimensione e il contenuto delle miniature non sono prova dell'esistenza di DWG in una cartella. Celle vuote nella radice C: non dimostrano un guasto.
- Installer e nuova Ribbon: collaudo reale su Windows/AutoCAD non eseguito in questo ambiente.
- Tempi effettivi prima/dopo: da confrontare sullo stesso PC tramite il report persistente introdotto nella 3.73.
- Le versioni AutoCAD legacy mantengono i limiti descritti nella matrice di compatibilità. Le nuove API del plugin non ampliano il supporto ufficiale Autodesk.
