"""Executes actual new Lisp function bodies against simulated CAD/COM objects.
This is NOT an Autodesk runtime and does NOT validate DWG rendering or ObjectDBX.
"""
import unittest,copy,math
from pathlib import Path
import numpy as np
from lisp_model import Lisp,Symbol,truth,Error,boolean
HERE=Path(__file__).resolve().parent
W=HERE.parent
PAYLOAD=W/'build' if (W/'build/YQArchItaliano').is_dir() else W
class Obj:
 def __init__(self,points,attrs=None):self.points=np.array(points,dtype=float);self.attrs=attrs or {};self.layer='0';self.deleted=False
class Def:
 def __init__(self,name,entities=None,origin=None):self.name=name;self.entities=entities or [];self.origin=origin or [0.,0.,0.];self.deleted=False
class Model(Lisp):
 def eval(self,x,env=None):
  if isinstance(x,list) and x and str(x[0]).upper()=='VLAX-FOR':
   env=env if env is not None else self.env
   coll=self.eval(x[2],env);items=coll.entities if isinstance(coll,Def) else coll
   result=None
   for item in items:
    env.setv(str(x[1]).upper(),item)
    for code in x[3:]:result=self.eval(code,env)
   return result
  return super().eval(x,env)
 def call(self,name,args=None,env=None):
  if str(name).upper()=='VLA-GETBOUNDINGBOX':
   obj,lo,hi=args;env=env if env is not None else self.env
   env.setv(str(lo).upper(),obj.points.min(axis=0).tolist());env.setv(str(hi).upper(),obj.points.max(axis=0).tolist());return None
  return super().call(name,args,env)
class TreesTests(unittest.TestCase):
 def setUp(self):
  self.l=Model();self.l.load((HERE/'Trees_372.lsp').read_text('ascii'));self.calls=[];self.instances=[];self.db={'asset':None};self.defs={};self.lock=False;self.off=False;self.freeze=False;self.fail_transform=False;self.fail_delete=False;self.fail_copy=False
  self.assets={name:Def(name,[Obj([[-1,-2,0],[1,-2,0],[1,2,0],[-1,2,0]])]) for name in ['YQTREE'+str(i) for i in range(1,6)]+['YQBUSH'+str(i) for i in range(1,6)]}
  self.l.env[':VLAX-TRUE']=-1;self.l.env[':VLAX-FALSE']=0;self.l.env['VLAX-VBOBJECT']=9
  self.l.api.update({'MIN':min,'MAX':max,'ABS':abs,'FIX':math.trunc,'<=':lambda a,b:boolean(a<=b),'DISTANCE':lambda a,b:float(np.linalg.norm(np.array(a)-np.array(b))),
   'VL-POSITION':lambda a,b:next((i for i,v in enumerate(b) if v==a),None),'VLAX-3D-POINT':lambda p:p,
   'VLAX-GET-ACAD-OBJECT':lambda:'app','VLA-GET-ACTIVEDOCUMENT':lambda app:'doc',
   'VLA-GET-MODELSPACE':lambda doc:'model','VLA-GET-PAPERSPACE':lambda doc:'paper',
   'VLA-GET-LAYERS':lambda doc:['layer'],'VLA-GET-BLOCKS':lambda doc:self.assets if doc is self.db else self.defs,
   'VLA-ITEM':lambda coll,key:coll[key] if isinstance(coll,dict) else key,
   'VLA-GET-LOCK':lambda obj:-1 if self.lock else 0,'VLA-GET-FREEZE':lambda obj:-1 if self.freeze else 0,'VLA-GET-LAYERON':lambda obj:0 if self.off else -1,
   'VLA-GET-NAME':lambda obj:obj.name if isinstance(obj,Def) else str(obj),
   'VLA-GET-ORIGIN':lambda obj:obj.origin,'VLA-GET-COUNT':lambda obj:len(obj.entities),
   'TBLSEARCH':lambda table,name:self.defs.get(name), 'FINDFILE':lambda path:path,
   'VLA-GETINTERFACEOBJECT':self.dbx,'VLAX-CREATE-OBJECT':lambda name:self.db,
   'VLA-OPEN':lambda db,path:self.calls.append(('open',path)), 'VLAX-RELEASE-OBJECT':lambda db:self.calls.append(('release',)),
   'VLAX-MAKE-SAFEARRAY':lambda kind,bounds:[None]*(bounds.b-bounds.a+1),
   'VLAX-SAFEARRAY-FILL':lambda arr,values:arr.__setitem__(slice(None),values) or arr,
   'VLA-ADD':self.add,'VLA-COPYOBJECTS':self.copy_objects,'VLA-INSERTBLOCK':self.insert,'VLA-COPY':self.copy,
   'VLA-TRANSFORMBY':self.transform,'VLA-MOVE':self.move,'VLA-SCALEENTITY':self.scale,'VLA-ROTATE':self.rotate,
   'VLA-PUT-LAYER':lambda obj,layer:setattr(obj,'layer',layer),'VLA-DELETE':self.delete,
   'VLA-STARTUNDOMARK':lambda doc:self.calls.append(('undo-start',)), 'VLA-ENDUNDOMARK':lambda doc:self.calls.append(('undo-end',)),
   'WCMATCH':lambda text,patterns:boolean(any(s in text for s in ['CANCEL','ANNULL','QUIT','EXIT','INTERRUZ'])),
   'EXIT':lambda:(_ for _ in ()).throw(RuntimeError('quit / exit abort')),
   'UNLOAD_DIALOG':lambda n:self.calls.append(('unload',n)),
   'INITGET':lambda *a:None,'GETKWORD':lambda prompt:'Si',
   'VLAX-ERASED-P':lambda obj:boolean(obj.deleted),'VLAX-ENAME->VLA-OBJECT':lambda obj:obj,
   'VLA-GET-OBJECTNAME':lambda obj:'AcDbBlockReference','SSNAME':lambda ss,i:ss[i],'SSLENGTH':len,
   'YQT72-SYS':lambda:'C:\\YQ',
  })
  self.c('defaults');self.l.env['*YQT72-DOC*']='doc';self.l.env['*YQT72-SPACE*']='model';self.l.env['*YQT72-COUNT*']=0;self.l.env['*YQT72-TARGETLAYER*']='Alberi'
 def c(self,fn,*args):return self.l.call('yqt72-'+fn,list(args))
 def put(self,k,v):return self.c('put',k,v)
 def dbx(self,app,name):self.calls.append(('dbx',name));return self.db
 def add(self,blocks,origin,name):d=Def(name,origin=origin);blocks[name]=d;return d
 def copy_objects(self,db,arr,owner):
  if self.fail_copy:raise RuntimeError('deep clone failed')
  self.assertIs(db,self.db);self.assertGreater(len(arr),0);self.calls.append(('copy-objects',len(arr),owner.name));owner.entities=copy.deepcopy(arr);return owner.entities
 def insert(self,space,point,name,sx,sy,sz,angle):
  d=self.defs.get(name) or self.assets[name];o=Obj(np.vstack([e.points for e in d.entities]));self.instances.append(o);self.calls.append(('insert',name));return o
 def copy(self,obj):o=copy.deepcopy(obj);self.instances.append(o);self.calls.append(('copy-ref',));return o
 def transform(self,o,m):
  if self.fail_transform:raise RuntimeError('transform failed')
  pts=np.c_[o.points,np.ones(len(o.points))];o.points=(np.array(m)@pts.T).T[:,:3]
 def move(self,o,a,b):o.points+=np.array(b)-np.array(a)
 def scale(self,o,p,f):o.points=(o.points-np.array(p))*f+np.array(p)
 def rotate(self,o,p,angle):
  c,s=math.cos(angle),math.sin(angle);o.points=((np.array([[c,-s,0],[s,c,0],[0,0,1]])@(o.points-np.array(p)).T).T+np.array(p))
 def delete(self,o):
  self.calls.append(('delete',))
  if self.fail_delete:raise RuntimeError('delete failed')
  o.deleted=True
 def setup_source(self,name='YQTREE1'):
  self.l.env['*YQT72-SOURCES*']=[name];self.put('min','1');self.put('max','1');self.put('random','0');self.put('diam','3000')
 def setup_run(self):
  self.l.api['YQT72-DIALOG']=lambda:1
  self.l.api['SSGET']=lambda *a:(_ for _ in ()).throw(AssertionError('must not select objects for included trees'))
  pts=iter([[100.,200.,0.],None]);self.l.api['GETPOINT']=lambda *a:next(pts)
 def test_original_five_tree_names_imported(self):self.c('prepare-builtins');self.assertEqual(len(self.l.env['*YQT72-SOURCES*']),5);self.assertEqual(len(self.defs),5)
 def test_original_five_bush_names_imported(self):self.put('source','1');self.c('prepare-builtins');self.assertTrue(all('YQBUSH' in s for s in self.l.env['*YQT72-SOURCES*']))
 def test_one_model_only(self):self.put('variant','3');self.c('prepare-builtins');self.assertEqual(len(self.defs),1);self.assertIn('YQTREE3',next(iter(self.defs)))
 def test_source_asset_not_saved(self):self.c('prepare-builtins');self.assertTrue(any(c[0]=='open' for c in self.calls));self.assertEqual(self.calls[-1],('release',))
 def test_original_definitions_not_mutated(self):self.c('prepare-builtins');self.assertTrue(all(d.name==k and len(d.entities)==1 for k,d in self.assets.items()))
 def test_definition_collision_gets_unique_alias(self):self.defs['YQIT_ALB_372_YQTREE1']=Def('user');self.put('variant','1');self.c('prepare-builtins');self.assertIn('YQIT_ALB_372_YQTREE1_1',self.defs);self.assertEqual(self.defs['YQIT_ALB_372_YQTREE1'].name,'user')
 def test_cached_own_definitions_not_duplicated(self):self.c('prepare-builtins');n=len(self.defs);self.c('prepare-builtins');self.assertEqual(len(self.defs),n)
 def test_dbx_exact_autocad_major(self):self.c('dbx');self.assertIn(('dbx','ObjectDBX.AxDbDocument.26'),self.calls)
 def test_missing_dbx_yields_no_geometry(self):self.l.api['VLA-GETINTERFACEOBJECT']=lambda *a:None;self.l.api['VLAX-CREATE-OBJECT']=lambda *a:None;self.c('prepare-builtins');self.assertFalse(self.instances);self.assertTrue(any('ObjectDBX' in s for s in self.l.output))
 def test_import_failure_cleanup_pending_definition(self):
  self.fail_copy=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertTrue(next(iter(self.defs.values())).deleted);self.assertIn(('release',),self.calls);self.assertIn(('undo-end',),self.calls)
 def test_builtin_run_does_not_select_existing_blocks(self):self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertEqual(len(self.instances),1);self.assertEqual(self.l.env['*YQT72-COUNT*'],1);self.assertTrue(any('completate: 1' in s for s in self.l.output))
 def test_point_insertion_center_and_size(self):
  self.setup_source();self.c('place',[100.,200.,30.]);p=self.instances[-1].points;self.assertTrue(np.allclose((p.max(0)+p.min(0))/2,[100,200,30]));self.assertAlmostEqual(max(np.ptp(p[:,0]),np.ptp(p[:,1])),3000)
 def test_min_max_equal_deterministic_size(self):self.setup_source();self.put('min','2');self.put('max','2');self.c('place',[0.,0.,0.]);self.assertEqual(np.ptp(self.instances[-1].points[:,1]),6000)
 def test_random_coefficient_range(self):
  for _ in range(300):v=self.c('coeff',0.5,2.0);self.assertGreaterEqual(v,0.5);self.assertLess(v,2.0)
 def test_random_seed_reproducible(self):self.l.env['*YQT72-SEED*']=37.;a=[self.c('rand') for _ in range(10)];self.l.env['*YQT72-SEED*']=37.;self.assertEqual(a,[self.c('rand') for _ in range(10)])
 def test_random_rotation_preserves_distances(self):self.setup_source();self.put('random','1');self.c('place',[0.,0.,0.]);p=self.instances[-1].points;self.assertAlmostEqual(float(np.linalg.norm(p[2]-p[1])),3000)
 def test_selected_block_copy_attributes_and_original_preserved(self):
  original=Obj([[0,0,0],[2,0,0],[2,4,0],[0,4,0]],{'TAG':'verde'});before=original.points.copy();self.setup_source();self.l.env['*YQT72-SOURCES*']=[original];self.c('place',[20.,30.,0.]);self.assertTrue(np.array_equal(original.points,before));self.assertEqual(self.instances[-1].attrs,{'TAG':'verde'});self.assertFalse(original.deleted)
 def test_locked_layer_no_geometry(self):self.lock=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertFalse(self.instances);self.assertFalse(any(c[0]=='undo-start' for c in self.calls))
 def test_off_layer_no_geometry(self):self.off=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertFalse(self.instances)
 def test_frozen_layer_no_geometry(self):self.freeze=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertFalse(self.instances)
 def test_transform_failure_cleanup(self):self.fail_transform=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertTrue(self.instances[-1].deleted);self.assertEqual(self.l.env['*YQT72-COUNT*'],0)
 def test_cleanup_failure_reported(self):self.fail_transform=True;self.fail_delete=True;self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertTrue(any('pulizia' in s for s in self.l.output))
 def test_esc_after_first_keeps_finished_tree(self):
  self.setup_run();pts=iter([[0.,0.,0.]])
  def getpt(*args):
   try:return next(pts)
   except StopIteration:raise RuntimeError('Function cancelled')
  self.l.api['GETPOINT']=getpt;self.l.call('c:YQ_HEAPTREES');self.assertEqual(len(self.instances),1);self.assertFalse(self.instances[0].deleted);self.assertEqual(self.l.env['*YQT72-COUNT*'],1);self.assertIn(('undo-end',),self.calls)
 def test_no_points_no_instances(self):self.setup_run();self.l.api['GETPOINT']=lambda *args:None;self.l.call('c:YQ_HEAPTREES');self.assertFalse(self.instances)
 def test_open_curve_includes_both_ends(self):self.assertEqual(self.c('distances',10.,3.,None),[0.,3.,6.,9.,10.])
 def test_closed_curve_does_not_duplicate_start(self):self.assertEqual(self.c('distances',12.,3.,True),[0.,3.,6.,9.])
 def test_short_filare_two_endpoints(self):self.assertEqual(self.c('distances',2.,3.,None),[0.,2.])
 def test_degenerate_curve_returns_no_distances(self):self.assertIsNone(self.c('distances',0.,3.,None))
 def test_zero_gap_returns_no_distances(self):self.assertIsNone(self.c('distances',3.,0.,None))
 def test_minimum_separation(self):self.assertFalse(truth(self.c('separated',[1,0,0],[[0,0,0]],2.)));self.assertTrue(truth(self.c('separated',[2,0,0],[[0,0,0]],2.)))
 def test_zero_min_separation_accepts(self):self.assertTrue(truth(self.c('separated',[0,0,0],[[0,0,0]],0.)))
 def test_zero_bbox(self):self.assertEqual(self.c('diameter',[0,0,0],[0,0,3]),0)
 def test_zero_bbox_causes_cleanup_no_success(self):
  self.assets['YQTREE1']=Def('YQTREE1',[Obj([[0,0,0],[0,0,1]])]);self.put('variant','1');self.setup_run();self.l.call('c:YQ_HEAPTREES');self.assertEqual(self.l.env['*YQT72-COUNT*'],0);self.assertTrue(self.instances[-1].deleted)
 def test_rotated_ucs_matrix(self):
  self.l.api['TRANS']=lambda p,fr,to,disp=None:[-p[1],p[0],p[2]]
  self.assertEqual(self.c('local-to-world',[1,2,3]),[[0.,-1.,0.,1],[1.,0.,0.,2],[0.,0.,1.,3],[0.,0.,0.,1.]])
 def test_inverse_ucs_rotation(self):
  self.l.api['TRANS']=lambda p,fr,to,disp=None:[-p[1],p[0],p[2]]
  a=np.array(self.c('local-to-world',[0,0,0]));b=np.array(self.c('world-to-local-rotation'));self.assertTrue(np.allclose(a@b,np.eye(4)))
 def dialog_tiles(self):self.l.tiles.update(source='0',variant='0',mode='0',min='0.5',max='2',diam='3000',spacing='3000',count='20',distance='0',random='1',layer='0');self.l.env['*YQT72-LAYERS*']=['Layer corrente']
 def test_valid_dialog(self):self.dialog_tiles();self.c('read-dialog');self.assertEqual(self.l.done,1)
 def test_invalid_diameter_rejected(self):self.dialog_tiles();self.l.tiles['diam']='0';self.c('read-dialog');self.assertIsNone(self.l.done)
 def test_inverted_coefficients_rejected(self):self.dialog_tiles();self.l.tiles['min']='3';self.c('read-dialog');self.assertIsNone(self.l.done)
 def test_invalid_count_rejected(self):self.dialog_tiles();self.l.tiles['count']='2.5';self.c('read-dialog');self.assertIsNone(self.l.done)
 def test_decimal_comma_supported(self):self.dialog_tiles();self.l.tiles['min']='0,75';self.c('read-dialog');self.assertEqual(self.l.done,1);self.assertEqual(self.c('num','0,75'),.75)
 def test_large_number_rejected_before_integer_overflow(self):self.assertFalse(truth(self.c('confirm-count',1e20)))
 def test_hundreds_require_no_question(self):self.l.api['GETKWORD']=lambda p:(_ for _ in ()).throw(AssertionError('unexpected confirmation'));self.assertTrue(truth(self.c('confirm-count',50)))
 def test_inspection_no_geometry(self):self.c('inspect');self.assertFalse(self.instances);self.assertTrue(any('10/10' in t for t in self.l.output))
 def test_filare_generates_endpoints_and_intermediate(self):
  self.setup_source();self.put('spacing','3');p=iter([[0.,0.,0.],[10.,0.,0.]]);self.l.api['GETPOINT']=lambda *a:next(p);self.c('line');self.assertEqual(len(self.instances),5)
  self.assertEqual([float((o.points.max(0)[0]+o.points.min(0)[0])/2) for o in self.instances],[0.,3.,6.,9.,10.])
 def test_filare_same_point_no_objects(self):
  self.setup_source();self.l.api['GETPOINT']=lambda *a:[0.,0.,0.];self.c('line');self.assertFalse(self.instances)
 def test_curve_closed_avoids_duplicate_end(self):
  self.setup_source();self.put('spacing','3');self.l.api.update({'ENTSEL':lambda *a:['curve',[0,0,0]],'VLAX-CURVE-GETENDPARAM':lambda e:1.,'VLAX-CURVE-GETDISTATPARAM':lambda e,p:12.,'VLAX-CURVE-ISCLOSED':lambda e:True,'VLAX-CURVE-GETPOINTATDIST':lambda e,d:[d,0.,0.]});self.c('curve');self.assertEqual(len(self.instances),4)
 def test_curve_invalid_reports_without_objects(self):
  self.setup_source();self.l.api.update({'ENTSEL':lambda *a:['notcurve',[0,0,0]],'VLAX-CURVE-GETENDPARAM':lambda e:None,'VLAX-CURVE-GETDISTATPARAM':lambda *a:None});self.c('curve');self.assertFalse(self.instances)
 def test_rectangle_centers_inside_bounds(self):
  self.setup_source();self.put('count','20');self.l.api.update({'GETPOINT':lambda *a:[10.,20.,7.],'GETCORNER':lambda *a:[30.,40.,7.]});self.c('rectangle');self.assertEqual(len(self.instances),20)
  for o in self.instances:
   c=(o.points.min(0)+o.points.max(0))/2;self.assertTrue(10<=c[0]<=30 and 20<=c[1]<=40 and c[2]==7)
 def test_rectangle_impossible_spacing_is_reported(self):
  self.setup_source();self.put('count','3');self.put('distance','1000');self.l.api.update({'GETPOINT':lambda *a:[0.,0.,0.],'GETCORNER':lambda *a:[1.,1.,0.]});self.c('rectangle');self.assertEqual(len(self.instances),1);self.assertTrue(any('1 posizioni trovate su 3' in p for p in self.l.output))
 def test_rectangle_zero_area_no_objects(self):
  self.setup_source();self.l.api.update({'GETPOINT':lambda *a:[0.,0.,0.],'GETCORNER':lambda *a:[0.,1.,0.]});self.c('rectangle');self.assertFalse(self.instances)
 def test_personal_source_only_in_current_space(self):
  expected=Obj([[0,0,0],[1,1,0]]);captured=[]
  self.l.api['SSGET']=lambda filters:captured.extend(filters) or [expected]
  self.c('select-sources');self.assertEqual(self.l.env['*YQT72-SOURCES*'],[expected]);self.assertTrue(any(getattr(f,'a',None)==410 and f.b=='Model' for f in captured))
 def test_dialog_cancel_no_database_objects(self):
  self.l.api['YQT72-DIALOG']=lambda:0;self.l.call('c:YQ_HEAPTREES');self.assertFalse(self.defs);self.assertFalse(self.instances)
if __name__=='__main__':unittest.main(verbosity=2)
