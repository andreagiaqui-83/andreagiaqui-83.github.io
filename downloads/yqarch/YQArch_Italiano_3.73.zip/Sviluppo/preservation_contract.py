"""Regression constraints pinned to actual 3.70 bytes, not an Autodesk validator.
No new layout may replace/reorder existing controls. Only the listed 40 additions
and their HelpString descriptions are permitted inside the current Ribbon.
"""
from pathlib import Path
import copy,hashlib,json,xml.etree.ElementTree as E
HERE=Path(__file__).resolve().parent

def check_preservation(parts):
    errors=[]
    def need(ok,message):
        if not ok: errors.append(message)
    records=json.loads((HERE/'ribbon_additions.json').read_text('utf8'))
    allowed={r['button_uid']:r for r in records}
    root=E.fromstring(parts['RibbonRoot.cui']); baseline=E.fromstring((HERE/'ribbon_370_reference.xml').read_bytes())
    encountered=[]
    for panel in root.iter('RibbonPanelSource'):
        for row_idx,row in enumerate(panel.findall('RibbonRow')[:3],1):
            for col,button in enumerate(row.findall('RibbonCommandButton'),1):
                uid=button.get('UID')
                if uid in allowed:
                    rec=allowed[uid];encountered.append(uid)
                    need(panel.get('UID')==rec['panel_uid'] and row_idx==rec['row'] and col==rec['column'],'added icon slot')
                    need(button.get('MenuMacroID')==rec['macro_id'],'added icon macro')
                    need(button.get('SmallImage')==rec['small_image'] and button.get('LargeImage')==rec['large_image'],'added icon resource')
                    row.remove(button)
    need(len(encountered)==40 and set(encountered)==set(allowed),'all 40 planned additions')
    # After removing additions, every old UI node must be byte-equivalent under ET.
    need(E.tostring(root)==E.tostring(baseline),'baseline 90 buttons and expanded routes unchanged')
    oldmg=E.fromstring((HERE/'macros_370_reference.xml').read_bytes());mg=E.fromstring(parts['MenuGroup.cui'])
    previous={m.get('UID'):m.find('Macro') for m in oldmg.iter('MenuMacro')}
    helpmap={r['macro_id']:r['function'] for r in records}
    for m in mg.iter('MenuMacro'):
        mid=m.get('UID')
        if mid in helpmap:
            need(m.findtext('Macro/HelpString')==helpmap[mid],'new icon tooltip description')
            m.find('Macro/HelpString').text=previous[mid].findtext('HelpString')
    need(E.tostring(mg)==E.tostring(oldmg),'macro definitions unchanged apart from allowed help')
    asset=json.loads((HERE/'ribbon_assets_reference.json').read_text())['parts']
    need(set(parts)==set(asset)|{'RibbonRoot.cui','MenuGroup.cui'},'same CUIx parts as 3.70')
    need(all(n in parts and hashlib.sha256(parts[n]).hexdigest()==digest for n,digest in asset.items()),'baseline BMP and OPC container bytes unchanged')
    return sorted(set(errors))

def normalize_runtime(raw: bytes) -> bytes:
    """Undo only explicitly allowed release references and diagnostic counts."""
    pairs=[(b'3.73',b'3.70'),(b'3.72',b'3.70'),(b'_372',b'_370'),(b'-372',b'-370'),(b'YQLIB371',b'YQLIB370'),
           (b'yqit372',b'yqit370'),(b'YQIT372',b'YQIT370'),(b'YQL72',b'YQL70'),(b'yql72',b'yql70'),
           (b'YQR72',b'YQR70'),(b'yqr72',b'yqr70'),(b'YQT72',b'YQT70'),(b'yqt72',b'yqt70'),
           (b'30 icone grandi e 100 piccole',b'30 icone grandi e 60 piccole'),
           (b'10 pannelli, 130 accessi',b'10 pannelli, 90 accessi'),
           (b'30 grandi + 100 piccoli',b'30 grandi + 60 piccoli')]
    for a,b in pairs:raw=raw.replace(a,b)
    return raw

def check_runtime(root):
    records=json.loads((HERE/'runtime_370_reference.json').read_text('utf8'))
    problems=[]
    allowed_changed={
        'YQArchItaliano/sys/YQArchItaliano_Library_372.lsp',
        'Sviluppo/installer_373.ps1',
    }
    for rec in records:
        p=root/rec['path']
        if not p.is_file():problems.append('missing pinned runtime '+rec['path']);continue
        if rec['path'] in allowed_changed:
            continue
        if hashlib.sha256(normalize_runtime(p.read_bytes())).hexdigest()!=rec['sha256']:
            problems.append('runtime behavior changed '+rec['path'])
    # 3.73 may change only two pinned behavioral files: the catalog adds a
    # pre-insertion DWG format guard, while the installer avoids duplicate
    # destination hashing. Protect the already-working 3.71 insertion flow.
    lib=(root/'YQArchItaliano/sys/YQArchItaliano_Library_372.lsp').read_text('ascii')
    for marker in (
        '(defun yql72-dwg-compatible-p',
        '((not (yql72-dwg-compatible-p path)) nil)',
        'PUNTO_ACQUISITO','VERIFICA_ENTITA',
        '(setq running (and inserted (= "1" (yql72-get "opzione|reopen-success" "0"))))',
        '(defun c:YQIT_VERIFICA_INSERIMENTO'):
        if marker not in lib:problems.append('catalog protection marker missing '+marker)
    installer=(root/'Sviluppo/installer_373.ps1').read_text('utf-8-sig')
    for marker in ('$script:VerifiedUnchanged[$dst]=$true','$script:VerifiedUnchanged.ContainsKey($dst)','foreach($menuVersion in 363..372)','Restore-Journal'):
        if marker not in installer:problems.append('installer protection marker missing '+marker)
    return problems
