import unittest,json,math
from pathlib import Path
from lisp_model import Lisp,Pair,truth,Error
HERE=Path(__file__).resolve().parent
W=HERE.parent
PAYLOAD=W/'build' if (W/'build/YQArchItaliano').is_dir() else W
class CatalogTests(unittest.TestCase):
 def setUp(self):
  self.l=Lisp();self.l.load((HERE/'Library_372.lsp').read_text());self.l.api['VL-FILE-DIRECTORY-P']=lambda p:True
 def c(self,name,*args):return self.l.call('yql72-'+name,list(args))
 def test_path_join(self):self.assertEqual(self.c('join','C:\\blocks\\','\\bagno\\wc.dwg'),'C:\\blocks\\bagno\\wc.dwg')
 def test_key_is_case_insensitive(self):self.assertEqual(self.c('key','c:/A/B.dwg'),'C:\\A\\B.DWG')
 def test_state_is_metadata(self):
  self.c('put','nome|ABC','Armadio');self.assertEqual(self.c('get','nome|ABC','x'),'Armadio')
  self.c('put','nome|ABC','Armadio 2');self.assertEqual(self.c('get','nome|ABC','x'),'Armadio 2');self.assertEqual(len(self.l.env['*YQL72-STATE*']),1)
 def test_state_malformed_improper(self):self.assertFalse(truth(self.c('string-row-p',Pair('a','b'),2)))
 def test_state_code_is_rejected(self):self.assertFalse(truth(self.c('string-row-p',['setq','x',42],2)))
 def test_state_two_strings(self):self.assertTrue(truth(self.c('string-row-p',['a','b'],2)))
 def test_numeric_comma(self):self.assertEqual(self.c('number',' 1,25 '),1.25)
 def test_numeric_invalid(self):self.assertIsNone(self.c('number','a5'))
 def test_profile_names_all(self):
  self.assertEqual(self.c('label',0),'Catalogo YQArch');self.assertEqual(self.c('label',1),'La mia libreria')
  for n in range(2,11):self.assertEqual(self.c('label',n),'Libreria progetto '+str(n-1))
 def test_profile_keys_original(self):
  self.assertEqual(self.c('profilekey',0),'yq_blocks');self.assertEqual(self.c('profilekey',1),'yq_blockviewer')
  for n in range(2,11):self.assertEqual(self.c('profilekey',n),'yq_blockviewer'+str(n-1))
 def test_opaque_names_are_not_guessed(self):self.assertTrue(self.c('nice','#U8bbe#U5907').startswith('Blocco personale '))
 def test_root_drive_is_rejected(self):self.assertFalse(truth(self.c('valid-root','C:\\')))
 def test_root_folder_is_allowed(self):self.assertTrue(truth(self.c('valid-root','C:\\Libreria')))
 def test_matrix_identity_translation(self):self.assertEqual(self.c('ucs-matrix',[10,20,30]),[[1.,0.,0.,10],[0.,1.,0.,20],[0.,0.,1.,30],[0.,0.,0.,1.]])
 def test_matrix_rotated_ucs(self):
  self.l.api['TRANS']=lambda p,f,t,disp=None:[-p[1],p[0],p[2]]
  self.assertEqual(self.c('ucs-matrix',[10,20,30]),[[0.,-1.,0.,10],[1.,0.,0.,20],[0.,0.,1.,30],[0.,0.,0.,1.]])
 def test_file_missing_abort(self):
  self.l.api['FINDFILE']=lambda p:None;self.l.api['TBLSEARCH']=lambda *x:None
  self.assertFalse(truth(self.c('can-insert','C:\\x.dwg')))
 def test_name_collision_cancel_default(self):
  self.l.api['FINDFILE']=lambda p:p;self.l.api['TBLSEARCH']=lambda *x:True;self.l.api['INITGET']=lambda x:None;self.l.api['GETKWORD']=lambda x:None
  self.assertFalse(truth(self.c('can-insert','C:\\x.dwg')))
 def test_name_collision_explicit_reuse(self):
  self.l.api['FINDFILE']=lambda p:p;self.l.api['TBLSEARCH']=lambda *x:True;self.l.api['INITGET']=lambda x:None;self.l.api['GETKWORD']=lambda x:'Usa'
  self.assertTrue(truth(self.c('can-insert','C:\\x.dwg')))
 def prepare_accept(self):
  self.l.tiles.update(dict(sx='1',sy='1',sz='1',uniform='1',angle='30',px='0',py='0',pz='0',point='0',layer='0'))
  self.l.env['*YQL72-SELECTED*']=0;self.l.env['*YQL72-FILTERED*']=[['x.dwg','A','Cat','ID',None,'note','tags']];self.l.env['*YQL72-LAYERS*']=['Layer corrente']
 def test_accept_positive_scale(self):self.prepare_accept();self.c('accept');self.assertEqual(self.l.done,1)
 def test_reject_zero_scale(self):self.prepare_accept();self.l.tiles['sx']='0';self.c('accept');self.assertIsNone(self.l.done);self.assertIn('maggiori',self.l.tiles['error'])
 def test_reject_negative_scale(self):self.prepare_accept();self.l.tiles['sx']='-1';self.c('accept');self.assertIsNone(self.l.done)
 def test_reject_bad_angle(self):self.prepare_accept();self.l.tiles['angle']='bad';self.c('accept');self.assertIsNone(self.l.done)
 def test_reject_bad_coordinates(self):self.prepare_accept();self.l.tiles.update(point='1',pz='bad');self.c('accept');self.assertIsNone(self.l.done)
 def test_uniform_scale_sync(self):self.prepare_accept();self.l.tiles['sx']='2.5';self.c('accept');self.assertEqual(self.l.tiles['sz'],'2.5')
 def test_independent_scale_preserved(self):self.prepare_accept();self.l.tiles.update(uniform='0',sy='3',sz='4');self.c('accept');self.assertEqual(self.c('get','opzione|sy',''),'3')
 def test_catalog_reader_195(self):
  self.l.api['YQL72-ROOT']=lambda idx:'C:\\Libreria';self.l.api['FINDFILE']=lambda p:p
  self.l.api['OPEN']=lambda p,m:open(PAYLOAD/'YQArchItaliano/sys/YQArchItaliano_Catalogo_372.dat')
  self.l.api['READ-LINE']=lambda f:(f.readline().rstrip('\n') or None);self.l.api['CLOSE']=lambda f:f.close()
  data=self.c('builtins');self.assertEqual(len(data),195);self.assertEqual(self.l.env['*YQL72-MISSING*'],0)
 def test_catalog_missing_count_not_hidden(self):
  self.l.api['YQL72-ROOT']=lambda idx:'C:\\Libreria'
  self.l.api['FINDFILE']=lambda p: None if p.endswith('YQ1105151979.dwg') else p
  self.l.api['OPEN']=lambda p,m:open(PAYLOAD/'YQArchItaliano/sys/YQArchItaliano_Catalogo_372.dat')
  self.l.api['READ-LINE']=lambda f:(f.readline().rstrip('\n') or None);self.l.api['CLOSE']=lambda f:f.close()
  data=self.c('builtins');self.assertEqual(len(data),194);self.assertEqual(self.l.env['*YQL72-MISSING*'],1)
 def test_reparse_failure_conservative(self):self.l.api['VLAX-CREATE-OBJECT']=lambda s:None;self.assertTrue(truth(self.c('reparse-p','C:\\Junction')))


class InsertionTests(unittest.TestCase):
 def setUp(self):
  self.l=Lisp();self.l.load((HERE/'Library_372.lsp').read_text());self.calls=[]
  self.l.env[':VLAX-TRUE']=-1;self.l.env[':VLAX-FALSE']=0
  self.l.env['*YQL72-CHOSEN*']=['C:/blocks/armadio.dwg','Armadio','Arredi','YQB001',None,'note','tags']
  self.l.env['*YQL72-LAYER*']='Arredi'
  self.lock=False;self.attributes=False;self.existing=False;self.transform_fail=False;self.delete_fail=False
  def insert(*args):self.calls.append(('insert',args));return 'ref'
  def transform(*args):
   self.calls.append(('transform',args))
   if self.transform_fail:raise RuntimeError('mock TransformBy failure')
  def delete(obj):
   self.calls.append(('delete',obj))
   if self.delete_fail:raise RuntimeError('mock deletion failure')
  self.l.api.update({
   'VLAX-GET-ACAD-OBJECT':lambda:'app','VLA-GET-ACTIVEDOCUMENT':lambda app:'doc',
   'VLA-GET-LAYERS':lambda doc:'layers','VLA-ITEM':lambda coll,name:name,
   'VLA-GET-LOCK':lambda obj:-1 if self.lock else 0,
   'VLA-GET-FREEZE':lambda obj:0,'VLA-GET-LAYERON':lambda obj:-1,
   'VLA-UPDATE':lambda obj:self.calls.append(('update',obj)),
   'VLA-GET-HANDLE':lambda obj:'H_'+obj,'HANDENT':lambda h:h,'ENTGET':lambda ent:[ent],
   'VLA-REGEN':lambda doc,mode:self.calls.append(('regen',doc,mode)),
   'FINDFILE':lambda path:path,'TBLSEARCH':lambda *args:True if self.existing else None,
   'INITGET':lambda s:None,'GETKWORD':lambda s:'Usa','GETPOINT':lambda text:[10,20,30],
   'VLA-GET-MODELSPACE':lambda doc:'model','VLA-GET-PAPERSPACE':lambda doc:'paper',
   'VLA-STARTUNDOMARK':lambda doc:self.calls.append(('undo-start',doc)),
   'VLA-ENDUNDOMARK':lambda doc:self.calls.append(('undo-end',doc)),
   'VLAX-3D-POINT':lambda pt:pt,'VLA-INSERTBLOCK':insert,'VLA-TRANSFORMBY':transform,
   'VLA-PUT-LAYER':lambda obj,name:self.calls.append(('layer',obj,name)),
   'VLA-GET-HASATTRIBUTES':lambda obj:-1 if self.attributes else 0,
   'VLA-GET-LAYER':lambda obj:'0','VLA-DELETE':delete,
   'VLAX-INVOKE':lambda obj,method:['child1','child2'],
  })
 def put(self,key,val):self.l.call('yql72-put',['opzione|'+key,val])
 def test_native_insertion_parameters(self):
  self.put('sx','2');self.put('sy','3');self.put('sz','4');self.put('angle','90')
  self.l.call('yql72-insert')
  args=next(x[1] for x in self.calls if x[0]=='insert')
  self.assertEqual(args[:6],('model',[0.,0.,0.],'C:/blocks/armadio.dwg',2.,3.,4.));self.assertAlmostEqual(args[6],math.pi/2)
  matrix=next(x[1][1] for x in self.calls if x[0]=='transform');self.assertEqual([r[3] for r in matrix[:3]],[10,20,30])
  self.assertEqual(self.calls[-1],('regen','doc',0));self.assertIn(('undo-end','doc'),self.calls)
 def test_locked_layer_no_mutation(self):self.lock=True;self.l.call('yql72-insert');self.assertEqual(self.calls,[])
 def test_attribute_block_not_exploded(self):
  self.attributes=True;self.put('explode','1');self.l.call('yql72-insert')
  self.assertFalse(any(x[0]=='delete' for x in self.calls));self.assertTrue(any('attributi' in x for x in self.l.output))
 def test_unattributed_block_exploded(self):
  self.put('explode','1');self.l.call('yql72-insert')
  self.assertIn(('delete','ref'),self.calls);self.assertIn(('layer','child1','Arredi'),self.calls)
 def test_transform_failure_cleanup(self):
  self.transform_fail=True;self.l.call('yql72-insert')
  self.assertIn(('delete','ref'),self.calls);self.assertEqual(self.calls[-1],('undo-end','doc'))
  self.assertFalse(any('Inserito:' in x for x in self.l.output))
 def test_cleanup_failure_is_reported(self):
  self.transform_fail=True;self.delete_fail=True;self.l.call('yql72-insert')
  self.assertTrue(any('pulizia incompleta' in x for x in self.l.output))
 def test_reused_existing_definition_not_claimed_as_new_source(self):
  self.existing=True;self.l.call('yql72-insert');self.assertIsNone(self.l.env.getv('*YQL72-LOADED-FILES*'))
 def test_reused_existing_cancel_no_objects(self):
  self.existing=True;self.l.api['GETKWORD']=lambda s:None;self.l.call('yql72-insert');self.assertEqual(self.calls,[])

if __name__=='__main__':unittest.main(verbosity=2)
