import unittest
from pathlib import Path
from lisp_model import Lisp,truth
HERE=Path(__file__).resolve().parent
W=HERE.parent
PAYLOAD=W/'build' if (W/'build/YQArchItaliano').is_dir() else W
class RibbonTests(unittest.TestCase):
 def setUp(self):
  self.l=Lisp();self.l.load((HERE/'Ribbon_372.lsp').read_text());self.file='C:/YQ/YQArchItaliano_Ribbon_372.cuix';self.group=None;self.calls=[];self.fail=False
  def load(groups,path):
   self.calls.append(('load',path))
   if self.fail and path==self.file:raise RuntimeError('mock load failure')
   self.group={'file':path,'type':1};return self.group
  def unload(group):self.calls.append(('unload',group['file']));self.group=None
  self.l.api.update({'YQR72-FILE':lambda:self.file,'YQR72-GROUP':lambda:self.group,
   'VLAX-GET-ACAD-OBJECT':lambda:'app','VLA-GET-MENUGROUPS':lambda app:'groups',
   'VLA-GET-MENUFILENAME':lambda group:group['file'],'VLA-GET-TYPE':lambda group:group['type'],
   'VL-BB-REF':lambda key:getattr(self,'bb',None),
   'VL-BB-SET':lambda key,val:setattr(self,'bb',val),
   'VLA-LOAD':load,'VLA-UNLOAD':unload,'FINDFILE':lambda x:x})
 def test_load_missing_own_group(self):self.l.call('yqr72-ensure',[None]);self.assertEqual(self.calls,[('load',self.file)]);self.assertTrue(truth(self.l.env.getv('*YQR72-OK*')))
 def test_already_loaded_is_idempotent(self):self.group={'file':self.file,'type':1};self.l.call('yqr72-ensure',[None]);self.assertEqual(self.calls,[])
 def test_old_group_upgraded(self):
  self.group={'file':'C:/old366.cuix','type':1};self.l.call('yqr72-ensure',[None]);self.assertEqual(self.calls,[('unload','C:/old366.cuix'),('load',self.file)])
 def test_force_reloads_only_current_group(self):self.group={'file':self.file,'type':1};self.l.call('yqr72-ensure',[True]);self.assertEqual(len(self.calls),2)
 def test_base_cui_not_unloaded(self):
  self.group={'file':'C:/acad.cuix','type':0};self.l.call('yqr72-ensure',[True]);self.assertEqual(self.calls,[]);self.assertFalse(truth(self.l.env.getv('*YQR72-OK*')))
 def test_failed_load_restores_old_file(self):
  self.group={'file':'C:/old366.cuix','type':1};self.fail=True;self.l.call('yqr72-ensure',[True]);self.assertEqual(self.group['file'],'C:/old366.cuix');self.assertFalse(truth(self.l.env.getv('*YQR72-OK*')))
 def test_workspace_marks_pending_only(self):self.l.call('yqr72-workspace',[None,['WSCURRENT',True]]);self.assertTrue(truth(self.l.env.getv('*YQR72-PENDING*')));self.assertEqual(self.calls,[])
 def test_unrelated_sysvar_ignored(self):self.l.call('yqr72-workspace',[None,['CLAYER',True]]);self.assertFalse(truth(self.l.env.getv('*YQR72-PENDING*')))
 def test_command_end_retry_bounded(self):
  self.fail=True;self.l.env['*YQR72-PENDING*']=True;self.l.env['*YQR72-RETRIES*']=0
  for _ in range(5):self.l.call('yqr72-after-command',[None,['LINE']])
  self.assertEqual(len(self.calls),2)
 def test_command_end_success_clears_pending(self):
  self.l.env['*YQR72-PENDING*']=True;self.l.env['*YQR72-RETRIES*']=0;self.l.call('yqr72-after-command',[None,['LINE']]);self.assertFalse(truth(self.l.env.getv('*YQR72-PENDING*')))
 def test_fresh_context_needs_late_initialization(self):
  self.assertTrue(truth(self.l.call('yqr72-late-init-needed')))
 def test_success_remembered_across_document_loads(self):
  self.l.env['*YQR72-PENDING*']=True;self.l.env['*YQR72-RETRIES*']=0
  self.l.call('yqr72-after-command',[None,['LINE']])
  self.assertFalse(truth(self.l.call('yqr72-late-init-needed')))
 def test_no_reloads_after_success_on_ordinary_commands(self):
  self.l.env['*YQR72-PENDING*']=True;self.l.env['*YQR72-RETRIES*']=0
  self.l.call('yqr72-after-command',[None,['LINE']]);n=len(self.calls)
  for _ in range(30):self.l.call('yqr72-after-command',[None,['ZOOM']])
  self.assertEqual(len(self.calls),n)
 def test_manual_ribbon_open_requests_one_reload(self):
  self.l.env['*YQR72-RETRIES*']=0
  self.l.call('yqr72-after-command',[None,['_.RIBBON']]);self.assertEqual(len(self.calls),1)
 def test_busy_prevents_recursive_ribbon_callback(self):
  self.l.env['*YQR72-BUSY*']=True;self.l.env['*YQR72-RETRIES*']=0
  self.l.call('yqr72-after-command',[None,['RIBBON']]);self.assertEqual(self.calls,[])
 def test_final_failure_stops_pending_flag(self):
  self.fail=True;self.l.env['*YQR72-PENDING*']=True;self.l.env['*YQR72-RETRIES*']=0
  for _ in range(10):self.l.call('yqr72-after-command',[None,['LINE']])
  self.assertFalse(truth(self.l.env.getv('*YQR72-PENDING*')));self.assertEqual(len(self.calls),2)
if __name__=='__main__':unittest.main(verbosity=2)
