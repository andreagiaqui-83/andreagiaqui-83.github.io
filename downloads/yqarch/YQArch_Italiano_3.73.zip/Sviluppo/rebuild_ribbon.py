"""Rebuild/validate YQArch's partial Ribbon OPC package.
Run against a local CUIx. No AutoCAD required, but NOT an AutoCAD UI test.
The defect fixed here: image relationships still pointed at deleted BMP files
although both the image resources and button references were converted to PNG.
This validator intentionally examines ALL OPC relationships, not only CUI XML.
"""
from pathlib import Path
from urllib.parse import unquote
import json, zipfile, io, posixpath, argparse
import xml.etree.ElementTree as E
REL_NS='http://schemas.openxmlformats.org/package/2006/relationships'
TYPES_NS='http://schemas.openxmlformats.org/package/2006/content-types'
E.register_namespace('',REL_NS)

def load_parts(path):
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None: raise ValueError('CUIx CRC non valido')
        if len(z.namelist())!=len(set(n.casefold() for n in z.namelist())): raise ValueError('Nomi duplicati CUIx')
        return {n:z.read(n) for n in z.namelist()}

def resolve_relationship(part,target):
    # OPC relationship is relative to the source part, not the _rels folder.
    if part=='_rels/.rels': source_dir=''
    else: source_dir=posixpath.dirname(part.rsplit('/_rels/',1)[0]+'/'+posixpath.basename(part)[:-5])
    path=unquote(target).split('#',1)[0]
    return posixpath.normpath(path.lstrip('/') if path.startswith('/') else posixpath.join(source_dir,path))

def check_relationships(parts):
    missing=[];edges=[];ids=[]
    for part,raw in parts.items():
        if not part.endswith('.rels'):continue
        root=E.fromstring(raw)
        if root.tag!='{'+REL_NS+'}Relationships':raise ValueError('Namespace relazioni non valido: '+part)
        seen=set()
        for rel in root:
            rid=rel.get('Id')
            if not rid or rid in seen:raise ValueError('ID relazione duplicato: '+part)
            seen.add(rid)
            if rel.get('TargetMode')=='External':raise ValueError('Risorsa Ribbon esterna non ammessa: '+part)
            target=resolve_relationship(part,rel.get('Target',''))
            edges.append((part,rel.get('Type'),target))
            if target not in parts:missing.append((part,rid,target))
    return missing,edges

def repair(path,out=None):
    parts=load_parts(path);before,edges=check_relationships(parts);changes=[]
    for part,raw in list(parts.items()):
        if not part.endswith('.rels'):continue
        root=E.fromstring(raw);changed=False
        for rel in root:
            target=rel.get('Target','');name=resolve_relationship(part,target)
            if name not in parts and name.lower().endswith('.bmp') and name[:-4]+'.png' in parts:
                rel.set('Target',target[:-4]+'.png');changes.append({'relationship':rel.get('Id'),'from':target,'to':target[:-4]+'.png'});changed=True
        if changed:parts[part]=E.tostring(root,encoding='utf-8',xml_declaration=True)
    after,edges=check_relationships(parts)
    if after:raise ValueError('Relazioni non risolte: '+repr(after[:10]))
    # Never rewrite stable UI identities while repairing package relationships.
    # Stable package timestamps, deterministic compression.
    dest=out or path
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(parts.items()):
            zi=zipfile.ZipInfo(name,(2026,9,30,0,0,0));zi.external_attr=0o100644<<16
            z.writestr(zi,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    verified=load_parts(dest);missing,edges=check_relationships(verified)
    assert not missing
    return {'baseline_missing_relationships':len(before),'repaired_relationships':len(changes),'remaining_missing':len(missing),'all_relationships':len(edges),'changes':changes}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('file',type=Path);p.add_argument('--output',type=Path);p.add_argument('--audit',type=Path);a=p.parse_args()
    report=repair(a.file,a.output)
    if a.audit:a.audit.parent.mkdir(parents=True,exist_ok=True);a.audit.write_text(json.dumps(report,indent=2),encoding='utf8')
    print({k:v for k,v in report.items() if k!='changes'})
