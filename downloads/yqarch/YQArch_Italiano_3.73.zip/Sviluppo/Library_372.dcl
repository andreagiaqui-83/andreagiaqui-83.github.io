yql72_catalog : dialog {
 label = "YQArch Italiano - Catalogo blocchi";
 : row {
  : popup_list { key="source"; label="Libreria:"; width=48; }
  : button { key="folder"; label="Cartella..."; width=16; fixed_width=true; }
  : button { key="refresh"; label="Aggiorna indice"; width=18; fixed_width=true; }
  : button { key="advanced"; label="Gestione avanzata..."; width=23; fixed_width=true; }
 }
 : text { key="rootlabel"; width=115; }
 : row {
  : edit_box { key="query"; label="Cerca nome o categoria:"; edit_width=44; }
  : toggle { key="favorites"; label="Solo preferiti"; }
  : toggle { key="recent"; label="Solo recenti"; }
  : button { key="reset"; label="Azzera filtri"; width=15; fixed_width=true; }
 }
 : row {
  : boxed_column { label="Categorie";
   : list_box { key="cats"; width=28; height=17; fixed_width=true; }
  }
  : boxed_column { label="Blocchi disponibili";
   : list_box { key="blocks"; allow_accept=true; multiple_select=false; width=49; height=17; fixed_width=true; }
  }
  : boxed_column { label="Anteprima del file selezionato";
   : image { key="preview"; width=34; height=13; fixed_width=true; fixed_height=true; color=0; }
   : text { key="previewnote"; width=34; }
   : row {
    : button { key="star"; label="Preferito"; }
    : button { key="rename"; label="Nome e categoria..."; }
   }
   : button { key="details"; label="Dettagli e percorso originale..."; }
  }
 }
 : text { key="selected"; width=115; }
 : text { label="Doppio clic sul blocco oppure seleziona e premi Inserisci: il punto nel disegno inserisce direttamente il blocco."; width=115; }
 : text { key="status"; width=115; }
 : boxed_row { label="Inserimento nel disegno - valori nelle unita del DWG";
  : column {
   : row {
    : edit_box { key="sx"; label="Scala X:"; edit_width=8; }
    : edit_box { key="sy"; label="Y:"; edit_width=8; }
    : edit_box { key="sz"; label="Z:"; edit_width=8; }
    : toggle { key="uniform"; label="Scala uniforme"; }
   }
   : row {
    : button { key="scale1"; label="Scala 1:1"; }
    : button { key="scale254"; label="Pollici > mm (25.4)"; }
    : edit_box { key="angle"; label="Rotazione (gradi):"; edit_width=8; }
   }
  }
  : column {
   : popup_list { key="layer"; label="Layer:"; width=27; }
   : toggle { key="explode"; label="Esplodi dopo inserimento"; }
   : toggle { key="repeat"; label="Riapri solo dopo inserimento riuscito"; }
  }
 }
 : row {
  : toggle { key="point"; label="Punto da coordinate UCS"; }
  : edit_box { key="px"; label="X:"; edit_width=10; }
  : edit_box { key="py"; label="Y:"; edit_width=10; }
  : edit_box { key="pz"; label="Z:"; edit_width=10; }
  : button { key="continue"; label="Continua indice"; width=19; fixed_width=true; }
 }
 : text { key="error"; width=115; }
 : row {
  : button { key="help"; label="Guida al catalogo"; }
  : button { key="explorer"; label="Apri cartella"; }
  spacer;
  : button { key="accept"; label="Inserisci blocco"; is_default=true; width=22; fixed_width=true; }
  : button { key="cancel"; label="Chiudi"; is_cancel=true; width=15; fixed_width=true; }
 }
}
yql72_folder : dialog {
 label="YQArch Italiano - Configura libreria";
 : edit_box { key="title"; label="Nome della libreria:"; edit_width=60; }
 : edit_box { key="path"; label="Cartella dei DWG:"; edit_width=60; }
 : text { label="Indica una cartella specifica, anche di rete. Nessun file viene spostato."; }
 : text { label="Le sottocartelle vengono indicizzate; i collegamenti di sistema sono esclusi."; }
 : text { key="error"; width=86; }
 : row {
  : button { key="browse"; label="Sfoglia..."; }
  spacer;
  : button { key="accept"; label="Conferma"; is_default=true; }
  : button { key="cancel"; label="Annulla"; is_cancel=true; }
 }
}
yql72_alias : dialog {
 label="YQArch Italiano - Nome nel catalogo";
 : text { label="Modifica solo la scheda del catalogo: il file DWG non viene rinominato."; }
 : edit_box { key="title"; label="Nome leggibile:"; edit_width=62; }
 : edit_box { key="category"; label="Categoria:"; edit_width=62; }
 : text { key="error"; width=85; }
 : row {
  : button { key="reset"; label="Ripristina nome del catalogo"; }
  spacer;
  : button { key="accept"; label="Salva"; is_default=true; }
  : button { key="cancel"; label="Annulla"; is_cancel=true; }
 }
}
