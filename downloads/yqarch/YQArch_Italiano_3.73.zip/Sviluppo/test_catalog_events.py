"""Regression tests for the actual Lisp callback bodies in the package.
Native DCL event dispatch is simulated following Autodesk's allow_accept contract.
These tests are NOT mouse tests inside AutoCAD.
"""
import re,unittest
from pathlib import Path
from lisp_model import Lisp,truth,Error
HERE=Path(__file__).resolve().parent

class CatalogEventTests(unittest.TestCase):
 def setUp(self):
  self.l=Lisp();self.l.load((HERE/'Library_372.lsp').read_text());self.render=[];self.close=[];self.refresh=[]
  self.items=[['C:/Arredi/armadio.dwg','Armadio','Arredi','A',None,'Nota','armadio'],['C:/Arredi/letto.dwg','Letto','Arredi','B',None,'Nota','letto']]
  self.l.env.update({'*YQL72-FILTERED*':self.items,'*YQL72-ITEMS*':self.items,'*YQL72-SELECTED*':0,'*YQL72-LAYERS*':['Layer corrente'], '*YQL72-QUERY*':'','*YQL72-CAT*':'Tutte le categorie','*YQL72-CATEGORIES*':['Tutte le categorie','Arredi'],'*YQL72-PROFILE*':0,'*YQL72-FAV*':'0','*YQL72-RECENT*':'0'})
  self.l.tiles.update(dict(blocks='0',sx='1',sy='1',sz='1',uniform='1',angle='0',px='0',py='0',pz='0',point='0',layer='0',repeat='0'))
  self.l.api['YQL72-RENDER']=lambda:self.render.append('render')
  self.l.api['DONE_DIALOG']=lambda v:self.close.append(v)
 def c(self,name,*args):return self.l.call('yql72-'+name,list(args))
 def select(self,value,reason=1):self.l.tiles['blocks']=value;self.c('block-selected',value,reason)
 def test_single_click_selects_only(self):
  self.select('1');self.assertEqual(self.l.env['*YQL72-SELECTED*'],1);self.assertEqual(self.close,[])
 def test_one_button_click_accepts_selected(self):
  self.select('1');self.c('accept');self.assertEqual(self.close,[1]);self.assertEqual(self.l.env['*YQL72-CHOSEN*'],self.items[1])
 def test_double_click_uses_native_default_once(self):
  dcl=(HERE/'Library_372.dcl').read_text();self.assertRegex(dcl,r'key="blocks";\s*allow_accept=true;\s*multiple_select=false;')
  self.select('1');self.select('1',4);self.c('accept') # default button activation by native DCL
  self.assertEqual(self.close,[1]);self.assertEqual(self.l.env['*YQL72-CHOSEN*'],self.items[1])
 def test_enter_uses_same_accept_handler(self):
  self.select('1');self.c('accept');self.assertEqual(self.close,[1]);self.assertEqual(self.l.env['*YQL72-CHOSEN*'][3],'B')
 def test_duplicate_accept_notification_is_idempotent(self):
  self.c('accept');self.c('accept');self.assertEqual(self.close,[1])
 def test_same_selection_focus_notification_does_not_render(self):
  self.select('1');self.select('1',2);self.select('1',4);self.assertEqual(len(self.render),1)
 def test_unchanged_search_blur_does_not_refresh(self):
  self.l.api['YQL72-REFRESH']=lambda:self.refresh.append('refresh')
  self.select('1');self.c('query-changed','');self.assertEqual(self.refresh,[]);self.c('accept');self.assertEqual(self.l.env['*YQL72-CHOSEN*'][3],'B')
 def test_changed_query_refreshes_once(self):
  self.l.api['YQL72-REFRESH']=lambda:self.refresh.append('refresh')
  self.c('query-changed','Letto');self.c('query-changed','Letto');self.assertEqual(self.refresh,['refresh'])
 def test_unchanged_category_does_not_refresh(self):
  self.l.api['YQL72-REFRESH']=lambda:self.refresh.append('refresh');self.c('category-changed','0');self.assertEqual(self.refresh,[])
 def test_changed_category_refreshes_once(self):
  self.l.api['YQL72-REFRESH']=lambda:self.refresh.append('refresh');self.c('category-changed','1');self.c('category-changed','1');self.assertEqual(self.refresh,['refresh'])
 def test_accept_reads_current_tile_not_stale_global(self):
  self.l.tiles['blocks']='1';self.c('accept');self.assertEqual(self.l.env['*YQL72-CHOSEN*'][3],'B')
 def test_invalid_scale_then_single_correction_accept(self):
  self.l.tiles['sx']='0';self.c('accept');self.assertEqual(self.close,[])
  self.l.tiles['sx']='2';self.c('accept');self.assertEqual(self.close,[1])
 def test_invalid_selection_never_closes(self):
  self.l.env['*YQL72-FILTERED*']=None;self.c('accept');self.assertEqual(self.close,[])
 def test_invalid_event_index_does_not_change_selection(self):
  self.select('200');self.assertEqual(self.l.env['*YQL72-SELECTED*'],0);self.assertEqual(self.render,[])
 def test_reentrant_accept_is_blocked(self):
  self.l.env['*YQL72-ACCEPTING*']=True;self.c('accept');self.assertEqual(self.close,[])
 def test_refresh_keeps_same_file_after_sort(self):
  self.l.api.update({'START_LIST':lambda k:None,'ADD_LIST':lambda s:None,'END_LIST':lambda:None})
  self.select('1');self.c('refresh');self.assertEqual(self.c('current')[3],'B');self.assertEqual(self.l.tiles['blocks'],'1')
 def test_filter_removing_selection_chooses_remaining_file(self):
  self.l.api.update({'START_LIST':lambda k:None,'ADD_LIST':lambda s:None,'END_LIST':lambda:None})
  self.select('1');self.l.env['*YQL72-QUERY*']='Armadio';self.c('refresh');self.assertEqual(self.c('current')[3],'A')
 def test_render_does_not_reenable_default_button_repeatedly(self):
  self.l.api.pop('YQL72-RENDER');calls=[]
  self.l.api.update({'DIMX_TILE':lambda k:100,'DIMY_TILE':lambda k:100,'START_IMAGE':lambda k:None,'FILL_IMAGE':lambda *a:None,'END_IMAGE':lambda:None,'MODE_TILE':lambda k,v:calls.append((k,v))})
  self.c('render');self.c('render');self.assertEqual([c for c in calls if c[0]=='accept'],[('accept',0)])
 def test_render_disables_accept_if_filter_empty(self):
  self.l.api.pop('YQL72-RENDER');calls=[]
  self.l.api.update({'DIMX_TILE':lambda k:100,'DIMY_TILE':lambda k:100,'START_IMAGE':lambda k:None,'FILL_IMAGE':lambda *a:None,'END_IMAGE':lambda:None,'MODE_TILE':lambda k,v:calls.append((k,v))})
  self.c('render');self.l.env['*YQL72-FILTERED*']=None;self.c('render');self.assertEqual([c for c in calls if c[0]=='accept'],[('accept',0),('accept',1)])
 def test_run_inserts_once_per_acceptance(self):
  insertions=[];calls=[1,0]
  def dialog():
   v=calls.pop(0);self.l.env['*YQL72-ACCEPTED*']=True if v else None;return v
  self.l.api.update({'YQL72-READ-STATE':lambda:None,'YQL72-BUILTINS':lambda:self.items,'YQL72-INDEX':lambda b:None,'YQL72-SAVE':lambda:None,'YQL72-DIALOG':dialog,'YQL72-INSERT':lambda:insertions.append('insert')})
  self.c('put','opzione|repeat','1');self.c('run',0);self.assertEqual(insertions,['insert'])
 def test_stale_dialog_status_without_acceptance_does_not_insert(self):
  insertions=[];calls=[1,0]
  self.l.api.update({'YQL72-READ-STATE':lambda:None,'YQL72-BUILTINS':lambda:self.items,'YQL72-INDEX':lambda b:None,'YQL72-SAVE':lambda:None,'YQL72-DIALOG':lambda:calls.pop(0),'YQL72-INSERT':lambda:insertions.append('insert')})
  self.c('put','opzione|repeat','1');self.c('run',0);self.assertEqual(insertions,[])

if __name__=='__main__':unittest.main(verbosity=2)
