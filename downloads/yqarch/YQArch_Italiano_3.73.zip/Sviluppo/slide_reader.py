"""Strict local reader for level-2 AutoCAD SLD vectors; inspection only."""
import struct
from pathlib import Path
from PIL import Image, ImageDraw

def read_slide(data):
 if not data.startswith(b'AutoCAD Slide\r\n\x1a\0'):raise ValueError('SLD signature')
 if data[18]!=2:raise ValueError('SLD level not supported')
 endian='<' if data[29:31]==b'4\x12' else '>'
 w,h=struct.unpack_from(endian+'HH',data,19);pos=31;last=(0,0);color=7;lines=[];poly=[];fills=[]
 def s8(x):return x if x<128 else x-256
 while pos+2<=len(data):
  word=struct.unpack_from(endian+'H',data,pos)[0];pos+=2;typ=word>>8;lo=word&255
  if typ<=127:
   y,x2,y2=struct.unpack_from(endian+'hhh',data,pos);pos+=6
   a=(word,y);b=(x2,y2);lines.append((a,b,color));last=a
  elif typ==255:color=lo
  elif typ==252:return (w,h,lines,fills)
  elif typ==251:
   dy,dx2,dy2=struct.unpack_from('bbb',data,pos);pos+=3
   a=(last[0]+s8(lo),last[1]+dy);b=(last[0]+dx2,last[1]+dy2);lines.append((a,b,color));last=a
  elif typ==254:
   dy=struct.unpack_from('b',data,pos)[0];pos+=1
   a=(last[0]+s8(lo),last[1]+dy);lines.append((last,a,color));last=a
  elif typ==253:
   x,y=struct.unpack_from(endian+'hh',data,pos);pos+=4
   if y<0:
    if poly:fills.append((poly,color));poly=[]
   else:poly.append((x,y))
  else:raise ValueError(f'Unsupported SLD record {typ:02x} at {pos-2}')
 raise ValueError('No SLD terminator')

def render(path,out,size=(500,330)):
 w,h,lines,fills=read_slide(Path(path).read_bytes());im=Image.new('RGB',size,(33,40,46));d=ImageDraw.Draw(im)
 scale=min((size[0]-20)/max(w,1),(size[1]-20)/max(h,1));ox=(size[0]-w*scale)/2;oy=(size[1]-h*scale)/2
 def p(pt):return (ox+pt[0]*scale,oy+(h-pt[1])*scale)
 colors={0:(255,255,255),1:(255,90,90),2:(255,232,65),3:(92,226,104),4:(0,215,220),5:(95,155,255),6:(255,100,235),7:(240,244,248),8:(160,164,169),9:(195,198,205)}
 def rgb(c):return colors.get(c,(185,200,213))
 for poly,c in fills:
  if len(poly)>2:d.polygon([p(pt) for pt in poly],fill=rgb(c))
 for a,b,c in lines:d.line((p(a),p(b)),fill=rgb(c),width=1)
 im.save(out);return len(lines)
