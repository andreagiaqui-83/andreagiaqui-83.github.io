import io, unittest
from pathlib import Path
from lisp_model import Lisp, truth

HERE=Path(__file__).resolve().parent

class DwgCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.l=Lisp()
        self.l.load((HERE/'Library_372.lsp').read_text())

    def compat(self, header, acadver):
        self.l.api['OPEN']=lambda p,m: io.StringIO(header)
        base=self.l.api['GETVAR']
        self.l.api['GETVAR']=lambda k: acadver if k=='ACADVER' else base(k)
        return truth(self.l.call('yql72-dwg-compatible-p',['C:\\blocchi\\test.dwg']))

    def test_autocad_2004_accepts_ac1018(self):
        self.assertTrue(self.compat('AC1018', '16.0'))

    def test_autocad_2004_rejects_ac1021(self):
        self.assertFalse(self.compat('AC1021', '16.0'))
        self.assertTrue(any('richiede AutoCAD 2007' in x for x in self.l.output))

    def test_autocad_2007_accepts_ac1021(self):
        self.assertTrue(self.compat('AC1021', '17.0'))

    def test_unknown_header_is_conservative(self):
        self.assertFalse(self.compat('XXXXXX', '26.0'))
        self.assertTrue(any('non riconosciuto' in x for x in self.l.output))

if __name__=='__main__': unittest.main(verbosity=2)
