import unittest,xml.etree.ElementTree as E
from pathlib import Path
from rebuild_ribbon import load_parts
from ribbon_contract import check_layout
class ContractTests(unittest.TestCase):
 def setUp(self):self.parts=load_parts(Path(__file__).resolve().parent.parent/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix')
 def mutate(self,fn):
  r=E.fromstring(self.parts['RibbonRoot.cui']);fn(r);self.parts['RibbonRoot.cui']=E.tostring(r)
 def test_current_layout_satisfies_contract(self):self.assertEqual(check_layout(self.parts),[])
 def test_versioned_tab_regression_rejected(self):
  self.mutate(lambda r:next(r.iter('RibbonTabSource')).set('UID','YQIT_TAB_372'))
  self.assertIn('stable tab identity',check_layout(self.parts))
 def test_changed_panel_identity_rejected(self):
  self.mutate(lambda r:next(r.iter('RibbonPanelSource')).set('UID','new-panel'))
  self.assertIn('stable panel identities',check_layout(self.parts))
 def test_nested_container_rejected_by_project_contract(self):
  self.mutate(lambda r:E.SubElement(next(r.iter('RibbonRow')),'RibbonRowPanel'))
  self.assertIn('project flat-row contract',check_layout(self.parts))
 def test_missing_expanded_command_detected(self):
  def remove(r):
   s=next(r.iter('RibbonSplitButton'));s.remove(s.find('RibbonCommandButton'))
  self.mutate(remove);self.assertIn('547 expanded command routes',check_layout(self.parts))
 def test_missing_macro_detected(self):
  self.mutate(lambda r:next(r.iter('RibbonCommandButton')).set('MenuMacroID','missing'))
  self.assertIn('valid macro reference',check_layout(self.parts))
 def test_changed_style_detected(self):
  self.mutate(lambda r:next(r.iter('RibbonCommandButton')).set('ButtonStyle','SmallWithText'))
  self.assertIn('icon-only row styles',check_layout(self.parts))
 def test_tab_not_added_to_workspace_detected(self):
  self.mutate(lambda r:next(r.iter('RibbonTabSource')).set('DefaultDisplay','DoNotAddToWorkspace'))
  self.assertIn('add tab to workspace',check_layout(self.parts))
if __name__=='__main__':unittest.main(verbosity=2)
