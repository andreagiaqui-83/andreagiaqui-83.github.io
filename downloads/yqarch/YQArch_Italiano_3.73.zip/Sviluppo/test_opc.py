"""OPC regression tests: detect missing targets that XML/CRC-only tests miss."""
from pathlib import Path
import copy,unittest
from rebuild_ribbon import load_parts,check_relationships,resolve_relationship
HERE=Path(__file__).resolve().parent
class OpcTests(unittest.TestCase):
 def setUp(self):self.parts=load_parts(HERE.parent/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix')
 def test_all_933_relationships_resolve(self):
  missing,edges=check_relationships(self.parts);self.assertEqual(missing,[]);self.assertEqual(len(edges),933)
 def test_regression_deleted_bmp_targets_detected(self):
  broken={n.replace('.bmp','.png'):raw for n,raw in self.parts.items()}
  missing,edges=check_relationships(broken);self.assertEqual(len(missing),916)
 def test_missing_cui_part_detected(self):
  del self.parts['RibbonRoot.cui'];self.assertEqual(len(check_relationships(self.parts)[0]),1)
 def test_missing_image_detected(self):
  name=next(n for n in self.parts if n.endswith('.bmp'));del self.parts[name];self.assertEqual(len(check_relationships(self.parts)[0]),1)
 def test_root_relationship_resolution(self):self.assertEqual(resolve_relationship('_rels/.rels','/icons/a.png'),'icons/a.png')
 def test_relative_part_relationship_resolution(self):self.assertEqual(resolve_relationship('foo/_rels/doc.xml.rels','../img/a.png'),'img/a.png')
 def test_duplicate_relation_id_rejected(self):
  import xml.etree.ElementTree as E
  root=E.fromstring(self.parts['_rels/.rels']);root.append(copy.deepcopy(root[0]));self.parts['_rels/.rels']=E.tostring(root)
  with self.assertRaises(ValueError):check_relationships(self.parts)
 def test_external_image_forbidden(self):
  import xml.etree.ElementTree as E
  root=E.fromstring(self.parts['_rels/.rels']);root[0].set('TargetMode','External');self.parts['_rels/.rels']=E.tostring(root)
  with self.assertRaises(ValueError):check_relationships(self.parts)
if __name__=='__main__':unittest.main(verbosity=2)
