"""Small deterministic evaluator for testing the new pure-Lisp logic with mock CAD APIs.
NOT an Autodesk AutoLISP implementation: integration, DCL rendering and CAD geometry
must still be tested in AutoCAD. Unsupported calls fail instead of succeeding silently.
"""
import math,re,functools,io
from lisp_checks import Symbol,String,read_forms
class Pair:
 def __init__(self,a,b):self.a=a;self.b=b
 def __eq__(self,x):return isinstance(x,Pair) and x.a==self.a and x.b==self.b
class Error:
 def __init__(self,e):self.message=str(e)
class Env(dict):
 def __init__(self,parent=None):super().__init__();self.parent=parent
 def find(self,key):return self if key in self or self.parent is None else self.parent.find(key)
 def getv(self,key):return self.find(key).get(key,None)
 def setv(self,key,value):self.find(key)[key]=value;return value
class Done(Exception):
 def __init__(self,result):self.result=result

def truth(x):return x is not None and x is not False and x != []
def boolean(x):return True if x else None

def car(x):return x.a if isinstance(x,Pair) else (x[0] if x else None)
def cdr(x):return x.b if isinstance(x,Pair) else ((x[1:] or None) if x else None)
def equal(a,b):
 if isinstance(a,Symbol) and isinstance(b,Symbol):return a.upper()==b.upper()
 return a==b
class Lisp:
 def __init__(self):
  self.env=Env();self.func={};self.api={};self.output=[];self.tiles={};self.done=None;self._install()
 def _install(self):
  def member(x,seq):
   for i,y in enumerate(seq or []):
    if equal(x,y):return seq[i:]
  def assoc(x,seq):return next((p for p in (seq or []) if equal(x,car(p))),None)
  def length(x):
   if isinstance(x,Pair):raise ValueError('improper list')
   return len(x or [])
  def typeof(x):
   if x is None:return Symbol('LIST')
   if x is True or isinstance(x,Symbol):return Symbol('SYM')
   if isinstance(x,str):return Symbol('STR')
   if isinstance(x,(list,Pair)):return Symbol('LIST')
   if isinstance(x,int):return Symbol('INT')
   if isinstance(x,float):return Symbol('REAL')
   return Symbol('VLA-OBJECT')
  def numberp(x):return isinstance(x,(int,float)) and not isinstance(x,bool)
  def distof(x,mode):
   try:return float(x)
   except ValueError:return None
  def princ(x=None,handle=None):
   if x is not None:self.output.append(str(x))
   return x
  def done(n):self.done=n;return n
  self.api={
   'LIST':lambda *a:list(a) or None,'CONS':lambda a,b:[a]+b if isinstance(b,list) else ([a] if b is None else Pair(a,b)),
   'CAR':car,'CDR':cdr,'CADR':lambda x:car(cdr(x)),'CADDR':lambda x:car(cdr(cdr(x))),
   'NTH':lambda n,x:x[n] if x and 0<=n<len(x) else None,'LENGTH':length,
   'NULL':lambda x:boolean(not truth(x)),'NOT':lambda x:boolean(not truth(x)),
   'NUMBERP':lambda x:boolean(numberp(x)),'LISTP':lambda x:boolean(x is None or isinstance(x,(list,Pair))),
   'TYPE':typeof,'=':lambda *a:boolean(all(equal(x,y) for x,y in zip(a,a[1:]))),
   '/=':lambda a,b:boolean(not equal(a,b)),'<':lambda *a:boolean(all(x<y for x,y in zip(a,a[1:]))),
   '>':lambda *a:boolean(all(x>y for x,y in zip(a,a[1:]))),'>=':lambda a,b:boolean(a>=b),'1+':lambda x:x+1,'1-':lambda x:x-1,
   '+':lambda *a:sum(a),'-':lambda a,*b:a-sum(b) if b else -a,'*':lambda *a:math.prod(a),'/':lambda a,b:a/b,
   'REM':lambda a,b:a%b,'LOGAND':lambda a,b:a&b,
   'STRCASE':lambda x,lower=None:x.lower() if truth(lower) else x.upper(),'STRCAT':lambda *a:''.join(a),
   'STRLEN':len,'SUBSTR':lambda s,start,length=None:s[start-1:] if length is None else s[start-1:start-1+length],
   'VL-STRING-SEARCH':lambda q,s:(s.index(q) if q in s else None),
   'VL-STRING-TRANSLATE':lambda fr,to,s:s.translate(str.maketrans(fr,to)),
   'VL-STRING-TRIM':lambda chars,s:s.strip(chars),'VL-STRING-RIGHT-TRIM':lambda chars,s:s.rstrip(chars),
   'VL-STRING-LEFT-TRIM':lambda chars,s:s.lstrip(chars),'VL-STRING->LIST':lambda s:list(map(ord,s)),'CHR':lambda n:chr(n),
   'ITOA':lambda x:str(int(x)),'ATOI':lambda s:int(s) if s.strip() else 0,'ATOF':lambda s:float(re.match(r'[-+]?\d*\.?\d+',s)[0]),
   'RTOS':lambda x,mode,precision:format(x,f'.{precision}f'),'DISTOF':distof,'MEMBER':member,'ASSOC':assoc,
   'REVERSE':lambda x:list(reversed(x or [])) or None,'APPEND':lambda *a:sum([v or [] for v in a],[]) or None,
   'SUBST':lambda new,old,seq:[new if equal(x,old) else x for x in seq],
   'VL-CATCH-ALL-ERROR-P':lambda x:boolean(isinstance(x,Error)),
   'VL-CATCH-ALL-ERROR-MESSAGE':lambda x:x.message,
   'GET_TILE':lambda k:self.tiles.get(k,''),'SET_TILE':lambda k,v:self.tiles.__setitem__(k,v) or v,
   'MODE_TILE':lambda k,v:None,'DONE_DIALOG':done,'PRINC':princ,'ALERT':lambda s:self.output.append(s),
   'VLAX-TMATRIX':lambda x:x,'TRANS':lambda point,fr,to,disp=None:point,
   'GETVAR':lambda k: {'MILLISECS':100,'CLAYER':'0','CVPORT':2,'DATE':2461313.5,'ACADVER':'26.0','CMDECHO':1}.get(k),
   'VL-FILENAME-BASE':lambda p:p.replace('\\','/').split('/')[-1].rsplit('.',1)[0],
   'VL-FILENAME-DIRECTORY':lambda p:p.replace('\\','/').rsplit('/',1)[0],
   'VL-FILENAME-EXTENSION':lambda p:('.'+p.rsplit('.',1)[1]) if '.' in p.replace('\\','/').split('/')[-1] else None,
   'OPEN':lambda p,m:io.StringIO('AC1018'),
   'READ-CHAR':lambda f:(lambda ch: ord(ch) if ch else None)(f.read(1)),
   'READ-LINE':lambda f:(lambda line: line.rstrip('\n') if line else None)(f.readline()),
   'CLOSE':lambda f:f.close(),
  }
  self.env['PI']=math.pi
 def quote(self,x):
  if isinstance(x,Symbol):
   if x.upper()=='NIL':return None
   if x.upper()=='T':return True
   if re.fullmatch(r'[-+]?\d+',x):return int(x)
   if re.fullmatch(r'[-+]?(?:\d+\.?\d*|\d*\.\d+)(?:[Ee][-+]?\d+)?',x):return float(x)
   return x
  if isinstance(x,list):
   if len(x)==3 and isinstance(x[1],Symbol) and x[1]=='.':return Pair(self.quote(x[0]),self.quote(x[2]))
   return [self.quote(v) for v in x] or None
  return str(x) if isinstance(x,String) else x
 def load(self,text):
  self.forms=read_forms(text)
  for f in self.forms:
   if f and isinstance(f,list) and str(f[0]).upper()=='DEFUN':self.func[str(f[1]).upper()]=(f[2],f[3:])
 def eval(self,x,env=None):
  env=env or self.env
  if isinstance(x,Symbol):
   q=self.quote(x)
   return env.getv(q.upper()) if isinstance(q,Symbol) else q
  if not isinstance(x,list):return str(x) if isinstance(x,String) else x
  if not x:return None
  op=str(x[0]).upper();args=x[1:]
  if op=='QUOTE':return self.quote(args[0])
  if op=='SETQ':
   val=None
   for k,v in zip(args[::2],args[1::2]):val=env.setv(str(k).upper(),self.eval(v,env))
   return val
  if op=='IF':return self.eval(args[1],env) if truth(self.eval(args[0],env)) else (self.eval(args[2],env) if len(args)>2 else None)
  if op=='PROGN':
   val=None
   for a in args:val=self.eval(a,env)
   return val
  if op=='COND':
   for clause in args:
    v=self.eval(clause[0],env)
    if truth(v):
     for a in clause[1:]:v=self.eval(a,env)
     return v
   return None
  if op in ('AND','OR'):
   for a in args:
    v=self.eval(a,env)
    if op=='AND' and not truth(v):return None
    if op=='OR' and truth(v):return True
   return True if op=='AND' else None
  if op=='FOREACH':
   v=None
   for item in self.eval(args[1],env) or []:
    env.setv(str(args[0]).upper(),item)
    for a in args[2:]:v=self.eval(a,env)
   return v
  if op=='WHILE':
   v=None;steps=0
   while truth(self.eval(args[0],env)):
    steps+=1
    if steps>100000:raise RuntimeError('model loop cap')
    for a in args[1:]:v=self.eval(a,env)
   return v
  if op=='REPEAT':
   v=None
   for _ in range(self.eval(args[0],env)):
    for a in args[1:]:v=self.eval(a,env)
   return v
  return self.call(op,[self.eval(a,env) for a in args],env)
 def call(self,name,args=None,env=None):
  if args is None:args=[]
  if env is None:env=self.env
  if isinstance(name,list) and str(name[0]).upper()=='LAMBDA':params,body=name[1],name[2:]
  else:
   name=str(name).upper()
   if name=='VL-CATCH-ALL-APPLY':
    try:return self.call(args[0],args[1] or [],env)
    except Exception as e:return Error(e)
   if name=='MAPCAR':return [self.call(args[0],list(a),env) for a in zip(*[s or [] for s in args[1:]])] or None
   if name=='VL-SORT':
    fn=args[1]
    def cmp(a,b):return -1 if truth(self.call(fn,[a,b],env)) else (1 if truth(self.call(fn,[b,a],env)) else 0)
    return sorted(args[0] or [],key=functools.cmp_to_key(cmp)) or None
   if name=='READ':return self.quote(read_forms(args[0])[0])
   if name in self.api:return self.api[name](*args)
   if name not in self.func:raise NotImplementedError(name)
   params,body=self.func[name]
  params=[str(k).upper() for k in params or []];sep=params.index('/') if '/' in params else len(params)
  if len(args)!=sep:raise ValueError(f'{name} arity: {len(args)} != {sep}')
  child=Env(env)
  for k in params:
   if k!='/':child[k]=None
  for k,v in zip(params[:sep],args):child[k]=v
  v=None
  for a in body:v=self.eval(a,child)
  return v
