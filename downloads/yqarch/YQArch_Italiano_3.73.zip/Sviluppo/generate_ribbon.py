"""Build only the additive 3.73 Ribbon from the pinned 3.70 XML and BMP parts.
No downloaded code. Does not change any LSP/installer or Autodesk workspace.
Run again after editing ribbon_additions.json only if the new layout is intended.
Normal packaging uses the already-validated CUIx from the payload.
"""
from pathlib import Path
import copy,json,zipfile,xml.etree.ElementTree as E
from rebuild_ribbon import load_parts
from ribbon_contract import check_layout
HERE=Path(__file__).resolve().parent

def generate(path: Path) -> None:
    parts=load_parts(path)
    root=E.fromstring((HERE/'ribbon_370_reference.xml').read_bytes())
    mg=E.fromstring((HERE/'macros_370_reference.xml').read_bytes())
    mm={m.get('UID'):m.find('Macro') for m in mg.iter('MenuMacro')}
    panels={p.get('UID'):p for p in root.iter('RibbonPanelSource')}
    additions=json.loads((HERE/'ribbon_additions.json').read_text('utf8'))
    for rec in additions:
        source=next(b for b in root.iter('RibbonCommandButton') if b.get('MenuMacroID')==rec['macro_id'])
        button=copy.deepcopy(source)
        for key,value in [('UID',rec['button_uid']),('Text',''),('ButtonStyle','SmallWithoutText'),('KeyTip',''),('SmallImage',rec['small_image']),('LargeImage',rec['large_image'])]:button.set(key,value)
        row=panels[rec['panel_uid']].findall('RibbonRow')[rec['row']-1]
        row.append(button)
        mm[rec['macro_id']].find('HelpString').text=rec['function']
    parts['RibbonRoot.cui']=E.tostring(root,encoding='utf-8',xml_declaration=True)
    parts['MenuGroup.cui']=E.tostring(mg,encoding='utf-8',xml_declaration=True)
    errors=check_layout(parts)
    if errors:raise ValueError('; '.join(errors))
    # Use exact serialization name and deterministic ZIP metadata.
    parts['RibbonRoot.cui']=E.tostring(root,encoding='utf-8',xml_declaration=True)
    parts['MenuGroup.cui']=E.tostring(mg,encoding='utf-8',xml_declaration=True)
    tmp=path.with_suffix('.cuix.part')
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for n,raw in sorted(parts.items()):
                zi=zipfile.ZipInfo(n,(2026,10,1,0,0,0));zi.external_attr=0o100644<<16
                z.writestr(zi,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        errors=check_layout(load_parts(tmp))
        if errors:raise ValueError('; '.join(errors))
        tmp.replace(path)
    finally:
        if tmp.exists():tmp.unlink()

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('cuix',type=Path);a=p.parse_args()
    generate(a.cuix)
