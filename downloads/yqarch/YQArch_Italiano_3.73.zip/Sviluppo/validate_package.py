"""Independent final-byte packaging checks. Does not execute Windows or AutoCAD.
Example: python validate_package.py --baseline original-3.71.exe --exe new.exe
 --zip new.zip --extract /new/empty/folder --report /outside/package_tests.json
"""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,struct,zipfile,io,xml.etree.ElementTree as E,sys
from rebuild_ribbon import load_parts,check_relationships
D=Path(__file__).resolve().parent.parent
P=argparse.ArgumentParser();P.add_argument('--baseline',type=Path,required=True);P.add_argument('--exe',type=Path,required=True);P.add_argument('--zip',type=Path,required=True);P.add_argument('--extract',type=Path,required=True);P.add_argument('--report',type=Path,required=True);a=P.parse_args()
R=[]
def check(name,ok,details=''):
 R.append({'test':name,'status':'PASS' if ok else 'FAIL','details':details});print(R[-1]['status'],name)
def h(raw):return hashlib.sha256(raw).hexdigest()
base=a.baseline.read_bytes();exe=a.exe.read_bytes();plain=a.zip.read_bytes()
check('Baseline EXE 3.71 originale',h(base)=='b2362f9f20c7dd5b3f83eecc0eed085cc595ee8455d7d1e366c6beadeb7095dd')
check('EXE presente e dimensione coerente',len(exe)==20211200)
pe=struct.unpack_from('<I',exe,0x3c)[0]
check('Intestazione PE32+ x64',exe[:2]==b'MZ' and exe[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',exe,pe+4)[0]==0x8664 and struct.unpack_from('<H',exe,pe+24)[0]==0x20b)
old_e=base.rfind(b'PK\x05\x06');new_e=exe.rfind(b'PK\x05\x06');f=struct.unpack_from('<4s4H2LH',base,old_e);start=old_e-f[5]-f[6];end=old_e+22+f[-1]
check('EOCD e allocazione launcher preservati',new_e==old_e and (start,end)==(1033568,19354782))
check('Coda nativa identica',exe[end:]==base[end:])
a0=base.index(b'\xef\xbb\xbfparam(');b0=base.index(b'\0',a0);script=(D/'Sviluppo/installer_373.ps1').read_bytes();old=b'YQArch Italiano 3.71 - Errore avvio';loc=base.index(old)
check('Script installer completo senza troncamento',exe[a0:a0+len(script)]==script and len(script)+2<=b0-a0)
check('Titolo launcher3.73',exe[loc:loc+len(old)]==old.replace(b'3.71',b'3.73'))
dif=[i for i in range(start) if exe[i]!=base[i]]
check('Modifiche prefisso limitate a script e titolo',all(a0<=i<b0 or loc<=i<loc+len(old) for i in dif))
with zipfile.ZipFile(io.BytesIO(exe[:end])) as ez,zipfile.ZipFile(io.BytesIO(plain)) as pz:
 check('CRC completo vero EXE',ez.testzip() is None)
 check('CRC completo ZIP',pz.testzip() is None)
 names=ez.namelist();pn=pz.namelist();check('Stessi percorsi EXE eZIP',names==pn)
 check('Nessun duplicato case insensitive',len(names)==len(set(n.casefold() for n in names)))
 check('Nessun percorso assoluto o risalita',all(not n.startswith('/') and '..' not in PurePosixPath(n).parts and ':' not in n and '\\' not in n for n in names))
 check('Nessun temporaneo o pycache distribuito',all('__pycache__' not in n and not n.endswith(('.pyc','.part','.tmp','.bak')) for n in names))
 check('File EXE eZIP byte-identici',all(ez.read(n)==pz.read(n) for n in names))
 expected={p.relative_to(D).as_posix():p for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 check('Copertura esatta directory build',set(names)==set(expected))
 check('Ogni file identico alla build',all(ez.read(n)==expected[n].read_bytes() for n in names))
 manifest=json.loads(ez.read('MANIFEST_SHA256.json'));md={r['path']:r for r in manifest}
 check('Manifest completo senza duplicati',len(md)==len(manifest) and set(md)==set(names)-{'MANIFEST_SHA256.json'})
 check('Manifest tutte dimensioni eSHA',all(len(ez.read(n))==m['size'] and h(ez.read(n))==m['sha256'] for n,m in md.items()))
 if a.extract.exists() and any(a.extract.iterdir()):raise SystemExit('Usare cartella di estrazione vuota, non verranno sovrascritti file.')
 a.extract.mkdir(parents=True,exist_ok=True);ez.extractall(a.extract)
 check('Riestrazione completa byte per byte',all((a.extract/n).read_bytes()==ez.read(n) for n in names))
 sysdir=a.extract/'YQArchItaliano/sys'
 check('Versione realmente estratta3.73',(sysdir/'YQArchItaliano.version').read_text().strip()=='3.73')
 parts=load_parts(sysdir/'YQArchItaliano_Ribbon_372.cuix');missing,edges=check_relationships(parts)
 check('CUIx estratto tutte933 relazioni risolte',not missing and len(edges)==933)
 from ribbon_contract import check_layout
 check('Ribbon estratta: ID stabili, 10 pannelli, 3 grandi e 10 piccole',not check_layout(parts),repr(check_layout(parts)))
 cat=json.loads((sysdir/'YQArchItaliano_Catalogo_372.json').read_text())
 check('Catalogo estratto195 DWG originali',len(cat)==195 and all(h((sysdir/'blocks'/r['path']).read_bytes())==r['sha256'] for r in cat))
 check('Catalogo estratto195 SLD',all((sysdir/'blocks'/r['preview']).is_file() for r in cat))
 headers=[(sysdir/'blocks'/r['path']).read_bytes()[:6].decode('ascii','replace') for r in cat]
 from collections import Counter
 hc=Counter(headers)
 check('Formati DWG catalogo noti e conteggi attesi',hc=={'AC1009':16,'AC1014':2,'AC1018':129,'AC1021':48},repr(dict(hc)))
 dcl=(sysdir/'YQArchItaliano_Library_372.dcl').read_text();lsp=(sysdir/'YQArchItaliano_Library_372.lsp').read_text()
 check('Controllo preventivo DWG legacy incluso','(defun yql72-dwg-compatible-p' in lsp and 'AC1021' in lsp and 'richiede ' in lsp and 'yql72-dwg-min-label' in lsp)
 check('Percorso punto-creazione-verifica e ritorno risultato', 'key="blocks"; allow_accept=true;' in dcl and 'PUNTO_ACQUISITO' in lsp and 'VERIFICA_ENTITA' in lsp and '\n *yql72-committed*)' in lsp)
 check('Riapertura soltanto opt-in dopo esito positivo', '(setq running (and inserted (= "1"' in lsp and '(yql72-get "opzione|repeat"' not in lsp)
 check('Moduli Alberature estratti',all((sysdir/f'YQArchItaliano_Trees_372.{e}').is_file() for e in ('lsp','dcl')))
 # The self-extractor reads the payload in its original fixed allocation window.
 with zipfile.ZipFile(io.BytesIO(exe[start:end])) as oldreader:
  check('Compatibilita finestra ZIP del launcher',oldreader.namelist()==names and oldreader.testzip() is None)
report={'checks':R,'files':len(names),'manifest_records':len(manifest),'exe':{'size':len(exe),'sha256':h(exe)},'zip':{'size':len(plain),'sha256':h(plain)},'limitations':'No esecuzione Windows/AutoCAD. PE non significa firma Authenticode.'}
a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('TOTAL',len(R),'FAIL',sum(r['status']=='FAIL' for r in R))
if any(r['status']=='FAIL' for r in R):sys.exit(1)
