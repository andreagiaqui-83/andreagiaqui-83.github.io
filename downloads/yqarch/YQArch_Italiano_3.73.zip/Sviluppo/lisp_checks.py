"""Small structural reader, NOT an AutoLISP evaluator or Autodesk compiler."""
import re
class Symbol(str):pass
class String(str):pass
def read_forms(text):
 pos=0;n=len(text)
 def skip():
  nonlocal pos
  while pos<n:
   if text[pos].isspace():pos+=1
   elif text.startswith(';|',pos):
    q=text.find('|;',pos+2)
    if q<0:raise ValueError('unterminated block comment')
    pos=q+2
   elif text[pos]==';':
    q=text.find('\n',pos);pos=n if q<0 else q+1
   else:break
 def read():
  nonlocal pos
  skip()
  if pos>=n:raise ValueError('unexpected EOF')
  c=text[pos];pos+=1
  if c=='(':
   out=[]
   while True:
    skip()
    if pos>=n:raise ValueError('unclosed list')
    if text[pos]==')':pos+=1;return out
    out.append(read())
  if c==')':raise ValueError('unexpected closing parenthesis')
  if c=="'":return [Symbol('quote'),read()]
  if c=='"':
   out=''
   while pos<n:
    q=text[pos];pos+=1
    if q=='"':return String(out)
    if q=='\\':
     if pos>=n:raise ValueError('unclosed escape')
     q=text[pos];pos+=1;out+=dict(n='\n',r='\r',t='\t').get(q,q)
    else:out+=q
   raise ValueError('unclosed string')
  start=pos-1
  while pos<n and not text[pos].isspace() and text[pos] not in '();\'"':pos+=1
  token=text[start:pos]
  if re.fullmatch(r'[-+]?\.\d+(?:e[-+]?\d+)?',token,re.I):raise ValueError('numeric token without leading zero: '+token)
  return Symbol(token)
 result=[]
 while True:
  skip()
  if pos>=n:return result
  result.append(read())
def walk(forms):
 for f in forms:
  if isinstance(f,list):
   yield f
   yield from walk(f)
def validate(forms):
 errors=[]
 for f in walk(forms):
  if not f or not isinstance(f[0],Symbol):continue
  name=f[0].upper()
  if name=='DEFUN' and len(f)>=3 and isinstance(f[2],list):
   if any(str(s).upper() in ('T','NIL') for s in f[2]):errors.append('reserved parameter in '+str(f[1]))
  if name=='LAMBDA' and len(f)>1 and isinstance(f[1],list):
   if any(str(s).upper() in ('T','NIL') for s in f[1]):errors.append('reserved lambda parameter')
  if name=='IF' and not 3<=len(f)<=4:errors.append('IF arity '+str(len(f)))
  if name=='SETQ' and (len(f)%2!=1):errors.append('SETQ arity '+str(len(f)))
  if name=='ACTION_TILE' and len(f)>=3 and isinstance(f[2],String):
   try:read_forms(f[2])
   except ValueError as e:errors.append('callback: '+str(e))
 return errors
