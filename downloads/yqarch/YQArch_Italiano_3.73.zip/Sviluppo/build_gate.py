"""Mandatory, standard-library-only checks before packaging. NOT AutoCAD validation."""
from pathlib import Path
from ribbon_contract import check_layout
from rebuild_ribbon import load_parts
from lisp_checks import read_forms,validate
from preservation_contract import check_runtime

def verify_critical_runtime(root: Path) -> None:
    sysdir=root/'YQArchItaliano/sys'
    problems=check_layout(load_parts(sysdir/'YQArchItaliano_Ribbon_372.cuix'))
    for path in sysdir.rglob('*'):
        if path.suffix.lower() not in ('.lsp','.mnl'):continue
        raw=path.read_bytes()
        try:text=raw.decode('utf8')
        except UnicodeDecodeError:text=raw.decode('cp1252')
        problems.extend(path.name+': '+e for e in validate(read_forms(text)))
    lib=(sysdir/'YQArchItaliano_Library_372.lsp').read_text('ascii')
    forms={str(f[1]).upper():f for f in read_forms(lib)
           if isinstance(f,list) and len(f)>2 and str(f[0]).upper()=='DEFUN'}
    insertion=forms.get('YQL72-INSERT',[])
    if not insertion or str(insertion[-1]).upper()!='*YQL72-COMMITTED*':
        problems.append('Il chiamante deve ricevere il commit: non terminare INSERT con PRINC.')
    if '(setq running (and inserted (= "1" (yql72-get "opzione|reopen-success" "0"))))' not in lib:
        problems.append('Manca il vincolo riapertura solo dopo commit e consenso.')
    if '(yql72-get "opzione|repeat"' in lib:
        problems.append('Il vecchio repeat automatico non deve riattivare il catalogo.')
    problems.extend(check_runtime(root))
    if problems:
        raise ValueError('Build sospesa dal controllo anti-regressione: '+'; '.join(problems))
