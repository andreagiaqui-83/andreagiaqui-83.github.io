"""New tests replay regression mutations against the real CUIx, not just counts."""
import copy,json,unittest,xml.etree.ElementTree as E
from pathlib import Path
from rebuild_ribbon import load_parts
from ribbon_contract import check_layout
from preservation_contract import check_preservation,check_runtime,normalize_runtime
D=Path(__file__).resolve().parent.parent
class AdditiveRibbonTests(unittest.TestCase):
 def setUp(self):
  self.parts=load_parts(D/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix')
  self.ref=json.loads((D/'Sviluppo/ribbon_additions.json').read_text('utf8'))
 def alter(self,fn):
  root=E.fromstring(self.parts['RibbonRoot.cui']);fn(root);self.parts['RibbonRoot.cui']=E.tostring(root)
 def test_full_ribbon_preserves_originals_and_adds_exactly_forty(self):self.assertEqual(check_preservation(self.parts),[])
 def test_every_panel_has_three_large_ten_small(self):
  r=E.fromstring(self.parts['RibbonRoot.cui'])
  self.assertEqual([[len(row.findall('RibbonCommandButton')) for row in p.findall('RibbonRow')[:3]] for p in r.iter('RibbonPanelSource')],[[3,5,5]]*10)
 def test_40_distinct_added_routes_and_own_icons(self):
  self.assertEqual(len(self.ref),40);self.assertEqual(len({r['button_uid'] for r in self.ref}),40)
  self.assertTrue(all(r['small_image'] in self.parts and r['large_image'] in self.parts for r in self.ref))
 def test_existing_button_cannot_be_replaced_even_if_counts_match(self):
  self.alter(lambda r:next(r.iter('RibbonCommandButton')).set('MenuMacroID','YQIT_MACRO_0023'))
  self.assertIn('baseline 90 buttons and expanded routes unchanged',check_preservation(self.parts))
 def test_existing_button_cannot_be_moved(self):
  def move(r):
   row=next(r.iter('RibbonRow'));b=row.find('RibbonCommandButton');row.remove(b);row.append(b)
  self.alter(move);self.assertIn('baseline 90 buttons and expanded routes unchanged',check_preservation(self.parts))
 def test_new_buttons_cannot_move_to_different_slots(self):
  def move(r):
   row=list(r.iter('RibbonPanelSource'))[0].findall('RibbonRow')[1];b=row.findall('RibbonCommandButton')[-1];row.remove(b);row.insert(1,b)
  self.alter(move);self.assertIn('added icon slot',check_preservation(self.parts))
 def test_new_button_cannot_change_command(self):
  self.alter(lambda r:next(b for b in r.iter('RibbonCommandButton') if '_EXTRA_' in b.get('UID','')).set('MenuMacroID','YQIT_MACRO_0001'))
  self.assertIn('added icon macro',check_preservation(self.parts))
 def test_new_button_cannot_lose_icon(self):
  self.alter(lambda r:next(b for b in r.iter('RibbonCommandButton') if '_EXTRA_' in b.get('UID','')).set('SmallImage','unknown.bmp'))
  self.assertIn('added icon resource',check_preservation(self.parts))
 def test_missing_added_button_detected(self):
  def remove(r):
   row=list(r.iter('RibbonPanelSource'))[0].findall('RibbonRow')[1];row.remove(row.findall('RibbonCommandButton')[-1])
  self.alter(remove);self.assertIn('all 40 planned additions',check_preservation(self.parts))
 def test_all_operation_macros_unchanged(self):
  r=E.fromstring(self.parts['MenuGroup.cui']);old=E.fromstring((D/'Sviluppo/macros_370_reference.xml').read_bytes())
  macro=lambda t:{m.get('UID'):m.findtext('Macro/Command') for m in t.iter('MenuMacro')}
  self.assertEqual(macro(r),macro(old))
 def test_command_mutation_detected_even_with_nonempty_tooltip(self):
  r=E.fromstring(self.parts['MenuGroup.cui']);r.find('.//Command').text='^c^c_ERASE';self.parts['MenuGroup.cui']=E.tostring(r)
  self.assertIn('macro definitions unchanged apart from allowed help',check_preservation(self.parts))
 def test_blank_new_tooltip_is_detected(self):
  mid=self.ref[0]['macro_id'];r=E.fromstring(self.parts['MenuGroup.cui']);next(m for m in r.iter('MenuMacro') if m.get('UID')==mid).find('Macro/HelpString').text='';self.parts['MenuGroup.cui']=E.tostring(r)
  self.assertIn('new icon tooltip description',check_preservation(self.parts))
 def test_bmp_change_is_rejected_even_with_valid_relationships(self):
  n=next(n for n in self.parts if n.endswith('.bmp'));self.parts[n]=self.parts[n][:-1]+bytes([self.parts[n][-1]^1])
  self.assertIn('baseline BMP and OPC container bytes unchanged',check_preservation(self.parts))
 def test_installed_runtime_preserves_370_behaviors(self):self.assertEqual(check_runtime(D),[])
 def test_new_uid_suffix_does_not_rewrite_stable_367_identity(self):self.assertEqual(normalize_runtime(b'YQIT_TAB_367 YQIT367_PANEL_01'),b'YQIT_TAB_367 YQIT367_PANEL_01')
 def test_regenerate_actual_cuix_identically(self):
  import tempfile,shutil
  from generate_ribbon import generate
  original=D/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix'
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'ribbon.cuix';shutil.copy2(original,target);generate(target)
   self.assertEqual(target.read_bytes(),original.read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
