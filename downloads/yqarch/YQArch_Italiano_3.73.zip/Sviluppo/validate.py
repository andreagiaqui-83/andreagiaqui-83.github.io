"""Static regression audit. NOT AutoCAD, an Autodesk schema validator or compiler."""
from pathlib import Path
import argparse,json,hashlib,re,io,sys,xml.etree.ElementTree as E
from PIL import Image
from bs4 import BeautifulSoup
from lisp_checks import read_forms,validate,walk,String
from rebuild_ribbon import load_parts,check_relationships
from ribbon_contract import check_layout,TAB,PANEL_IDS
from slide_reader import read_slide
D=Path(__file__).resolve().parent.parent;S=D/'YQArchItaliano/sys'
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--ribbon-baseline',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args();B=a.baseline/'YQArchItaliano/sys';checks=[]
def test(name,ok,detail=''):
 checks.append({'test':name,'status':'PASS' if ok else 'FAIL','detail':detail});print(checks[-1]['status'],name,detail if not ok else '')
def h(x):return hashlib.sha256(x).hexdigest()
def norm(s):
 for x,y in [('3.73','3.71'),('_372','_371'),('-372','-371'),('yqit372','yqit371'),('YQIT372','YQIT371'),('YQL72','YQL71'),('yql72','yql71'),('YQR72','YQR71'),('yqr72','yqr71'),('YQT72','YQT71'),('yqt72','yqt71')]:s=s.replace(x,y)
 return s
for name in ('yqarch.vlx','yqarch.slb','yqarch.dll','gyqarch.dll','YQArch_Sostegno_Originale.html','YQArch_Sostegno_Italiano.html'):
 test('Preservato '+name,(S/name).read_bytes()==(B/name).read_bytes())
orig=[p for p in B.rglob('*') if p.is_file() and p.suffix.lower() in ('.dwg','.sld','.slb','.dll','.shx')]
test('Tutti gli asset originali binari preservati',all((S/str(p.relative_to(B)).replace('_371','_372')).read_bytes()==p.read_bytes() for p in orig),str(len(orig)))
reg=(S/'YQArchItaliano_Command_Registry_372.txt').read_bytes()
test('Registro originale byte-identico',reg==(B/'YQArchItaliano_Command_Registry_371.txt').read_bytes())
cmds=[x.decode().strip() for x in reg.splitlines() if x.startswith(b'YQ')]
test('646 nomi registro univoci',len(cmds)==646 and len(set(cmds))==646)
test('Versione reale 3.73',(S/'YQArchItaliano.version').read_text().strip()=='3.73')
issues=[];texts=[]
for f in S.rglob('*'):
 if f.suffix.lower() in ('.lsp','.mnl'):
  raw=f.read_bytes()
  try:t=raw.decode('utf8')
  except UnicodeDecodeError:t=raw.decode('cp1252')
  texts.append(t)
  try:issues.extend([(str(f),e) for e in validate(read_forms(t))])
  except Exception as e:issues.append((str(f),str(e)))
test('Tutti LSP/MNL e callback: struttura e arita IF/SETQ',not issues,repr(issues[:8]))
test('Nessun riferimento attivo 370 nei moduli LSP/MNL',not any(re.search(r'(?i)(?:_370|\b3\.70|yql70|yqr70)',t) for t in texts))
for tag in ('Library','Trees','Ribbon'):
 for ext in ('lsp','mnl') if tag=='Ribbon' else ('lsp','dcl'):
  f=f'{tag}_372.{ext}';test('Sorgente e runtime uguali: '+f,(D/'Sviluppo'/f).read_bytes()==(S/('YQArchItaliano_'+f)).read_bytes())
for f in ['YQArchItaliano_Bootstrap.lsp','YQArchItaliano_Menu.lsp','YQArchItaliano_Runtime.lsp','YQArchItaliano_Trees_372.lsp','YQArchItaliano_Trees_372.dcl','YQArchItaliano_Menu_372.mnu']:
 test('Logica non interessata preservata: '+f,norm((S/f).read_bytes().decode('latin1'))==(B/norm(f)).read_bytes().decode('latin1'))
lib=(S/'YQArchItaliano_Library_372.lsp').read_text('ascii');dcl=(S/'YQArchItaliano_Library_372.dcl').read_text('ascii')
fn=lambda forms:{str(f[1]).upper():f for f in forms if isinstance(f,list) and len(f)>2 and str(f[0]).upper()=='DEFUN'}
bf=fn(read_forms((B/'YQArchItaliano_Library_371.lsp').read_text()));nf=fn(read_forms(norm(lib)))
for name in ('UCS-MATRIX','SAVE','READ-STATE','BUILTINS','INDEX-PART','ADVANCED','BLOCK-SELECTED','QUERY-CHANGED','ACCEPT'):
 test('Funzione catalogo non interessata: '+name,bf['YQL71-'+name]==nf['YQL71-'+name])
test('Doppio clic nativo e un solo pulsante predefinito','key="blocks"; allow_accept=true; multiple_select=false;' in dcl and dcl.split('yql72_folder')[0].count('is_default=true')==1)
test('Nessun punto o inserimento nel callback DCL',all(not any(str(k[0]).upper() in ('GETPOINT','VLA-INSERTBLOCK','YQL71-INSERT') for k in walk([nf['YQL71-'+name]]) if k) for name in ('ACCEPT','ACCEPT-VALUES','BLOCK-SELECTED')))
test('Nuova riapertura facoltativa distinta dalla preferenza precedente','(yql72-get "opzione|reopen-success" "0")' in lib and '(yql72-get "opzione|repeat"' not in lib)
test('Commit necessario prima della riapertura','(setq running (and inserted (= "1"' in lib)
test('Esito inserimento non perso in PRINC',str(nf['YQL71-INSERT'][-1]).upper()=='*YQL71-COMMITTED*')
test('Punto seguito da creazione e verifica','PUNTO_ACQUISITO' in lib and 'VERIFICA_ENTITA' in lib and '(entget entity)' in lib)
test('Aggiornamento grafico prima di riapertura','(foreach obj objects (vla-Update obj))' in lib and "'vla-Regen (list doc 0)" in lib)
test('Diagnostica ultimo inserimento disponibile','(defun c:YQIT_VERIFICA_INSERIMENTO' in lib)
test('Identita interna catalogo stabile tra bootstrap e libreria','*YQLIB371-LOADED*' in lib and '*YQLIB371-LOADED*' in (S/'YQArchItaliano_Bootstrap.lsp').read_text())
keys=set(re.findall(r'key\s*=\s*"([^"\n]+)"',dcl));used=[]
for f in walk(read_forms(lib)):
 if f and str(f[0]).upper() in ('ACTION_TILE','GET_TILE','SET_TILE','MODE_TILE','START_IMAGE','DIMX_TILE','DIMY_TILE') and len(f)>1 and isinstance(f[1],String):used.append(str(f[1]))
test('Chiavi DCL riferite esistenti',set(used)<=keys,repr(set(used)-keys))
test('DCL proprieta tecniche e delimitatori',dcl.count('{')==dcl.count('}') and 'fisso_' not in dcl)
cat=json.loads((S/'YQArchItaliano_Catalogo_372.json').read_text());oldcat=json.loads((B/'YQArchItaliano_Catalogo_371.json').read_text())
test('Catalogo invariato salvo percorso release',norm(json.dumps(cat,sort_keys=True))==json.dumps(oldcat,sort_keys=True))
test('195 schede in 17 categorie',len(cat)==195 and len({r['id'] for r in cat})==195 and len({r['category_it'] for r in cat})==17)
test('195 DWG accessibili con SHA originale',all(h((S/'blocks'/r['path']).read_bytes())==r['sha256'] for r in cat))
from collections import Counter
headers=Counter((S/'blocks'/r['path']).read_bytes()[:6].decode('ascii','replace') for r in cat)
test('Formati DWG catalogo: 147 legacy 2004 e 48 AutoCAD 2007',headers=={'AC1009':16,'AC1014':2,'AC1018':129,'AC1021':48},repr(dict(headers)))
test('Precheck DWG impedisce inserimenti incompatibili','(defun yql72-dwg-compatible-p' in lib and 'AC1021' in lib and '(yql72-dwg-compatible-p path)' in lib)
valid=[]
for r in cat:
 try:w,height,lines,fills=read_slide((S/'blocks'/r['preview']).read_bytes());valid.append(w>0 and height>0 and bool(lines or fills))
 except Exception:valid.append(False)
test('195 anteprime SLD presenti, leggibili e non vuote',len(valid)==195 and all(valid))
parts=load_parts(S/'YQArchItaliano_Ribbon_372.cuix');old=load_parts(B/'YQArchItaliano_Ribbon_371.cuix')
test('Contratto Ribbon stabili ID, righe, immagini, conteggi',not check_layout(parts),repr(check_layout(parts)))
root=E.fromstring(parts['RibbonRoot.cui']);mg=E.fromstring(parts['MenuGroup.cui']);om=E.fromstring(old['MenuGroup.cui'])
mac=lambda r:{m.get('UID'):m.findtext('Macro/Command') for m in r.iter('MenuMacro')}
test('Macro operative Ribbon conservate',mac(mg)==mac(om))
missing,edges=check_relationships(parts);test('Tutte 933 relazioni risolte',not missing and len(edges)==933)
imgs=[n for n in parts if n.endswith('.bmp')]
test('916 icone BMP decodificabili nelle dimensioni originali',len(imgs)==916 and all(Image.open(io.BytesIO(parts[n])).size in ((16,16),(17,16),(32,32)) for n in imgs))
test('Nessuna immagine fuori dai collegamenti OPC',set(imgs)=={n for _,k,n in edges if k=='Image'})
test('OPC senza prefissi namespace convertiti','xmlns=' in parts['[Content_Types].xml'].decode() and b'ns0:' not in parts['[Content_Types].xml'])
info=E.fromstring(parts['Menu_Package_Info.xml']);test('Indice parti coerente',{r.get('PartData_Name').lstrip('/') for r in info}==set(parts)-{'Menu_Package_Info.xml','[Content_Types].xml','_rels/.rels'})
if a.ribbon_baseline:
 reference=load_parts(a.ribbon_baseline)
 test('BMP uguali al pacchetto 3.67 visibile',all(parts[n]==reference[n] for n in imgs))
 test('Parti contenitore 3.67 preservate',all(parts[n]==reference[n] for n in parts if n not in ('RibbonRoot.cui','MenuGroup.cui')))
loader=(S/'YQArchItaliano_Ribbon_372.lsp').read_text('ascii')
test('Gruppo proprio e protezione CUI principale','YQARCHITALIANO_RIBBON' in loader and '(= 0 (vla-get-Type group))' in loader)
test('Limite tentativi e contesto applicazione','(< *YQR72-RETRIES* 2)' in loader and 'YQIT-RIBBON-READY-CONTEXT' in loader)
test('MenuGroups non spacciato per prova visiva','non certificano la visibilita' in loader)
script=(D/'Sviluppo/installer_373.ps1').read_bytes();prior=(a.baseline/'Sviluppo/installer_371.ps1').read_bytes()
script_text=script.decode('utf-8-sig')
test('Installer preserva backup/journal/rollback',all(x in script_text for x in ('Backup','Journal','Restore-Journal')))
test('Installer evita doppio hash sui file invariati', '$script:VerifiedUnchanged[$dst]=$true' in script_text and '$script:VerifiedUnchanged.ContainsKey($dst)' in script_text)
test('Installer ripulisce cache runtime YQArch 3.63-3.72','363..372' in script_text and "YQArchItaliano_Menu_" in script_text)
test('Installer senza residuo cartella temporanea 3.69','YQArchItaliano369_UI_' not in script_text)
test('Installer senza collisione PowerShell V/v', '$script:V[$dst]' not in script_text and 'foreach($v in 363..372)' not in script_text and '$script:VerifiedUnchanged' in script_text and 'foreach($menuVersion in 363..372)' in script_text)
test('BOM script installer conservato',script.startswith(b'\xef\xbb\xbfparam('))
sec=lambda base:sum((re.findall(r'(?i)\(setvar\s+"(?:SECURELOAD|TRUSTEDPATHS)"',f.read_bytes().decode('latin1')) for f in base.glob('*.lsp')),[])
test('Nessuna nuova scrittura alle impostazioni di sicurezza',sec(S)==sec(B))
guide=BeautifulSoup((S/'YQArch_Italiano_Guida.html').read_text(),'html.parser');ids=[a.get('id','').upper() for a in guide.find_all('article')]
test('Guida 646 schede univoche, registro coperto',len(ids)==646 and len(set(ids))==646 and set(ids)==set(cmds))
libs=['yq_blocks','yq_blockviewer']+[f'yq_blockviewer{i}' for i in range(1,10)]
test('11 schede aggiornate al flusso punto/commit/chiusura',all('YQIT_VERIFICA_INSERIMENTO' in guide.find(id=i).get_text() and 'Il catalogo si chiude' in guide.find(id=i).get_text() for i in libs))
ri=BeautifulSoup((S/'YQArchItaliano_Ribbon_Catalogo.html').read_text(),'html.parser')
test('Indice Ribbon schematico da 130 icone e 10 pannelli',len(ri.find_all('img'))==130 and len(ri.find_all('article'))==10 and 'Non è uno screenshot' in ri.get_text())
test('Documento e readme non certificano tutte le versioni AutoCAD', 'non equivalgono a esecuzione reale' in (D/'README.txt').read_text())
a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
print('TOTAL',len(checks),'FAIL',sum(x['status']=='FAIL' for x in checks))
if any(x['status']=='FAIL' for x in checks):sys.exit(1)
