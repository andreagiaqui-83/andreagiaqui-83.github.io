"""Project regression contract, NOT an Autodesk schema validator.
Keep known-working 3.67 top-level rows, OPC/BMP parts and tab/panel identities.
The identity suffix 367 is historical and must NOT be changed per release.
"""
import xml.etree.ElementTree as E
from rebuild_ribbon import check_relationships
TAB='YQIT_TAB_367'
PANEL_IDS=[f'YQIT367_PANEL_{i:02}' for i in range(1,11)]
STYLES={'LargeWithHorizontalText','LargeWithoutText','LargeWithText','SmallWithoutText','SmallWithText'}
def check_layout(parts):
 errors=[]
 def need(ok,label):
  if not ok:errors.append(label)
 root=E.fromstring(parts['RibbonRoot.cui']);macros=E.fromstring(parts['MenuGroup.cui'])
 need(macros.get('Name')=='YQARCHITALIANO_RIBBON','own group')
 tabs=list(root.iter('RibbonTabSource'));panels=list(root.iter('RibbonPanelSource'))
 need(len(tabs)==1 and tabs[0].get('UID')==TAB,'stable tab identity')
 need([p.get('UID') for p in panels]==PANEL_IDS,'stable panel identities')
 need(not list(root.iter('RibbonRowPanel')),'project flat-row contract')
 for t in tabs:
  need(t.get('DefaultDisplay')=='AddToWorkspace','add tab to workspace')
  need([p.get('PanelId') for p in t.iter('RibbonPanelSourceReference')]==PANEL_IDS,'all ten panels referenced')
 main=[];expanded=[];cats=[]
 for p in panels:
  rows=[];is_expanded=False
  for c in p:
   if c.tag=='RibbonPanelBreak':is_expanded=True;continue
   if c.tag=='RibbonRow':
    if is_expanded:expanded+=list(c.iter('RibbonCommandButton'));cats+=c.findall('RibbonSplitButton')
    else:rows.append(c)
  need(len(rows)==3,'three direct rows in '+p.get('UID',''))
  for i,row in enumerate(rows):
   buttons=row.findall('RibbonCommandButton');main+=buttons
   need(len(buttons)==(3 if i==0 else 5),'3/5/5 direct buttons per row')
   need(all(b.get('ButtonStyle')==('LargeWithoutText' if i==0 else 'SmallWithoutText') and b.get('Text')=='' for b in buttons),'icon-only row styles')
 need(len(main)==130,'130 main buttons')
 need(len(expanded)==547,'547 expanded command routes')
 need(len(cats)==23,'23 expanded categories')
 mm={m.get('UID'):m.find('Macro') for m in macros.iter('MenuMacro')}
 for b in root.iter('RibbonCommandButton'):
  m=mm.get(b.get('MenuMacroID'))
  need(m is not None,'valid macro reference')
  if m is not None:need(bool(m.findtext('Name')) and bool(m.findtext('HelpString')) and bool(m.findtext('Command')),'tooltip and command')
  need(b.get('ButtonStyle') in STYLES,'known button style')
 for e in [*root.iter(),*macros.iter()]:
  for k in ('SmallImage','LargeImage'):
   if e.get(k):need(e.get(k) in parts,'image attribute reference')
  if e.tag in ('SmallImage','LargeImage'):need(e.get('Name') in parts,'macro image reference')
 uids=[e.get('UID') for e in root.iter() if e.get('UID')]
 need(len(uids)==len(set(uids)),'unique UIDs')
 missing,edges=check_relationships(parts);need(not missing and len(edges)==933,'OPC closure')
 need(sum(n.endswith('.bmp') for n in parts)==916 and not any(n.endswith('.png') for n in parts),'consistent BMP package')
 from preservation_contract import check_preservation
 errors.extend(check_preservation(parts))
 return sorted(set(errors))
