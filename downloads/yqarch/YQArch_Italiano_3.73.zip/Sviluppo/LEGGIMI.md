# Ricostruzione 3.73

Il pacchetto contiene i sorgenti nativi e gli asset. Core VLX e launcher PE
sono binari conservati: questa procedura non li ricompila e non firma l'EXE.

```console
python Sviluppo/ricompila.py --baseline /originali/YQArch_Italiano_3.71.exe --out /cartella/esterna
python Sviluppo/validate.py --baseline /baseline_3.71_estratta --report /risultati/statici.json
python -m unittest discover -s Sviluppo -p "test_*.py" -v
```

Hash EXE baseline:
`b2362f9f20c7dd5b3f83eecc0eed085cc595ee8455d7d1e366c6beadeb7095dd`.
La ricompilazione del pacchetto usa solo Python standard. Test grafici degli
asset richiedono Pillow; BeautifulSoup4 analizza la guida; alcuni test di
alberature usano NumPy. Non sono dipendenze del plugin installato.

## Vincoli contro le regressioni

`ribbon_contract.py` conserva ID scheda/pannelli già associati alle aree di
lavoro. Il suffisso interno 367 è STABILE, non va rinumerato con la release.
Righe dirette e BMP originali sono la topologia conservativa scelta in questa
release: il contratto di progetto non pretende di essere lo schema Autodesk.
`rebuild_ribbon.py` controlla gli archivi OPC, non crea il nuovo layout partendo
da una vecchia release. La sorgente XML effettiva è contenuta nel CUIx ZIP.

`test_insertion_flow.py` esegue i corpi Lisp del catalogo fino all'inserimento
usando API simulate. Conta accettazioni, punti, creazioni e riaperture. Non
ridurre i test ai soli callback DCL. Il vecchio repeat non abilita la nuova
opzione reopen-success. Successo significa commit e handle riscontrati.

`validate_package.py` verifica e riestrae i byte dell'EXE. Ripetere i test e
ricostruire da quella cartella per confermare la riproducibilità; non contare
le ripetizioni come nuovi test. Non inserire gli output finali nel payload.

Questi strumenti non sono AutoCAD, un compilatore AutoLISP o il parser WPF.
Il collaudo reale resta necessario. Non affermare che una scheda sia visibile
solo perché MenuGroups contiene il suo gruppo.

## Controlli obbligatori prima del packaging

`ricompila.py` esegue sempre `build_gate.py`: ID/layout/relazioni Ribbon, struttura LSP e vincolo di riapertura dopo commit. Un fallimento arresta la build prima di creare EXE/ZIP. È un controllo di progetto, non un certificato Autodesk.

## Variazione additiva 3.73

La 3.71 è stata confermata dall’utente. Per la Ribbon, gli XML della 3.70 (prima dell’aggiunta dei 40 accessi) e le firme delle
risorse sono conservati in Sviluppo come riferimenti di regressione, non come
moduli caricati da AutoCAD. `ribbon_additions.json` descrive le sole 40 icone
aggiuntive. `generate_ribbon.py` rigenera il CUIx da questi dati e dalle BMP
congelate. La rigenerazione è controllata byte per byte.

`preservation_contract.py` rimuove virtualmente i 40 nuovi pulsanti e verifica
che ritorni esattamente la struttura XML precedente, comprese espansioni,
UID, macro e ordine dei 90 accessi preesistenti. I controlli runtime proteggono la 3.71 e ammettono in 3.73 soltanto le modifiche dichiarate al precheck DWG e all’ottimizzazione hash dell’installer.

La disposizione è 3/5/5 nelle stesse tre righe dirette. Non introdurre
RibbonRowPanel né convertire le BMP in un altro formato per fare spazio.
Non aumentare i numeri dei test dichiarati sommando la ripetizione sulla
cartella estratta. I test con API simulate non sono un collaudo Autodesk.
