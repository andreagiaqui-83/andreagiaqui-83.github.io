"""Whole catalog->point->entity flow using ACTUAL LISP bodies, mocked CAD/DCL.
These tests assert ordering/counts; they do not render dialogs or create a real DWG.
"""
import unittest
import test_catalog
from lisp_model import truth

class FullFlowTests(unittest.TestCase):
 def setUp(self):
  harness=test_catalog.InsertionTests();harness.setUp();self.h=harness;self.l=harness.l;self.calls=harness.calls
  self.dialogs=0;self.points=0;self.allow_second=False;self.cancel_point=False
  self.item=self.l.env['*YQL72-CHOSEN*']
  self.l.env['*YQL72-FILTERED*']=[self.item];self.l.env['*YQL72-LAYERS*']=['Arredi']
  self.l.env['*YQL72-SELECTED*']=0
  self.l.tiles.update(dict(blocks='0',sx='1',sy='1',sz='1',uniform='1',angle='0',px='0',py='0',pz='0',point='0',layer='0',repeat='0'))
  def point(prompt):
   self.points+=1;self.calls.append(('point',[10,20,30]));return None if self.cancel_point else [10,20,30]
  def dialog():
   self.dialogs+=1;self.calls.append(('dialog',self.dialogs))
   if self.dialogs>1:
    if not self.allow_second:raise AssertionError('Second catalog opened without explicit request')
    self.assertTrue(truth(self.l.env.getv('*YQL72-COMMITTED*')))
    self.assertEqual(self.calls[-2],('regen','doc',0))
    return 0
   self.l.call('yql72-accept');self.assertEqual(self.l.done,1)
   return 1
  self.l.api.update({'GETPOINT':point,'YQL72-READ-STATE':lambda:None,'YQL72-BUILTINS':lambda:[self.item],
    'YQL72-INDEX':lambda b:None,'YQL72-SAVE':lambda:None,'YQL72-DIALOG':dialog})
 def runflow(self):self.l.call('yql72-run',[0])
 def assert_once(self):
  self.assertEqual(self.dialogs,1);self.assertEqual(self.points,1)
  self.assertEqual(sum(x[0]=='insert' for x in self.calls),1)
  self.assertTrue(truth(self.l.env.getv('*YQL72-COMMITTED*')))
  self.assertEqual(self.l.env.getv('*YQL72-LAST-HANDLES*'),['H_ref'])
 def test_one_accept_one_point_one_insert_then_close(self):
  self.runflow();self.assert_once();self.assertEqual(self.calls[-1],('regen','doc',0))
 def test_old_repeat_preference_does_not_reopen_dialog(self):
  self.h.put('repeat','1');self.runflow();self.assert_once()
 def test_point_precedes_creation_and_update_precedes_return(self):
  self.runflow();names=[x[0] for x in self.calls]
  for a,b in [('point','insert'),('insert','transform'),('transform','update'),('update','undo-end'),('undo-end','regen')]:self.assertLess(names.index(a),names.index(b))
 def test_explicit_reopen_happens_only_after_commit_and_regen(self):
  self.l.tiles['repeat']='1';self.allow_second=True;self.runflow();self.assertEqual(self.dialogs,2);self.assertEqual(self.points,1)
 def test_cancel_point_never_reopens_even_with_repeat_checked(self):
  self.l.tiles['repeat']='1';self.cancel_point=True;self.runflow()
  self.assertEqual(self.dialogs,1);self.assertEqual(self.points,1);self.assertFalse(any(x[0]=='insert' for x in self.calls))
 def test_esc_point_closes_without_retry(self):
  def esc(prompt):raise RuntimeError('Function cancelled')
  self.l.api['GETPOINT']=esc;self.l.tiles['repeat']='1';self.runflow()
  self.assertEqual(self.dialogs,1);self.assertFalse(any(x[0]=='insert' for x in self.calls));self.assertFalse(truth(self.l.env.getv('*YQL72-COMMITTED*')))
 def test_failed_create_never_requests_second_point_or_dialog(self):
  def fail(*a):raise RuntimeError('mock InsertBlock failure')
  self.l.api['VLA-INSERTBLOCK']=fail;self.l.tiles['repeat']='1';self.runflow()
  self.assertEqual(self.dialogs,1);self.assertEqual(self.points,1);self.assertFalse(truth(self.l.env.getv('*YQL72-COMMITTED*')))
 def test_failed_transform_removes_only_new_object_and_stops(self):
  self.h.transform_fail=True;self.l.tiles['repeat']='1';self.runflow();self.assertEqual(self.dialogs,1);self.assertIn(('delete','ref'),self.calls)
 def test_nonexistent_handle_not_success_and_no_second_dialog(self):
  self.l.api['HANDENT']=lambda h:None;self.runflow()
  self.assertEqual(self.dialogs,1);self.assertFalse(truth(self.l.env.getv('*YQL72-COMMITTED*')));self.assertIn(('delete','ref'),self.calls)
 def test_regen_error_does_not_insert_again_or_delete_committed_object(self):
  def fail(*a):raise RuntimeError('mock refresh failure')
  self.l.api['VLA-REGEN']=fail;self.runflow();self.assert_once();self.assertFalse(any(x[0]=='delete' for x in self.calls))
 def test_hidden_layer_rejected_before_point(self):
  self.l.api['VLA-GET-LAYERON']=lambda obj:0;self.runflow()
  self.assertEqual(self.dialogs,1);self.assertEqual(self.points,0);self.assertFalse(any(x[0]=='insert' for x in self.calls))
 def test_frozen_layer_rejected_without_changing_layer(self):
  self.l.api['VLA-GET-FREEZE']=lambda obj:-1;self.runflow();self.assertEqual(self.points,0);self.assertFalse(any(x[0]=='layer' for x in self.calls))
 def test_coordinate_mode_has_no_getpoint(self):
  self.l.tiles.update(dict(point='1',px='12',py='34',pz='5'));self.runflow()
  self.assertEqual(self.dialogs,1);self.assertEqual(self.points,0);self.assertEqual(self.l.env.getv('*YQL72-LAST-POINT*'),[12,34,5])
 def test_empty_explode_result_does_not_claim_success(self):
  self.l.tiles['explode']='1';self.l.api['VLAX-INVOKE']=lambda *a:None;self.runflow()
  self.assertFalse(truth(self.l.env.getv('*YQL72-COMMITTED*')));self.assertIn(('delete','ref'),self.calls)
 def test_exploded_entities_verified_individually_before_commit(self):
  self.l.tiles['explode']='1';self.runflow();self.assertEqual(self.l.env.getv('*YQL72-LAST-HANDLES*'),['H_child1','H_child2'])
 def test_diagnostic_trace_follows_entire_route(self):
  self.runflow();self.assertEqual(self.l.env.getv('*YQL72-INSERT-TRACE*'),['RICHIESTA_ACCETTATA','VALIDAZIONE','ATTESA_PUNTO','PUNTO_ACQUISITO','CREAZIONE','POSIZIONAMENTO','VERIFICA_ENTITA','INSERITO'])

if __name__=='__main__':unittest.main(verbosity=2)
