yqt72_main : dialog {
 label = "YQArch Italiano - Alberature";
 : row {
  : boxed_column { label = "Vegetazione e origine dei simboli";
   : popup_list { key = "source"; label = "Origine:"; width = 47; }
   : image { key = "preview"; width = 42; height = 12; color = 0; aspect_ratio = 1.85; }
   : popup_list { key = "variant"; label = "Modello:"; width = 47; }
  }
  : boxed_column { label = "Dimensioni e disposizione";
   : text { label = "Tutte le misure sono nelle unita del DWG."; }
   : edit_box { key = "diam"; label = "Diametro base:"; edit_width = 14; }
   : edit_box { key = "min"; label = "Coefficiente minimo:"; edit_width = 14; }
   : edit_box { key = "max"; label = "Coefficiente massimo:"; edit_width = 14; }
   : toggle { key = "random"; label = "Rotazione casuale"; }
   : popup_list { key = "mode"; label = "Inserimento:"; width = 49; }
   : edit_box { key = "spacing"; label = "Interasse del filare:"; edit_width = 14; }
   : edit_box { key = "count"; label = "Quantita nell'area:"; edit_width = 14; }
   : edit_box { key = "distance"; label = "Distanza minima fra i centri:"; edit_width = 14; }
   : popup_list { key = "layer"; label = "Layer di inserimento:"; width = 49; }
  }
 }
 : text { key = "sourcehelp"; width = 110; }
 : text { label = "Diametro effettivo = diametro base x coefficiente; ingombro XY prima della rotazione."; }
 : text { label = "Punti singoli: un clic inserisce. Invio termina. ESC conserva i blocchi gia inseriti."; }
 : text { key = "error"; width = 110; }
 : row {
  : button { key = "reset"; label = "Ripristina valori predefiniti"; width = 30; }
  : button { key = "help"; label = "Come si usa"; width = 22; }
  spacer;
  : button { key = "accept"; label = "OK - Inserisci"; is_default = true; width = 18; }
  : button { key = "cancel"; label = "Annulla"; is_cancel = true; width = 14; }
 }
}
