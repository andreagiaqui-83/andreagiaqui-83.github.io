YQArch Italiano 3.73
====================

Release candidata definitiva basata sulla YQArch Italiano 3.71 collaudata sul PC dell'utente.

PUNTI PROTETTI
- Ribbon funzionante della 3.71: 10 pannelli, 3 icone grandi + 10 piccole per pannello.
- 130 accessi diretti, 23 categorie e 547 voci nelle espansioni.
- Inserimento catalogo: selezione -> Inserisci -> punto nel DWG -> inserimento completato.
- Nessuna riapertura obbligatoria del catalogo dopo il punto.
- Nessun reset del profilo, del CUI principale, di Express Tools o BlockHub CAD.

NOVITA' 3.73
- controllo del formato DWG prima di inserire un blocco incompatibile con la versione di AutoCAD;
- aggiornamento installer più efficiente sui file già identici;
- pulizia controllata delle cache YQArch obsolete;
- documentazione e guida consolidate, con 646 schede comando;
- test anti-regressione aggiornati per Ribbon e catalogo.

COMPATIBILITA' CATALOGO
Il catalogo standard contiene 195 DWG:
  16 AC1009
   2 AC1014
 129 AC1018 (AutoCAD 2004/2005/2006)
  48 AC1021 (AutoCAD 2007/2008/2009)
AutoCAD 2004-2006 può quindi leggere 147/195 blocchi; i 48 AC1021 vengono bloccati preventivamente con un messaggio chiaro. Da AutoCAD 2007 in poi i formati del catalogo sono leggibili.

INSTALLAZIONE
1. Chiudere AutoCAD.
2. Avviare YQArch_Italiano_3.73.exe su Windows x64 oppure usare lo ZIP/manuale seguendo INSTALLAZIONE_LEGACY.md.
3. Al primo avvio verificare Ribbon, un inserimento blocco e YQIT_DIAGNOSTICA_COMPLETA.
4. Conservare la 3.71 come rollback collaudato.

LIMITI DICHIARATI
I test di build/statici non equivalgono a esecuzione reale su ogni versione di AutoCAD e Windows. AutoCAD LT, Mac e CAD alternativi non sono certificati. Consultare COMPATIBILITA_AUTOCAD_WINDOWS.md.

GUIDA
Aprire YQArchItaliano\sys\YQArch_Italiano_Guida.html. Contiene 646 schede e una sezione dedicata alle librerie blocchi e alla diagnostica.
