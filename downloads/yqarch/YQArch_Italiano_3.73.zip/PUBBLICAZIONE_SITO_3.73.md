# Pubblicazione YQArch Italiano 3.73 sul sito

## Stato
Questo pacchetto è il candidato definitivo derivato dalla 3.71 collaudata. La pubblicazione pubblica deve avvenire **solo dopo** l'ultimo test reale della 3.73 sul PC con AutoCAD: installazione/aggiornamento, Ribbon, inserimento blocco, nuovo DWG e cambio area di lavoro.

## Checklist prima di sostituire il download
- conservare la 3.71 come rollback;
- verificare SHA-256 di EXE e ZIP pubblicati;
- installare la 3.73 con AutoCAD chiuso;
- controllare la scheda YQArch Italiano e almeno un pulsante per pannello;
- inserire un blocco con il flusso a un solo passaggio dopo la scelta del punto;
- chiudere e riaprire un DWG;
- cambiare area di lavoro e verificare che la Ribbon torni/permanga correttamente;
- eseguire `YQIT_DIAGNOSTICA_COMPLETA` e `YQIT_VERIFICA_INSERIMENTO`;
- verificare che BlockHub CAD ed Express Tools siano invariati;
- aprire la Guida e controllare ricerca, indice e schede principali.

## Testo consigliato per la pagina
**YQArch Italiano 3.73** è una versione consolidata del plugin YQArch per AutoCAD in italiano. La release mantiene la Ribbon e l'inserimento diretto dei blocchi già collaudati nella 3.71, aggiunge controlli di compatibilità dei DWG, migliora l'aggiornamento dell'installer e aggiorna la guida completa con 646 schede comando.

La distribuzione è pensata principalmente per **AutoCAD completo su Windows**. AutoCAD 2027 è l'ambiente di riferimento del progetto. Le versioni precedenti usano percorsi di compatibilità progressivamente più legacy; per AutoCAD 2004–2006 una parte della libreria blocchi richiede file salvati in formato più recente ed è quindi protetta da un controllo preventivo. Consultare la pagina/nota di compatibilità prima dell'installazione.

**Download consigliato:** installer EXE per Windows x64. È disponibile anche lo ZIP per installazione manuale/legacy.

> Nota di trasparenza: il pacchetto è sottoposto a controlli automatici e a test sul PC di riferimento, ma non ogni singolo comando storico è stato certificato su ogni versione di AutoCAD e Windows. La localizzazione e il consolidamento del core storico proseguono in modo conservativo per evitare regressioni.

## File da pubblicare
- `YQArch_Italiano_3.73.exe`
- `YQArch_Italiano_3.73.zip`
- `YQArch_Italiano_3.73_GUIDA.html`
- `YQArch_Italiano_3.73_SHA256.txt`
- opzionale: `YQArch_Italiano_3.73_REPORT.html` / verifiche tecniche

Non sostituire il download pubblico fino al collaudo reale finale della 3.73.
