# Evidenza di riferimento — 1 ottobre 2026

L'utente ha confermato che **YQArch Italiano 3.71 funziona bene sul proprio PC** dopo il collaudo della Ribbon aggiornata e del catalogo blocchi. La 3.71 è quindi la baseline operativa da proteggere durante il consolidamento 3.73.

La conferma comprende la presenza/uso della Ribbon con il layout ampliato e l'inserimento blocchi già corretto. Non equivale a un collaudo di ogni singolo comando storico, né certifica automaticamente altre versioni di AutoCAD o Windows.
