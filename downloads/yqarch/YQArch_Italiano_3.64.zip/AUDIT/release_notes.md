# YQArch Italiano 3.64

Corrette le due pagine di sostegno a partire dal pacchetto completo 3.63, conservato separatamente.

- Sostieni il progetto YQArch originale apre una pagina dedicata agli autori originali con i riferimenti originali già presenti nel pacchetto.
- Sostieni lo sviluppo di YQArch Italiano apre la pagina con PayPal (andrea.giaqui@gmail.com) e Postepay P2P (333 724 0544), recuperati senza modificarli dalla precedente pagina mista.
- Corrette le diciture di YQ_DONATE nei pannelli, nell’elenco comandi, nella guida e nel file scorciatoie distribuito. Il comando storico YQ_DONATE/yqjz apre la pagina originale. Il file scorciatoie personale esistente è conservato dall’installer, quindi la sua eventuale vecchia descrizione può rimanere; il collegamento apre comunque la pagina corretta.
- Entrambe le pagine mostrano i destinatari anche senza rete o JavaScript; nessun reindirizzamento automatico o modulo di pagamento.
- Guida aggiornata: la scheda YQ_DONATE descrive l’apertura della pagina, senza istruzioni generiche su layer o geometria.
- Pacchetto completo EXE e ZIP; migrazione delle cache menu 3.62/3.63/3.64 con backup. Le 23 categorie, 547 voci, 493 pulsanti e 458 riferimenti bitmap sono conservati. Le DLL associate assumono il nome Menu_364.

Verifiche: 22 controlli di regressione, 19 controlli menu/icone e 4 controlli di separazione destinatari e instradamento superati (45 totali). Le chiamate AutoLISP alle pagine sono eseguite da un simulatore limitato, non da AutoCAD. Lo script PowerShell conserva backup, ripristino e protezione dei file personali. Integrità dei pacchetti controllata dopo estrazione.

Evidenza utente sulla 3.63: AutoCAD 2027 italiano, 646/646 funzioni definite, 23/23 categorie, 547 voci, 1 menu visibile e DLL presenti. Bootstrap 1.281 ms, singola misura e non benchmark dell’avvio. Il log aggiuntivo mostra prompt italiani di muri/porte, griglia assi, numerazione e ricaricamento menu; non certifica la geometria o la resa visiva delle icone.

Limiti: nessuna esecuzione della 3.64 in AutoCAD/Windows in questo ambiente. Localizzazione nativa integrale, collaudo geometrico e completamento di tutte le schede guida restano attività aperte.
