# Audit menu e icone — YQArch Italiano 3.63

## Cause verificate
Nel MNU 3.62 la prima categoria Impostazioni e supporto non si chiudeva prima di Muri e pilastri. Un’ulteriore chiusura in Porte e finestre compensava la profondità più avanti, rendendo invisibili le due categorie al primo livello. Nel gruppo Testi mancava la chiusura delle altezze: altri gruppi, tra cui Quotatura e Modifica quote, restavano annidati. Anche la categoria ET - Quotatura non si chiudeva correttamente. Il parser della 3.62 termina con un livello ancora aperto.

La scelta della variante POP38 aveva inoltre ereditato intestazioni ripetute e le altezze tutte etichettate “2 mm”. La 3.63 ricostruisce l’albero usando le intestazioni specifiche della POP37, conserva la voce aggiuntiva YQ_IRONFRAME e tutti i comandi ET, ed emette nuove chiusure dal modello gerarchico. Non si affida al solo conteggio delle parentesi o dei nomi comando.

Il nome personalizzazione 3.62 era YQArchItaliano_Menu_362.cuix, ma il pacchetto conteneva soltanto yqarch.dll e gyqarch.dll. Le DLL con il basename della personalizzazione mancavano. La 3.63 distribuisce i due nomi richiesti per tema chiaro/scuro, riutilizzando la DLL originale esclusivamente di risorse (entrypoint PE zero). Le immagini vengono lette dal sistema nativo di personalizzazione AutoCAD; nessun overlay.

## Copertura
23 categorie principali, 547 voci eseguibili (comprese ripetizioni, macro di impostazione ed Express Tools), 471 comandi distinti del registro storico esposti. Registro invariato: 646 nomi. I restanti 175 sono elencati separatamente, senza attribuire loro una nuova funzione pubblica non verificata. La presenza dei 646 simboli, verificata dall’utente nella 3.62, non è la misura delle voci del menu.

483 pulsanti storici preservati e 10 pulsanti di supporto aggiunti con immagini originali. 493 pulsanti totali, 458 nomi immagine distinti, tutti presenti fra le 480 bitmap della DLL. Le copie dark/light usano la stessa grafica storica; non è un ridisegno delle icone per tema o alta densità.

## Verifiche
22 test di regressione e 19 test specifici menu/icone superati. Il nuovo diagnostico è eseguito su oggetti COM simulati: riconosce la vecchia gerarchia difettosa, una macro YQ_WALL rimossa anche a parità di numero di voci e una DLL assente. Passa con la nuova gerarchia completa. Non è una prova AutoCAD/Windows. I byte di VLX, DWG, SLB, SLD, font e DLL originali sono preservati.

Il report utente della 3.62 conferma AutoCAD 2027 italiano, 646/646 funzioni definite, core/modulo caricati, LISPSYS=1 e un menu. Il tempo di 1.672 ms è una misura del bootstrap, senza confronto prima/dopo. La 3.63 richiede ancora controllo visuale sullo stesso ambiente.

## Verifica dopo installazione
Chiudere AutoCAD, installare l’EXE, riaprire e lanciare YQIT_VERIFICA_MENU. Attesi: 1 menu, 23/23 categorie, 18/18 voci Muri e pilastri, 27/27 Porte e finestre, totale 547 voci, DLL .dll e _light.dll presenti. Controllare icone e menu dopo nuovo DWG, cambio workspace e riavvio. Il report completo è scritto nella cartella temporanea; la diagnostica non avvia i comandi né modifica il disegno.

## Fonti Autodesk
- Gestione immagini e contratto nomi DLL: https://help.autodesk.com/cloudhelp/2021/ENU/AutoCAD-Customization/files/GUID-9AA3EEC1-031C-4E88-A966-4CBC07AD112C.htm
- Elementi menu e proprietà SubMenu/Caption/Macro: https://help.autodesk.com/cloudhelp/2015/FRA/AutoCAD-ActiveX/files/GUID-8ACA3C83-3640-44A8-9A5F-122DADBD180C.htm
- Livelli di chiusura dei sottomenu: https://help.autodesk.com/cloudhelp/2016/CHS/AutoCAD-ActiveX/files/GUID-8AFB9847-002B-4301-877F-C63C5FDD99B5.htm
