# YQArch Italiano 3.63

Correzione completa del sistema menu a partire dalla 3.62, conservata come release precedente.

- Ricostruita la gerarchia con 23 categorie principali. Muri e pilastri (18 voci), Porte e finestre (27), testi, quote, curve e gli altri gruppi tornano al livello previsto.
- Corrette chiusure mancanti/sovrabbondanti dei sottomenu; nessuna macro precedente perduta. Rimossa una sola voce ET perfettamente duplicata, senza eliminare il comando.
- Ripristinate intestazioni specifiche al posto dei ripetuti “Componenti edificio” e “Altri strumenti”. Ripristinate le 13 misure distinte in Imposta altezza testo; corretta la categoria ET - Testi e la chiusura ET - Quotatura.
- Ripristinato il contratto nomi menu/DLL: YQArchItaliano_Menu_363.dll e YQArchItaliano_Menu_363_light.dll contengono le stesse risorse originali di yqarch.dll. Nessuna immagine ricreata o sostituita. Le 458 risorse richiamate esistono tutte tra le 480 bitmap originali.
- Aggiunta una barra Supporto italiano, nascosta per impostazione predefinita, per dare un’associazione immagine anche a 10 comandi di supporto. Pulsanti totali: 493; gli originali 483 restano presenti.
- YQIT_VERIFICA_MENU e YQIT_DIAGNOSTICA_COMPLETA verificano ora anche le categorie al primo livello, le voci e le macro per categoria e le DLL attese; il solo conteggio “un menu” non viene più presentato come prova di completezza.
- Installer completo: migrazione delle cache 3.62/3.63 con backup, mantenendo il ripristino e le impostazioni personali della 3.62.

Verifiche locali: 22 controlli di regressione e 19 specifici menu/icone superati. I test del nuovo diagnostico usano oggetti COM simulati; non sono esecuzioni AutoCAD. Integrità EXE/ZIP controllata anche sul contenuto estratto.

Evidenza ricevuta sulla 3.62: AutoCAD 2027 italiano, ACADVER 26.0s, LISPSYS=1, core e modulo caricati, 646/646 funzioni definite, un menu visibile; bootstrap YQArch 1.672 ms. È una singola misura del bootstrap, non un benchmark dell’intero avvio. Lo screenshot dimostra i difetti di menu e icone poi corretti in questa release.

Limiti: nessuna esecuzione della 3.63 in AutoCAD/Windows in questo ambiente. La localizzazione nativa totale, il collaudo geometrico e la guida analitica integrale restano aperti come nella 3.62.
