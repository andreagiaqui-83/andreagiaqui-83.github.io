from pathlib import Path
import sys,re,json,unittest,collections,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'work364/src'),str(ROOT/'work364/tests')]
from menu_tools import parse_menu,popup,walk_menu,bitmaps
from prepare364 import command
from test_regression import Eval,Symbol,forms,walk
SYS=ROOT/'work364/release/YQArchItaliano/sys'
def read(n):return (SYS/n).read_bytes().decode('cp1252')
OLD=(ROOT/'work/release/YQArchItaliano/sys/YQArchItaliano_Menu_362.mnu').read_bytes().decode('cp1252')
NEW=read('YQArchItaliano_Menu_364.mnu')
TREE=parse_menu(popup(NEW,1))[0]
EXPECTED=json.loads((ROOT/'work364/reports/menu_expected.json').read_text())

class MockCAD(Eval):
    """Bounded execution of the shipped diagnostic with mock read-only COM objects."""
    def __init__(self,tree,missing_dll=False):
        super().__init__();self.tree=tree;self.missing_dll=missing_dll
        for _,_,f in forms(read('YQArchItaliano_Menu.lsp')):
            if isinstance(f,list) and len(f)>2 and str(f[0]).lower()=='defun':self.defs[str(f[1]).lower()]=f
        self.env['*yqit-menu-expected*']=EXPECTED
    def ev(self,x):
        if not isinstance(x,list) or not x:return super().ev(x)
        n=str(x[0]).lower();a=x[1:]
        if n=='if':return self.ev(a[1]) if self.truth(self.ev(a[0])) else self.ev(a[2]) if len(a)>2 else None
        if n=='vlax-for':
            for item in self.ev(a[1]):
                self.env[str(a[0]).lower()]=item
                for v in a[2:]:self.ev(v)
            return None
        if n=='cond':
            for clause in a:
                if self.truth(self.ev(clause[0])):
                    r=None
                    for expr in clause[1:]:r=self.ev(expr)
                    return r
            return None
        custom={'vla-get-type','vla-get-macro','vla-get-submenu','vla-get-caption','yqit-menu-group','yqit364-menu-main','yqit364-get','append','assoc','car','cdr','cadr','caddr','length','itoa','strcase','vl-string-trim','vl-filename-directory','vl-filename-base','vl-princ-to-string','findfile'}
        if n not in custom:return super().ev(x)
        v=[self.ev(y) for y in a]
        if n=='vla-get-type':return 2 if 'children' in v[0] else 1 if v[0]['label']=='--' else 0
        if n=='vla-get-macro':return v[0].get('macro','')
        if n=='vla-get-submenu':return v[0]['children']
        if n=='vla-get-caption':return v[0]['label']
        if n=='yqit-menu-group':return 'YQARCH'
        if n=='yqit364-menu-main':return self.tree
        if n=='yqit364-get':return 'C:/Support/YQArchItaliano_Menu_364.cuix'
        if n=='append':return sum([a or [] for a in v],[])
        if n=='assoc':return next((a for a in v[1] if a[0]==v[0]),None)
        if n=='car':return v[0][0]
        if n=='cdr':return v[0][1:]
        if n=='cadr':return v[0][1]
        if n=='caddr':return v[0][2]
        if n=='length':return len(v[0] or [])
        if n=='itoa':return str(v[0])
        if n=='strcase':return v[0].upper()
        if n=='vl-string-trim':return v[1].strip(v[0])
        if n=='vl-filename-directory':return 'C:/Support'
        if n=='vl-filename-base':return 'YQArchItaliano_Menu_364'
        if n=='vl-princ-to-string':return str(v[0])
        if n=='findfile':return None if self.missing_dll else v[0]
        raise NotImplementedError(n)

class MenuTests(unittest.TestCase):
    def test_old_menu_has_unclosed_submenu(self):
        self.assertTrue(parse_menu(popup(OLD,1),strict=False)[1])
    def test_old_walls_doors_nested_under_settings(self):
        tree,_=parse_menu(popup(OLD,1),strict=False);top=[n['label'] for n in tree if 'children' in n]
        self.assertNotIn('Muri e pilastri',top);self.assertNotIn('Porte e finestre',top)
        paths=[p for p,n in walk_menu(tree) if command(n.get('macro',''))=='YQ_WALL']
        self.assertEqual(paths[0][:2],('Impostazioni e supporto','Muri e pilastri'))
    def test_all_23_categories_are_root_siblings(self):
        top=[n['label'] for n in TREE if 'children' in n]
        self.assertEqual(len(top),23);self.assertEqual(len(set(top)),23)
        for x in ['Muri e pilastri','Porte e finestre','Testi e contenuti','Quotatura','Modifica quote','Simboli architettonici','Tratteggio e tipi di linea']:self.assertIn(x,top)
    def test_new_arrow_structure_balanced(self):self.assertEqual(parse_menu(popup(NEW,1))[1],[])
    def test_wall_door_counts_and_paths(self):
        d={n['label']:n for n in TREE if 'children' in n}
        for cat,count in [('Muri e pilastri',18),('Porte e finestre',27)]:
            self.assertEqual(len([n for p,n in walk_menu(d[cat]['children']) if n.get('macro','').strip()]),count)
    def test_every_prior_macro_preserved(self):
        old={n['macro'].strip().lower() for p,n in walk_menu(parse_menu(popup(OLD,1),strict=False)[0]) if n.get('macro','').strip()}
        new={n['macro'].strip().lower() for p,n in walk_menu(TREE) if n.get('macro','').strip()}
        self.assertFalse(old-new,old-new)
    def test_exact_text_height_choices(self):
        heights=[(n['label'],n['macro']) for p,n in walk_menu(TREE) if 'Imposta altezza testo' in p]
        self.assertEqual(len(heights),13)
        for label,macro in heights:self.assertEqual(float(label.split()[0]),float(re.search(r'YQ_T_HEIGHT ([0-9.]+)',macro)[1]))
    def test_et_siblings_and_no_duplicate_macro(self):
        et=next(n for n in TREE if n['label']=='Strumenti ET')
        self.assertEqual(len(et['children']),9);self.assertEqual(et['children'][0]['label'],'ET - Testi')
        macros=[n['macro'] for p,n in walk_menu(et['children']) if n.get('macro','').strip()]
        self.assertEqual(len(macros),len(set(macros)))
    def test_all_icon_references_exist_in_native_dll(self):
        bm=bitmaps(SYS/'yqarch.dll');refs=re.findall(r'_Button\("[^"]*",\s*([^,]+),\s*([^\)]+)\)',NEW)
        self.assertEqual(len(refs),493)
        for pair in refs:
            for name in pair:self.assertIn(name.strip().lower(),bm)
    def test_resource_dlls_match_canonical_menu_and_themes(self):
        base=(SYS/'yqarch.dll').read_bytes()
        for name in ['YQArchItaliano_Menu_364.dll','YQArchItaliano_Menu_364_light.dll']:self.assertEqual((SYS/name).read_bytes(),base)
    def test_all_named_yq_menu_commands_have_toolbar_icon_assignment(self):
        assigned={command(m[1]) for m in re.findall(r'\[_Button\((.*?)\)\](.*)',NEW)}
        for path,node in walk_menu(TREE):
            cmd=command(node.get('macro',''))
            if cmd:self.assertIn(cmd,assigned,(path,cmd))
    def test_old_release_is_missing_its_named_icon_dll(self):
        self.assertFalse((ROOT/'work/release/YQArchItaliano/sys/YQArchItaliano_Menu_362.dll').exists())
    def test_visible_labels_no_known_mojibake(self):
        labels=re.findall(r'\[([^\]]+)\]',NEW)
        self.assertFalse(any('Ã' in x or 'ï¿½' in x for x in labels))
    def test_installer_invalidates_both_compiled_menu_generations(self):
        s=(ROOT/'work364/installer364.ps1').read_text('utf-8-sig')
        self.assertIn("@('yqarch','gyqarch','YQArchItaliano_Menu_362','YQArchItaliano_Menu_363','YQArchItaliano_Menu_364')",s)
        self.assertIn('Record-Original $path',s)
    def test_diagnostic_passes_complete_mock_menu(self):
        r=MockCAD(TREE).call('yqit364-menu-audit-lines',[])
        self.assertIn('Struttura menu e file DLL icone: PASS.',r);self.assertIn('Categorie principali: 23/23',r)
    def test_diagnostic_rejects_old_topology(self):
        old=parse_menu(popup(OLD,1),strict=False)[0];r=MockCAD(old).call('yqit364-menu-audit-lines',[])
        self.assertTrue(any('FAIL categoria assente o annidata: Muri e pilastri' in x for x in r))
    def test_diagnostic_rejects_missing_wall_with_same_leaf_count(self):
        tree=json.loads(json.dumps(TREE))
        for p,n in walk_menu(tree):
            if command(n.get('macro',''))=='YQ_WALL':n['macro']='^C^C^PYQ_AXISLINE ^P'
        r=MockCAD(tree).call('yqit364-menu-audit-lines',[])
        self.assertTrue(any('Macro mancanti:' in x and 'YQ_WALL' in x for x in r))
    def test_diagnostic_rejects_missing_icon_dll(self):
        r=MockCAD(TREE,True).call('yqit364-menu-audit-lines',[])
        self.assertFalse('Struttura menu e file DLL icone: PASS.' in r)
    def test_no_security_or_lispsys_change(self):
        for p in SYS.glob('*.lsp'):self.assertNotRegex(p.read_bytes().decode('cp1252'),r'(?i)\(setvar\s+"(?:SECURELOAD|TRUSTEDPATHS|LISPSYS)"')

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(MenuTests))
    report={'test':result.testsRun,'PASS':result.testsRun-len(result.failures)-len(result.errors),'FAIL':len(result.failures),'errors':len(result.errors),'scope':'Static menu/resource checks and shipped AutoLISP diagnostic executed with mock COM objects. Not an AutoCAD test.','details':[str(x)+': '+y for x,y in result.failures+result.errors]}
    (ROOT/'work364/reports/test_menu364.json').write_text(json.dumps(report,indent=2));sys.exit(not result.wasSuccessful())
