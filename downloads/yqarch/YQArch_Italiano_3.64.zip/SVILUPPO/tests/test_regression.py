"""Permanent checks on the actual release sources. No AutoCAD-runtime claims."""
from pathlib import Path
import sys,re,json,unittest,hashlib,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'work/src'))
from lisp_tools import forms,walk,Symbol,decode
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'baseline/YQArch_Italiano_3.61/YQArchItaliano/sys'
SYS=ROOT/'work364/release/YQArchItaliano/sys'

def source(name):return (SYS/name).read_bytes().decode('cp1252')
def getdef(name):
    for p in SYS.glob('*.lsp'):
        for _,_,f in forms(p.read_bytes().decode('cp1252')):
            for x in walk(f):
                if len(x)>2 and str(x[0]).lower()=='defun' and str(x[1]).lower()==name.lower():return x
    raise KeyError(name)

class CallableValue:pass
class LispError:pass
class Eval:
    """Bounded subset evaluator for pure string and registry logic only."""
    def __init__(self):self.env={};self.defs={};self.steps=0
    def add(self,name):self.defs[name.lower()]=getdef(name)
    def call(self,name,args):
        f=self.defs[name.lower()];params=f[2];split=params.index(Symbol('/')) if Symbol('/') in params else len(params)
        old=self.env.copy();self.env.update(zip(map(str.lower,params[:split]),args))
        for s in params[split+1:]:self.env[str(s).lower()]=None
        result=None
        try:
            for x in f[3:]:result=self.ev(x)
        finally:self.env=old
        return result
    def ev(self,x):
        self.steps+=1
        if self.steps>200000:raise RuntimeError('Possible infinite loop')
        if isinstance(x,Symbol):
            t=x.lower()
            if t=='nil':return None
            if t=='t':return True
            try:return int(t)
            except ValueError:return self.env.get(t)
        if not isinstance(x,list):return x
        if not x:return None
        n=str(x[0]).lower();a=x[1:]
        if n=='quote':return a[0]
        if n=='if':return self.ev(a[1]) if self.ev(a[0]) else (self.ev(a[2]) if len(a)>2 else None)
        if n=='progn':
            r=None
            for v in a:r=self.ev(v)
            return r
        if n=='setq':
            for i in range(0,len(a),2):r=self.ev(a[i+1]);self.env[a[i].lower()]=r
            return r
        if n=='while':
            count=0
            # AutoLISP zero is truthy, unlike Python.
            while self.truth(self.ev(a[0])):
                for v in a[1:]:self.ev(v)
                count+=1
                if count>10000:raise RuntimeError('Infinite loop')
            return None
        if n=='foreach':
            for item in self.ev(a[1]) or []:
                self.env[a[0].lower()]=item
                for v in a[2:]:self.ev(v)
            return None
        if n=='and':
            for v in a:
                r=self.ev(v)
                if not self.truth(r):return None
            return r
        if n=='or':
            for v in a:
                r=self.ev(v)
                if self.truth(r):return r
            return None
        vals=[self.ev(v) for v in a]
        if n in self.defs:return self.call(n,vals)
        if n=='eval':return self.ev(vals[0])
        if n=='read':return Symbol(vals[0])
        if n=='vl-catch-all-apply':
            try:return self.ev([vals[0]]+[[Symbol('quote'),v] for v in vals[1]])
            except Exception:return LispError()
        if n=='vl-catch-all-error-p':return isinstance(vals[0],LispError)
        if n=='type':return Symbol('USUBR' if isinstance(vals[0],CallableValue) else 'LIST' if isinstance(vals[0],list) else 'NIL' if vals[0] is None else 'STR')
        if n=='findfile':return vals[0]
        if n=='yqit361-read-lines':return self.env['registry']
        if n=='member':return vals[0] in (vals[1] or [])
        if n=='not':return not self.truth(vals[0])
        if n=='=':return vals[0]==vals[1]
        if n=='/=':return vals[0]!=vals[1]
        if n=='+':return sum(vals)
        if n=='-':return vals[0]-vals[1]
        if n=='1+':return vals[0]+1
        if n=='strlen':return len(vals[0])
        if n=='strcat':return ''.join(vals)
        if n=='substr':return vals[0][vals[1]-1:vals[1]-1+vals[2]] if len(vals)>2 else vals[0][vals[1]-1:]
        if n=='vl-string-search':
            r=vals[1].find(vals[0],vals[2] if len(vals)>2 else 0);return r if r>=0 else None
        if n=='cons':return [vals[0]]+(vals[1] or [])
        if n=='reverse':return list(reversed(vals[0] or []))
        if n=='list':return vals
        raise NotImplementedError(n)
    @staticmethod
    def truth(v):return v is not None and v is not False and v!=[]

class Regression(unittest.TestCase):
    def test_all_lisp_balanced_and_special_form_arity(self):
        for p in SYS.rglob('*'):
            if p.suffix.lower() not in ('.lsp','.mnl'):continue
            for _,_,f in forms(decode(p.read_bytes())[0]):
                for x in walk(f):
                    if not x:continue
                    if str(x[0]).lower()=='if':self.assertIn(len(x),(3,4),(p.name,str(x)[:160]))
                    if str(x[0]).lower()=='setq':self.assertEqual(len(x)%2,1,(p.name,str(x)[:100]))
    def test_registry_unique_646(self):
        names=source('YQArchItaliano_Command_Registry_364.txt').splitlines()
        self.assertEqual(len(names),646);self.assertEqual(len(set(names)),646)
        self.assertEqual(names,(BASE/'YQArchItaliano_Command_Registry_361.txt').read_text().splitlines())
    def test_menu_one_main_and_context(self):
        s=source('YQArchItaliano_Menu_364.mnu')
        pops=re.findall(r'(?m)^\*\*\*POP(\d+)',s)
        self.assertEqual(pops,['1','0'])
        self.assertIn('**yqarch\r\n**yqarche',s)
        self.assertNotIn('Pull-down Menu',s)
    def test_menu_preserves_every_command(self):
        pattern=r'(?:YQ_|YQIT_)[A-Z0-9_]+'
        old=set(re.findall(pattern,(BASE/'yqarch.mnu').read_bytes().decode('cp1252')))
        new=set(re.findall(pattern,source('YQArchItaliano_Menu_364.mnu')))
        self.assertFalse(old-new,old-new)
        self.assertIn('YQ_IRONFRAME',new)
    def test_legacy_menu_filenames_are_identical(self):
        data=(SYS/'YQArchItaliano_Menu_364.mnu').read_bytes()
        for n in ['yqarch.mnu','gyqarch.mnu']:self.assertEqual(data,(SYS/n).read_bytes())
    def test_context_macros_are_global(self):
        s=source('YQArchItaliano_Menu_364.mnu').split('***POP0')[1].split('***TOOLBARS')[0]
        self.assertNotRegex(s,r"'(?=zoom|pan|osnap|-osnap)")
    def test_core_and_geometry_assets_unchanged(self):
        for p in BASE.rglob('*'):
            if p.suffix.lower() in ('.vlx','.dll','.dwg','.sld','.slb','.shx'):
                self.assertEqual(p.read_bytes(),(SYS/p.relative_to(BASE)).read_bytes(),str(p))
    def test_no_security_variables_changed(self):
        for p in SYS.glob('*.lsp'):
            self.assertNotRegex(p.read_bytes().decode('cp1252'),r'(?i)\(setvar\s+"(?:SECURELOAD|TRUSTEDPATHS|LISPSYS)"')
    def test_replace_identity_terminates(self):
        e=Eval();e.add('yqit-replace-all');self.assertEqual(e.call('yqit-replace-all',['Stampa multipla','Stampa multipla','Stampa multipla']),'Stampa multipla')
    def test_replace_containing_source_terminates(self):
        e=Eval();e.add('yqit-replace-all');self.assertEqual(e.call('yqit-replace-all',['aaaa','a','aa']),'aaaaaaaa')
    def test_replace_empty_needle(self):
        e=Eval();e.add('yqit-replace-all');self.assertEqual(e.call('yqit-replace-all',['abc','','X']),'abc')
    def test_replace_multiple_and_first_position(self):
        e=Eval();e.add('yqit-replace-all');self.assertEqual(e.call('yqit-replace-all',['Blocks e Blocks','Blocks','Blocchi']),'Blocchi e Blocchi')
    def test_registry_mixed_function_values(self):
        names=source('YQArchItaliano_Command_Registry_364.txt').splitlines()
        e=Eval();e.add('yqit361-defined-p');e.add('yqit361-command-status');e.env['registry']=names
        present=set(names[1:-1:2])
        for n in names:e.env['c:'+n.lower()]=CallableValue() if n in present else None
        actual=e.call('yqit361-command-status',[])
        self.assertEqual(set(actual[0]),present);self.assertEqual(set(actual[1]),set(names)-present)
    def test_nil_interned_symbol_is_not_command(self):
        e=Eval();e.add('yqit361-defined-p');e.env['c:yq_wall']=None
        self.assertFalse(e.call('yqit361-defined-p',['C:YQ_WALL']))
    def test_native_flag_is_set_only_after_module_end(self):
        s=source('YQArchItaliano_NativeCommands_364.lsp')
        self.assertIn('(setq *YQIT-NATIVE-364* nil)',s[:300]);self.assertIn('(setq *YQIT-NATIVE-364* T)',s[-150:])
    def test_lispsys_two_is_unicode_functions(self):
        s=str(getdef('yqit361-lispsys-label'))
        self.assertIn('LISPSYS=2 - funzioni Unicode, compilazione MBCS',s)
    def test_no_legacy_menu_load_at_core_startup(self):
        s=source('yqstart.lsp');self.assertNotIn('(c:yq_menu)',s)
    def test_installer_has_real_files_and_recovery(self):
        s=(ROOT/'work364/installer364.ps1').read_text('utf-8-sig')
        self.assertNotIn('YQArchItaliano_UI32.exe',s);self.assertNotIn('YQArchItaliano_UI64.exe',s)
        self.assertNotIn('$proc.Kill()',s)
        for term in ['Record-Original','Restore-Journal','Assert-NotCancelled','Get-FileHash','Get-SafeDestination','Write-Bootstrap']:self.assertIn(term,s)
    def test_menu_loader_precedes_first_invocation(self):
        s=source('yqitaliano.lsp');self.assertLess(s.index('(load "YQArchItaliano_Menu.lsp")'),s.index('    (yqit-load-menu)'))
    def test_dcl_properties_unchanged(self):
        # Ignore values and labels: technical property identifiers must remain identical.
        def props(b):
            s=decode(b)[0];s=re.sub(r'"(?:\\.|[^"\\])*"','""',s);s=re.sub(r'//[^\n]*','',s)
            return re.findall(r'\b(\w+)\s*=',s)
        for p in BASE.glob('*.dcl'):
            target=SYS/p.name.replace('_361','_364');self.assertEqual(props(p.read_bytes()),props(target.read_bytes()))
    def test_catalog_commands_are_technical_identifiers(self):
        s=source('YQArchItaliano_Runtime.lsp');checked=0
        for a,b,f in forms(s):
            if isinstance(f,list) and len(f)>2 and str(f[0]).lower()=='setq' and str(f[1]).lower()=='*yqit-pandect-data*':
                for title,cmd,alias,default in re.findall(r'\(list "([^"\r\n]*)" "([^"\r\n]*)" "([^"\r\n]*)" "([^"\r\n]*)"\)',s[a:b]):
                    self.assertRegex(cmd,r'(?i)^(?:yq[a-z0-9_]*|xc_ss)$',(title,cmd));checked+=1
        self.assertEqual(checked,476)
    def test_catalog_preserves_visible_labels_and_shortcuts(self):
        pat=r'\(list "([^"\r\n]*)" "([^"\r\n]*)" "([^"\r\n]*)" "([^"\r\n]*)"\)'
        def leaves(s):
            for a,b,f in forms(s):
                if isinstance(f,list) and len(f)>2 and str(f[0]).lower()=='setq' and str(f[1]).lower()=='*yqit-pandect-data*':return [(x[0],x[2],x[3]) for x in re.findall(pat,s[a:b])]
        expected=leaves((BASE/'YQArchItaliano_Runtime.lsp').read_bytes().decode('cp1252'))
        self.assertEqual(expected.count(('Sostegno ai progetti YQArch','yqjz','yqjz')),1)
        expected=[('Sostieni il progetto YQArch originale',alias,default)
                  if label=='Sostegno ai progetti YQArch' else (label,alias,default)
                  for label,alias,default in expected]
        self.assertEqual(expected,leaves(source('YQArchItaliano_Runtime.lsp')))

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Regression)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    data={'tests':result.testsRun,'pass':result.testsRun-len(result.errors)-len(result.failures),'fail':len(result.failures),'errors':len(result.errors),'scope':'Static checks and bounded pure-logic evaluator; not AutoCAD runtime','details':[str(t)+': '+msg for t,msg in result.failures+result.errors]}
    (ROOT/'work364/test_results.json').write_text(json.dumps(data,indent=2))
    sys.exit(not result.wasSuccessful())
