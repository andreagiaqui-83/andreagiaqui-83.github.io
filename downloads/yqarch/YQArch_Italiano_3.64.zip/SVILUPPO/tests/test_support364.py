"""Recipient isolation and dispatch checks on the shipped HTML and AutoLISP."""
from pathlib import Path
import sys,re,json,unittest
from lxml import html as LH
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_regression import Eval,Symbol,SYS,ROOT

class LocalPages(Eval):
    def __init__(self,missing=False):
        super().__init__();self.opened=[];self.alerts=[];self.missing=missing
        self.directory='C:\\Support italiano è\\sys'
        for n in ['c:YQIT_DONATE_ORIGINAL','c:YQIT_DONATE_ITALIANO',
                  'c:YQ_DONATE','yqit-donate-original-legacy']:self.add(n)
    def ev(self,x):
        # The structural parser retains source escapes; AutoLISP evaluates \\ as \.
        if isinstance(x,str) and not isinstance(x,Symbol):
            return re.sub(r'\\([\\"nrt])',lambda m:{'\\':'\\','"':'"','n':'\n','r':'\r','t':'\t'}[m[1]],x)
        if isinstance(x,list) and x:
            n=str(x[0]).lower()
            if n=='yqit-sysdir':return self.directory
            if n=='princ':return None
            if n=='findfile':
                path=self.ev(x[1])
                return path if not self.missing and (SYS/path.split('\\')[-1]).is_file() else None
            if n=='startapp':self.opened.append([self.ev(v) for v in x[1:]]);return 33
            if n=='alert':self.alerts.append(self.ev(x[1]));return None
        return super().ev(x)

class SupportTests(unittest.TestCase):
    def test_recipient_isolation_and_both_italian_methods(self):
        original=LH.fromstring((SYS/'YQArch_Sostegno_Originale.html').read_bytes())
        italian=LH.fromstring((SYS/'YQArch_Sostegno_Italiano.html').read_bytes())
        self.assertIn('Lin Yaozong',original.text_content())
        self.assertIn('h2099@126.com',original.text_content())
        self.assertEqual(original.xpath('//a/@href'),['http://yqarch.cn'])
        for method,recipient in [('PayPal','andrea.giaqui@gmail.com'),('Postepay P2P','333 724 0544')]:
            self.assertNotIn(recipient,original.text_content())
            self.assertNotIn(method,original.text_content())
            blocks=italian.xpath('//div[@class="method"]')
            self.assertEqual(sum(method in b.text_content() and recipient in b.text_content() for b in blocks),1)
        self.assertNotIn('h2099@126.com',italian.text_content())
        self.assertEqual(len(italian.xpath('//div[@class="method"]')),2)
        for doc in [original,italian]:
            self.assertFalse(doc.xpath('//script|//iframe|//form|//meta[@http-equiv]'))
            self.assertFalse(doc.xpath('//*[@src and not(starts-with(@src,"data:"))]'))

    def test_actual_lisp_dispatch_opens_correct_existing_page(self):
        for command,page in [('c:YQIT_DONATE_ORIGINAL','Originale'),('c:YQ_DONATE','Originale'),
                             ('c:YQIT_DONATE_ITALIANO','Italiano')]:
            e=LocalPages();e.call(command,[])
            self.assertEqual(e.opened,[['explorer.exe',e.directory+'\\YQArch_Sostegno_'+page+'.html']])
            self.assertEqual(e.alerts,[])

    def test_missing_page_does_not_open_a_different_recipient(self):
        for cmd in ['c:YQIT_DONATE_ORIGINAL','c:YQIT_DONATE_ITALIANO','c:YQ_DONATE']:
            e=LocalPages(missing=True);e.call(cmd,[])
            self.assertFalse(e.opened);self.assertEqual(len(e.alerts),1)

    def test_menu_payload_unchanged_except_release_identifiers(self):
        old=ROOT/'work363/release/YQArchItaliano/sys'
        normal=lambda b:b.replace(b'3.63',b'3.64').replace(b'_363',b'_364').replace(b'ID_tb363_',b'ID_tb364_')
        self.assertEqual(normal((old/'YQArchItaliano_Menu_363.mnu').read_bytes()),(SYS/'YQArchItaliano_Menu_364.mnu').read_bytes())
        for suffix in ['.dll','_light.dll']:
            self.assertEqual((old/('YQArchItaliano_Menu_363'+suffix)).read_bytes(),(SYS/('YQArchItaliano_Menu_364'+suffix)).read_bytes())
        text=(SYS/'YQArchItaliano_Menu_364.mnu').read_text('cp1252')
        self.assertIn('[Sostieni il progetto YQArch originale...]^c^c^pYQIT_DONATE_ORIGINAL',text)
        self.assertIn('[Sostieni lo sviluppo di YQArch Italiano...]^c^c^pYQIT_DONATE_ITALIANO',text)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SupportTests))
    report={'test':result.testsRun,'PASS':result.testsRun-len(result.failures)-len(result.errors),
            'FAIL':len(result.failures),'errors':len(result.errors),
            'scope':'Recipient isolation, actual shipped AutoLISP dispatch in a bounded mock, preserved menu and images; no AutoCAD execution.',
            'details':[str(x)+': '+y for x,y in result.failures+result.errors]}
    (ROOT/'work364/reports/test_support364.json').write_text(json.dumps(report,indent=2))
    sys.exit(not result.wasSuccessful())
