"""Small, lossless AutoLISP lexical reader for static checks, not an AutoCAD runtime."""
import re
from dataclasses import dataclass

class Symbol(str): pass
@dataclass
class Token:
    kind: str
    value: str
    start: int
    end: int

def tokens(text):
    i=0
    while i<len(text):
        c=text[i]
        if c.isspace(): i+=1; continue
        if text.startswith(';|',i):
            j=text.find('|;',i+2)
            if j<0: raise ValueError(f'Commento non terminato: {i}')
            i=j+2;continue
        if c==';':
            j=text.find('\n',i);i=len(text) if j<0 else j+1;continue
        if c in "()'":
            yield Token(c,c,i,i+1);i+=1;continue
        if c=='"':
            j=i+1
            while j<len(text):
                if text[j]=='\\': j+=2;continue
                if text[j]=='"':break
                j+=1
            if j>=len(text):raise ValueError(f'Stringa non terminata: {i}')
            yield Token('string',text[i+1:j],i,j+1);i=j+1;continue
        j=i+1
        while j<len(text) and not text[j].isspace() and text[j] not in "();'\"":j+=1
        yield Token('symbol',text[i:j],i,j);i=j

def forms(text):
    ts=list(tokens(text));i=0
    def parse():
        nonlocal i
        if i>=len(ts):raise ValueError('Espressione incompleta')
        t=ts[i];i+=1
        if t.kind=='(':
            out=[]
            while i<len(ts) and ts[i].kind!=')':out.append(parse())
            if i==len(ts):raise ValueError(f'Parentesi aperta: {t.start}')
            i+=1;return out
        if t.kind==')':raise ValueError(f'Parentesi inattesa: {t.start}')
        if t.kind=="'":return [Symbol('quote'),parse()]
        return t.value if t.kind=='string' else Symbol(t.value)
    out=[]
    while i<len(ts):
        start=ts[i].start;value=parse();out.append((start,ts[i-1].end,value))
    return out

def walk(x):
    if isinstance(x,list):
        yield x
        for y in x:yield from walk(y)

def replace_defun(text,name,new):
    hits=[(a,b) for a,b,f in forms(text) if isinstance(f,list) and len(f)>1 and str(f[0]).lower() in ('defun','defun-q') and str(f[1]).lower()==name.lower()]
    if len(hits)!=1:raise ValueError((name,len(hits)))
    a,b=hits[0];return text[:a]+new.rstrip()+text[b:]

def decode(data):
    try:return data.decode('utf-8-sig'),'utf-8'
    except UnicodeDecodeError:return data.decode('cp1252',errors='replace'),'cp1252'
