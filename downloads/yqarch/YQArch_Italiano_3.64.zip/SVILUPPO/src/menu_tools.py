"""Parse legacy menu topology and read resource-only PE bitmaps without execution."""
from pathlib import Path
import struct,re,io
from PIL import Image

def popup(s,number):
    return re.split(r'(?m)^\*\*\*',s.split('***POP'+str(number),1)[1],1)[0]

def parse_menu(text,strict=True):
    """Reconstruct actual arrow-defined topology (indentation is not semantic)."""
    root=[];stack=[root];titles=[];errors=[]
    for line_no,line in enumerate(text.splitlines(),1):
        m=re.match(r'\s*(?:[A-Za-z0-9_]+\s+)?\[([^\]]*)\](.*)',line)
        if not m:continue
        label,macro=m.groups();close=0
        while label.startswith('<-'):close+=1;label=label[2:]
        if label.startswith('->'):
            node={'label':label[2:],'children':[],'line':line_no};stack[-1].append(node);stack.append(node['children'])
        else:
            node={'label':label,'macro':macro,'line':line_no};stack[-1].append(node)
        for _ in range(close):
            if len(stack)==1:errors.append(f'Underflow line {line_no}')
            else:stack.pop()
    if len(stack)!=1:errors.append(f'Unclosed submenus: {len(stack)-1}')
    if strict and errors:raise ValueError('; '.join(errors))
    return root,errors

def walk_menu(nodes,path=()):
    for n in nodes:
        full=path+(n['label'],)
        if 'children' in n:yield from walk_menu(n['children'],full)
        else:yield full,n

def intended_tree(text):
    """Recover declared category layout from the less-corrupted POP37 indentation."""
    root=[];stack=[(-1,root)]
    for line in text.splitlines():
        m=re.match(r'(\s*)\[([^\]]*)\](.*)',line)
        if not m:continue
        ws,label,macro=m.groups();indent=len(ws);label=re.sub(r'^(?:<-)+','',label)
        while stack[-1][0]>=indent:stack.pop()
        if label.startswith('->'):
            node={'label':label[2:],'children':[]};stack[-1][1].append(node);stack.append((indent,node['children']))
        elif label!='YQARCH ITALIANO':stack[-1][1].append({'label':label,'macro':macro})
    return root

def emit(nodes,indent=0):
    lines=[]
    for n in nodes:
        if 'children' in n:
            lines.append(' '*indent+'[->'+n['label']+']')
            body=emit(n['children'],indent+3)
            assert body,'Empty submenu'
            i=body[-1].index('[');body[-1]=body[-1][:i+1]+'<-'+body[-1][i+1:]
            lines.extend(body)
        else:lines.append(' '*indent+'['+n['label']+']'+n.get('macro',''))
    return lines

def pe_resources(path):
    b=Path(path).read_bytes();pe=struct.unpack_from('<I',b,60)[0]
    assert b[pe:pe+4]==b'PE\0\0'
    n=struct.unpack_from('<H',b,pe+6)[0];sz=struct.unpack_from('<H',b,pe+20)[0];op=pe+24;magic=struct.unpack_from('<H',b,op)[0]
    sections=[struct.unpack_from('<8sIIII',b,op+sz+40*i) for i in range(n)]
    def off(rva):
        for name,vs,va,rs,ptr in sections:
            if va<=rva<va+max(vs,rs):return ptr+rva-va
        raise ValueError(rva)
    rva,_=struct.unpack_from('<II',b,op+(96 if magic==267 else 112)+16);root=off(rva);resources={}
    def visit(pos,parents):
        named,ids=struct.unpack_from('<HH',b,pos+12)
        for i in range(named+ids):
            name,ptr=struct.unpack_from('<II',b,pos+16+8*i)
            if name&0x80000000:
                q=root+(name&0x7fffffff);ln=struct.unpack_from('<H',b,q)[0];name=b[q+2:q+2+2*ln].decode('utf-16-le')
            if ptr&0x80000000:visit(root+(ptr&0x7fffffff),parents+[name])
            else:
                r,size,cp,_=struct.unpack_from('<IIII',b,root+ptr);data=b[off(r):off(r)+size];assert len(data)==size
                resources[tuple(parents+[name])]=data
    visit(root,[])
    assert struct.unpack_from('<I',b,op+16)[0]==0,'Expected resource-only DLL'
    return resources

def bitmaps(path):return {str(k[1]).lower():v for k,v in pe_resources(path).items() if k[0]==2}

def dib_image(data):return Image.open(io.BytesIO(data))
