from pathlib import Path
import json,csv,shutil,re,html
from lxml import html as LH
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work364';R=W/'reports';REL=W/'release'
SYS=REL/'YQArchItaliano/sys';OLD=ROOT/'work363/release/YQArchItaliano/sys';OUT=ROOT/'output364'

def main():
    evidence={'versione':'3.63','AutoCAD':'2027 italiano, ACADVER 26.0s','LISPSYS':1,
              'comandi_definiti':646,'menu_visibili':1,'categorie':23,'voci_eseguibili':547,
              'dll_icone':'PRESENTI secondo diagnostica utente; resa visiva non certificata',
              'bootstrap_ms':1281,'fonte':'Diagnostica incollata dall’utente il 27 settembre 2026',
              'log_aggiuntivo':'Prompt italiani YQ_WALL e YQ_DOOR; griglia assi e 13 numeri progressivi dichiarati creati; menu ricaricato. Non è un collaudo geometrico.'}
    (R/'evidenza_runtime_3.63.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
    for filename in ['YQArchItaliano_Modernization_364.csv','YQArchItaliano_Command_Audit_364.csv']:
        rows=list(csv.DictReader((SYS/filename).read_text('utf-8-sig').splitlines()));new=[]
        for row in rows:
            row={k.replace('3_63','3_64'):v for k,v in row.items()}
            row['caricamento_3_63_utente']='DEFINITO: diagnostica utente 646/646; presenza non equivale a esecuzione'
            row['runtime_3_64']='NON ESEGUITO IN AUTOCAD'
            if row['comando']=='YQ_DONATE':
                row['UI_3_64']='Pagina originale separata; instradamento LSP verificato con simulatore limitato'
                row['geometria_3_64']='NON APPLICABILE: apre una pagina informativa'
            new.append(row)
        with (SYS/filename).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=new[0]);writer.writeheader();writer.writerows(new)
    shutil.copy2(SYS/'YQArchItaliano_Command_Audit_364.csv',R/'matrice_646_comandi.csv')
    (SYS/'YQArchItaliano_Command_Audit_364.txt').write_text('3.64: 646 nomi nel registro, 471 comandi singoli nel menu storico, 23 categorie e 547 voci eseguibili. Corrette le pagine Sostieni. La diagnostica utente della 3.63 conferma 646/646 funzioni e 23/23 categorie su AutoCAD 2027 italiano. La 3.64 è verificata localmente, non eseguita in AutoCAD in questo ambiente.\n')
    cp=json.loads((SYS/'YQArchItaliano_CorePatch_364.json').read_text())
    cp.update(version='3.64',baseline='3.63',baseline_runtime_utente=evidence,runtime_testato=False,
              note='Separazione delle pagine Sostieni; recuperati i due metodi italiani già forniti. Menu e risorse grafiche della 3.63 conservati.')
    (SYS/'YQArchItaliano_CorePatch_364.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2))
    notes='''# YQArch Italiano 3.64

Corrette le due pagine di sostegno a partire dal pacchetto completo 3.63, conservato separatamente.

- Sostieni il progetto YQArch originale apre una pagina dedicata agli autori originali con i riferimenti originali già presenti nel pacchetto.
- Sostieni lo sviluppo di YQArch Italiano apre la pagina con PayPal (andrea.giaqui@gmail.com) e Postepay P2P (333 724 0544), recuperati senza modificarli dalla precedente pagina mista.
- Corrette le diciture di YQ_DONATE nei pannelli, nell’elenco comandi, nella guida e nel file scorciatoie distribuito. Il comando storico YQ_DONATE/yqjz apre la pagina originale. Il file scorciatoie personale esistente è conservato dall’installer, quindi la sua eventuale vecchia descrizione può rimanere; il collegamento apre comunque la pagina corretta.
- Entrambe le pagine mostrano i destinatari anche senza rete o JavaScript; nessun reindirizzamento automatico o modulo di pagamento.
- Guida aggiornata: la scheda YQ_DONATE descrive l’apertura della pagina, senza istruzioni generiche su layer o geometria.
- Pacchetto completo EXE e ZIP; migrazione delle cache menu 3.62/3.63/3.64 con backup. Le 23 categorie, 547 voci, 493 pulsanti e 458 riferimenti bitmap sono conservati. Le DLL associate assumono il nome Menu_364.

Verifiche: 22 controlli di regressione, 19 controlli menu/icone e 4 controlli di separazione destinatari e instradamento superati (45 totali). Le chiamate AutoLISP alle pagine sono eseguite da un simulatore limitato, non da AutoCAD. Lo script PowerShell conserva backup, ripristino e protezione dei file personali. Integrità dei pacchetti controllata dopo estrazione.

Evidenza utente sulla 3.63: AutoCAD 2027 italiano, 646/646 funzioni definite, 23/23 categorie, 547 voci, 1 menu visibile e DLL presenti. Bootstrap 1.281 ms, singola misura e non benchmark dell’avvio. Il log aggiuntivo mostra prompt italiani di muri/porte, griglia assi, numerazione e ricaricamento menu; non certifica la geometria o la resa visiva delle icone.

Limiti: nessuna esecuzione della 3.64 in AutoCAD/Windows in questo ambiente. Localizzazione nativa integrale, collaudo geometrico e completamento di tutte le schede guida restano attività aperte.
'''
    readme='''YQARCH ITALIANO 3.64 — PAGINE DI SOSTEGNO

1. Chiudere AutoCAD e avviare YQArch_Italiano_3.64.exe. Pacchetto completo: non serve installare prima la 3.63.
2. In YQARCH ITALIANO > Impostazioni e supporto, aprire Sostieni il progetto YQArch originale: sono presenti solo i riferimenti degli autori originali.
3. Aprire Sostieni lo sviluppo di YQArch Italiano: sono presenti PayPal (andrea.giaqui@gmail.com) e Postepay P2P (333 724 0544).

Comandi diretti: YQIT_DONATE_ORIGINAL e YQIT_DONATE_ITALIANO. YQ_DONATE/yqjz resta associato al progetto originale. I dati sono visibili anche senza rete; per effettuare il contributo si usa il servizio indicato.

L’installer crea backup e conserva i file personali noti. Nei file scorciatoie personali già esistenti può rimanere la precedente descrizione testuale; la pagina aperta dal comando viene comunque corretta.

Lo ZIP contiene YQArchItaliano/sys (plugin completo), AUDIT (rapporti, matrici, test), SVILUPPO (script e test), guida offline e rapporto della release.
Le correzioni menu/icone della 3.63 sono incluse. Per la diagnostica usare YQIT_VERIFICA_MENU o YQIT_DIAGNOSTICA_COMPLETA.

45 controlli locali superati. La 3.64 non è stata eseguita in AutoCAD in questo ambiente. La presenza dei comandi non certifica geometria e localizzazione integrale.
'''
    for name,text in [('README.txt',readme),('RELEASE_NOTES_3.64.md',notes)]:
        (REL/name).write_text(text);(SYS/name).write_text(text)
    (REL/'YQArchItaliano/YQARCH_ITALIANO_README.txt').write_text(readme)
    (SYS/'README_GITHUB.md').write_text(readme);(R/'release_notes.md').write_text(notes)
    changelog=SYS/'CHANGELOG.md';changelog.write_text(notes+'\n\n'+(OLD/'CHANGELOG.md').read_text('utf-8-sig'))
    for name in ['COMPATIBILITA_AUTOCAD_WINDOWS.md','INSTALLAZIONE_LEGACY.md']:
        text=(OLD/name).read_text().replace('3.63','3.64').replace('_363','_364')
        if name.startswith('COMPATIBILITA'):
            text=text.split('## Evidenza della release precedente')[0]+'## Evidenza della release precedente\nLa diagnostica utente della 3.63 su AutoCAD 2027 italiano conferma 646/646 funzioni e 23/23 categorie (547 voci), un menu e DLL presenti. La 3.64 corregge le pagine Sostieni ed è stata verificata localmente; nessun collaudo AutoCAD della nuova release in questo ambiente.\n'
        else:
            text=text.replace('Menu e DLL immagini 3.64','Menu e DLL immagini 3.64')
            text=text.replace('YQArchItaliano_Menu_362 e YQArchItaliano_Menu_364','YQArchItaliano_Menu_362, YQArchItaliano_Menu_363 e YQArchItaliano_Menu_364')
        (REL/name).write_text(text);(SYS/name).write_text(text)
    (SYS/'YQArchItaliano_Compatibility_Matrix.txt').write_text((REL/'COMPATIBILITA_AUTOCAD_WINDOWS.md').read_text())

    doc=LH.fromstring((OLD/'YQArch_Italiano_Guida.html').read_text().replace('3.63','3.64').replace('_363','_364'))
    for aside in doc.xpath('//aside'):
        if '23 categorie principali' in aside.text_content():aside.getparent().remove(aside)
    notice=LH.fromstring('<aside style="margin:18px;padding:18px;background:#e9f4ef;border-left:5px solid #207653"><b>YQArch Italiano 3.64 — pagine di sostegno corrette</b><p>Le due voci Sostieni aprono pagine separate. La pagina italiana contiene PayPal e Postepay P2P. Il report utente della 3.63 conferma 646/646 funzioni e 23/23 categorie; la 3.64 supera 45 controlli locali e richiede il collaudo in AutoCAD.</p><p>Le 646 schede sono conservate; la documentazione analitica completa resta da terminare.</p></aside>')
    doc.find('body').insert(1,notice)
    card=doc.get_element_by_id('yq_donate')
    updated=LH.fromstring('''<article class="card" id="yq_donate" data-search="yq_donate yqjz sostieni originale italiano paypal postepay sostegno impostazioni supporto">
<h3>Sostieni il progetto YQArch originale</h3><div class="meta"><span class="tag"><b>Comando:</b> <code>YQ_DONATE</code></span><span class="tag"><b>Scorciatoia storica:</b> <code>yqjz</code></span><span class="doclevel">Pagina informativa locale</span></div>
<p>Apre nel browser la pagina di sostegno dedicata agli autori originali di YQArch.</p>
<div class="when"><p><b>Quando usarlo:</b> per consultare i riferimenti del progetto originale.</p><p><b>Prima di iniziare:</b> YQArch Italiano deve essere caricato e la pagina HTML deve essere installata nella cartella sys.</p></div>
<div class="grid"><div class="box"><h4>Procedura</h4><ol><li>Digita YQ_DONATE oppure scegli Impostazioni e supporto → Sostieni il progetto YQArch originale. La voce del menu usa il comando equivalente YQIT_DONATE_ORIGINAL.</li><li>Il browser apre YQArch_Sostegno_Originale.html con i riferimenti degli autori originali.</li></ol></div><div class="box"><h4>Risultato atteso</h4><p>Pagina originale con il riferimento Alipay già fornito. Non richiede punti, selezioni o modifiche al disegno.</p><h4>Sostegno alla versione italiana</h4><p>Usa la voce separata Sostieni lo sviluppo di YQArch Italiano oppure YQIT_DONATE_ITALIANO. La pagina italiana riporta PayPal: andrea.giaqui@gmail.com e Postepay P2P: 333 724 0544.</p></div></div>
<p class="notice">Se la pagina manca, viene visualizzato un avviso. Instradamento verificato localmente sul codice AutoLISP; nessuna esecuzione AutoCAD della 3.64 in questo ambiente.</p></article>''')
    card.getparent().replace(card,updated)
    for node in doc.xpath('//a[@href="#yq_donate"]'):
        if len(node)==0:node.text='Sostieni il progetto YQArch originale'
    guide='<!doctype html>\n'+LH.tostring(doc,encoding='unicode')
    (SYS/'YQArch_Italiano_Guida.html').write_text(guide);(OUT/'YQArch_Italiano_3.64_GUIDA.html').write_text(guide)

    oldreport=LH.fromstring((ROOT/'output363/YQArch_Italiano_3.63_REPORT.html').read_text())
    style=oldreport.xpath('//style')[0].text
    menus=LH.tostring(oldreport.xpath('//div[@class="menus"]')[0],encoding='unicode')
    scripts=''.join(LH.tostring(x,encoding='unicode') for x in oldreport.xpath('//script'))
    body='''<header><small>YQARCH ITALIANO · 3.64</small><h1>Pagine di sostegno separate</h1><p>Ripristinati i due metodi del progetto italiano nella pagina corretta.</p></header><main>
<div class="stats"><b>45 controlli locali superati</b><b>23 categorie</b><b>547 voci eseguibili</b></div>
<h2>Correzione</h2><p>La pagina originale della 3.63 conteneva anche i metodi italiani; quella italiana mostrava soltanto un testo generico. I metodi già presenti sono stati spostati nella pagina italiana. Entrambe le pagine sono informative e leggibili senza rete o JavaScript.</p>
<table><tr><th>Voce del menu</th><th>Contenuto della pagina</th></tr><tr><td>Sostieni il progetto YQArch originale</td><td>Solo riferimenti degli autori originali: Lin Yaozong, Alipay h2099@126.com e sito ufficiale già presente nel pacchetto.</td></tr><tr><td>Sostieni lo sviluppo di YQArch Italiano</td><td>PayPal: andrea.giaqui@gmail.com<br>Postepay P2P: 333 724 0544</td></tr></table>
<p>I comandi di menu sono YQIT_DONATE_ORIGINAL e YQIT_DONATE_ITALIANO. Il comando storico YQ_DONATE/yqjz apre la pagina originale. Aggiornate le diciture dei pannelli e la scheda guida. Le scorciatoie personali già installate vengono conservate, inclusa l’eventuale vecchia descrizione.</p>
<h2>Verifiche e limiti</h2><p>22 controlli di regressione, 19 su menu e icone, 4 sui destinatari e sull’apertura delle pagine. Gli ultimi eseguono il codice AutoLISP distribuito con un simulatore limitato, inclusa l’assenza della pagina. Non sono prove in AutoCAD.</p>
<p>La diagnostica 3.63 fornita dall’utente conferma 646/646 funzioni definite, 23/23 categorie, 547 voci, un menu e DLL presenti su AutoCAD 2027 italiano. Il bootstrap di 1.281 ms è una singola misura. Il log mostra prompt italiani per muri e porte, griglia assi, numerazione e ricaricamento menu; non certifica geometria o resa visiva delle icone.</p>
<p>La 3.64 non è stata eseguita su Windows/AutoCAD in questo ambiente. Localizzazione nativa integrale e documentazione analitica di tutti i comandi restano da completare. Il launcher Windows della 3.63 è riutilizzato con script e payload ricostruiti; non è ricompilato da sorgente.</p>
<h2>Installazione</h2><p>Chiudi AutoCAD, installa l’EXE completo 3.64 e riapri le due voci Sostieni in Impostazioni e supporto. Lo ZIP comprende plugin completo, guida, matrici, sorgenti delle modifiche e test. La 3.63 resta conservata separatamente.</p>
<h2>Menu e icone conservati</h2><p>Anteprima ricavata dalla sorgente MNU e dalle bitmap originali, non screenshot AutoCAD. 471 comandi distinti del registro sono esposti nel menu storico; gli altri comprendono pannelli e helper. Le 493 associazioni dei pulsanti risolvono tutte le 458 immagini richiamate. Le DLL distribuite sono Menu_364.dll e Menu_364_light.dll.</p>
<input class="search" type="search" placeholder="Cerca una voce o un comando" aria-label="Cerca nel menu">'''
    report='<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>YQArch Italiano 3.64 — rapporto</title><style>'+style+'</style></head><body>'+body+menus+'</main>'+scripts+'</body></html>'
    (OUT/'YQArch_Italiano_3.64_REPORT.html').write_text(report);(R/'REPORT_SOSTEGNO_3.64.html').write_text(report)
    shutil.copy2(W/'test_results.json',R/'test_regressione_364.json')
    print('Guida, rapporto e documentazione 3.64 aggiornati.')

if __name__=='__main__':main()
