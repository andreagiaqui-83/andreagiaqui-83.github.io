"""Build the support-page correction from the preserved, complete 3.63 payload."""
from pathlib import Path
import shutil, re, json, csv
from lxml import html as LH

ROOT=Path(__file__).resolve().parents[2]
W=ROOT/'work364'; BASE=ROOT/'work363/release'; REL=W/'release'
SYS=REL/'YQArchItaliano/sys'; R=W/'reports'

def command(macro):
    m=re.search(r'\^p((?:YQ(?:IT)?_)[A-Z0-9_]+|YQARCH|XC_SS)(?:\s|$)',macro,re.I)
    return m[1].upper() if m else ''

def migrate(b):
    return (b.replace(b'_363',b'_364').replace(b'3.63',b'3.64')
            .replace(b'yqit363',b'yqit364').replace(b'YQIT363',b'YQIT364')
            .replace(b'*YQIT-NATIVE-363*',b'*YQIT-NATIVE-364*').replace(b'ID_tb363_',b'ID_tb364_'))

def page(title,subtitle,card,style):
    # Plain local HTML: recipients remain visible without scripts or network access.
    return ('<!doctype html>\n<html lang="it"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>'+title+'</title><style>'+style+
            '\nmain{max-width:820px}.hero .wrap{max-width:776px}.hero .badge{color:#142033}'
            '.method .value{user-select:all}p{line-height:1.6}</style></head><body>'
            '<header class="hero"><div class="wrap"><span class="badge">'+
            ('PROGETTO ORIGINALE' if 'originale' in title else 'VERSIONE ITALIANA')+
            '</span><h1>'+title+'</h1><p>'+subtitle+'</p></div></header><main>'+card+
            '<footer>YQArch Italiano 3.64 · pagina informativa locale di sostegno</footer>'
            '</main></body></html>\n')

def main():
    if REL.exists():shutil.rmtree(REL)
    shutil.copytree(BASE,REL)
    (REL/'MANIFEST_SHA256.json').unlink()
    text_ext={'.lsp','.mnl','.dcl','.mnu','.txt','.md','.csv','.tsv','.html','.json','.version','.man'}
    for p in list(REL.rglob('*')):
        if not p.is_file():continue
        if p.suffix.lower() in text_ext and p.name!='CHANGELOG.md':p.write_bytes(migrate(p.read_bytes()))
        n=p.name.replace('_363','_364').replace('3.63','3.64')
        if n!=p.name:p.rename(p.with_name(n))

    # Reuse the exact, already supplied recipients. Never derive new payment URLs.
    original=LH.fromstring((BASE/'YQArchItaliano/sys/YQArch_Sostegno_Originale.html').read_text('utf-8-sig'))
    style=original.xpath('//style')[0].text
    original_card=original.xpath('//section[contains(@class,"card original")]')[0]
    italian_card=original.xpath('//section[contains(@class,"card italiano")]')[0]
    assert italian_card.xpath('.//div[@class="value"]/text()')==['andrea.giaqui@gmail.com','333 724 0544']
    # Scope the notice to the selected recipient without displaying the other one's methods.
    notice=italian_card.xpath('.//div[contains(@class,"notice")]')[0]
    notice.clear();notice.set('class','notice blue')
    notice.text='I contributi sostengono esclusivamente lo sviluppo indipendente di YQArch Italiano.'
    orig_html=page('Sostieni il progetto YQArch originale',
        'Contributi destinati agli autori del progetto originale YQArch.',
        LH.tostring(original_card,encoding='unicode'),style)
    it_html=page('Sostieni YQArch Italiano',
        'Sostieni traduzione, interfaccia, manutenzione e test della versione italiana.',
        LH.tostring(italian_card,encoding='unicode'),style)
    (SYS/'YQArch_Sostegno_Originale.html').write_text(orig_html)
    (SYS/'YQArch_Sostegno_Italiano.html').write_text(it_html)

    # Historical YQ_DONATE/yqjz continues to open the original project page.
    for name in ['YQArchItaliano_Runtime.lsp','yqshortcut.txt','yqpanel.txt']:
        p=SYS/name;b=p.read_bytes()
        b=b.replace(b'Sostegno ai progetti YQArch',b'Sostieni il progetto YQArch originale')
        b=b.replace(b'Sostieni YQArch originale e la versione italiana',b'Sostieni il progetto YQArch originale')
        p.write_bytes(b)
    p=SYS/'yqitaliano.lsp';s=p.read_bytes().decode('cp1252')
    s=s.replace(';; YQ_DONATE originale non sovrascritto: comportamento YQArch preservato.',
                ';; Alias storico associato alla pagina locale del solo progetto originale.')
    p.write_bytes(s.encode('cp1252'))
    p=SYS/'YQArchItaliano_Menu.lsp';b=p.read_bytes()
    b=b.replace(b'"YQARCHITALIANO_MENU_362" "YQARCHITALIANO_MENU_364"',
                b'"YQARCHITALIANO_MENU_362" "YQARCHITALIANO_MENU_363" "YQARCHITALIANO_MENU_364"')
    p.write_bytes(b)
    script=migrate((ROOT/'work363/installer363.ps1').read_bytes()).replace(b'363_UI_',b'364_UI_')
    script=script.replace(b"'YQArchItaliano_Menu_362','YQArchItaliano_Menu_364'",
                          b"'YQArchItaliano_Menu_362','YQArchItaliano_Menu_363','YQArchItaliano_Menu_364'")
    (W/'installer364.ps1').write_bytes(script)

    for name in ['copertura_menu.csv','menu_expected.json','menu_tree.json','mappa_icone.csv','registro_fuori_menu_principale.txt']:
        b=(ROOT/'work363/reports'/name).read_bytes()
        if name=='mappa_icone.csv':b=b.replace(b'ID_tb363_',b'ID_tb364_')
        (R/name).write_bytes(b)
    # The historical audits remain separately attributed rather than relabeled as new tests.
    hist=R/'storico_3.63';hist.mkdir(exist_ok=True)
    for name in ['AUDIT_MENU_ICONE_3.63.md','metriche_363.json','release_notes.md']:
        shutil.copy2(ROOT/'work363/reports'/name,hist/name)
    print('3.64 prepared: separate recipients, both Italian payment methods restored.')

if __name__=='__main__':main()
