"""Complete 3.64 packages from the immutable 3.63 native launcher and corrected payload."""
from pathlib import Path
import io,zipfile,struct,hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work364';REL=W/'release';REPORTS=W/'reports';OUT=ROOT/'output364'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pack(entries,padding=0):
    out=io.BytesIO();out.write(b'\0'*padding)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(entries.items()):
            info=zipfile.ZipInfo(name,(2026,9,27,16,20,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compresslevel=9)
    return out.getvalue()
def main():
    OUT.mkdir(exist_ok=True)
    old=(ROOT/'output363/YQArch_Italiano_3.63.exe').read_bytes()
    assert sha(old)=='91b7d78a674c30ab620ea793a0429616181995ebcf64bcdd8faa358cfd6ea709','Baseline 3.63 differs'
    # Layout retained from the resource slots of the supplied launcher (3.61 -> 3.62).
    start=1008864;script_capacity=24694;zs=1033568;ze=19354782
    assert old[start:start+9]==b'\xef\xbb\xbfparam('
    assert old[start+script_capacity:zs]==b'\0'*10
    assert old[ze-22:ze-18]==b'PK\x05\x06'
    with zipfile.ZipFile(io.BytesIO(old[zs:ze])) as z:assert z.testzip() is None
    script=(W/'installer364.ps1').read_bytes();assert len(script)<script_capacity
    files={str(p.relative_to(REL)):p.read_bytes() for p in REL.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json'}
    manifest=[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]
    files['MANIFEST_SHA256.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    (REL/'MANIFEST_SHA256.json').write_bytes(files['MANIFEST_SHA256.json'])
    small=pack(files);assert len(small)<=ze-zs,(len(small),ze-zs)
    payload=pack(files,ze-zs-len(small));assert len(payload)==ze-zs
    new=bytearray(old);new[start:start+script_capacity]=script+b'\r\n#'+b' '*(script_capacity-len(script)-3);new[zs:ze]=payload
    title=b'YQArch Italiano 3.63 - Errore avvio';assert new.count(title)==1;new=new.replace(title,b'YQArch Italiano 3.64 - Errore avvio')
    pe=struct.unpack_from('<I',old,60)[0];n=struct.unpack_from('<H',old,pe+6)[0];sz=struct.unpack_from('<H',old,pe+20)[0];exec_sections=[]
    for i in range(n):
        sec=pe+24+sz+40*i;length,ptr=struct.unpack_from('<II',old,sec+16);flags=struct.unpack_from('<I',old,sec+36)[0]
        if flags&0x20000000:assert old[ptr:ptr+length]==new[ptr:ptr+length];exec_sections.append(old[sec:sec+8].split(b'\0')[0].decode())
    assert len(new)==len(old)
    exe=OUT/'YQArch_Italiano_3.64.exe';exe.write_bytes(new)
    extracted=W/'extracted_exe'
    if extracted.exists():shutil.rmtree(extracted)
    with zipfile.ZipFile(io.BytesIO(exe.read_bytes()[zs:ze])) as z:
        assert z.testzip() is None;z.extractall(extracted)
    for row in manifest:assert sha((extracted/row['path']).read_bytes())==row['sha256']
    check={'version':'3.64','baseline':'3.63','exe_bytes':len(new),'payload_files':len(files),'payload_zip_bytes':len(small),'sha256_files_verified_after_extract':len(manifest),'zip_crc':'PASS','native_executable_sections_unchanged':exec_sections,'powershell_script_bytes':len(script),'native_windows_execution':'NON ESEGUITA','notes':'Launcher nativo 3.63 riutilizzato, script e payload completi ricostruiti; non ricompilato da sorgente.'}
    (REPORTS/'verifica_pacchetto.json').write_text(json.dumps(check,ensure_ascii=False,indent=2))
    full=dict(files)
    for p in REPORTS.rglob('*'):
        if p.is_file() and p.name!='verifica_zip.json':full['AUDIT/'+str(p.relative_to(REPORTS))]=p.read_bytes()
    for dirname in ['src','tests']:
        for p in (W/dirname).rglob('*'):
            if p.is_file() and p.suffix in ('.py','.lsp','.ps1') and '__pycache__' not in str(p):full['SVILUPPO/'+dirname+'/'+str(p.relative_to(W/dirname))]=p.read_bytes()
    full['SVILUPPO/installer364.ps1']=script
    full['SVILUPPO/lisp_tools.py']=(ROOT/'work/src/lisp_tools.py').read_bytes()
    full['SVILUPPO/README.txt']='Requisiti: Python 3, Pillow, lxml. Conservare i pacchetti precedenti: i sorgenti del core compilato e del launcher Windows non sono disponibili.\nLayout richiesto nella cartella di lavoro: output363/YQArch_Italiano_3.63.exe; work363/release (payload 3.63); work363/installer363.ps1; work363/reports (audit 3.63); output363/YQArch_Italiano_3.63_REPORT.html; work/release (payload 3.62); baseline/YQArch_Italiano_3.61/YQArchItaliano/sys; work/src/lisp_tools.py. Copiare src e tests da questo archivio in work364/src e work364/tests.\nPer il payload 3.63, estrarre dall’EXE l’intervallo [1033568:19354782] come ZIP; lo script PowerShell è nei byte [1008864:1033558] con BOM UTF-8 e commento finale di padding. Il pacchetto ZIP completo 3.63 contiene installer e audit precedenti.\nOrdine: prepare364.py, test_regression.py, test_menu364.py, test_support364.py, docs364.py, build364.py. Gli script sono in work364/src, i test in work364/tests. Output in output364. I test simulati non sostituiscono AutoCAD.\n'.encode()
    full['YQArch_Italiano_3.64_GUIDA.html']=(OUT/'YQArch_Italiano_3.64_GUIDA.html').read_bytes()
    full['YQArch_Italiano_3.64_REPORT.html']=(OUT/'YQArch_Italiano_3.64_REPORT.html').read_bytes()
    full['SHA256.txt']=''.join(sha(b)+'  '+name+'\n' for name,b in sorted(full.items())).encode()
    verification={'files':len(full)+1,'zip_crc':'PASS','all_members_compared_to_build':'PASS','runtime_manifest_verified_after_extraction':'PASS'}
    full['AUDIT/verifica_zip.json']=json.dumps(verification,indent=2).encode()
    zdata=pack(full);zpath=OUT/'YQArch_Italiano_3.64.zip';zpath.write_bytes(zdata)
    dest=W/'extracted_zip'
    if dest.exists():shutil.rmtree(dest)
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        for n,b in full.items():assert z.read(n)==b
        z.extractall(dest)
    for line in (dest/'SHA256.txt').read_text().splitlines():
        h,n=line.split('  ',1);assert sha((dest/n).read_bytes())==h,n
    for row in manifest:assert sha((dest/row['path']).read_bytes())==row['sha256']
    (REPORTS/'verifica_zip.json').write_text(json.dumps(verification,indent=2))
    names=['YQArch_Italiano_3.64.exe','YQArch_Italiano_3.64.zip','YQArch_Italiano_3.64_GUIDA.html','YQArch_Italiano_3.64_REPORT.html']
    (OUT/'SHA256.txt').write_text(''.join(sha((OUT/n).read_bytes())+'  '+n+'\n' for n in names))
    print(json.dumps(dict(check,complete_zip_bytes=len(zdata),complete_zip_files=len(full)),ensure_ascii=False))
if __name__=='__main__':main()
