# Installazione e ripristino — 3.64

## Installazione normale
1. Chiudere completamente AutoCAD. Conservare gli installer 3.60 e 3.61.
2. Eseguire YQArch_Italiano_3.64.exe nel proprio account Windows. Non richiede una modifica globale delle impostazioni di sicurezza.
3. L’installer aggiorna i profili AutoCAD completi già presenti nelle cartelle Support dell’utente. Conserva i file personali dei profili user1/user2/userCCD/userHBA esistenti e le scorciatoie.
4. I file sostituiti e le vecchie cache menu sono salvati in %LOCALAPPDATA%/YQArchItaliano/Backup/3.64_DATA_ID. Il journal elenca ogni destinazione e se esisteva prima dell’operazione.
5. Dopo l’installazione avviare AutoCAD e usare YQIT_DIAGNOSTICA_COMPLETA. Il risultato dell’installer certifica soltanto la copia/integrità dei file.

## ZIP e sistemi legacy
Estrarre tutto lo ZIP in una cartella stabile. Il plugin si trova in YQArchItaliano/sys. Per un profilo senza installazione precedente aggiungere tale cartella ai Percorsi di ricerca dei file di supporto; configurare i percorsi attendibili secondo le regole del proprio ambiente. Caricare YQArchItaliano_Bootstrap.lsp con APPLOAD e inserirlo nel Gruppo di avvio. Verificare il caricamento in un secondo DWG.

Per un aggiornamento manuale fare prima una copia dell’intera cartella YQArch esistente. Conservare i file personali; sostituire i file distribuiti con quelli nuovi. Le risorse compilate yqarch/gyqarch .mns/.mnc/.mnr/.cui/.cuix della vecchia installazione vanno spostate nel backup, così AutoCAD usa il nuovo MNU. Non toccare acad.cuix, il menu principale o i workspace dell’utente.

Non sostituire l’acad.lsp/acaddoc.lsp personale con quello del pacchetto: aggiungere, se necessario, la sola chiamata al bootstrap preservando le altre routine. Non editare acad2027.lsp o acad2027doc.lsp e gli equivalenti delle altre release.

## Ripristino
In caso di errore o annullamento l’installer tenta automaticamente il ripristino di tutti i file già modificati. I backup persistono. Un arresto del sistema o un ripristino incompleto richiedono il recupero dal journal, a AutoCAD chiuso: copiare backup su target per le voci existed=true e rimuovere soltanto i target creati da questa installazione per existed=false. Verificare i percorsi prima del recupero. Le cartelle vuote possono restare.

L’installer non elimina intere cartelle di versioni precedenti, non modifica il registro e non chiude forzatamente AutoCAD. Vecchie chiamate personalizzate non riconosciute vengono conservate: eventuali percorsi esterni o copie del core caricati da routine personali richiedono il report diagnostico per essere identificati.

## Menu e DLL immagini 3.64
Tenere nella stessa cartella YQArchItaliano_Menu_364.mnu, .mnl, .dll e _light.dll. Per aggiornamento manuale mettere nel backup anche le cache YQArchItaliano_Menu_362, YQArchItaliano_Menu_363 e YQArchItaliano_Menu_364 con estensioni .mns/.mnc/.mnr/.cui/.cuix; non eliminare DLL, menu di altre applicazioni o il CUIx principale. Caricare il bootstrap e verificare le 23 categorie.
