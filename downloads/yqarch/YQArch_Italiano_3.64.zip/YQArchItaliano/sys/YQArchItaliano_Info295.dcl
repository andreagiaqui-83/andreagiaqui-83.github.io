
yqit_original_version : dialog {
  label = "[YQArch Italiano] - Versione originale di YQArch";
  : boxed_column {
    label = "YQArch originale";
    : text { label = "Versione: 6.7.4"; }
    : text { label = "Data release: 07/04/2022"; }
    : text { label = "Autore originale: Walter Lam"; }
    : text { label = "Progetto: Yuanquan Architecture (YQArch)"; }
    spacer;
    : text { label = "Questa informazione riguarda il motore YQArch originale"; }
    : text { label = "integrato nella versione italiana."; }
  }
  : row {
    : button { key="site"; label="Sito ufficiale"; width=18; fixed_width=true; }
    : button { key="support"; label="Sostieni il progetto originale"; width=28; fixed_width=true; }
  }
  spacer;
  ok_only;
}

yqit_original_about : dialog {
  label = "[YQArch Italiano] - Informazioni sulla versione originale";
  : boxed_column {
    label = "Yuanquan Architecture (YQArch)";
    : text { label = "Software CAD per disegno architettonico e decorazione."; }
    : text { label = "Versione originale: 6.7.4 - 07/04/2022"; }
    : text { label = "Autore originale: Walter Lam"; }
    spacer;
    : text { label = "Sito ufficiale: yqarch.cn"; }
    : text { label = "Le risorse originali possono essere disponibili in cinese."; }
    spacer;
    : text { label = "YQArch Italiano � un'edizione italiana moderna e indipendente"; }
    : text { label = "basata sul motore originale, con interfacce e comandi progressivamente modernizzati."; }
  }
  : row {
    : button { key="site"; label="Sito ufficiale"; width=18; fixed_width=true; }
    : button { key="support"; label="Pagina di sostegno"; width=22; fixed_width=true; }
  }
  spacer;
  ok_only;
}
