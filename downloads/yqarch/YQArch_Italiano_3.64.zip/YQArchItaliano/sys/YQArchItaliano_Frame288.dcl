yqit_frame : dialog {
  label = "[YQArch Italiano] - Cornice disegno";
  : row {
    : boxed_column {
      label = "Formato";
      : radio_row {
        : radio_button { key="a0"; label="A0"; }
        : radio_button { key="a1"; label="A1"; }
        : radio_button { key="a2"; label="A2"; }
        : radio_button { key="a3"; label="A3"; value="1"; }
        : radio_button { key="a4"; label="A4"; }
      }
      : edit_box { key="width"; label="Larghezza (mm):"; edit_width=12; value="420"; }
      : edit_box { key="height"; label="Altezza (mm):"; edit_width=12; value="297"; }
      : boxed_column {
        label = "Margini";
        : edit_box { key="leftoff"; label="Margine sinistro (mm):"; edit_width=10; value="25"; }
        : edit_box { key="otheroff"; label="Altri margini (mm):"; edit_width=10; value="5"; }
      }
      : edit_box { key="thick"; label="Spessore della linea (mm):"; edit_width=10; value="0.25"; }
    }
    : boxed_column {
      label = "Impostazioni";
      : edit_box { key="layer"; label="Layer cornice:"; edit_width=14; value="TK"; }
      : boxed_column {
        label = "Orientamento";
        : radio_row {
          : radio_button { key="land"; label="Orizzontale"; value="1"; }
          : radio_button { key="port"; label="Verticale"; }
        }
      }
      : popup_list { key="extra"; label="Cornice aggiuntiva:"; width=24; }
      : boxed_column {
        label = "Cartiglio";
        : radio_column {
          : radio_button { key="std"; label="Predefinito"; value="1"; }
          : radio_button { key="full"; label="A tutta larghezza"; }
          : radio_button { key="block"; label="Da blocco"; }
          : radio_button { key="none"; label="Nessuna"; }
        }
      }
      : edit_box { key="scale"; label="Scala del disegno 1:"; edit_width=10; value="100"; }
    }
  }
  : text { label="La cornice viene creata nel disegno corrente usando il runtime italiano nativo."; }
  : button { key="reset"; label="Ripristina valori predefiniti"; width=38; fixed_width=true; alignment=centered; }
  spacer;
  ok_cancel;
}
