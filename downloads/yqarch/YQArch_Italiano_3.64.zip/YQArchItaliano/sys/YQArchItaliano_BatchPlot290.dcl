yqit_batchplot : dialog {
  label = "[YQArch Italiano] - Stampa multipla";
  width = 94;
  : row {
    : radio_button { key = "p1"; label = "Impostazione 1"; value = "1"; }
    : radio_button { key = "p2"; label = "Impostazione 2"; }
    : radio_button { key = "p3"; label = "Impostazione 3"; }
    : radio_button { key = "p4"; label = "Impostazione 4"; }
    : radio_button { key = "p5"; label = "Impostazione 5"; }
  }
  : row {
    : boxed_column {
      label = "Impostazioni di stampa";
      width = 61;
      : popup_list { key = "printer"; label = "Stampante:"; width = 52; }
      : popup_list { key = "paper"; label = "Formato carta:"; width = 52; }
      : row {
        : edit_box { key = "ctb"; label = "Stile di stampa CTB/STB:"; value = "acad.stb"; edit_width = 34; }
        : button { key = "modify"; label = "Modifica"; width = 12; }
      }
      : row {
        : toggle { key = "fit"; label = "Adatta al foglio"; value = "1"; }
        : text { label = "Scala di stampa:"; }
        : edit_box { key = "sc1"; value = "1"; edit_width = 6; }
        : edit_box { key = "sc2"; value = "100"; edit_width = 6; }
      }
      : row {
        : toggle { key = "plt"; label = "Genera file .plt"; }
        : toggle { key = "reverse"; label = "Stampa in direzione opposta"; }
        : edit_box { key = "setnum"; label = "Impostazione di stampa (0-100):"; value = "1"; edit_width = 6; }
      }
      : row {
        : edit_box { key = "out"; label = "Cartella di output:"; value = "D:/"; edit_width = 37; }
        : button { key = "browse"; label = "Sfoglia"; width = 11; }
      }
      : list_box { key = "outlist"; height = 4; width = 54; }
      : row {
        : edit_box { key = "prefix"; label = "Prefisso nome file:"; value = "nome"; edit_width = 12; }
        : edit_box { key = "start"; label = "Numero iniziale:"; value = "01"; edit_width = 6; }
        : toggle { key = "inc"; label = "Incrementa"; }
        : edit_box { key = "pre"; label = "Prefisso:"; edit_width = 7; }
      }
      : row {
        : toggle { key = "attrname"; label = "Nome file da attributi del blocco"; }
        : toggle { key = "snattr"; label = "Aggiungi numero progressivo prima degli attributi"; }
      }
      : row {
        : edit_box { key = "tag1"; label = "Tag attributo 1:"; edit_width = 12; }
        : button { key = "pick1"; label = "Preleva"; width = 10; }
        : edit_box { key = "tag2"; label = "Tag attributo 2:"; edit_width = 12; }
        : button { key = "pick2"; label = "Preleva"; width = 10; }
      }
      : row {
        : edit_box { key = "tag3"; label = "Tag attributo 3:"; edit_width = 12; }
        : button { key = "pick3"; label = "Preleva"; width = 10; }
        : edit_box { key = "tag4"; label = "Tag attributo 4:"; edit_width = 12; }
        : button { key = "pick4"; label = "Preleva"; width = 10; }
      }
      : toggle { key = "preview"; label = "Anteprima di stampa"; value = "1"; }
      : boxed_column {
        label = "Note";
        : text { label = "1) Il numero iniziale pu� essere 1, 01, 001..."; }
        : text { label = "2) Sono disponibili blocchi e polilinee chiuse."; }
        : text { label = "3) La rotazione pu� essere automatica quando necessario."; }
        : text { label = "4) DWG To PDF.pc3 non pu� scrivere direttamente nell'unit� C:."; }
        : text { label = "5) Le cornici devono essere parallele al sistema WCS."; }
      }
    }
    : boxed_column {
      label = "Impostazioni cornice";
      width = 31;
      : popup_list { key = "sel"; label = "Selezione:"; width = 25; }
      : text { label = "Per la stampa multipagina � necessario definire i nomi dei blocchi."; width = 30; }
      : row {
        : toggle { key = "limlay"; label = "Limita per layer"; }
        : toggle { key = "limblk"; label = "Limita per blocco"; }
      }
      : button { key = "pickframe"; label = "Seleziona blocco/layer"; width = 25; }
      : edit_box { key = "blk"; label = "Nome blocco:"; edit_width = 16; }
      : edit_box { key = "otherblk"; label = "Altro blocco:"; value = "YQFRAME*"; edit_width = 16; }
      : edit_box { key = "lay"; label = "Nome layer:"; edit_width = 16; }
      : edit_box { key = "otherlay"; label = "Altro nome layer:"; value = "TK*"; edit_width = 16; }
      : text { label = "Ordinamento di stampa:"; }
      : list_box { key = "sort"; height = 14; width = 29; }
    }
  }
  : button { key = "reset"; label = "Ripristina valori predefiniti"; width = 44; fixed_width = true; alignment = centered; }
  spacer;
  ok_cancel;
}
