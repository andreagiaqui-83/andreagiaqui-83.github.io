;;; YQArch Italiano 3.35 - modulo Griglia assi
;;; Caricato DOPO YQArchItaliano_Runtime.lsp.

(setq *YQIT-GRID273-X* "3900*5")
(setq *YQIT-GRID273-Y* "3900 3900 3900")
(setq *YQIT-GRID273-SYMDIM* "1")

(defun yqit273-str-or (v fallback)
  (if (= (type v) 'STR) v fallback))

(defun yqit273-grid-dialog (/ dcl id res sx sy sv)
  (setq dcl (findfile "YQArchItaliano_Grid273.dcl"))
  (if (null dcl)
    nil
    (progn
      (setq id (load_dialog dcl))
      (if (and (= (type id) 'INT) (> id 0) (new_dialog "yqit_grid273" id))
        (progn
          (setq sx (getenv "YQIT_GRID_X"))
          (setq sy (getenv "YQIT_GRID_Y"))
          (setq sx (yqit273-str-or sx "3900*5"))
          (setq sy (yqit273-str-or sy "3900 3900 3900"))
          (setq *YQIT-GRID273-X* sx)
          (setq *YQIT-GRID273-Y* sy)
          (setq *YQIT-GRID273-SYMDIM* "1")
          (set_tile "gx" sx)
          (set_tile "gy" sy)
          (set_tile "symdim" "1")
          (action_tile "gx" "(setq *YQIT-GRID273-X* $value)")
          (action_tile "gy" "(setq *YQIT-GRID273-Y* $value)")
          (action_tile "symdim" "(setq *YQIT-GRID273-SYMDIM* $value)")
          (action_tile "reset" "(progn (set_tile \"gx\" \"3900*5\") (set_tile \"gy\" \"3900 3900 3900\") (set_tile \"symdim\" \"1\") (setq *YQIT-GRID273-X* \"3900*5\" *YQIT-GRID273-Y* \"3900 3900 3900\" *YQIT-GRID273-SYMDIM* \"1\"))")
          (action_tile "accept" "(progn (setq *YQIT-GRID273-X* (get_tile \"gx\") *YQIT-GRID273-Y* (get_tile \"gy\") *YQIT-GRID273-SYMDIM* (get_tile \"symdim\")) (done_dialog 1))")
          (action_tile "cancel" "(done_dialog 0)")
          (setq res (start_dialog))
          (unload_dialog id)
          (if (= res 1)
            (list
              (yqit273-str-or *YQIT-GRID273-X* "3900*5")
              (yqit273-str-or *YQIT-GRID273-Y* "3900 3900 3900")
              (yqit273-str-or *YQIT-GRID273-SYMDIM* "1"))
            nil))
        (progn
          (if (and (= (type id) 'INT) (> id 0)) (unload_dialog id))
          nil)))))

(defun yqit273-grid-run (/ vals sx sy sv xv yv base sym)
  (setq vals (yqit273-grid-dialog))
  (if vals
    (progn
      (setq sx (car vals))
      (setq sy (cadr vals))
      (setq sv (caddr vals))
      (if (and (= (type sx) 'STR) (= (type sy) 'STR) (= (type sv) 'STR))
        (progn
          (setq xv (yqit-grid-parse sx))
          (setq yv (yqit-grid-parse sy))
          (if (and xv yv)
            (progn
              (setenv "YQIT_GRID_X" sx)
              (setenv "YQIT_GRID_Y" sy)
              (setq base (vl-catch-all-apply 'getpoint (list "\nSpecificare il punto base della griglia assi: ")))
              (if (vl-catch-all-error-p base) (setq base nil))
              (if base
                (progn
                  (setq sym (= sv "1"))
                  (yqit-grid-draw base (yqit-grid-cumulative xv) (yqit-grid-cumulative yv) sym)
                  (princ "\nGriglia assi creata."))))
            (alert "Le distanze inserite non sono valide.")))
        (alert "Errore nei dati della finestra Griglia assi."))))
  (princ))


;;; Motore geometrico Griglia assi con entit� native.
;;; Evita dipendenze COM fragili nella creazione di linee/simboli e valida ogni punto.
(defun yqit285-point-p (p)
  (and (= (type p) 'LIST)
       (>= (length p) 2)
       (numberp (car p))
       (numberp (cadr p))))

(defun yqit285-num-list-p (lst / ok)
  (setq ok (= (type lst) 'LIST))
  (if ok
    (foreach v lst (if (not (numberp v)) (setq ok nil))))
  ok)

(defun yqit285-pt3 (x y)
  (list (float x) (float y) 0.0))

(defun yqit285-ent-line (p1 p2 layer)
  (if (and (yqit285-point-p p1) (yqit285-point-p p2) (= (type layer) 'STR))
    (entmakex (list '(0 . "LINE") '(100 . "AcDbEntity") (cons 8 layer)
                    '(100 . "AcDbLine") (cons 10 p1) (cons 11 p2)))))

(defun yqit285-ent-circle (pt radius layer)
  (if (and (yqit285-point-p pt) (numberp radius) (> radius 0.0) (= (type layer) 'STR))
    (entmakex (list '(0 . "CIRCLE") '(100 . "AcDbEntity") (cons 8 layer)
                    '(100 . "AcDbCircle") (cons 10 pt) (cons 40 radius)))))

(defun yqit285-ent-text (pt height text layer)
  (if (and (yqit285-point-p pt) (numberp height) (> height 0.0)
           (= (type text) 'STR) (= (type layer) 'STR))
    (entmakex (list '(0 . "TEXT") '(100 . "AcDbEntity") (cons 8 layer)
                    '(100 . "AcDbText") (cons 10 pt) (cons 40 height) (cons 1 text)
                    (cons 7 (getvar "TEXTSTYLE")) '(50 . 0.0)))))

(defun yqit285-safe-dim (space p1 p2 dimpt)
  (if (and (yqit285-point-p p1) (yqit285-point-p p2) (yqit285-point-p dimpt))
    (vl-catch-all-apply 'vla-AddDimAligned
      (list space (vlax-3d-point p1) (vlax-3d-point p2) (vlax-3d-point dimpt)))))

(defun yqit-grid-draw (base xs ys symdim / doc space axisLayer symLayer xTotal yTotal
                       x y p1 p2 r off idx letters prev cur h tx ty)
  (vl-load-com)
  (if (not (yqit285-point-p base))
    (progn (alert "Punto base della griglia non valido.") nil)
    (if (or (not (yqit285-num-list-p xs)) (not (yqit285-num-list-p ys)))
      (progn (alert "Distanze della griglia non valide.") nil)
      (progn
        (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
              space (if (= 1 (getvar "CVPORT")) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
              axisLayer (yqit273-str-or (yqit-config-get "AXIS_LAYER_NAME") "DOTE")
              symLayer (yqit273-str-or (yqit-config-get "SYMBOL_AXIS_LAYER_NAME") axisLayer)
              xTotal 0.0 yTotal 0.0)
        (foreach x xs (if (> x xTotal) (setq xTotal x)))
        (foreach y ys (if (> y yTotal) (setq yTotal y)))
        (yqit-ensure-layer-native axisLayer 1)
        (yqit-ensure-layer-native symLayer 3)

        ;; Linee verticali e orizzontali: entit� native, senza conversioni COM dei punti.
        (foreach x xs
          (yqit285-ent-line
            (yqit285-pt3 (+ (car base) x) (cadr base))
            (yqit285-pt3 (+ (car base) x) (+ (cadr base) yTotal)) axisLayer))
        (foreach y ys
          (yqit285-ent-line
            (yqit285-pt3 (car base) (+ (cadr base) y))
            (yqit285-pt3 (+ (car base) xTotal) (+ (cadr base) y)) axisLayer))

        (if symdim
          (progn
            (setq r (distof (yqit273-str-or (yqit-config-get "SYMBOL_AXIS_RADIUS") "4") 2))
            (if (or (null r) (not (numberp r)) (<= r 0.0)) (setq r 4.0))
            (setq off (* r 2.5) h (* r 0.9) idx 1)
            (foreach x xs
              (setq tx (+ (car base) x) ty (- (cadr base) off))
              (yqit285-ent-circle (yqit285-pt3 tx ty) r symLayer)
              (yqit285-ent-text (yqit285-pt3 (- tx (* h 0.35)) (- ty (* h 0.5))) h (itoa idx) symLayer)
              (setq idx (1+ idx)))
            (setq letters "ABCDEFGHJKLMNPQRSTUVWXY" idx 1)
            (foreach y ys
              (setq tx (- (car base) off) ty (+ (cadr base) y))
              (yqit285-ent-circle (yqit285-pt3 tx ty) r symLayer)
              (yqit285-ent-text (yqit285-pt3 (- tx (* h 0.35)) (- ty (* h 0.5))) h
                                (if (<= idx (strlen letters)) (substr letters idx 1) (itoa idx)) symLayer)
              (setq idx (1+ idx)))

            ;; Quote: ogni quota � protetta; un errore non interrompe la griglia.
            (setq prev nil)
            (foreach cur xs
              (if prev
                (progn
                  (setq p1 (yqit285-pt3 (+ (car base) prev) (cadr base))
                        p2 (yqit285-pt3 (+ (car base) cur) (cadr base)))
                  (yqit285-safe-dim space p1 p2
                    (yqit285-pt3 (/ (+ (car p1) (car p2)) 2.0) (- (cadr base) (* off 2.0)))))
              (setq prev cur))
            (setq prev nil)
            (foreach cur ys
              (if prev
                (progn
                  (setq p1 (yqit285-pt3 (car base) (+ (cadr base) prev))
                        p2 (yqit285-pt3 (car base) (+ (cadr base) cur)))
                  (yqit285-safe-dim space p1 p2
                    (yqit285-pt3 (- (car base) (* off 2.0)) (/ (+ (cadr p1) (cadr p2)) 2.0))))
              (setq prev cur))))
        (vla-Regen doc 1)
        T))))))

(defun c:YQ_GRIDAXIS () (yqit273-grid-run))
(defun c:YQIT_GRIDAXIS () (yqit273-grid-run))

;;; Registrazione forte DOPO il runtime: evita che AutoCAD continui a
;;; eseguire la precedente yqit-grid-native registrata con VLAX-ADD-CMD.
(vl-load-com)
(vl-catch-all-apply 'vlax-remove-cmd (list "YQ_GRIDAXIS"))
(setq *YQIT-GRID-REGISTER-RESULT*
  (vl-catch-all-apply 'vlax-add-cmd (list "YQ_GRIDAXIS" 'yqit273-grid-run "YQ_GRIDAXIS" 0)))
(if (vl-catch-all-error-p *YQIT-GRID-REGISTER-RESULT*)
  (princ "\nYQArch Italiano 3.35: ATTENZIONE - registrazione Griglia assi non riuscita.")
  (princ))

(princ)
(princ)
