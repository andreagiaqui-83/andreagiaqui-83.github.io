;;; YQArch Italiano 3.64 - menu unico alla sorgente e migrazione dei gruppi legacy.
;;; Non modifica CUI principali, workspace o menu di altre applicazioni.
(vl-load-com)

(defun yqit364-get (obj prop / r)
  (setq r (vl-catch-all-apply 'vlax-get-property (list obj prop)))
  (if (vl-catch-all-error-p r) nil r))

(defun yqit364-owned-group (g / n f b)
  (setq n (strcase (vla-get-Name g))
        f (yqit364-get g 'MenuFileName)
        b (if f (strcase (vl-filename-base f)) ""))
  (or (member n '("YQARCH" "GYQARCH" "YQARCHITALIANO_TEST"))
      (member b '("YQARCH" "GYQARCH" "YQARCHITALIANO_MENU_362" "YQARCHITALIANO_MENU_363" "YQARCHITALIANO_MENU_364"))))

(defun yqit364-menu-snapshot (/ gs g ms m out)
  (setq out nil gs (vla-get-MenuGroups (vlax-get-acad-object)))
  (vlax-for g gs
    (if (yqit364-owned-group g)
      (progn
        (setq ms (vla-get-Menus g))
        (vlax-for m ms
          (setq out (cons (list (vla-get-Name g)
                               (yqit364-get g 'MenuFileName)
                               (vla-get-Name m)
                               (= :vlax-true (vla-get-OnMenuBar m))) out))))))
  (reverse out))

(defun yqit364-menu-count (/ n row)
  (setq n 0)
  (foreach row (yqit364-menu-snapshot)
    (if (nth 3 row) (setq n (1+ n))))
  n)

(defun yqit364-menu-main (g / m found)
  (setq found nil)
  (if g
    (vlax-for m (vla-get-Menus g)
      (if (= (strcase (vla-get-Name m)) "YQARCH ITALIANO")
        (setq found m))))
  found)

(defun yqit364-menu-valid (g / f)
  (setq f (if g (yqit364-get g 'MenuFileName)))
  (and f (= (strcase (vl-filename-base f)) "YQARCHITALIANO_MENU_364")
       (yqit364-menu-main g)))

(defun yqit364-menu-ensure (force / src gs g main r oldnames oldfiles n f ok bad current)
  (setq src (strcat (yqit-sysdir) "\\YQArchItaliano_Menu_364.mnu")
        gs (vla-get-MenuGroups (vlax-get-acad-object))
        g (yqit-menu-group)
        ok nil bad nil oldnames nil oldfiles nil)
  (if (not (findfile src))
    (princ "\nYQArch Italiano: sorgente menu 3.64 non trovata.")
    (progn
      (if (or force (not (yqit364-menu-valid g)) (> (yqit364-menu-count) 1))
        (progn
          ;; Memorizza solo nomi/percorsi: nessun riferimento a popup sopravvive a Unload.
          (vlax-for current gs
            (if (yqit364-owned-group current)
              (if (= 0 (vla-get-Type current))
                (setq bad T)
                (progn
                  (setq oldnames (cons (vla-get-Name current) oldnames))
                  (setq oldfiles (cons (yqit364-get current 'MenuFileName) oldfiles))))))
          (if bad
            (princ "\nYQArch Italiano: un menu YQArch e' configurato come menu principale. Migrazione automatica sospesa; consultare la diagnostica.")
            (progn
              (setq g nil main nil current nil)
              (foreach n oldnames
                (setq r (vl-catch-all-apply 'vla-Unload (list (vla-Item gs n))))
                (if (vl-catch-all-error-p r) (setq bad T)))
              (if (not bad)
                (progn
                  (setq r (vl-catch-all-apply 'vla-Load (list gs src)))
                  (if (vl-catch-all-error-p r)
                    (progn
                      (foreach f oldfiles
                        (if (and f (findfile f)) (vl-catch-all-apply 'vla-Load (list gs f))))
                      (princ (strcat "\nYQArch Italiano: caricamento menu fallito; ripristino precedente tentato. "
                                     (vl-catch-all-error-message r))))
                    (setq g r))))))))
      (if (and (not bad) (yqit364-menu-valid g))
        (progn
          (setq main (yqit364-menu-main g))
          (if (/= :vlax-true (vla-get-OnMenuBar main))
            (vl-catch-all-apply 'vla-InsertInMenuBar (list main "")))
          (setq ok (and (= 1 (yqit364-menu-count))
                        (= :vlax-true (vla-get-OnMenuBar main))))
          (if ok (setenv "YQIT_MENU_VERSION" "3.64"))))))
  (if (not ok)
    (princ "\nYQArch Italiano: menu da verificare con YQIT_DIAGNOSTICA_COMPLETA."))
  ok)

;;; YQArch Italiano 3.64 - verifica della gerarchia realmente caricata.
(if (findfile "YQArchItaliano_Menu_Expected_364.lsp")
  (load "YQArchItaliano_Menu_Expected_364.lsp"))

(defun yqit364-menu-leaves (menu / item kind macro out)
  (setq out nil)
  (vlax-for item menu
    (setq kind (vla-get-Type item))
    (cond
      ((= kind 2)
        (setq out (append out (yqit364-menu-leaves (vla-get-SubMenu item)))))
      ((= kind 0)
        (setq macro (vla-get-Macro item))
        (if (and macro (/= "" (vl-string-trim " \t\r\n" macro)))
          (setq out (cons (strcase macro) out))))))
  out)

(defun yqit364-menu-has-command (macros cmd / found macro)
  (setq found nil)
  (foreach macro macros
    (if (vl-string-search (strcat cmd " ") (strcat macro " ")) (setq found T)))
  found)

(defun yqit364-menu-audit-lines (/ grp main roots item row target leaves missing cmd good lines file stem full total)
  (setq grp (yqit-menu-group) main (yqit364-menu-main grp)
        roots nil total 0 good T
        lines (list "VERIFICA STRUTTURA MENU 3.64 (lettura ActiveX, nessun comando eseguito)"))
  (if (not main)
    (setq good nil lines (append lines (list "FAIL: menu principale italiano non trovato.")))
    (progn
      (vlax-for item main
        (if (= 2 (vla-get-Type item))
          (setq roots (cons (cons (vla-get-Caption item) (vla-get-SubMenu item)) roots))))
      (if (not *YQIT-MENU-EXPECTED*)
        (setq good nil lines (append lines (list "FAIL: specifica della gerarchia attesa non caricata.")))
        (progn
          (setq lines (append lines (list (strcat "Categorie principali: " (itoa (length roots))
                  "/" (itoa (length *YQIT-MENU-EXPECTED*))))))
          (if (/= (length roots) (length *YQIT-MENU-EXPECTED*)) (setq good nil))
          (foreach row *YQIT-MENU-EXPECTED*
            (setq target (assoc (car row) roots) missing nil)
            (if (not target)
              (setq good nil lines (append lines (list (strcat "FAIL categoria assente o annidata: " (car row)))))
              (progn
                (setq leaves (yqit364-menu-leaves (cdr target)) total (+ total (length leaves)))
                (foreach cmd (caddr row)
                  (if (not (yqit364-menu-has-command leaves cmd)) (setq missing (cons cmd missing))))
                (if (or missing (/= (length leaves) (cadr row))) (setq good nil))
                (setq lines (append lines (list
                  (strcat (if (and (not missing) (= (length leaves) (cadr row))) "PASS " "FAIL ")
                          (car row) ": " (itoa (length leaves)) "/" (itoa (cadr row)) " voci eseguibili."))))
                (if missing (setq lines (append lines (list (strcat "  Macro mancanti: " (vl-princ-to-string (reverse missing))))))))))
          (setq lines (append lines (list (strcat "Totale voci eseguibili nelle categorie attese: " (itoa total)))))))))
  (setq file (if grp (yqit364-get grp 'MenuFileName)))
  (if file
    (progn
      (setq stem (strcat (vl-filename-directory file) "\\" (vl-filename-base file)))
      (foreach full (list (strcat stem ".dll") (strcat stem "_light.dll"))
        (setq lines (append lines (list (strcat (if (findfile full) "PRESENTE " "MANCANTE ") full))))
        (if (not (findfile full)) (setq good nil))))
    (setq good nil lines (append lines (list "FAIL: percorso menu non disponibile per verifica DLL icone."))))
  (setq lines (append lines (list
    (if good "Struttura menu e file DLL icone: PASS." "Struttura menu o file DLL icone: FAIL; leggere le righe precedenti.")
    "La presenza delle DLL non certifica la resa visiva delle icone. Confrontare menu e barre a schermo."
    "Il registro di 646 comandi comprende anche pannelli e helper: 471 sono esposti nel menu storico come comandi singoli.")))
  lines)

(defun yqit364-menu-audit-safe (/ r)
  (setq r (vl-catch-all-apply 'yqit364-menu-audit-lines nil))
  (if (vl-catch-all-error-p r)
    (list (strcat "Verifica struttura menu non completata: " (vl-catch-all-error-message r)))
    r))

(defun c:YQIT_VERIFICA_MENU (/ rows n row lines path f)
  (setq rows (yqit364-menu-snapshot) n (yqit364-menu-count)
        lines (list (strcat "Menu YQArch visibili: " (itoa n) "; atteso: 1.")))
  (foreach row rows (setq lines (append lines (list (vl-princ-to-string row)))))
  (setq lines (append lines (yqit364-menu-audit-safe))
        path (strcat (getvar "TEMPPREFIX") "YQArch_Italiano_Verifica_Menu_3.64.txt"))
  (foreach row lines (princ (strcat "\n" row)))
  (if (setq f (open path "w"))
    (progn (foreach row lines (write-line row f)) (close f) (princ (strcat "\nReport: " path))))
  (princ))
(princ)
