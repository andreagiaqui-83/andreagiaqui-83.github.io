(defun c:1`()
  (setvar "TILEMODE" (if (= (getvar "TILEMODE") 0) 1 0))
)
(defun c:``()
  (command (if (yq_ismodelspace) "_.PSPACE" "_.MSPACE"))
)
(princ)  ; Ϊ���һ��
