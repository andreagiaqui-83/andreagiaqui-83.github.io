# Limiti 3.64

Restano da completare: eliminazione del ponte di traduzione a runtime, revisione di tutte le risorse compilate e delle preview contenenti testi, guida analitica per ogni comando, prove AutoCAD/Windows e misure prima/dopo. La presenza delle schede o l’esito di uno scanner non è una certificazione.
