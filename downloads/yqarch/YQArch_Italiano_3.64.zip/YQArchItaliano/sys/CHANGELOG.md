# YQArch Italiano 3.64

Corrette le due pagine di sostegno a partire dal pacchetto completo 3.63, conservato separatamente.

- Sostieni il progetto YQArch originale apre una pagina dedicata agli autori originali con i riferimenti originali già presenti nel pacchetto.
- Sostieni lo sviluppo di YQArch Italiano apre la pagina con PayPal (andrea.giaqui@gmail.com) e Postepay P2P (333 724 0544), recuperati senza modificarli dalla precedente pagina mista.
- Corrette le diciture di YQ_DONATE nei pannelli, nell’elenco comandi, nella guida e nel file scorciatoie distribuito. Il comando storico YQ_DONATE/yqjz apre la pagina originale. Il file scorciatoie personale esistente è conservato dall’installer, quindi la sua eventuale vecchia descrizione può rimanere; il collegamento apre comunque la pagina corretta.
- Entrambe le pagine mostrano i destinatari anche senza rete o JavaScript; nessun reindirizzamento automatico o modulo di pagamento.
- Guida aggiornata: la scheda YQ_DONATE descrive l’apertura della pagina, senza istruzioni generiche su layer o geometria.
- Pacchetto completo EXE e ZIP; migrazione delle cache menu 3.62/3.63/3.64 con backup. Le 23 categorie, 547 voci, 493 pulsanti e 458 riferimenti bitmap sono conservati. Le DLL associate assumono il nome Menu_364.

Verifiche: 22 controlli di regressione, 19 controlli menu/icone e 4 controlli di separazione destinatari e instradamento superati (45 totali). Le chiamate AutoLISP alle pagine sono eseguite da un simulatore limitato, non da AutoCAD. Lo script PowerShell conserva backup, ripristino e protezione dei file personali. Integrità dei pacchetti controllata dopo estrazione.

Evidenza utente sulla 3.63: AutoCAD 2027 italiano, 646/646 funzioni definite, 23/23 categorie, 547 voci, 1 menu visibile e DLL presenti. Bootstrap 1.281 ms, singola misura e non benchmark dell’avvio. Il log aggiuntivo mostra prompt italiani di muri/porte, griglia assi, numerazione e ricaricamento menu; non certifica la geometria o la resa visiva delle icone.

Limiti: nessuna esecuzione della 3.64 in AutoCAD/Windows in questo ambiente. Localizzazione nativa integrale, collaudo geometrico e completamento di tutte le schede guida restano attività aperte.


# YQArch Italiano 3.62 — note di rilascio

Stato: pacchetto costruito per collaudo; revisione nativa totale non completata né certificata. Baseline 3.61 immutata.

- Menu: una sola definizione principale POP1; menu contestuale POP0. Alias storici mantenuti e YQ_IRONFRAME conservato. File menu della release con nome distinto per evitare il riuso della cache 3.61.
- Caricamento: bootstrap per documento con protezione dalla ricorsione MNL e caricamenti ripetuti. Rimossi i due richiami al vecchio YQ_MENU durante lo startup core e la riscrittura automatica delle scorciatoie a ogni avvio.
- Panoramica: ripristinati 459 identificatori tecnici usando le scorciatoie originali; etichette e scorciatoie visibili preservate.
- Prompt: corretta la sostituzione che poteva non terminare per stringhe uguali o sostituzioni contenenti il testo cercato.
- Diagnostica: conteggio individuale delle funzioni comando, non semplice presenza dei simboli; controllo menu e percorsi; misura del bootstrap; correzione LISPSYS=2.
- Installer: rimosso il controllo di helper assenti; backup persistente prima delle scritture, hash, annullamento cooperativo e ripristino. Finestra da 1010×650 a 900×585. Layout XAML validato staticamente, non renderizzato su Windows.
- Core VLX, DLL, geometrie DWG, slide e font conservati byte per byte. Launcher nativo Go riutilizzato dalla 3.61, con risorse installer e payload ricostruiti; sorgente originale del launcher non disponibile.

Restano da completare: eliminazione del ponte di traduzione a runtime, revisione di tutte le risorse compilate e delle preview contenenti testi, guida analitica per ogni comando, prove AutoCAD/Windows e misure prima/dopo. La presenza delle schede o l’esito di uno scanner non è una certificazione.


---
## Cronologia precedente (testi storici, non nuova certificazione)

# Changelog YQArch Italiano

## 3.59
- Chiusura delle 89 UI residue: 148/148 interfacce grafiche rilevate certificate integralmente italiane.
- Stile comune DCL/VV uniformato e ripristino delle keyword tecniche `fixed_width/fixed_height`.
- 152 patch UI FAS4 a lunghezza invariata; SLB invariato.
- Classe C residua: 0.

## 3.56
- Chiusura globale della revisione linguistica del core storico con ulteriori patch FAS4 conservative a lunghezza invariata.
- Rifinitura del menu **Impostazioni e supporto** e sincronizzazione terminologica delle relative voci.
- Correzione dei caratteri accentati nelle DCL native e controllo sistematico delle codifiche.
- Guida italiana ampliata a 646/646 schede con procedure passo-passo, livelli di documentazione e ricerca.
- Mantenuti congelati SLB e moduli moderni gia collaudati.
- Rafforzati i test su LSP, DCL, pannelli, registro comandi, struttura FAS4 e packaging.

## 3.53
- Stabilizzazione dei pannelli Q5/Q7 e correzione dell'invocazione XC_SS.
- Normalizzazione del menu Impostazioni e supporto e separazione del sostegno al progetto originale da quello all'edizione italiana.
- Prima guida completa con 646 schede.
- Ulteriore revisione di Sezione porta, isolamento, retini e quote.

## 3.52
- Revisione massiva dei prompt e delle stringhe visibili del core.
- Loader esterno reso piu deterministico e silenzioso.
- Pulizia delle voci legacy dei pannelli/scorciatoie.

## 3.51
- Revisione massiva del core visibile: 284 stringhe FAS4 inglesi localizzate e 74 controparti cinesi neutralizzate in italiano, senza riallocare il FAS.
- Corretto `YQ_BANISTER`: rimosse tutte le variabili locali/formali `t` in conflitto con la costante AutoLISP `T`.
- Audit globale T/NIL, sintassi LSP/DCL, registro 646 comandi, packaging e riferimenti release-specifici.

## 3.49
- Onda 1: modernizzate UI Scala curva e Scala mobile; nuova anteprima Parapetto; core funzionale invariato.

# 3.48 - 2026-09-10

- Consolidamento grafico delle interfacce native.
- Porta scorrevole: lista preset non sovrapposta.
- Anteprime scale più tecniche e leggibili.
- Revisione terminologica e correzione refusi DCL esterni.
- Matrice di modernizzazione aggiornata con evidenza runtime 3.47.
- Core storico stabile preservato.

# 3.48 - 2026-09-10

- Avvio della revisione completa come edizione italiana moderna.
- Nuove anteprime professionali e dinamiche per scale e porta scorrevole.
- Glossario tecnico e matrice di modernizzazione dei 646 comandi.
- Cinque prompt storici yqpanel tradotti alla fonte.
- Core VLX stabile preservato.

# 3.48 - 2026-09-10

- Ripristino core reale 3.42; lint AutoLISP rigoroso; moduli nativi isolati; diagnostica 646 comandi.

# 3.42 - 2026-09-09

- Sezione scala: eliminato il posizionamento `VL-CMDF + PAUSE` della 3.41.
- Nuovo posizionamento interno: `prompt italiano originale + GETPOINT(QO$, stringa vuota)` + helper originale `YQ_MOVE(QJ,QO$,target)`.
- Generatore geometrico, DCL, varianti, resource stream e anteprime invariati.
- Pianta vano scala e gli altri percorsi migliorati restano congelati.

# 3.41 - 2026-09-09

- Sezione scala: sostituita la sequenza finale di 6 `ads-cmd` con una singola `VL-CMDF` atomica, preservando gruppo QJ, `_non`, punto base QO$ e `PAUSE` originali.
- Generatore geometrico e tutte le opzioni della Sezione scala restano originali.
- Pianta vano scala congelata sulla 3.40 dopo il superamento del precedente punto critico nel test reale.
- Nessuna modifica alle anteprime, a Finestra, Porta scorrevole, Scala mobile o Scala curva.

# 3.40 - 2026-09-09

- Pianta vano scala: corretti 5 override OSNAP locali `non` e 1 risposta `y` nel call-graph originale (`_non` / `_y`).
- Pianta vano scala: ricostruite `STAIRPLAN` e `STAIRPLANE` con etichette native italiane e senza sovrapposizioni inglesi/cinesi.
- Finestra, Porta scorrevole, Scala mobile e Scala curva congelate rispetto alla 3.39.
- Confermata la policy: equivalenza funzionale completa e stabilità AutoCAD 2027 hanno priorità sulla conservazione del codice legacy.

# 3.33 - 2026-09-08

- Corretto il numero release visualizzato dal bootstrap installer (patch binaria stessa lunghezza, senza ricompilare il launcher).
- Sezione scala: comando originale preservato; compatibilità PEDIT localizzata tramite PEDITACCEPT temporaneo e ripristino automatico.
- Sezione scala: anteprima originale resa leggibile cambiando soltanto lo sfondo del tile DCL VIEW.
- Simbolo pendenza: ulteriori stringhe puramente visive localizzate nativamente nel FAS a lunghezza invariata; keyword tecniche non modificate.
- Corretto il refuso visibile `mousa` -> `mouse` nei prompt di rotazione del core.
- Rafforzato il gate: diff binario VLX ammesso solo nelle posizioni dichiarate, controllo keyword tecniche e controllo versione bootstrap.
- Ribadita policy: nessuna modifica della logica funzionale originale YQArch come soluzione finale.

# YQArch Italiano 3.06

- Localizzazione nativa mirata della scala rettilinea nel secondo stream FAS4 di `yqarch.vlx`.
- Tradotti alla fonte i prompt `Plan of a staircase`, `Landing width`, `Tread width` e `Current Step Altezza`.
- Lunghezza dello stream FAS4, chiave di cifratura, offset e bytecode preservati.
- DCL italiano della scala preservato; nessuna riscrittura della logica geometrica.
- Numerazione automatica, YQ_WALL, Porta, Griglia assi, Cornice, Stampa multipla, Dizionario e Menu grafico congelati funzionalmente.

# YQArch Italiano 3.04

- Preparazione della release pubblica aggiornata.
- Preservato il motore originale funzionante della Numerazione automatica.
- Tradotti prompt residui dell'Indicatore (secondo/terzo punto, commento, angolo polare).
- Tradotto il messaggio finale “numeri progressivi creati”.
- Ripulito il commento predefinito con “Marmo”.
- Migliorata la documentazione di compatibilità Windows/AutoCAD e dei problemi noti.
- Nessuna modifica agli offset o ai simboli eseguibili del core FAS4.

# YQArch Italiano 3.04

- Audit strutturale della localizzazione nel core FAS4 incorporato in `yqarch.vlx`.
- Traduzione nativa alla sorgente binaria di stringhe UI/prompt riconosciute, con patch a lunghezza fissa per non modificare offset e flusso eseguibile.
- Completate le stringhe residue di Scala curva e Indicatore utente, oltre a numerose stringhe condivise di quote, scale, pannelli e comandi.
- Ridotto il banner storico YQArch all'avvio intervenendo direttamente sulle risorse del core.
- Numerazione automatica mantiene integralmente il motore originale YQArch, già verificato funzionante nella 3.00.
- Corrette stringhe residue nei DCL incorporati (ordinali, incremento/decremento, cifre).
- Aggiornato l'audit di regressione e localizzazione.

# Changelog

## 3.00
- Corretto il flusso di Numerazione automatica: la selezione degli oggetti è ora immediata.
- Mantenuta la Porta nativa italiana introdotta nella 2.97.
- Pulizia di file obsoleti/non referenziati.
- Revisione terminologica e grammaticale di stringhe visibili.
- Aggiunta documentazione per GitHub, compatibilità, problemi noti e attribuzioni.
- Audit statico dei prompt AutoLISP/DCL.
- Conservati i moduli già stabilizzati senza riscritture funzionali.

## 2.97
- Migrazione nativa di Numerazione automatica e Porta.

## 2.96
- Ripristinati i due metodi di sostegno alla versione italiana.
