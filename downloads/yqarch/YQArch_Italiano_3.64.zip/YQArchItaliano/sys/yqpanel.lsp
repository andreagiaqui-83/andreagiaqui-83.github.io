;;;=========================================================================
;;;         Դ Ȫ �� ��    [����������]���LSP��������
;;;-------------------------------------------------------------------------
;;; �ļ��� sys\
;;;=========================================================================
;;; ע���������зֺ�";"������ע�ͣ����׼ӷֺ�����ʱȡ�����С�

;;; �����д: Walter Lam   QQ: 575825448
;;; ���ƴ������ļ��뱣��������Ϣ


;;;======================
;;; һЩ�Զ������������
;;;======================

(defun c:yq_mi (/ ss p1 p2)
    (yq_cbegin)
    (princ "\n****Specchia")
    (if (and (setq ss (ssget ":l"))
             (yq_ssredraw ss 3)
             (setq p1 (getpoint "\nSpecificare primo punto della linea speculare:"))
             (setq p2 (getpoint p1 "\nSpecificare secondo punto della linea speculare:"))
        )
        (if (getpoint "\nFare clic per eliminare gli oggetti originali: <Spazio per conservarli> ")
            (yq_mirror ss p1 p2 t)
            (yq_mirror ss p1 p2 nil)
        )
    )
    (yq_cend)
)


(defun c:yq_ccb(/ pt)
    (princ "\n****Taglia con punto base")
    (and (setq pt (getpoint "\nPunto base: "))
         (ssget)
         (command "_.COPYBASE" "_non" pt "_p" "" "_.ERASE" "_p" "")
    )
    (princ)
)


(defun c:yq_rz(/ pt1 pt2)
    (princ "\n****Ruota a 0 gradi")
    (and (ssget)
         (setq pt1 (getpoint "\nPunto base: "))
         (setq pt2 (getpoint pt1 "\nIndicare angolo da impostare a 0 gradi: "))
         (command "_.ROTATE" "_p" "" "_non" pt1 "_r" "_non" pt1 "_non" pt2 "0")
    )
    (princ)
)


(defun c:yq_rg()
    (princ "\n****Rigenera area")
    (if (ssget) (command "_.ERASE" "_p" "" "_.OOPS"))
    (princ)
)


(defun c:yq_zd()
    (princ "\n****Riduci vista 0.5x")
    (command "_.ZOOM" "0.5x")
    (princ)
)


(defun c:yq_ze()
    (princ "\n****Zoom estensioni")
    (command "_.ZOOM" "_e")
    (princ)
)


(defun c:yq_zz()
    (princ "\n****Vista precedente")
    (command "_.ZOOM" "_p")
    (princ)
)


(defun c:yq_edb(/ ss la)
    (princ "\n****Esplodi blocco sul proprio layer")
    (if (setq ss (ssget '((0 . "INSERT"))))
        (foreach e (yq_ss2lst ss)
            (yq_mark)
            (setq la (cdr (assoc 8 (entget e))))
            (command "_.EXPLODE" e) (yq_cmdenter)
            (command "_.CHPROP" (yq_newss) "" "la" la "")
        )
    )
    (princ)
)


(defun c:yq_edc(/ ss)
    (princ "\n****Esplodi blocco sul layer corrente")
    (if (setq ss (ssget '((0 . "INSERT"))))
        (foreach e (yq_ss2lst ss)
            (yq_mark)
            (command "_.EXPLODE" e) (yq_cmdenter)
            (command "_.CHPROP" (yq_newss) "" "la" (getvar "CLAYER") "")
        )
    )
    (princ)
)


(defun c:yq_vxx(/ pt1 pt2 ss)
    (princ "\n****Sposta senza trascinare")
    (and (setq ss (ssget))
         (yq_ssredraw ss 3)
         (setq pt1 (getpoint "\nPunto base: "))
         (setq pt2 (getpoint pt1 "\nPunto destinazione: "))
         (command "_.MOVE" ss "" "_non" pt1 "_non" pt2)
    )
    (if ss (yq_ssredraw ss 4))
    (princ)
)


(defun c:yq_cxx(/ pt1 pt2 ss)
    (princ "\n****Copia senza trascinare")
    (if (and (setq ss (ssget))
             (yq_ssredraw ss 3)
             (setq pt1 (getpoint "\nPunto base: "))
        )
        (while (setq pt2 (getpoint pt1 "\nPunto destinazione: "))
             (command "_.COPY" ss "" "_non" pt1 "_non" pt2)
        )
    )
    (if ss (yq_ssredraw ss 4))
    (princ)
)


(defun c:yq_date ( / pt str )
    (princ "\n****Inserisci data e ora\n")
    (if (setq pt (getpoint))
        (progn
            (setq str (rtos (getvar "CDATE") 2 6)
                  str (strcat (substr str 1 4) "-" (substr str 5 2) "-" (substr str 7 2)
                              " " (substr str 10 2) ":" (substr str 12 2))
            )
            (yq_text pt (* 3 (getvar "DIMSCALE")) str)
        )
    )
    (princ)
)


(defun c:yq_cm(/ ss pt1 pt2 n d a ss0)
    (yq_cbegin)
    (princ "\n****Copia N volte")
    (if (and (setq ss (ssget))
             (setq pt1 (getpoint "\nPunto base: "))
             (setq pt2 (getpoint pt1 "\nSecondo punto: "))
        )
        (progn
            (setq ss0 (yq_copy2pt ss pt1 pt2))
            (initget 2)
            (setq yq_cm (if yq_cm yq_cm 1)
                  n (getint (strcat "\nNumero copie (negativo = divisione interna): <" (itoa yq_cm) "> "))
                  yq_cm (if n n yq_cm)
                  d (distance pt1 pt2)
                  a (angle pt1 pt2)
            )
            (if (minusp yq_cm) 
                (setq d (/ d (abs yq_cm)))
                (setq pt1 pt2 ss ss0)
            )
            (setq pt2 (polar pt1 a d))
            (repeat (1- (abs yq_cm))
                (yq_copy2pt ss  pt1 pt2)
                (setq pt2 (polar pt2 a d))
            )
        )
    )
    (yq_cend)
)


;;;==============
;;; SOLID��HATCH
;;;==============
;;; 2012.7.17 д
(defun c:yq_s2h(/ ss e)
    (princ "\n****Converti SOLID in HATCH")
    (if (setq ss (ssget '((0 . "SOLID,TRACE"))))
        (foreach x (yq_ss2lst ss)
            (setq e (yq_pline (yq_getvertexes x nil) 1))
            (command "_.BHATCH" "_p" "_s" "_s" e "" "")
            (command "_matchprop" x (entlast) "")
            (entdel x)(entdel e)
        )
    )
    (princ)
)


;;;========
;;; ����Բ
;;;========
;;; 2012.12.20 д
(defun c:yq_a2c(/ ss en)
    (princ "\n****Converti arco in cerchio")
    (if (setq ss (ssget '((0 . "ARC"))))
        (foreach x (yq_ss2lst ss)
            (setq en (cddr (entget x))
                  en (vl-remove-if '(lambda (x) (member (car x) '(50 51))) en)
            )
            (entmake (cons '(0 . "CIRCLE") en))
            (entdel x)
        )
    )
    (princ)
)



;;;============
;;; Բ������
;;;============
;;; 2012.6.30 д
(defun c:yq_c2x(/ ss)
    (princ "\n****Converti cerchio in polilinea")
    (if (setq ss (ssget '((0 . "CIRCLE"))))
        (foreach x (yq_ss2lst ss)
            (yq_cirle2donut x)
        )
    )
    (princ)
)



(defun c:yq_expattblk(/ ss)
    (yq_cbegin)
    (princ "\n****Esplodi blocco attributi mantenendo testo")
    (if (setq ss (ssget (list (cons 0 "INSERT"))))
    (foreach e (yq_ss2lst ss)
        (yq_explodeattblk e)
    )
    )
    (yq_cend)
)



(defun c:yq_fxx(/ ss)
    (yq_cbegin)
    (princ "\n****Raccorda polilinee in serie")
    (setq yq_fxx (if yq_fxx yq_fxx 0))
    (setq yq_fxx (yq_getdist "\nRaggio di raccordo: " yq_fxx))
    (and (setq ss (ssget '((0 . "LWPOLYLINE"))))
         (foreach e (yq_ss2lst ss)
             (yq_filletpline e yq_fxx)
         )
    )
    (yq_cend)
)



(defun c:yq_cfxx(/ ss)
    (yq_cbegin)
    (princ "\n****Smussa polilinee in serie")
    (setq yq_cfxx (if yq_cfxx yq_cfxx 0))
    (setq yq_cfxx (yq_getdist "\nDistanza di smusso: " yq_cfxx))
    (and (setq ss (ssget '((0 . "LWPOLYLINE"))))
         (foreach e (yq_ss2lst ss)
             (yq_chamferpline e yq_cfxx)
         )
    )
    (yq_cend)
)



(defun c:yq_delendspaces(/ ss)
    (yq_cbegin)
    (princ "\n****Rimuovi spazi iniziali/finali")
    (and (setq ss (ssget (list (cons 0 "*TEXT"))))
         (foreach x (yq_ss2lst ss)
             (yq_updent x (list (cons 1 (yq_allTrim (yq_dxf x 1))))) 
         )
    )
    (yq_cend)
)



;;;==================
;;; �����и���ȡͼ��
;;;==================
(defun c:yq_qgtx(/ e1 e2 e3 e4)
    (yq_cbegin)
    (princ "\n****Ritaglia/estrai immagine")
    (if (and (setq e1 (car (yq_entsel "\nSelezionare l'immagine da ritagliare: " (list (cons 0 "IMAGE")))))
             (setq e2 (car (yq_entsel "\nSelezionare il contorno di ritaglio: " (list (cons 0 "*POLYLINE,CIRCLE,ELLIPSE")))))
             (setq e3 (yq_clone e1))
        )
    (progn
        (setq e4 (yq_pline (yq_curve2ptlst_d e2) 1))
        (if (= (yq_dxf e3 280) 0)
            (command "_.IMAGECLIP" e3 "_n" "_s" e4)
            (command "_.IMAGECLIP" e3 "_d" "_.IMAGECLIP" e3 "_n" "_s" e4)
        )
        (entdel e4)
        (command "_.MOVE" (entlast) "" (car (yq_getvertexes e2 0)))
    )
    )
    (yq_cend)
)



;;;============
;;; ը�����տ�
;;;============
(defun c:yq_refx (/ e)
    (yq_cbegin)
    (princ "\n****Esplodi blocco riferimento")
    (if (setq e (car (yq_entsel "\nSelezionare il blocco di riferimento: " (list (cons 0 "INSERT")))))
    (progn
        (command "_.XREF" "_b" (yq_dxf e 2))
        (command "_.EXPLODE" e)
    )
    )
    (yq_cend)
)



;;;=================================
;;; ��ɫ/����/�߿��ָ�Ϊ���bylayer
;;;=================================
(defun c:yq_00(/ ss)
    (yq_cbegin)
    (princ "\n****Ripristina colore/tipo linea/spessore ByLayer")
    (cond 
        ((setq ss (yq_sspre))
            (command "_.CHPROP" ss "" "_lt" "bylayer" "_lw" "bylayer" "_c" "bylayer" "")
            (princ "\nOggetti selezionati ripristinati a ByLayer.")
        )
        (t
           	(setvar "CECOLOR" "bylayer")
           	(setvar "CELTYPE" "bylayer")
           	(setvar "CELWEIGHT" -1)
           	(princ "\nPropriet� correnti ripristinate su DaLayer.")
	       )
	   )
   	(yq_cend)
)


;;----- �µ����ɷ������� -----







(princ)
