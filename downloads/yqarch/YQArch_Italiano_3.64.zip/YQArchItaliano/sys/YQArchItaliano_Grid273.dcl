yqit_grid273 : dialog {
  label = "[YQArch Italiano] - Griglia assi";
  : boxed_column {
    label = "Distanze tra gli assi";
    : edit_box { key = "gx"; label = "Larghezze:"; edit_width = 36; }
    : edit_box { key = "gy"; label = "Profondit�:"; edit_width = 36; }
    : toggle { key = "symdim"; label = "Disegna simboli degli assi e quote"; }
    : button { key = "reset"; label = "Ripristina valori predefiniti"; width = 38; fixed_width = true; alignment = centered; }
  }
  spacer;
  ok_cancel;
}
