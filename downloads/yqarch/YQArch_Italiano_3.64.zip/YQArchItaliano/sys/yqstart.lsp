;;; YQArch Italiano 3.64 - avvio core e personalizzazioni.
(setq old_cmdecho (getvar "CMDECHO"))
(setvar "CMDECHO" 0)
;;; YQArch Italiano 3.64: caricamento silenzioso e deterministico dei moduli esterni.
;;; Non altera SECURELOAD/TRUSTEDPATHS e non nasconde errori reali.
(vl-load-com)
(defun yqit361-pathjoin (d f / last)
  (if (or (null d) (= d "")) f
    (progn
      (setq last (substr d (strlen d) 1))
      (if (or (= last "\\") (= last "/")) (strcat d f) (strcat d "\\" f)))))
(defun yqit361-load-one (full / r)
  (setq r (vl-catch-all-apply 'load (list full)))
  (if (vl-catch-all-error-p r)
    (princ (strcat "\nYQArch Italiano: impossibile caricare " full ": "
                   (vl-catch-all-error-message r))))
  r)
(defun yqit361-load-dir (d / files ext f)
  (if (and d (/= d ""))
    (progn
      (setq files nil)
      (foreach ext '("*.lsp" "*.fas" "*.vlx")
        (foreach f (vl-directory-files d ext 1)
          (if (not (member (strcase f) (mapcar 'strcase files)))
            (setq files (cons f files)))))
      (setq files (vl-sort files '(lambda (a b) (< (strcase a) (strcase b)))))
      (foreach f files (yqit361-load-one (yqit361-pathjoin d f)))))
  (princ))
;;; YQArch Italiano: SECURELOAD lasciato invariato.

(if (null c:yq_about)(progn
(if (or (and (getvar "GCADVER") (<= "13.0" (substr (getvar "GCADVER") 2 4)))
        (<= "15.0" (substr (getvar "ACADVER") 1 4))
    )
(progn


;;; ���ء�ԴȪ��ơ��������
(if (and (null c:yq_about)(findfile "yqarch.vlx"))(load "yqarch.vlx"))


;;; �� acad.lsp �ļ����ص�ÿһ��ͼ��
(if (getvar "acadlspasdoc") (setvar "acadlspasdoc" 1))


;;; ����Ļ��״̬����ʾ��ǰ����ע���� DIMSCALE������ע��ʽ DIMSTY����������ʽ STYLE��
;(setvar "MODEMACRO" (strcat "DIMSCALE:<1:" "$(substr,$(getvar,DIMSCALE),1,6)"
;    "> DIMSTY:<" "$(getvar,DIMSTYLE)" "> STYLE:<" "$(getvar,TEXTSTYLE)" ">"))


;;; ����ԴȪϵͳ������
(if (findfile "yqpanel.lsp") (load "yqpanel.lsp"))


;;; ����ԴȪ���ϵͳĿ¼�¡�library���ļ��еĳ����ļ�
(if (and yq_library (/= yq_library ""))
    (progn
        (princ)
        (yqit361-load-dir yq_library)
        (princ)
    )
)


;;; ����ԴȪ���ϵͳĿ¼�¡���ǰ�û����ļ��еĳ����ļ�
(if (and yq_user (/= yq_user ""))
    (progn
        (princ)
        (princ)
        (yq_runsc)             ; scorciatoie comandi
        (setq *YQIT361-PANEL-RESULT* (vl-catch-all-apply 'yq_yqpanel nil))
        (if (vl-catch-all-error-p *YQIT361-PANEL-RESULT*)
          (princ (strcat "\nYQArch Italiano: avviso pannelli di sistema - " (vl-catch-all-error-message *YQIT361-PANEL-RESULT*))))
        (setq *YQIT361-PANEL-RESULT* (vl-catch-all-apply 'yq_runpanel nil))
        (if (vl-catch-all-error-p *YQIT361-PANEL-RESULT*)
          (princ (strcat "\nYQArch Italiano: avviso pannelli utente - " (vl-catch-all-error-message *YQIT361-PANEL-RESULT*))))
        (yq_runlaysc)          ; scorciatoie layer
        (yq_runwlaysc)         ; scorciatoie wildcard layer
        (yq_runltpsc)          ; scorciatoie tipi linea
        (yq_runhatsc)          ; scorciatoie retini
        (yqit361-load-dir yq_user)
        (princ)
    )
)


;;; ����ԴȪ�˵�Ϊ AutoCAD ԭ�˵������һ��
;;; Menu gestito dal modulo italiano dopo il caricamento del core.


(princ)


)(princ (yq_ec "\nDisponibile solo con AutoCAD 2000/GstarCAD 8 o versioni successive!" "\nDisponibile solo con AutoCAD 2000/GstarCAD 8 o versioni successive."))
)
)
)



(if old_cmdecho (progn (setvar "CMDECHO" old_cmdecho) (setq old_cmdecho nil)))
(princ)

(if (and (not *YQIT-BOOTSTRAP-BUSY*) (findfile "YQArchItaliano_Bootstrap.lsp")) (load "YQArchItaliano_Bootstrap.lsp"))
(princ)
