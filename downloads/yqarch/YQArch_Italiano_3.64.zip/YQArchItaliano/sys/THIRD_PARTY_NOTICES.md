﻿# Attribuzioni e componenti di terze parti

YQArch Italiano è una localizzazione/ricostruzione indipendente dell'interfaccia.

YQArch originale e i relativi componenti, marchi, risorse, moduli compilati e contenuti appartengono ai rispettivi autori. La pubblicazione su GitHub deve rispettare la licenza e le condizioni di redistribuzione del progetto originale.

La pagina di sostegno distingue esplicitamente:
- sostegno al progetto YQArch originale;
- sostegno allo sviluppo indipendente della versione italiana.
