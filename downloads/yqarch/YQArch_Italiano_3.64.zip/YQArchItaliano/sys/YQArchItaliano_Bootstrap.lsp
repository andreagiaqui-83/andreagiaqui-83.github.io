;;; YQArch Italiano 3.64 - un'inizializzazione per documento, senza ricorsione MNL.
(vl-load-com)
(defun yqit364-bootstrap (/ started echo result file)
  (if (and (not *YQIT-BOOTSTRAP-BUSY*) (/= *YQIT-LOADED-VERSION* "3.64"))
    (progn
      (setq *YQIT-BOOTSTRAP-BUSY* T
            started (getvar "MILLISECS")
            echo (getvar "CMDECHO"))
      (setvar "CMDECHO" 0)
      (setq file (findfile "yqitaliano.lsp"))
      (if file
        (setq result (vl-catch-all-apply 'load (list file)))
        (setq result nil))
      (setvar "CMDECHO" echo)
      (setq *YQIT-BOOTSTRAP-BUSY* nil)
      (cond
        ((not file) (princ "\nYQArch Italiano: modulo italiano non trovato."))
        ((vl-catch-all-error-p result)
          (princ (strcat "\nYQArch Italiano: inizializzazione incompleta: "
                         (vl-catch-all-error-message result))))
        ((and c:yq_about *YQIT-NATIVE-364*)
          (setq *YQIT-LOADED-VERSION* "3.64"
                *YQIT-STARTUP-MS* (- (getvar "MILLISECS") started)))
        (T (princ "\nYQArch Italiano: core o modulo nativo non caricato.")))))
  (princ))
(yqit364-bootstrap)
(princ)
