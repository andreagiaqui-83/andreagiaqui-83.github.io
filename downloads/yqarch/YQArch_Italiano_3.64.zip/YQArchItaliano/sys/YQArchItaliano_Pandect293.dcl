yqit_pandect : dialog {
  label = "[YQArch Italiano] - Panoramica comandi";
  : row {
    : boxed_column {
      label = "Categorie";
      width = 31;
      : list_box { key="cats"; height=25; width=31; }
    }
    : boxed_column {
      label = "Comandi";
      width = 54;
      : list_box { key="cmds"; height=25; width=54; }
    }
    : boxed_column {
      label = "Dettagli";
      width = 28;
      : text { label="Comando:"; }
      : text { key="cmdname"; label=""; width=26; }
      : edit_box { key="shortcut"; label="Scorciatoia:"; edit_width=14; }
      : text { key="default"; label="Predefinita: -"; width=26; }
      spacer;
      : button { key="run"; label="Esegui comando"; width=24; fixed_width=true; }
      : button { key="open"; label="Apri elenco categoria"; width=24; fixed_width=true; }
      spacer;
      : button { key="save"; label="Salva scorciatoia"; width=24; fixed_width=true; }
      : button { key="resetone"; label="Ripristina predefinita"; width=24; fixed_width=true; }
    }
  }
  : row {
    : button { key="resetall"; label="Ripristina tutte le scorciatoie"; width=30; fixed_width=true; }
    : button { key="export"; label="Salva con nome..."; width=22; fixed_width=true; }
    : button { key="reload"; label="Ricarica elenco"; width=20; fixed_width=true; }
  }
  spacer;
  ok_cancel;
}

yqit_pandect_category : dialog {
  label = "[YQArch Italiano] - Panoramica comandi";
  : boxed_column {
    : text { key="title"; label="Categoria"; width=74; }
    : list_box { key="items"; height=26; width=74; }
  }
  : row {
    : text { label="Comando:"; }
    : text { key="cmd"; label=""; width=30; }
    : edit_box { key="shortcut"; label="Scorciatoia:"; edit_width=12; }
  }
  : row {
    : button { key="run"; label="Esegui"; width=16; fixed_width=true; }
    : button { key="save"; label="Salva scorciatoia"; width=22; fixed_width=true; }
    : button { key="reset"; label="Ripristina predefinita"; width=24; fixed_width=true; }
  }
  spacer;
  ok_cancel;
}
