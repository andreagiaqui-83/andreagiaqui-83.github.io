# Compatibilità YQArch Italiano 3.64

Nessuna versione AutoCAD o Windows è stata eseguita in questo ambiente Linux. Le fasce seguenti indicano obiettivi, non certificazioni.

| Fascia | Versioni | Stato 3.64 |
|---|---|---|
| Principale | AutoCAD completo 2021–2027 Windows | Analisi statica; runtime da collaudare |
| Estesa | AutoCAD 2015–2020 Windows | Prevista; MBCS; runtime da collaudare |
| Legacy | AutoCAD 2008–2014 Windows | Best effort; usare istruzioni manuali dove l’installer non rileva il profilo |
| Legacy parziale | AutoCAD 2004–2007 Windows | Best effort; non certificata |

L’installer EXE è x64 e richiede Windows PowerShell 5.1, WPF e .NET Framework con ZipFile/Get-FileHash. Il plugin contiene componenti legacy: la presenza di AutoLISP in AutoCAD LT non rende questa distribuzione compatibile con LT. Mac e prodotti CAD alternativi non certificati. Su Windows x86 usare soltanto il percorso manuale, senza assumere compatibilità delle DLL storiche.

La documentazione Autodesk di AutoCAD 2027 richiede Windows 11 a 64 bit. Il fatto che l’installer possa essere eseguito su Windows 10 non costituisce supporto Autodesk di AutoCAD 2027 su Windows 10. Per le release precedenti verificare la specifica coppia AutoCAD/Windows nei requisiti ufficiali.

LISPSYS: 0 usa le funzioni legacy MBCS; 1 supporta funzioni Unicode e compilazione Unicode; 2 supporta funzioni Unicode ma compilazione MBCS. Non viene modificato automaticamente. I file nuovi LSP/MNL sono CP1252 senza BOM; i nomi tecnici sono ASCII. I dati storici comprendono codifiche miste: vedere audit encoding. Nessuna ricompilazione del FAS/VLX.

SECURELOAD e TRUSTEDPATHS restano invariati. Un percorso di supporto e un percorso attendibile hanno scopi diversi. Se il caricamento è impedito dalle impostazioni del proprio profilo, configurare la cartella del plugin nelle Opzioni di AutoCAD o rivolgersi al responsabile CAD; non disattivare SECURELOAD.

Fonti Autodesk consultate il 27 settembre 2026:
- https://www.autodesk.com/it/support/technical/article/caas/sfdcarticles/sfdcarticles/ITA/System-requirements-for-AutoCAD-2027-including-Specialized-Toolsets.html
- https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Core/files/GUID-1853092D-6E6D-4A06-8956-AD2C3DF203A3.htm
- https://help.autodesk.com/cloudhelp/2027/ENU/AutoCAD-Customization/files/GUID-FDB4038D-1620-4A56-8824-D37729D42520.htm
- https://help.autodesk.com/cloudhelp/2027/ENG/AutoCAD-Core/files/GUID-2FB4611D-F141-48D5-9B6E-460EB59351AF.htm

## Evidenza della release precedente
La diagnostica utente della 3.63 su AutoCAD 2027 italiano conferma 646/646 funzioni e 23/23 categorie (547 voci), un menu e DLL presenti. La 3.64 corregge le pagine Sostieni ed è stata verificata localmente; nessun collaudo AutoCAD della nuova release in questo ambiente.
