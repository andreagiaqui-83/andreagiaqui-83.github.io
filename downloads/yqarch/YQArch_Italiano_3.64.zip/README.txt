YQARCH ITALIANO 3.64 — PAGINE DI SOSTEGNO

1. Chiudere AutoCAD e avviare YQArch_Italiano_3.64.exe. Pacchetto completo: non serve installare prima la 3.63.
2. In YQARCH ITALIANO > Impostazioni e supporto, aprire Sostieni il progetto YQArch originale: sono presenti solo i riferimenti degli autori originali.
3. Aprire Sostieni lo sviluppo di YQArch Italiano: sono presenti PayPal (andrea.giaqui@gmail.com) e Postepay P2P (333 724 0544).

Comandi diretti: YQIT_DONATE_ORIGINAL e YQIT_DONATE_ITALIANO. YQ_DONATE/yqjz resta associato al progetto originale. I dati sono visibili anche senza rete; per effettuare il contributo si usa il servizio indicato.

L’installer crea backup e conserva i file personali noti. Nei file scorciatoie personali già esistenti può rimanere la precedente descrizione testuale; la pagina aperta dal comando viene comunque corretta.

Lo ZIP contiene YQArchItaliano/sys (plugin completo), AUDIT (rapporti, matrici, test), SVILUPPO (script e test), guida offline e rapporto della release.
Le correzioni menu/icone della 3.63 sono incluse. Per la diagnostica usare YQIT_VERIFICA_MENU o YQIT_DIAGNOSTICA_COMPLETA.

45 controlli locali superati. La 3.64 non è stata eseguita in AutoCAD in questo ambiente. La presenza dei comandi non certifica geometria e localizzazione integrale.
