YQArch Italiano 3.78
====================
INSTALLAZIONE
1. Chiudere AutoCAD e avviare YQArch_Italiano_3.78.exe.
2. Attendere il completamento dell'installazione con backup automatico.
3. Riaprire AutoCAD. Nessuna sostituzione manuale dei file.

La correzione Ribbon usa una sola riga principale: 1 grande affiancato a 5 piccoli (3+2), altri 7 accessi nel flyout di ogni pannello.
Nessuna copia manuale di file richiesta. Conservati core, impostazioni personali, 646 comandi, 195 DWG del catalogo con anteprime e flusso d'inserimento diretto.
Nessuna modifica a SECURELOAD, TRUSTEDPATHS, LISPSYS o ai plugin di terzi.

I test statici e logici non equivalgono a esecuzione reale su Windows/AutoCAD. Il collaudo nativo della 3.77 su AutoCAD 2027 italiano è acquisito; il CUIx della 3.78 è identico. La diagnostica della 3.77 rileva 646/646 comandi definiti e zero mancanti, senza eseguirli. Le altre coppie AutoCAD/Windows non vengono dichiarate certificate.

Guida: YQArchItaliano/sys/YQArch_Italiano_Guida.html (646 schede; restano procedure generiche da approfondire).
Compatibilità e limiti: COMPATIBILITA_AUTOCAD_WINDOWS.md e YQArchItaliano/sys/KNOWN_ISSUES.md.
Il launcher PE originale viene conservato; è ricostruito l'intero payload, non è un aggiornamento differenziale. L'EXE non è firmato Authenticode.
