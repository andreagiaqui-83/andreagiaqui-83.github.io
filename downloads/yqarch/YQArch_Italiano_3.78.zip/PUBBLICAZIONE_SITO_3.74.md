# Pubblicazione YQArch Italiano 3.74

La 3.74 non va pubblicata come definitiva prima del breve collaudo reale del nuovo layout Ribbon e della pagina **Sostieni YQArch Italiano**. La 3.73 resta la release pubblica/rollback verificata finché il collaudo non è concluso.

Dopo esito positivo:
1. pubblicare esattamente EXE e ZIP 3.74 verificati, senza ricostruirli;
2. aggiornare `/yqarch-italiano/`, guida, rapporto, SHA-256 e `downloads/releases.json` se presente;
3. descrivere la nuova Ribbon come `2 principali con etichetta + 11 secondari compatti per pannello`, mantenendo 130 accessi, 23 categorie e 547 voci espanse;
4. indicare il contatto WhatsApp, email e il collegamento ad andreagiaquinto.it nella pagina locale Sostieni;
5. non dichiarare ogni comando o ogni AutoCAD/Windows come certificato;
6. verificare i download dal dominio pubblico, gli hash, i link, desktop/mobile e dati strutturati.
