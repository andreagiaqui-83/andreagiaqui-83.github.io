# YQArch Italiano 3.74 — Miglioramento Ribbon e contatti

## Base della release
La 3.74 è costruita integralmente sul pacchetto **3.73**, collaudato realmente sul PC di riferimento con **AutoCAD 2026 italiano**. La 3.73 ha confermato installazione/aggiornamento, Ribbon, caricamento e inserimento blocchi diretto. La 3.74 non modifica il core geometrico né il flusso del catalogo blocchi.

## Ribbon più leggibile
La scheda **YQArch Italiano** mantiene gli stessi 10 pannelli e gli stessi **130 accessi diretti**, ma la disposizione visibile viene resa più simile alle Ribbon di CAD Tools Italiano ed Express Tools:

- **2 comandi principali grandi con etichetta visibile** per pannello;
- **11 comandi secondari compatti** per pannello, distribuiti su due righe 6/5;
- tutti i pulsanti conservano UID, macro, immagini e comando originale;
- le espansioni conservano **23 categorie e 547 voci**;
- i suggerimenti continuano a mostrare nome e funzione del comando.

Sono quindi cambiati soltanto **ordine e stile di presentazione** dei 130 accessi visibili; nessun comando viene rimosso o sostituito.

## Pagina “Sostieni YQArch Italiano”
La pagina locale è stata aggiornata e resa più utile:

- contributi PayPal e Postepay P2P restano chiaramente separati dal sostegno al progetto YQArch originale;
- nuova CTA principale **WhatsApp** al numero +39 333 724 0544;
- nuovo collegamento email per suggerimenti, contatti e segnalazioni bug;
- indicazioni pratiche sui dati utili da fornire in una segnalazione;
- collegamenti a **andreagiaquinto.it** e alla pagina pubblica YQArch Italiano.

## Funzioni protette
Restano invariati rispetto alla 3.73:

- inserimento blocchi: `Selezione → Inserisci → punto nel DWG → inserimento completato`;
- controllo preventivo dei formati DWG legacy;
- 195 DWG e 195 anteprime SLD;
- core storico, libreria SLB e DLL;
- backup, journal e rollback dell'installer;
- nessuna modifica automatica a `SECURELOAD`, `TRUSTEDPATHS` o al CUI principale;
- identificatori stabili della scheda e dei pannelli Ribbon.

## Compatibilità
Il catalogo contiene 16 DWG `AC1009`, 2 `AC1014`, 129 `AC1018` e 48 `AC1021`. AutoCAD 2004–2006 può leggere 147/195 blocchi; i 48 `AC1021` richiedono AutoCAD 2007 o successivo e vengono intercettati prima dell'inserimento su versioni troppo vecchie.

## Stato del collaudo
La **3.73** è la baseline realmente collaudata. La 3.74 modifica la presentazione della Ribbon e la pagina locale di sostegno: prima della pubblicazione definitiva richiede un breve collaudo reale su AutoCAD del nuovo layout e dei collegamenti della pagina Sostieni.
