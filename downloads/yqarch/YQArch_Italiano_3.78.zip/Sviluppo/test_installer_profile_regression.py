"""Regression tests for the 3.72 multi-profile PowerShell variable collision."""
from pathlib import Path
import re
import unittest
SCRIPT=(Path(__file__).resolve().parent/'installer_378.ps1').read_text(encoding='utf-8-sig')
class InstallerMultiProfileRegression(unittest.TestCase):
    def test_verified_cache_has_descriptive_noncolliding_name(self):
        self.assertIn('$script:VerifiedUnchanged=@{}',SCRIPT)
        self.assertIn('$script:VerifiedUnchanged[$dst]=$true',SCRIPT)
        self.assertIn('$script:VerifiedUnchanged.ContainsKey($dst)',SCRIPT)
        self.assertNotRegex(SCRIPT,r'(?i)\$script:v(?:\W|$)')
    def test_menu_loop_cannot_overwrite_verified_cache(self):
        self.assertIn('foreach($menuVersion in 363..377)',SCRIPT)
        self.assertNotRegex(SCRIPT,r'(?i)foreach\(\$v\s+in\s+363\.\.374\)')
        scoped={m.casefold() for m in re.findall(r'\$script:([A-Za-z_][A-Za-z0-9_]*)',SCRIPT)}
        unscoped={m.casefold() for m in re.findall(r'(?<!:)\$([A-Za-z_][A-Za-z0-9_]*)',SCRIPT)}
        self.assertFalse(scoped & unscoped & {'verifiedunchanged'})
    def test_multiple_profiles_are_indexed_from_real_array(self):
        self.assertIn('$profiles=@($profiles|Sort-Object -Unique)',SCRIPT)
        self.assertIn('for($idx=0;$idx-lt $profiles.Count;$idx++)',SCRIPT)
        self.assertIn('$prof=$profiles[$idx]',SCRIPT)
    def test_rollback_remains_active(self):
        self.assertIn('Restore-Journal',SCRIPT)
        self.assertIn("'Installazione interrotta'",SCRIPT)
if __name__=='__main__':unittest.main()
