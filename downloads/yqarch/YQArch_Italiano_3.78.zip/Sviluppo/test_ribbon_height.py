"""Reject the observed 3.76 layout defect; no claim of measuring AutoCAD pixels."""
import copy
from pathlib import Path
import unittest
import xml.etree.ElementTree as E
from rebuild_ribbon import load_parts
from ribbon_contract import check_layout

class HeightRegressionTests(unittest.TestCase):
    def setUp(self):
        self.parts = load_parts(Path(__file__).resolve().parent.parent / 'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix')
        self.root = E.fromstring(self.parts['RibbonRoot.cui'])
        self.panel = next(self.root.iter('RibbonPanelSource'))
        self.row = self.panel.find('RibbonRow')
        self.stack = self.row.find('RibbonRowPanel')

    def errors(self):
        self.parts['RibbonRoot.cui'] = E.tostring(self.root)
        return check_layout(self.parts)

    def test_actual_failed_topology_with_same_button_count_rejected(self):
        # Reproduce exactly the relevant 3.76 arrangement: large row,
        # followed by five small buttons on another outer row.
        second = E.Element('RibbonRow', UID='REGRESSION_SECOND_ROW')
        for subrow in self.stack.findall('RibbonRow'):
            for button in list(subrow.findall('RibbonCommandButton')):
                subrow.remove(button)
                second.append(button)
        self.row.remove(self.stack)
        self.panel.insert(list(self.panel).index(self.row)+1, second)
        errors = self.errors()
        self.assertIn('one outer visible row in YQIT367_PANEL_01', errors)
        self.assertIn('standard structural height budget in YQIT367_PANEL_01', errors)

    def test_large_button_inside_small_stack_rejected(self):
        self.stack.find('.//RibbonCommandButton').set('ButtonStyle','LargeWithText')
        self.assertIn('standard structural height budget in YQIT367_PANEL_01', self.errors())

    def test_four_small_rows_rejected(self):
        for number in (3,4):
            row = E.SubElement(self.stack, 'RibbonRow', UID='BAD_ROW_'+str(number))
            button = copy.deepcopy(self.stack.find('.//RibbonCommandButton'))
            button.set('UID','BAD_BUTTON_'+str(number)); row.append(button)
        self.assertIn('standard structural height budget in YQIT367_PANEL_01', self.errors())

    def test_even_empty_extra_outer_row_rejected(self):
        self.panel.insert(list(self.panel).index(self.row)+1, E.Element('RibbonRow',UID='EMPTY_EXTRA'))
        self.assertIn('one outer visible row in YQIT367_PANEL_01', self.errors())

    def test_nested_stack_rejected(self):
        E.SubElement(self.stack.find('RibbonRow'),'RibbonRowPanel',UID='BAD_NESTED')
        self.assertIn('no nested small stack in YQIT367_PANEL_01', self.errors())

    def test_moved_break_rejected(self):
        br = self.panel.find('RibbonPanelBreak');self.panel.remove(br);self.panel.append(br)
        self.assertIn('one outer visible row in YQIT367_PANEL_01', self.errors())

    def test_second_break_rejected(self):
        self.panel.append(E.Element('RibbonPanelBreak', UID='EXTRA_BREAK'))
        self.assertIn('one panel break in YQIT367_PANEL_01', self.errors())

    def test_missing_visible_small_button_rejected(self):
        subrow=self.stack.find('RibbonRow'); subrow.remove(subrow.find('RibbonCommandButton'))
        self.assertIn('promoted command UID/macro/icon population unchanged',self.errors())

if __name__ == '__main__':
    unittest.main()
