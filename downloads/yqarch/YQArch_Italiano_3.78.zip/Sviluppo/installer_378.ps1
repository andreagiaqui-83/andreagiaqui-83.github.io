﻿param(
[Parameter(Mandatory=$true)][string]$PayloadZip,
[switch]$Worker,
[string]$StateFile,
[string]$LogFile
)
$ErrorActionPreference='Stop'
function Write-SharedUtf8 {
param([string]$Path,[string]$Text,[switch]$Append)
$enc=New-Object Text.UTF8Encoding($false)
$mode=if($Append){[IO.FileMode]::Append}else{[IO.FileMode]::Create}
$fs=New-Object IO.FileStream($Path,$mode,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
try {$b=$enc.GetBytes($Text);$fs.Write($b,0,$b.Length);$fs.Flush()}finally{$fs.Dispose()}
}
function Read-SharedUtf8 {
param([string]$Path)
if(-not(Test-Path -LiteralPath $Path)){return ''}
$fs=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
try {$sr=New-Object IO.StreamReader($fs,[Text.Encoding]::UTF8,$true);try{return $sr.ReadToEnd()}finally{$sr.Dispose()}}finally{$fs.Dispose()}
}
function Write-State {
param([int]$Pct,[int]$Stage,[string]$Status,[string]$Detail,[string]$Message,[string]$Kind='info')
if(-not $StateFile){return}
$obj=[ordered]@{pct=$Pct;stage=$Stage;status=$Status;detail=$Detail;message=$Message;kind=$Kind;timestamp=(Get-Date).ToString('HH:mm:ss');heartbeat=[DateTime]::UtcNow.Ticks}
Write-SharedUtf8 $StateFile ($obj|ConvertTo-Json -Compress)
if($Message -and $LogFile){Write-SharedUtf8 $LogFile ((Get-Date -Format 'HH:mm:ss')+"`t"+$Kind+"`t"+$Message+"`r`n") -Append}
}
function Assert-AutoCADClosed {
if(@(Get-Process -Name acad,acadlt -ErrorAction SilentlyContinue).Count -gt 0){throw 'Chiudere completamente AutoCAD prima di installare o aggiornare YQArch.'}
}
function Assert-NotCancelled {
if($StateFile -and (Test-Path -LiteralPath ($StateFile+'.cancel'))){throw 'Installazione annullata: ripristino delle modifiche.'}
}
function Get-SafeDestination([string]$Root,[string]$Relative) {
$base=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
$dest=[IO.Path]::GetFullPath((Join-Path $Root $Relative))
if(-not $dest.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Percorso non valido nel pacchetto.'}
return $dest
}
function Read-Startup([string]$Path) {
$enc=[Text.Encoding]::GetEncoding(1252);$skip=0;$bytes=@()
if(Test-Path -LiteralPath $Path){$bytes=[IO.File]::ReadAllBytes($Path)}
if($bytes.Length -ge 3 -and $bytes[0]-eq 239 -and $bytes[1]-eq 187 -and $bytes[2]-eq 191){$enc=New-Object Text.UTF8Encoding($true);$skip=3}
elseif($bytes.Length -ge 2 -and $bytes[0]-eq 255 -and $bytes[1]-eq 254){$enc=[Text.Encoding]::Unicode;$skip=2}
elseif($bytes.Length -ge 2 -and $bytes[0]-eq 254 -and $bytes[1]-eq 255){$enc=[Text.Encoding]::BigEndianUnicode;$skip=2}
elseif($bytes.Length -gt 0){try{$strict=New-Object Text.UTF8Encoding($false,$true);[void]$strict.GetString($bytes);$enc=New-Object Text.UTF8Encoding($false)}catch{}}
$text=if($bytes.Length -gt $skip){$enc.GetString($bytes,$skip,$bytes.Length-$skip)}else{''}
return @{Text=$text;Encoding=$enc}
}
function Write-Bootstrap([string]$Profile) {
$loader=(Join-Path $Profile 'YQArchItaliano_Bootstrap.lsp').Replace('\','/').Replace('"','\"')
$block="`r`n;;; BEGIN YQARCH ITALIANO MANAGED`r`n(load `"$loader`")`r`n;;; END YQARCH ITALIANO MANAGED`r`n"
foreach($name in @('acad.lsp','acaddoc.lsp')){
$path=Join-Path $Profile $name;$data=Read-Startup $path;$text=$data.Text
$text=[regex]::Replace($text,'(?ms)^;;; BEGIN YQARCH ITALIANO MANAGED\r?\n.*?^;;; END YQARCH ITALIANO MANAGED[^\r\n]*(?:\r?\n|$)','')
$text=[regex]::Replace($text,'(?m)^\(if \(and \(null c:yq_about\)\(findfile "yqstart\.lsp"\)\) \(load "yqstart\.lsp"\)\)\s*\r?\n?','')
$text=[regex]::Replace($text,'(?m)^\(if \(findfile "YQArchItaliano_Bootstrap\.lsp"\) \(load "YQArchItaliano_Bootstrap\.lsp"\)\)\s*\r?\n?','')
[IO.File]::WriteAllText($path,($text.TrimEnd()+$block),$data.Encoding)
}
}
function Is-Personal([string]$Relative) {
return ($Relative -match '^(?i:user1|user2|userCCD|userHBA)\\' -or $Relative -in @('yquser.txt','yqshortcut.txt','shortcut_6.7.4.yqs','config.txt'))
}
function Record-Original([string]$Target,[string]$Backup) {
if($script:Recorded.ContainsKey($Target)){return}
$exists=Test-Path -LiteralPath $Target
if($exists){[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Backup))|Out-Null;[IO.File]::Copy($Target,$Backup,$true)}
$entry=[pscustomobject]@{target=$Target;backup=$Backup;existed=$exists}
$script:Journal.Add($entry)
$line=(ConvertTo-Json -InputObject $entry -Compress)+"`n"
$bytes=[Text.Encoding]::UTF8.GetBytes($line)
$fs=New-Object IO.FileStream($script:JournalFile,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$fs.Write($bytes,0,$bytes.Length);$fs.Flush($true)}finally{$fs.Dispose()}
$script:Recorded[$Target]=$true
}
function Restore-Journal {
$errors=New-Object 'System.Collections.Generic.List[string]'
for($i=$script:Journal.Count-1;$i-ge 0;$i--){
$e=$script:Journal[$i]
try{if($e.existed){[IO.File]::Copy($e.backup,$e.target,$true)}elseif(Test-Path -LiteralPath $e.target){[IO.File]::Delete($e.target)}}catch{$errors.Add($e.target+': '+$_.Exception.Message)}
}
return @($errors.ToArray())
}
function File-Sha([string]$Path) {
$fs=[IO.File]::OpenRead($Path)
try{return ([BitConverter]::ToString($script:Hasher.ComputeHash($fs))).Replace('-','').ToLowerInvariant()}finally{$fs.Dispose()}
}
function Timing([string]$Label) {
$now=$script:Clock.Elapsed.TotalSeconds
$script:Metrics.fasi.Add([pscustomobject]@{fase=$Label;secondi=[Math]::Round($now-$script:Mark,3)})
$script:Mark=$now
}
function Save-Metrics([string]$Outcome) {
$script:Metrics.esito=$Outcome
$script:Metrics.secondi_totali=[Math]::Round($script:Clock.Elapsed.TotalSeconds,3)
$json=ConvertTo-Json -InputObject $script:Metrics -Depth 6
$folder=Join-Path $env:LOCALAPPDATA 'YQArchItaliano\Log'
[IO.Directory]::CreateDirectory($folder)|Out-Null
$name='Installazione_3.78_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'.json'
$script:MetricsPath=Join-Path $folder $name
[IO.File]::WriteAllText($script:MetricsPath,$json,[Text.Encoding]::UTF8)
if($backupRoot){[IO.File]::WriteAllText((Join-Path $backupRoot 'prestazioni.json'),$json,[Text.Encoding]::UTF8)}
}
if($Worker){
$tmpRoot=$null;$backupRoot=$null;$currentStage=0
$script:Clock=[Diagnostics.Stopwatch]::StartNew();$script:Mark=0
$script:Metrics=[ordered]@{versione='3.78';esito='';secondi_totali=0;profili=0;copiati=0;invariati=0;personali_conservati=0;obsoleti_rimossi=0;verificati=0;fasi=(New-Object 'System.Collections.Generic.List[object]')}
$script:Hasher=[Security.Cryptography.SHA256]::Create()
$script:Journal=New-Object 'System.Collections.Generic.List[object]';$script:Recorded=@{};$script:VerifiedUnchanged=@{}
try{
Assert-AutoCADClosed
Write-State 2 0 'Rilevamento AutoCAD...' '' 'Avvio installazione YQArch Italiano 3.78' 'info'
if(-not $env:APPDATA){throw 'Variabile APPDATA non disponibile.'}
$profiles=New-Object 'System.Collections.Generic.List[string]'
$base=Join-Path $env:APPDATA 'Autodesk'
if(Test-Path -LiteralPath $base){
foreach($product in Get-ChildItem -LiteralPath $base -Directory){
if($product.Name -notmatch '(?i)^AutoCAD(?!\s+LT)'){continue}
foreach($release in Get-ChildItem -LiteralPath $product.FullName -Directory){
foreach($lang in Get-ChildItem -LiteralPath $release.FullName -Directory){
$sup=Join-Path $lang.FullName 'Support'
if($lang.FullName -notmatch '(?i)AutoIsolate' -and (Test-Path -LiteralPath $sup)){$profiles.Add($sup)}
}
}
}
}
$profiles=@($profiles|Sort-Object -Unique)
if($profiles.Count-eq 0){throw 'Nessun profilo AutoCAD rilevato. Avviare AutoCAD una volta oppure seguire INSTALLAZIONE_LEGACY.md nello ZIP.'}
$script:Metrics.profili=$profiles.Count;Timing 'Rilevamento profili'
$currentStage=1
Write-State 8 1 'Preparazione...' ($profiles.Count.ToString()+' profili rilevati') 'Verifica del pacchetto e preparazione dei backup.' 'info'
Assert-NotCancelled
$tmpRoot=Join-Path $env:TEMP ('YQArchItaliano_378_'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($tmpRoot)|Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$currentStage=2
$zip=[IO.Compression.ZipFile]::OpenRead($PayloadZip)
try{
$entries=@($zip.Entries);$total=[Math]::Max(1,$entries.Count)
for($i=0;$i-lt $entries.Count;$i++){
Assert-NotCancelled;$e=$entries[$i];$dest=Get-SafeDestination $tmpRoot $e.FullName
if([string]::IsNullOrEmpty($e.Name)){[IO.Directory]::CreateDirectory($dest)|Out-Null}else{
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))|Out-Null
$entryStream=$e.Open();try{$targetStream=[IO.File]::Create($dest);try{$entryStream.CopyTo($targetStream)}finally{$targetStream.Dispose()}}finally{$entryStream.Dispose()}
}
if($i%15-eq 0){Write-State (12+[int](15*($i+1)/$total)) 2 'Estrazione del pacchetto...' $e.FullName ''}
}
}finally{$zip.Dispose()}
$src=Join-Path $tmpRoot 'YQArchItaliano\sys'
if(-not(Test-Path -LiteralPath (Join-Path $src 'YQArchItaliano.version'))){throw 'Pacchetto incompleto.'}
$manifest=Get-Content -LiteralPath (Join-Path $tmpRoot 'MANIFEST_SHA256.json') -Encoding UTF8 -Raw|ConvertFrom-Json
Timing 'Estrazione'
$hashes=@{};$done=0
foreach($m in $manifest){
Assert-NotCancelled;$path=Get-SafeDestination $tmpRoot $m.path
if((File-Sha $path) -ne $m.sha256){throw ('Integrita non valida: '+$m.path)}
$hashes[$m.path.Replace('\','/')]=[string]$m.sha256;$done++
if($done%25-eq 0){Write-State (27+[int](3*$done/$manifest.Count)) 2 'Verifica pacchetto...' $m.path ''}
}
Timing 'SHA-256 sorgenti'
$backupRoot=Join-Path $env:LOCALAPPDATA ('YQArchItaliano\Backup\3.78_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,8))
[IO.Directory]::CreateDirectory($backupRoot)|Out-Null
$script:JournalFile=Join-Path $backupRoot 'journal.jsonl'
$currentStage=3;$files=@(Get-ChildItem -LiteralPath $src -Recurse -File)
for($idx=0;$idx-lt $profiles.Count;$idx++){
$prof=$profiles[$idx];$bak=Join-Path $backupRoot ('profilo_'+$idx)
for($i=0;$i-lt $files.Count;$i++){
Assert-NotCancelled;$item=$files[$i];$rel=$item.FullName.Substring($src.Length).TrimStart('\');$dst=Join-Path $prof $rel
if($rel-in @('acad.lsp','acaddoc.lsp')){continue}
if((Is-Personal $rel)-and(Test-Path -LiteralPath $dst)){$script:Metrics.personali_conservati++;continue}
$key='YQArchItaliano/sys/'+$rel.Replace('\','/')
if(-not $hashes.ContainsKey($key)){throw ('File senza manifest: '+$rel)}
if([IO.File]::Exists($dst) -and (Get-Item -LiteralPath $dst).Length -eq $item.Length -and (File-Sha $dst) -eq $hashes[$key]){
$script:Metrics.invariati++;$script:VerifiedUnchanged[$dst]=$true;continue
}
Record-Original $dst (Join-Path $bak $rel)
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dst))|Out-Null
[IO.File]::Copy($item.FullName,$dst,$true);$script:Metrics.copiati++
if($i%15-eq 0){Write-State (30+[int](45*($idx+($i+1)/$files.Count)/$profiles.Count)) 3 'Aggiornamento profili...' $rel ''}
}
foreach($name in @('acad.lsp','acaddoc.lsp')){Record-Original (Join-Path $prof $name) (Join-Path $bak $name)}
Write-Bootstrap $prof
$stems=@('yqarch','gyqarch');foreach($menuVersion in 363..377){$stems+=('YQArchItaliano_Menu_'+$menuVersion)}
foreach($stem in $stems){
foreach($ext in @('mns','mnc','mnr','cui','cuix')){
$rel=$stem+'.'+$ext;$path=Join-Path $prof $rel
if(Test-Path -LiteralPath $path){Record-Original $path (Join-Path $bak $rel);[IO.File]::Delete($path)}
}
}
$obsolete=Join-Path $tmpRoot 'OBSOLETE_FILES_378.json'
if([IO.File]::Exists($obsolete)){
foreach($o in (Get-Content -LiteralPath $obsolete -Encoding UTF8 -Raw|ConvertFrom-Json)){
$target=Get-SafeDestination $prof $o.path
if([IO.File]::Exists($target) -and (File-Sha $target) -eq $o.sha256){
Assert-NotCancelled;Record-Original $target (Join-Path $bak $o.path)
[IO.File]::Delete($target);$script:Metrics.obsoleti_rimossi++
}
}
}
Write-State (30+[int](45*($idx+1)/$profiles.Count)) 3 'Profilo aggiornato' $prof ('Aggiornato: '+$prof) 'ok'
}
Timing 'Backup e aggiornamento profili'
$currentStage=4;Write-State 78 4 'Impostazioni personali conservate' $backupRoot ('Backup: '+$backupRoot) 'ok'
Assert-NotCancelled;$currentStage=5
Write-State 86 5 'Verifica finale...' '' 'Confronto SHA-256 dei file installati.' 'info'
foreach($prof in $profiles){
foreach($item in $files){
$rel=$item.FullName.Substring($src.Length).TrimStart('\')
if($rel-in @('acad.lsp','acaddoc.lsp') -or (Is-Personal $rel)){continue}
$dst=Join-Path $prof $rel
Assert-NotCancelled;$key='YQArchItaliano/sys/'+$rel.Replace('\','/')
if(-not $script:VerifiedUnchanged.ContainsKey($dst) -and (-not [IO.File]::Exists($dst) -or (File-Sha $dst) -ne $hashes[$key])){throw ('Verifica installazione fallita: '+$rel)}
$script:Metrics.verificati++
if($script:Metrics.verificati%25-eq 0){Write-State 90 5 'Verifica file installati...' $rel ''}
}
}
Timing 'SHA-256 destinazioni'
[IO.File]::WriteAllText((Join-Path $backupRoot 'journal.json'),(ConvertTo-Json -InputObject @($script:Journal.ToArray()) -Depth 4),[Text.Encoding]::UTF8)
Save-Metrics 'Completata'
$currentStage=6;Write-State 95 6 'Completamento...' '' 'File installati verificati. Collaudo AutoCAD richiesto.' 'ok'
[IO.File]::WriteAllText((Join-Path $backupRoot 'ESITO.txt'),'Installazione 3.78 completata; backup conservato.',[Text.Encoding]::UTF8)
if($LogFile -and(Test-Path -LiteralPath $LogFile)){[IO.File]::Copy($LogFile,(Join-Path $backupRoot 'installazione.log'),$true)}
Write-State 100 7 'Installazione completata' 'Aprire AutoCAD e lanciare YQIT_DIAGNOSTICA_COMPLETA.' ('Report tempi: '+$script:MetricsPath+' | Backup: '+$backupRoot) 'ok'
exit 0
}catch{
$message=$_.Exception.Message;$restoreErrors=@(Restore-Journal)
if($restoreErrors.Count-gt 0){$message+=' Ripristino incompleto: '+($restoreErrors-join '; ')}elseif($script:Journal.Count-gt 0){$message+=' Modifiche ai file ripristinate.'}
if($backupRoot){$message+=' Backup: '+$backupRoot}
try{Timing 'Interruzione e ripristino';Save-Metrics 'Interrotta'}catch{}
Write-State -1 $currentStage 'Installazione interrotta' $message $message 'error'
exit 1
}finally{
if($script:Hasher){$script:Hasher.Dispose()}
if($tmpRoot-and(Test-Path -LiteralPath $tmpRoot)){Remove-Item -LiteralPath $tmpRoot -Recurse -Force -ErrorAction SilentlyContinue}
}
}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="YQArch Italiano 3.78 – Installazione / Aggiornamento" Width="900" Height="585" MinWidth="900" MinHeight="585" WindowStartupLocation="CenterScreen" ResizeMode="CanMinimize" Background="#F7F9FC" FontFamily="Segoe UI" FontSize="14">
<Grid>
 <Grid.RowDefinitions><RowDefinition Height="116"/><RowDefinition Height="*"/><RowDefinition Height="48"/></Grid.RowDefinitions>
 <Border Grid.Row="0" Background="White" Padding="24,14">
  <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="300"/></Grid.ColumnDefinitions>
   <StackPanel Orientation="Horizontal">
    <Border Width="54" Height="54" CornerRadius="12" Background="#1677FF" Margin="0,0,16,0"><TextBlock Text="⌂" Foreground="White" FontSize="31" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
    <StackPanel><TextBlock Text="YQArch Italiano 3.78" FontSize="25" FontWeight="SemiBold"/><TextBlock Text="Installazione / Aggiornamento" FontSize="17" Foreground="#1769E8" FontWeight="SemiBold" Margin="0,3,0,0"/><TextBlock Text="AutoCAD Windows · collaudo richiesto" FontSize="14" Margin="8,8,0,0"/></StackPanel>
   </StackPanel>
   <Border Grid.Column="1" CornerRadius="12" Background="#EAF3FF" Height="70" VerticalAlignment="Center"><StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,0,14,0"><Border Width="28" Height="28" CornerRadius="14" Background="#19B765" VerticalAlignment="Top" Margin="0,8,9,0"><TextBlock Text="✓" Foreground="White" FontSize="18" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><StackPanel Margin="0,6,0,0"><TextBlock Text="Backup e verifica" FontSize="15.5" FontWeight="SemiBold"/><TextBlock Text="Impostazioni personali conservate" Margin="0,2,0,0"/><TextBlock Text="Backup recuperabile a fine procedura"/></StackPanel></StackPanel></Border>
  </Grid>
 </Border>
 <Grid Grid.Row="1" Margin="18,0,18,8"><Grid.ColumnDefinitions><ColumnDefinition Width="234"/><ColumnDefinition Width="12"/><ColumnDefinition/></Grid.ColumnDefinitions>
  <Border Background="White" CornerRadius="16" BorderBrush="#E8EEF6" BorderThickness="1" Padding="16,10"><StackPanel x:Name="Steps"/></Border>
  <Border Grid.Column="2" Background="White" CornerRadius="16" BorderBrush="#E8EEF6" BorderThickness="1" Padding="22,16"><Grid>
   <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition/></Grid.RowDefinitions>
   <Grid><TextBlock x:Name="Status" Text="Preparazione..." FontSize="17.5" FontWeight="SemiBold" Margin="0,0,84,0" TextWrapping="Wrap"/><TextBlock x:Name="Percent" Text="0%" FontSize="22" Foreground="#1267F4" HorizontalAlignment="Right"/></Grid>
   <TextBlock Grid.Row="1" x:Name="Detail" Text="Avvio installer" Foreground="#38506D" Margin="0,5,0,9" TextTrimming="CharacterEllipsis"/>
   <ProgressBar Grid.Row="2" x:Name="Progress" Height="12" Minimum="0" Maximum="100" Value="0" Foreground="#1677FF" Background="#E7EDF5"/>
   <Grid Grid.Row="3" Margin="0,7,0,7"><Grid.RowDefinitions><RowDefinition/><RowDefinition/></Grid.RowDefinitions><TextBlock x:Name="Elapsed" Text="Tempo trascorso: 00:00" Foreground="#38506D"/><TextBlock Grid.Row="1" x:Name="Remaining" Text="Tempo rimanente stimato: --:--" Foreground="#38506D" HorizontalAlignment="Right"/></Grid>
   <Grid Grid.Row="4"><Grid.RowDefinitions><RowDefinition Height="28"/><RowDefinition/></Grid.RowDefinitions><TextBlock Text="Attività" FontSize="16.5" FontWeight="SemiBold"/><ListBox Grid.Row="1" x:Name="Log" BorderThickness="0" Background="#F7F9FC" Padding="6" FontFamily="Segoe UI" FontSize="12.5" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></Grid>
  </Grid></Border>
 </Grid>
 <Border Grid.Row="2" Background="White" BorderBrush="#E7EDF5" BorderThickness="0,1,0,0"><Grid Margin="20,0"><StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Border Width="20" Height="20" CornerRadius="10" Background="#1677FF"><TextBlock Text="✓" Foreground="White" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><TextBlock Text="Preferenze conservate. Backup dei file modificati disponibile." Margin="9,0,0,0" VerticalAlignment="Center" Foreground="#38506D"/></StackPanel><Button x:Name="CloseBtn" Content="Annulla" Width="110" Height="32" HorizontalAlignment="Right" VerticalAlignment="Center" FontWeight="SemiBold"/></Grid></Border>
</Grid>
</Window>
'@
$reader=New-Object System.Xml.XmlNodeReader $xaml
$win=[Windows.Markup.XamlReader]::Load($reader)
$win.Add_Loaded({ try { $win.Topmost=$true; $win.Activate()|Out-Null; $win.Focus()|Out-Null; $win.Topmost=$false } catch {} })
foreach($n in 'Steps','Status','Percent','Detail','Progress','Elapsed','Remaining','Log','CloseBtn'){ Set-Variable -Name $n -Value $win.FindName($n) }
$stepNames=@('Rilevamento AutoCAD','Preparazione','Installazione pacchetto','Aggiornamento profili','Migrazione impostazioni','Verifica finale','Completamento')
$stepPanels=@()
for($i=0;$i -lt 7;$i++){
$b=New-Object Windows.Controls.Border; $b.CornerRadius=10; $b.Padding='8,4'; $b.Margin='0,0.5'
$sp=New-Object Windows.Controls.StackPanel
$t=New-Object Windows.Controls.TextBlock; $t.Text="○  $($i+1)   $($stepNames[$i])"; $t.FontSize=14; $t.FontWeight='SemiBold'
$s=New-Object Windows.Controls.TextBlock; $s.Text='      In attesa'; $s.Foreground='#60758F'; $s.Margin='0,1,0,0'
$sp.Children.Add($t)|Out-Null; $sp.Children.Add($s)|Out-Null; $b.Child=$sp; $Steps.Children.Add($b)|Out-Null; $stepPanels+=,@($b,$t,$s)
}
$start=Get-Date; $script:done=$false; $script:cancel=$false; $script:finalElapsed=$null; $script:lastStateWrite=[datetime]::MinValue; $script:lastLogCount=0
$work=Join-Path $env:TEMP ('YQArchItaliano_UI_'+[guid]::NewGuid().ToString('N')); [IO.Directory]::CreateDirectory($work)|Out-Null
$stateFile=Join-Path $work 'state.json'; $logFile=Join-Path $work 'activity.log'
$psExe=(Get-Command powershell.exe -ErrorAction Stop).Source
$workerArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-STA','-File',$PSCommandPath,'-PayloadZip',$PayloadZip,'-Worker','-StateFile',$stateFile,'-LogFile',$logFile)
$psi=New-Object Diagnostics.ProcessStartInfo
$psi.FileName=$psExe; $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true
function Q([string]$v){ '"'+($v -replace '"','\"')+'"' }
$psi.Arguments=($workerArgs | ForEach-Object { Q $_ }) -join ' '
$proc=[Diagnostics.Process]::Start($psi)
function Apply-State($m){
if($null -eq $m){return}
$pct=[int]$m.pct; $stage=[int]$m.stage
if($pct -ge 0){$Progress.Value=$pct;$Percent.Text="$pct%"}
if($m.status){$Status.Text=[string]$m.status}; if($m.detail){$Detail.Text=[string]$m.detail}
for($j=0;$j-lt 7;$j++){
$b,$t,$s=$stepPanels[$j]
if($pct -eq 100 -or $j -lt $stage){$t.Text="✓  $($j+1)   $($stepNames[$j])";$t.Foreground='#1769E8';$s.Text='      Completato';$s.Foreground='#60758F';$b.Background='Transparent'}
elseif($j -eq $stage){$t.Text="●  $($j+1)   $($stepNames[$j])";$t.Foreground='#1769E8';$s.Text='      In corso...';$s.Foreground='#1769E8';$b.Background='#EAF3FF'}
else{$t.Text="○  $($j+1)   $($stepNames[$j])";$t.Foreground='#111827';$s.Text='      In attesa';$s.Foreground='#60758F';$b.Background='Transparent'}
}
if($pct -eq 100){if(-not $script:finalElapsed){$script:finalElapsed=(Get-Date)-$start};$script:done=$true;$Elapsed.Text=('Tempo trascorso: {0:mm\:ss}' -f $script:finalElapsed);$CloseBtn.Content='Chiudi';$CloseBtn.IsEnabled=$true;$Remaining.Text='Tempo rimanente stimato: --:--'}
elseif($pct -lt 0){if(-not $script:finalElapsed){$script:finalElapsed=(Get-Date)-$start};$Elapsed.Text=('Tempo trascorso: {0:mm\:ss}' -f $script:finalElapsed);$script:done=$true;$CloseBtn.Content='Chiudi';$CloseBtn.IsEnabled=$true;$Percent.Text='Errore';$Percent.Foreground='Red'; if($stage -ge 0 -and $stage -lt 7){$b,$t,$ss=$stepPanels[$stage];$t.Text="✕  $($stage+1)   $($stepNames[$stage])";$t.Foreground='Red';$ss.Text='      Errore';$ss.Foreground='Red';$b.Background='#FFF1F2'}}
}
$CloseBtn.Add_Click({
if($script:done){$win.Close();return}
$script:cancel=$true;$CloseBtn.Content='Attendere...';$CloseBtn.IsEnabled=$false
[IO.File]::WriteAllText(($stateFile+'.cancel'),'cancel')
$Status.Text='Annullamento e ripristino...'
})
$win.Add_Closing({param($s,$e) if(-not $script:done){$e.Cancel=$true;if(-not $script:cancel){$CloseBtn.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent)))}} })
$timer=New-Object Windows.Threading.DispatcherTimer; $timer.Interval=[TimeSpan]::FromMilliseconds(250)
$timer.Add_Tick({
try{
if(Test-Path -LiteralPath $stateFile){
$fi=Get-Item -LiteralPath $stateFile -ErrorAction SilentlyContinue
if($fi -and $fi.LastWriteTimeUtc -gt $script:lastStateWrite){
$script:lastStateWrite=$fi.LastWriteTimeUtc
$txt=Read-SharedUtf8 $stateFile; if($txt){ try { Apply-State ($txt|ConvertFrom-Json) } catch {} }
}
}
if(Test-Path -LiteralPath $logFile){
$logText=Read-SharedUtf8 $logFile; $lines=@($logText -split "`r?`n" | Where-Object { $_ -ne '' })
if($lines.Count -gt $script:lastLogCount){
for($i=$script:lastLogCount;$i -lt $lines.Count;$i++){$parts=$lines[$i].Split("`t",3); if($parts.Count -ge 3){$icon=if($parts[1]-eq 'ok'){'✓'}elseif($parts[1]-eq 'error'){'✕'}else{'•'};$Log.Items.Add("$icon  $($parts[0])  $($parts[2])")|Out-Null}}
$script:lastLogCount=$lines.Count; if($Log.Items.Count-gt 0){$Log.ScrollIntoView($Log.Items[$Log.Items.Count-1])}
}
}
if(!$script:done){$ts=(Get-Date)-$start;$Elapsed.Text=('Tempo trascorso: {0:mm\:ss}'-f$ts);$p=$Progress.Value;if($p-gt 0){$s=[math]::Max(0,[int]($ts.TotalSeconds*(100-$p)/$p));$Remaining.Text=('Tempo rimanente stimato: {0}:{1:00}'-f[int]($s/60),($s%60))}}
if($proc.HasExited -and !$script:done){$script:done=$true;if($proc.ExitCode-eq 0){$Progress.Value=100;$Percent.Text='100%';$Status.Text='Installazione completata';$Remaining.Text='Tempo rimanente stimato: 0:00'}else{$Status.Text='Installazione interrotta'};$CloseBtn.Content='Chiudi';$CloseBtn.IsEnabled=$true}                                     
}catch{ $Status.Text='Errore interfaccia installer'; $Detail.Text=$_.Exception.Message }
})
$win.Add_ContentRendered({$timer.Start()})
[void]$win.ShowDialog()
$timer.Stop()
if($proc){$proc.WaitForExit()}
$exitCode=if($proc){$proc.ExitCode}else{1}
Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
exit $exitCode
