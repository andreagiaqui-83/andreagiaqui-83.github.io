import unittest,tempfile,shutil
from pathlib import Path
from build_gate import verify_critical_runtime
class BuildGateTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.sys=self.root/'YQArchItaliano/sys';self.sys.mkdir(parents=True)
  actual=Path(__file__).resolve().parent.parent/'YQArchItaliano/sys'
  shutil.copytree(actual,self.sys,dirs_exist_ok=True)
  (self.root/'Sviluppo').mkdir()
  shutil.copy2(Path(__file__).resolve().parent/'installer_378.ps1',self.root/'Sviluppo/installer_378.ps1')
 def tearDown(self):self.tmp.cleanup()
 def test_current_runtime_passes_packaging_gate(self):verify_critical_runtime(self.root)
 def test_lost_insertion_result_blocks_packaging(self):
  p=self.sys/'YQArchItaliano_Library_372.lsp';p.write_text(p.read_text().replace('\n *yql72-committed*)','\n (princ))'))
  with self.assertRaisesRegex(ValueError,'commit'):verify_critical_runtime(self.root)
 def test_unconditional_reopen_blocks_packaging(self):
  p=self.sys/'YQArchItaliano_Library_372.lsp';s=p.read_text().replace('(setq running (and inserted (= "1" (yql72-get "opzione|reopen-success" "0"))))','(setq running T)');p.write_text(s)
  with self.assertRaisesRegex(ValueError,'riapertura'):verify_critical_runtime(self.root)
if __name__=='__main__':unittest.main(verbosity=2)
