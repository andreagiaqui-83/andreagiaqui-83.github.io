"""Regression tests for the 3.78 Ribbon presentation and exact command population."""
import json,unittest,xml.etree.ElementTree as E
from pathlib import Path
from rebuild_ribbon import load_parts
from ribbon_contract import check_layout
from ribbon_layout import PRIMARY_MACROS,DIRECT_ROW_COUNTS,OVERFLOW_ROW_COUNTS,OVERFLOW_UID_PREFIX
from preservation_contract import check_preservation,check_runtime,normalize_runtime
D=Path(__file__).resolve().parent.parent
class AdditiveRibbonTests(unittest.TestCase):
 def setUp(self):
  self.parts=load_parts(D/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix')
  self.ref=json.loads((D/'Sviluppo/ribbon_additions.json').read_text('utf8'))
 def alter(self,fn):
  root=E.fromstring(self.parts['RibbonRoot.cui']);fn(root);self.parts['RibbonRoot.cui']=E.tostring(root)
 def test_full_ribbon_preserves_exact_commands_icons_and_original_slideouts(self):self.assertEqual(check_preservation(self.parts),[])
 def test_every_panel_has_one_primary_five_visible_and_seven_flyout(self):
  r=E.fromstring(self.parts['RibbonRoot.cui'])
  for p in r.iter('RibbonPanelSource'):
   if not (p.get('UID') or '').startswith('YQIT367_PANEL_'):continue
   rows=[]
   for child in p:
    if child.tag=='RibbonPanelBreak':break
    if child.tag=='RibbonRow':rows.append(child)
   self.assertEqual(len(rows),1)
   self.assertEqual(len(list(rows[0].iter('RibbonCommandButton'))),sum(DIRECT_ROW_COUNTS))
   self.assertEqual(tuple(len(r.findall('RibbonCommandButton')) for r in rows[0].find('RibbonRowPanel').findall('RibbonRow')),(3,2))
   self.assertEqual(rows[0].find('RibbonCommandButton').get('MenuMacroID'),PRIMARY_MACROS[p.get('UID')])
   self.assertTrue(all(b.get('ButtonStyle')=='LargeWithText' and b.get('Text') for b in rows[0].findall('RibbonCommandButton')))
   self.assertTrue(all(b.get('ButtonStyle')=='SmallWithoutText' and b.get('Text') for row in rows[0].find('RibbonRowPanel').findall('RibbonRow') for b in row.findall('RibbonCommandButton')))
   overflow=[x for x in p.findall('RibbonRow') if (x.get('UID') or '').startswith(OVERFLOW_UID_PREFIX)]
   self.assertEqual(tuple(len(x.findall('RibbonCommandButton')) for x in overflow),OVERFLOW_ROW_COUNTS)
   self.assertTrue(all(b.get('ButtonStyle')=='SmallWithText' and b.get('Text') for row in overflow for b in row.findall('RibbonCommandButton')))
 def test_40_distinct_added_routes_and_own_icons(self):
  self.assertEqual(len(self.ref),40);self.assertEqual(len({r['button_uid'] for r in self.ref}),40)
  self.assertTrue(all(r['small_image'] in self.parts and r['large_image'] in self.parts for r in self.ref))
 def test_promoted_command_substitution_is_detected(self):
  self.alter(lambda r:next(r.iter('RibbonCommandButton')).set('MenuMacroID','YQIT_MACRO_0001'))
  self.assertIn('promoted command UID/macro/icon population unchanged',check_preservation(self.parts))
 def test_primary_change_is_detected(self):
  def change(r):
   row=next(r.iter('RibbonPanelSource')).findall('RibbonRow')[0];row.find('RibbonCommandButton').set('MenuMacroID','YQIT_MACRO_0024')
  self.alter(change);self.assertIn('expected primary command in YQIT367_PANEL_01',check_layout(self.parts))
 def test_primary_label_loss_is_detected(self):
  self.alter(lambda r:next(r.iter('RibbonCommandButton')).set('Text',''))
  self.assertIn('labelled primary button in YQIT367_PANEL_01',check_layout(self.parts))
 def test_promoted_button_icon_mutation_is_detected(self):
  self.alter(lambda r:next(r.iter('RibbonCommandButton')).set('SmallImage','unknown.bmp'))
  self.assertIn('promoted command UID/macro/icon population unchanged',check_preservation(self.parts))
 def test_overflow_button_loss_is_detected(self):
  def remove(r):
   p=next(r.iter('RibbonPanelSource'));row=next(x for x in p.findall('RibbonRow') if (x.get('UID') or '').startswith(OVERFLOW_UID_PREFIX));row.remove(row.find('RibbonCommandButton'))
  self.alter(remove);self.assertIn('4/3 flyout buttons in YQIT367_PANEL_01',check_layout(self.parts))
 def test_original_expanded_route_change_is_detected(self):
  def mutate(r):
   p=next(r.iter('RibbonPanelSource'));row=next(x for x in p.findall('RibbonRow') if not (x.get('UID') or '').startswith(OVERFLOW_UID_PREFIX) and x.find('RibbonSplitButton') is not None);row.find('.//RibbonCommandButton').set('Text','X')
  self.alter(mutate);self.assertIn('original expanded routes and panel identities unchanged',check_preservation(self.parts))
 def test_all_operation_macros_unchanged(self):
  r=E.fromstring(self.parts['MenuGroup.cui']);old=E.fromstring((D/'Sviluppo/macros_370_reference.xml').read_bytes())
  macro=lambda t:{m.get('UID'):m.findtext('Macro/Command') for m in t.iter('MenuMacro')}
  self.assertEqual(macro(r),macro(old))
 def test_command_mutation_detected_even_with_nonempty_tooltip(self):
  r=E.fromstring(self.parts['MenuGroup.cui']);r.find('.//Command').text='^c^c_ERASE';self.parts['MenuGroup.cui']=E.tostring(r)
  self.assertIn('macro definitions unchanged apart from allowed help',check_preservation(self.parts))
 def test_blank_new_tooltip_is_detected(self):
  mid=self.ref[0]['macro_id'];r=E.fromstring(self.parts['MenuGroup.cui']);next(m for m in r.iter('MenuMacro') if m.get('UID')==mid).find('Macro/HelpString').text='';self.parts['MenuGroup.cui']=E.tostring(r)
  self.assertIn('new icon tooltip description',check_preservation(self.parts))
 def test_bmp_change_is_rejected_even_with_valid_relationships(self):
  n=next(n for n in self.parts if n.endswith('.bmp'));self.parts[n]=self.parts[n][:-1]+bytes([self.parts[n][-1]^1])
  self.assertIn('baseline BMP and OPC container bytes unchanged',check_preservation(self.parts))
 def test_installed_runtime_preserves_370_behaviors(self):self.assertEqual(check_runtime(D),[])
 def test_stable_367_identity_remains_historical(self):self.assertEqual(normalize_runtime(b'YQIT_TAB_367 YQIT367_PANEL_01'),b'YQIT_TAB_367 YQIT367_PANEL_01')
 def test_regenerate_actual_cuix_identically(self):
  import tempfile,shutil
  from generate_ribbon import generate
  original=D/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix'
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'ribbon.cuix';shutil.copy2(original,target);generate(target)
   self.assertEqual(target.read_bytes(),original.read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
