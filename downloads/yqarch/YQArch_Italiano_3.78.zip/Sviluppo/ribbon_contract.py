"""Project regression contract, NOT an Autodesk schema validator.
Keep stable 3.67 tab/panel identities and the exact command/icon population.
3.78 changes only presentation: 1 labelled primary + 5 compact visible + 7 in
panel flyout. The identity suffix 367 is historical and must NOT change.
"""
import xml.etree.ElementTree as E
from rebuild_ribbon import check_relationships
from ribbon_layout import PRIMARY_MACROS,DIRECT_ROW_COUNTS,SMALL_ROW_COUNTS,OVERFLOW_ROW_COUNTS,OVERFLOW_UID_PREFIX
TAB='YQIT_TAB_367'
PANEL_IDS=[f'YQIT367_PANEL_{i:02}' for i in range(1,11)]
STYLES={'LargeWithHorizontalText','LargeWithoutText','LargeWithText','SmallWithoutText','SmallWithText'}

def _direct_rows(panel):
 rows=[]
 for c in panel:
  if c.tag=='RibbonPanelBreak':break
  if c.tag=='RibbonRow':rows.append(c)
 return rows

def check_layout(parts):
 errors=[]
 def need(ok,label):
  if not ok:errors.append(label)
 root=E.fromstring(parts['RibbonRoot.cui']);macros=E.fromstring(parts['MenuGroup.cui'])
 need(macros.get('Name')=='YQARCHITALIANO_RIBBON','own group')
 tabs=list(root.iter('RibbonTabSource'));panels=list(root.iter('RibbonPanelSource'))
 need(len(tabs)==1 and tabs[0].get('UID')==TAB,'stable tab identity')
 need([p.get('UID') for p in panels]==PANEL_IDS,'stable panel identities')
 for t in tabs:
  need(t.get('DefaultDisplay')=='AddToWorkspace','add tab to workspace')
  need([p.get('PanelId') for p in t.iter('RibbonPanelSourceReference')]==PANEL_IDS,'all ten panels referenced')
 direct=[];overflow=[];expanded_original=[];cats=[]
 for p in panels:
  rows=_direct_rows(p);is_expanded=False;overflow_rows=[]
  for c in p:
   if c.tag=='RibbonPanelBreak':is_expanded=True;continue
   if c.tag=='RibbonRow' and is_expanded:
    if (c.get('UID') or '').startswith(OVERFLOW_UID_PREFIX):overflow_rows.append(c)
    else:
     expanded_original+=list(c.iter('RibbonCommandButton'));cats+=c.findall('RibbonSplitButton')
  pid=p.get('UID','')
  need(len(p.findall('RibbonPanelBreak'))==1,'one panel break in '+pid)
  need(len(rows)==1,'one outer visible row in '+pid)
  need(all(c.tag in ('ModifiedRev','Name','Alias','RibbonRow','RibbonPanelBreak') for c in p),'known panel children in '+pid)
  need(len(overflow_rows)==2,'two overflow rows in '+pid)
  need(tuple(len(r.findall('RibbonCommandButton')) for r in overflow_rows)==OVERFLOW_ROW_COUNTS,'4/3 flyout buttons in '+pid)
  for row in rows:
   primary=row.findall('RibbonCommandButton')
   stacks=row.findall('RibbonRowPanel')
   direct+=list(row.iter('RibbonCommandButton'))
   need(len(primary)==1 and primary[0].get('MenuMacroID')==PRIMARY_MACROS.get(pid),'expected primary command in '+pid)
   need(len(primary)==1 and all(b.get('ButtonStyle')=='LargeWithText' and bool((b.get('Text') or '').strip()) for b in primary),'labelled primary button in '+pid)
   need(len(stacks)==1,'one adjacent small stack in '+pid)
   need([c.tag for c in row if c.tag!='ModifiedRev']==['RibbonCommandButton','RibbonRowPanel'],'primary and stack share outer row in '+pid)
   for stack in stacks:
    subrows=stack.findall('RibbonRow')
    need(stack.get('UID')==pid+'_SMALL_STACK','stable small stack identity in '+pid)
    need(not list(stack.iter('RibbonRowPanel'))[1:],'no nested small stack in '+pid)
    need(all(c.tag in ('ModifiedRev','RibbonRow') for c in stack),'only small rows inside stack in '+pid)
    need(tuple(len(r.findall('RibbonCommandButton')) for r in subrows)==SMALL_ROW_COUNTS,'3/2 small stack in '+pid)
    for subrow in subrows:
     need(all(c.tag in ('ModifiedRev','RibbonCommandButton') for c in subrow),'only buttons inside small rows in '+pid)
     need(all(b.get('ButtonStyle')=='SmallWithoutText' and bool((b.get('Text') or '').strip()) for b in subrow.findall('RibbonCommandButton')),'compact visible secondary buttons in '+pid)
   # Symbolic layout budget, not a pixel measurement or AutoCAD certificate.
   # Sibling panel rows sum; items sharing a row take the maximum height.
   def units(node):
    if node.tag=='ModifiedRev':return 0
    if node.tag=='RibbonCommandButton':return 3 if node.get('ButtonStyle','').startswith('Large') else 1
    children=[c for c in node if c.tag!='ModifiedRev']
    if node.tag=='RibbonRow':return max([units(c) for c in children] or [1])
    if node.tag=='RibbonRowPanel':return sum(units(c) for c in children)
    return 99
   need(sum(units(r) for r in rows)<=3,'standard structural height budget in '+pid)
  for row in overflow_rows:
   buttons=row.findall('RibbonCommandButton');overflow+=buttons
   need(all(b.get('ButtonStyle')=='SmallWithText' and bool((b.get('Text') or '').strip()) for b in buttons),'labelled small flyout buttons in '+pid)
 need(len(direct)==60,'60 visible buttons')
 need(sum(1 for b in direct if b.get('ButtonStyle')=='LargeWithText')==10,'10 labelled primary buttons')
 need(sum(1 for b in direct if b.get('ButtonStyle')=='SmallWithoutText')==50,'50 compact visible secondary buttons')
 need(len(overflow)==70,'70 flyout buttons')
 need(len(expanded_original)==547,'547 original expanded command routes')
 need(len(cats)==23,'23 expanded categories')
 need(len(direct)+len(overflow)==130,'130 promoted access routes preserved')
 mm={m.get('UID'):m.find('Macro') for m in macros.iter('MenuMacro')}
 for b in root.iter('RibbonCommandButton'):
  m=mm.get(b.get('MenuMacroID'))
  need(m is not None,'valid macro reference')
  if m is not None:need(bool(m.findtext('Name')) and bool(m.findtext('HelpString')) and bool(m.findtext('Command')),'tooltip and command')
  need(b.get('ButtonStyle') in STYLES,'known button style')
 for e in [*root.iter(),*macros.iter()]:
  for k in ('SmallImage','LargeImage'):
   if e.get(k):need(e.get(k) in parts,'image attribute reference')
  if e.tag in ('SmallImage','LargeImage'):need(e.get('Name') in parts,'macro image reference')
 uids=[e.get('UID') for e in root.iter() if e.get('UID')]
 need(len(uids)==len(set(uids)),'unique UIDs')
 missing,edges=check_relationships(parts);need(not missing and len(edges)==933,'OPC closure')
 need(sum(n.endswith('.bmp') for n in parts)==916 and not any(n.endswith('.png') for n in parts),'consistent BMP package')
 from preservation_contract import check_preservation
 errors.extend(check_preservation(parts))
 return sorted(set(errors))
