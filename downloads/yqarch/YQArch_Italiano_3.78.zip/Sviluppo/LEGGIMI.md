# Ricostruzione YQArch Italiano 3.78

Il payload completo si ricostruisce con Python standard da questa directory pulita.
Il launcher PE e il core compilato sono binari originali conservati, non ricompilati né firmati.

`python Sviluppo/ricompila.py --baseline /originali/YQArch_Italiano_3.71.exe --out /output/esterno`

Baseline SHA-256: b2362f9f20c7dd5b3f83eecc0eed085cc595ee8455d7d1e366c6beadeb7095dd.

Eseguire unittest, validate.py con baseline 3.73, validate_package.py sui byte dell'EXE e una seconda build dalla cartella estratta. Le suite simulate non sono un collaudo Windows/AutoCAD.

La Ribbon usa una riga principale con un grande e un sottopannello piccoli affiancati. Il vecchio divieto di RibbonRowPanel era scorretto. I test di altezza verificano la semantica dei contenitori, non il motore WPF. Identificatori 367/372 stabili; non rinumerarli.

Prova grafica nativa della 3.77 acquisita il 3 ottobre 2026; il CUIx della 3.78 è identico. I report STORICO_AUDIT_3.76 e STORICO_AUDIT_3.77 sono evidenza storica. Conservare la distinzione fra verifiche automatiche 3.78 e collaudo nativo 3.77.
