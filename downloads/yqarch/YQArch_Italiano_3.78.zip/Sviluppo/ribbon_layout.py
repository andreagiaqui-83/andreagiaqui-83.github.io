"""Ribbon YQArch Italiano 3.78.
Una riga principale con grande e sottopannello piccoli affiancati.
Collaudo grafico AutoCAD ancora richiesto; nessuna certificazione di pixel.
Comandi, UID dei pulsanti/pannelli/scheda, macro e risorse preservati.
"""
import xml.etree.ElementTree as E

PRIMARY_MACROS={
 'YQIT367_PANEL_01':'YQIT_MACRO_0025', # Disegna muro
 'YQIT367_PANEL_02':'YQIT_MACRO_0042', # Disegna porta
 'YQIT367_PANEL_03':'YQIT_MACRO_0070', # Pianta vano scala
 'YQIT367_PANEL_04':'YQIT_MACRO_0126', # Simbolo di sezione
 'YQIT367_PANEL_05':'YQIT_MACRO_0232', # Quota lineare
 'YQIT367_PANEL_06':'YQIT_MACRO_0380', # Catalogo blocchi YQArch
 'YQIT367_PANEL_07':'YQIT_MACRO_0408', # Crea layer
 'YQIT367_PANEL_08':'YQIT_MACRO_0339', # Azzera quota Z
 'YQIT367_PANEL_09':'YQIT_MACRO_0164', # Numerazione automatica
 'YQIT367_PANEL_10':'YQIT_MACRO_0011', # Guida YQArch Italiano
}
# Una sola riga principale: grande e sottopannello piccoli affiancati.
# DIRECT_ROW_COUNTS descrive i gruppi funzionali, NON righe principali.
DIRECT_ROW_COUNTS=(1,5)
SMALL_ROW_COUNTS=(3,2)
# I sette promoted rimanenti vanno nel flyout inferiore; la loro disposizione
# non influenza l'altezza della Ribbon quando il pannello è chiuso.
OVERFLOW_ROW_COUNTS=(4,3)
OVERFLOW_UID_PREFIX='YQIT_OVERFLOW_'


def macro_names(macros_root):
    return {m.get('UID'):(m.findtext('Macro/Name') or '').strip() for m in macros_root.iter('MenuMacro')}


def _new_row(uid):
    row=E.Element('RibbonRow',{'UID':uid})
    E.SubElement(row,'ModifiedRev',{'MajorVersion':'18','MinorVersion':'0','UserVersion':'0'})
    return row


def _direct_rows(panel):
    """Return only rows before RibbonPanelBreak."""
    rows=[]
    for child in panel:
        if child.tag=='RibbonPanelBreak':
            break
        if child.tag=='RibbonRow':
            rows.append(child)
    return rows


def apply_presentation(root:E.Element, macros_root:E.Element)->None:
    names=macro_names(macros_root)
    panels={p.get('UID'):p for p in root.iter('RibbonPanelSource')}
    for pid,primary_mid in PRIMARY_MACROS.items():
        panel=panels[pid]
        rows=_direct_rows(panel)
        if len(rows) < 3:
            raise ValueError('Struttura Ribbon baseline inattesa in '+pid)
        base_rows=rows[:3]
        buttons=[b for row in base_rows for b in row.findall('RibbonCommandButton')]
        by_mid={b.get('MenuMacroID'):b for b in buttons}
        if len(buttons)!=13 or primary_mid not in by_mid:
            raise ValueError('Popolazione Ribbon inattesa in '+pid)

        # Preserve the established order of every secondary command, moving only
        # the selected primary to the first position.
        ordered=[by_mid[primary_mid]]+[b for b in buttons if b.get('MenuMacroID')!=primary_mid]
        visible_count=sum(DIRECT_ROW_COUNTS)
        visible=ordered[:visible_count]
        overflow=ordered[visible_count:]
        if len(overflow)!=sum(OVERFLOW_ROW_COUNTS):
            raise ValueError('Conteggio overflow inatteso in '+pid)

        # Remove every promoted button from the original three rows.
        for row in base_rows:
            for b in list(row.findall('RibbonCommandButton')):
                row.remove(b)

        # LargeWithText occupies the full standard button height. A sibling
        # RibbonRow BELOW it adds vertical height even with only small buttons.
        # Put the small stack BESIDE it, within the same outer RibbonRow.
        main_row=base_rows[0]
        main_row.set('ResizeStyle','None')
        main_row.set('ResizePriority','100')
        main_row.set('TopJustify','True')
        primary=visible[0]
        primary.set('Text',names[primary.get('MenuMacroID')])
        primary.set('ButtonStyle','LargeWithText')
        primary.set('KeyTip','')
        main_row.append(primary)
        stack=E.SubElement(main_row,'RibbonRowPanel',{
            'UID':pid+'_SMALL_STACK','ResizeStyle':'None',
            'ResizePriority':'100','TopJustify':'True'})
        E.SubElement(stack,'ModifiedRev',{'MajorVersion':'18','MinorVersion':'0','UserVersion':'0'})
        pos=1
        for row,count in zip(base_rows[1:],SMALL_ROW_COUNTS):
            panel.remove(row)  # Preserve row UID, change only its parent.
            row.set('ResizeStyle','None')
            row.set('ResizePriority','100')
            row.set('TopJustify','True')
            for b in visible[pos:pos+count]:
                label=names.get(b.get('MenuMacroID'),'')
                if not label: raise ValueError('Etichetta macro mancante')
                b.set('Text',label)
                b.set('ButtonStyle','SmallWithoutText')
                b.set('KeyTip','')
                row.append(b)
            stack.append(row)
            pos+=count

        # Remove generated overflow from a previous run, keeping regeneration
        # idempotent when applied to a generated XML in development.
        for child in list(panel):
            if child.tag=='RibbonRow' and (child.get('UID') or '').startswith(OVERFLOW_UID_PREFIX):
                panel.remove(child)

        children=list(panel)
        break_index=next((i for i,c in enumerate(children) if c.tag=='RibbonPanelBreak'),None)
        if break_index is None:
            raise ValueError('RibbonPanelBreak mancante in '+pid)
        insert_at=break_index+1
        pnum=pid.rsplit('_',1)[-1]
        pos=0
        for oi,count in enumerate(OVERFLOW_ROW_COUNTS,1):
            row=_new_row(f'{OVERFLOW_UID_PREFIX}P{pnum}_R{oi}')
            for b in overflow[pos:pos+count]:
                mid=b.get('MenuMacroID');label=names.get(mid,'')
                if not label: raise ValueError('Etichetta macro mancante: '+str(mid))
                b.set('Text',label)
                b.set('ButtonStyle','SmallWithText')
                b.set('KeyTip','')
                row.append(b)
            panel.insert(insert_at,row);insert_at+=1;pos+=count
        if pos!=len(overflow):
            raise AssertionError('Conteggio overflow Ribbon non coerente')
