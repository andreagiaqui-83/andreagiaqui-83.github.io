from pathlib import Path
import base64,html,zipfile,xml.etree.ElementTree as E
from ribbon_layout import OVERFLOW_UID_PREFIX
ROOT=Path(__file__).resolve().parent.parent
CUIX=ROOT/'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.cuix'
OUT=ROOT/'YQArchItaliano/sys/YQArchItaliano_Ribbon_Catalogo.html'
with zipfile.ZipFile(CUIX) as z:
    parts={n:z.read(n) for n in z.namelist()}
root=E.fromstring(parts['RibbonRoot.cui']);mg=E.fromstring(parts['MenuGroup.cui'])
mm={m.get('UID'):m.find('Macro') for m in mg.iter('MenuMacro')}
def rec(b):
    mid=b.get('MenuMacroID');m=mm[mid];name=(m.findtext('Name') or b.get('Text') or mid).strip();helptext=(m.findtext('HelpString') or '').strip();cmd=(m.findtext('CLICommand') or '').strip();img=b.get('LargeImage') if b.get('ButtonStyle','').startswith('Large') else b.get('SmallImage');raw=parts[img]
    return name,helptext,cmd,'data:image/bmp;base64,'+base64.b64encode(raw).decode()
def direct_rows(panel):
    rows=[]
    for child in panel:
        if child.tag=='RibbonPanelBreak':break
        if child.tag=='RibbonRow':rows.append(child)
    return rows
panels=[]
for p in root.iter('RibbonPanelSource'):
    if not (p.get('UID') or '').startswith('YQIT367_PANEL_'): continue
    visible=[];overflow=[]
    for ri,row in enumerate(direct_rows(p)):
        for b in row.iter('RibbonCommandButton'):
            name,hp,cmd,img=rec(b);visible.append((0 if b.get('ButtonStyle')=='LargeWithText' else 1,name,hp,cmd,img))
    for row in p.findall('RibbonRow'):
        if (row.get('UID') or '').startswith(OVERFLOW_UID_PREFIX):
            for b in row.findall('RibbonCommandButton'):
                name,hp,cmd,img=rec(b);overflow.append((name,hp,cmd,img))
    panels.append((p.get('Text'),visible,overflow))
css='''
:root{--bg:#202a36;--panel:#39485a;--line:#64748b;--ink:#f8fafc;--muted:#cbd5e1;--accent:#9ed0ff;--tile:#2e3b4b}*{box-sizing:border-box}body{margin:0;background:#111827;color:var(--ink);font-family:Segoe UI,Arial,sans-serif}.wrap{max-width:1800px;margin:auto;padding:24px}h1{margin:0 0 8px}p{color:var(--muted)}.bar{display:grid;grid-template-columns:repeat(5,minmax(290px,1fr));gap:10px}.panel{background:var(--panel);border:1px solid #526174;border-radius:8px;padding:8px 8px 5px;min-width:0}.mainrow{display:flex;gap:10px;align-items:center;justify-content:center}.primary{display:flex;justify-content:center;min-height:88px}.primary .tool{width:min(190px,100%);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:var(--tile);border:1px solid #526174;border-radius:5px;padding:6px;font-weight:600;font-size:12px}.primary img{width:32px;height:32px;margin-bottom:4px}.secondary{display:grid;grid-template-columns:repeat(3,24px);gap:6px;justify-content:center;margin-top:7px}.small{display:flex;align-items:center;justify-content:center;width:24px;height:24px;background:var(--tile);border:1px solid #526174;border-radius:3px}.small img{max-width:16px;max-height:16px}.panel h3{font-size:12px;text-align:center;font-weight:500;margin:7px 0 0;padding-top:5px;border-top:1px solid #526174;color:#f3f4f6}.flyout{margin-top:8px;padding:8px;border:1px dashed #738196;border-radius:5px;background:#263343}.flyout summary{cursor:pointer;font-size:11px;color:#dce7f3}.flygrid{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:8px}.flytool{display:flex;align-items:center;gap:6px;min-width:0;background:#314154;border:1px solid #526174;border-radius:4px;padding:5px;font-size:10px}.flytool img{width:16px;height:16px;flex:0 0 16px}.flytool span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.legend{margin-top:18px;padding:14px;border:1px solid #334155;border-radius:8px;background:#172033}.cmd{color:var(--accent)}@media(max-width:1550px){.bar{grid-template-columns:repeat(4,minmax(280px,1fr))}}@media(max-width:1200px){.bar{grid-template-columns:repeat(3,minmax(270px,1fr))}}@media(max-width:900px){.bar{grid-template-columns:repeat(2,minmax(260px,1fr))}}@media(max-width:600px){.wrap{padding:14px}.bar{grid-template-columns:1fr}.primary .tool{font-size:13px}}
'''
out=['<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Schema Ribbon YQArch Italiano 3.78</title><style>',css,'</style></head><body><main class="wrap"><h1>Ribbon YQArch Italiano 3.78</h1><p><strong>Versione 3.78: CUIx identico alla 3.77 collaudata su AutoCAD 2027 italiano.</strong></p><p>Schema ricavato direttamente dal CUIx distribuito. <strong>Non è uno screenshot di AutoCAD</strong>. Ogni pannello mostra 1 comando principale grande e un sottopannello di 5 secondari piccoli affiancato al principale; gli altri 7 accessi promossi passano nella freccia/flyout. Il vincolo progettuale è non aumentare l’altezza standard della Ribbon di AutoCAD. I 130 accessi promossi, le 23 categorie e le 547 rotte complete restano disponibili.</p><section class="bar">']
for title,visible,overflow in panels:
    out.append('<article class="panel"><div class="mainrow"><div class="primary">')
    for ri,name,hp,cmd,img in visible:
        if ri==0:
            tip=html.escape(name+' — '+hp);out.append(f'<span class="tool" title="{tip}"><img src="{img}" alt=""><span>{html.escape(name)}</span></span>')
    out.append('</div><div class="secondary">')
    for ri,name,hp,cmd,img in visible:
        if ri==1:
            tip=html.escape(name+' — '+hp);out.append(f'<span class="small" tabindex="0" title="{tip}" aria-label="{tip}"><img src="{img}" alt=""></span>')
    out.append('</div></div>')
    out.append('<details class="flyout"><summary>Altri comandi nella freccia del pannello</summary><div class="flygrid">')
    for name,hp,cmd,img in overflow:
        tip=html.escape(name+' — '+hp);out.append(f'<span class="flytool" title="{tip}"><img src="{img}" alt=""><span>{html.escape(name)}</span></span>')
    out.append('</div></details>')
    out.append(f'<h3>{html.escape(title)} ▾</h3></article>')
out.append('</section><div class="legend"><strong>Struttura 3.78.</strong> Un solo comando principale grande per pannello; cinque secondari restano piccoli in due righe interne al sottopannello affiancato; altri sette sono spostati nel flyout inferiore. La riga principale è unica: non somma verticalmente pulsante grande e piccoli. Nessun comando o UID viene eliminato e le categorie storiche restano sotto la stessa freccia.</div></main></body></html>')
OUT.write_text(''.join(out),encoding='utf-8')
print(OUT,OUT.stat().st_size)
