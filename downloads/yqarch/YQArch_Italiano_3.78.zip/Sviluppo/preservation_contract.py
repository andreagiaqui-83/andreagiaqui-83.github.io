"""Regression constraints pinned to actual 3.70/3.73 behavior.

3.78 may reorganize only the 130 promoted Ribbon access buttons: 60 remain visible
and 70 are moved into generated flyout rows. Commands, UIDs, images, original
expanded categories/routes, macro commands and OPC assets must remain identical
to the known working population.
"""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as E
from ribbon_layout import OVERFLOW_UID_PREFIX
HERE=Path(__file__).resolve().parent


def _direct_expected():
    """Expected promoted-button identity/macro/icon set from 3.70 + 40 additions."""
    base=E.fromstring((HERE/'ribbon_370_reference.xml').read_bytes())
    expected={}
    for panel in base.iter('RibbonPanelSource'):
        for row in panel.findall('RibbonRow')[:3]:
            for b in row.findall('RibbonCommandButton'):
                expected[b.get('UID')]=(b.get('MenuMacroID'),b.get('SmallImage'),b.get('LargeImage'))
    for r in json.loads((HERE/'ribbon_additions.json').read_text('utf8')):
        expected[r['button_uid']]=(r['macro_id'],r['small_image'],r['large_image'])
    return expected


def _promoted_actual(root):
    """Collect all 130 promoted routes whether visible or moved to the flyout."""
    actual={}
    for panel in root.iter('RibbonPanelSource'):
        # Rows before RibbonPanelBreak are the visible portion.
        for child in panel:
            if child.tag=='RibbonPanelBreak': break
            if child.tag=='RibbonRow':
                for b in child.iter('RibbonCommandButton'):
                    actual[b.get('UID')]=(b.get('MenuMacroID'),b.get('SmallImage'),b.get('LargeImage'))
        # 3.78-generated overflow rows live after RibbonPanelBreak.
        for row in panel.findall('RibbonRow'):
            if (row.get('UID') or '').startswith(OVERFLOW_UID_PREFIX):
                for b in row.findall('RibbonCommandButton'):
                    actual[b.get('UID')]=(b.get('MenuMacroID'),b.get('SmallImage'),b.get('LargeImage'))
    return actual


def _strip_promoted(root):
    """Remove visible promoted rows and generated overflow rows before baseline compare."""
    for panel in root.iter('RibbonPanelSource'):
        direct=[]
        for child in list(panel):
            if child.tag=='RibbonPanelBreak': break
            if child.tag=='RibbonRow': direct.append(child)
        for row in direct:
            panel.remove(row)
        for row in list(panel.findall('RibbonRow')):
            if (row.get('UID') or '').startswith(OVERFLOW_UID_PREFIX):
                panel.remove(row)
    return root


def check_preservation(parts):
    errors=[]
    def need(ok,message):
        if not ok: errors.append(message)
    root=E.fromstring(parts['RibbonRoot.cui'])
    expected=_direct_expected();actual=_promoted_actual(root)
    need(actual==expected,'promoted command UID/macro/icon population unchanged')

    # After removing the visible promoted rows and the generated overflow rows,
    # everything else (break, original slideout, categories and 547 routes) must
    # remain element-equivalent to the pinned 3.70 UI.
    residual=_strip_promoted(E.fromstring(parts['RibbonRoot.cui']))
    baseline=_strip_promoted(E.fromstring((HERE/'ribbon_370_reference.xml').read_bytes()))
    need(E.tostring(residual)==E.tostring(baseline),'original expanded routes and panel identities unchanged')

    # Macro commands are immutable; only the 40 pre-existing tooltip descriptions
    # introduced by 3.71+ are allowed to differ from 3.70.
    oldmg=E.fromstring((HERE/'macros_370_reference.xml').read_bytes());mg=E.fromstring(parts['MenuGroup.cui'])
    previous={m.get('UID'):m.find('Macro') for m in oldmg.iter('MenuMacro')}
    records=json.loads((HERE/'ribbon_additions.json').read_text('utf8'))
    helpmap={r['macro_id']:r['function'] for r in records}
    for m in mg.iter('MenuMacro'):
        mid=m.get('UID')
        if mid in helpmap:
            need(m.findtext('Macro/HelpString')==helpmap[mid],'new icon tooltip description')
            m.find('Macro/HelpString').text=previous[mid].findtext('HelpString')
    need(E.tostring(mg)==E.tostring(oldmg),'macro definitions unchanged apart from allowed help')

    asset=json.loads((HERE/'ribbon_assets_reference.json').read_text())['parts']
    need(set(parts)==set(asset)|{'RibbonRoot.cui','MenuGroup.cui'},'same CUIx parts as 3.70')
    need(all(n in parts and hashlib.sha256(parts[n]).hexdigest()==digest for n,digest in asset.items()),'baseline BMP and OPC container bytes unchanged')
    return sorted(set(errors))


def normalize_runtime(raw: bytes) -> bytes:
    """Undo only explicitly allowed release references and diagnostic counts."""
    pairs=[(b'3.78',b'3.70'),(b'3.78',b'3.70'),(b'3.73',b'3.70'),(b'3.72',b'3.70'),(b'_372',b'_370'),(b'-372',b'-370'),(b'YQLIB371',b'YQLIB370'),
           (b'yqit372',b'yqit370'),(b'YQIT372',b'YQIT370'),(b'YQL72',b'YQL70'),(b'yql72',b'yql70'),
           (b'YQR72',b'YQR70'),(b'yqr72',b'yqr70'),(b'YQT72',b'YQT70'),(b'yqt72',b'yqt70'),
           (b'10 comandi principali grandi con etichetta, 50 secondari visibili compatti e 70 secondari nel flyout',b'30 icone grandi e 60 piccole'),
           (b'10 pannelli, 60 accessi visibili e 70 nel flyout',b'10 pannelli, 90 accessi'),
           (b'10 grandi con testo + 50 piccoli visibili + 70 piccoli nel flyout',b'30 grandi + 60 piccoli'),
           (b'20 icone grandi etichettate e 110 piccole',b'30 icone grandi e 60 piccole'),
           (b'10 pannelli, 130 accessi',b'10 pannelli, 90 accessi'),
           (b'20 grandi con testo + 110 piccoli',b'30 grandi + 60 piccoli'),
           (b'30 icone grandi e 100 piccole',b'30 icone grandi e 60 piccole'),
           (b'30 grandi + 100 piccoli',b'30 grandi + 60 piccoli')]
    for a,b in pairs:raw=raw.replace(a,b)
    return raw


def check_runtime(root):
    records=json.loads((HERE/'runtime_370_reference.json').read_text('utf8'))
    problems=[]
    allowed_changed={
        'YQArchItaliano/sys/YQArchItaliano_Library_372.lsp',
        'YQArchItaliano/sys/YQArchItaliano_Ribbon_372.lsp',
        'Sviluppo/installer_378.ps1',
    }
    for rec in records:
        # Historical reference names the previous installer; current package must
        # carry only installer_378.ps1.
        if rec['path'].startswith('Sviluppo/installer_'):
            p=root/'Sviluppo/installer_378.ps1'
            if not p.is_file():problems.append('missing current installer')
            continue
        p=root/rec['path']
        if not p.is_file():problems.append('missing pinned runtime '+rec['path']);continue
        if rec['path'] in allowed_changed: continue
        if hashlib.sha256(normalize_runtime(p.read_bytes())).hexdigest()!=rec['sha256']:
            problems.append('runtime behavior changed '+rec['path'])
    lib=(root/'YQArchItaliano/sys/YQArchItaliano_Library_372.lsp').read_text('ascii')
    for marker in (
        '(defun yql72-dwg-compatible-p',
        '((not (yql72-dwg-compatible-p path)) nil)',
        'PUNTO_ACQUISITO','VERIFICA_ENTITA',
        '(setq running (and inserted (= "1" (yql72-get "opzione|reopen-success" "0"))))',
        '(defun c:YQIT_VERIFICA_INSERIMENTO'):
        if marker not in lib:problems.append('catalog protection marker missing '+marker)
    installer=(root/'Sviluppo/installer_378.ps1').read_text('utf-8-sig')
    for marker in ('$script:VerifiedUnchanged[$dst]=$true','$script:VerifiedUnchanged.ContainsKey($dst)','foreach($menuVersion in 363..377)','Restore-Journal'):
        if marker not in installer:problems.append('installer protection marker missing '+marker)
    return problems
