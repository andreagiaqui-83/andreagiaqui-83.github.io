"""Rebuild complete 3.78 EXE/ZIP from this distribution and exact 3.71 launcher.
Python standard library only. No download, no execution of Windows/AutoCAD code.
The launcher binary is reused; this script does not claim to compile Go code.
"""
from pathlib import Path
import argparse, hashlib, io, json, struct, zipfile
from build_gate import verify_critical_runtime

BASE_SHA = 'b2362f9f20c7dd5b3f83eecc0eed085cc595ee8455d7d1e366c6beadeb7095dd'
VERSION = '3.78'

def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def build(baseline: Path, output: Path) -> None:
    root = Path(__file__).resolve().parent.parent
    output = output.resolve()
    if output == root or root in output.parents:
        raise ValueError('La cartella di output deve essere esterna al pacchetto.')
    base = baseline.read_bytes()
    if digest(base) != BASE_SHA:
        raise ValueError('Serve l’EXE 3.71 originale, senza modifiche.')
    verify_critical_runtime(root)
    files = sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
    for p in files:
        if p.is_symlink():
            raise ValueError('Collegamenti simbolici non ammessi nel pacchetto.')
    manifest = [{'path':p.relative_to(root).as_posix(), 'size':p.stat().st_size, 'sha256':digest(p.read_bytes())}
                for p in files if p.relative_to(root).as_posix() != 'MANIFEST_SHA256.json']
    (root/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=True,indent=2),encoding='utf8')
    files = sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
    names = [p.relative_to(root).as_posix() for p in files]
    if len(names) != len(set(n.casefold() for n in names)):
        raise ValueError('Nomi duplicati anche senza distinzione maiuscole/minuscole.')
    def archive(prefix: int = 0) -> bytes:
        target = io.BytesIO(b'\0'*prefix); target.seek(prefix)
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p,n in zip(files,names):
                if n.startswith('/') or '..' in Path(n).parts or ':' in n:
                    raise ValueError('Percorso non sicuro: '+n)
                info=zipfile.ZipInfo(n,(2026,10,1,0,0,0));info.external_attr=0o100644<<16
                z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        return target.getvalue()
    eocd=base.rfind(b'PK\x05\x06')
    if eocd < 0: raise ValueError('EOCD non trovato.')
    fields=struct.unpack_from('<4s4H2LH',base,eocd)
    end=eocd+22+fields[-1];start=eocd-fields[5]-fields[6]
    if (start,end)!=(1033568,19354782):raise ValueError('Allocazione launcher inattesa.')
    plain=archive();capacity=end-start
    if len(plain)>capacity:raise ValueError('Payload troppo grande: nessun byte viene troncato.')
    embedded=archive(capacity-len(plain))
    if len(embedded)!=capacity:raise ValueError('Dimensione embedded non coerente.')
    script=(root/'Sviluppo/installer_378.ps1').read_bytes()
    a0=base.index(b'\xef\xbb\xbfparam(');b0=base.index(b'\0',a0)
    if len(script)+2>b0-a0:raise ValueError('Script troppo lungo: nessun troncamento.')
    prefix=bytearray(base[:start]);prefix[a0:b0]=script+b'# '+b' '*(b0-a0-len(script)-2)
    old=b'YQArch Italiano 3.71 - Errore avvio'
    if prefix.count(old)!=1:raise ValueError('Titolo launcher non univoco.')
    loc=prefix.index(old);prefix[loc:loc+len(old)]=old.replace(b'3.71',b'3.78')
    exe=bytes(prefix)+embedded+base[end:]
    if len(exe)!=len(base):raise ValueError('Allocazione finale diversa dal launcher originale.')
    for raw in (exe[:end],plain):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            bad=z.testzip()
            if bad is not None:raise ValueError('CRC errato: '+bad)
    output.mkdir(parents=True,exist_ok=True)
    for name,raw in [(f'YQArch_Italiano_{VERSION}.exe',exe),(f'YQArch_Italiano_{VERSION}.zip',plain)]:
        dest=output/name;temp=dest.with_suffix(dest.suffix+'.part');temp.write_bytes(raw);temp.replace(dest)
        print(name,len(raw),digest(raw))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:build(args.baseline,args.out)
    except (OSError,ValueError,zipfile.BadZipFile,KeyError,struct.error) as exc:parser.exit(1,str(exc)+'\n')
