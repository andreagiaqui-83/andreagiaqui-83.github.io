"""Static regression audit for YQArch Italiano 3.78. NOT an AutoCAD execution test."""
from pathlib import Path
import argparse,json,hashlib,re,io,sys,xml.etree.ElementTree as E
from PIL import Image
from bs4 import BeautifulSoup
from lisp_checks import read_forms,validate,walk,String
from rebuild_ribbon import load_parts,check_relationships
from ribbon_contract import check_layout,PRIMARY_MACROS
from ribbon_layout import OVERFLOW_UID_PREFIX
from slide_reader import read_slide
D=Path(__file__).resolve().parent.parent;S=D/'YQArchItaliano/sys'
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args();B=a.baseline/'YQArchItaliano/sys';checks=[]
def test(name,ok,detail=''):
 checks.append({'test':name,'status':'PASS' if ok else 'FAIL','detail':detail});print(checks[-1]['status'],name,detail if not ok else '')
def h(x):return hashlib.sha256(x).hexdigest()
def norm_bytes(raw):return raw.replace(b'3.78',b'3.73').replace(b'3.74',b'3.73').replace(b'AUDIT_3.78',b'AUDIT_3.73').replace(b'RELEASE_NOTES_3.78.md',b'RELEASE_NOTES_3.73.md')

# Binary payload and catalog stay identical to the real-tested 3.73 baseline.
orig=[p for p in B.rglob('*') if p.is_file() and p.suffix.lower() in ('.dwg','.sld','.slb','.dll','.shx')]
test('Tutti gli asset binari funzionali della 3.73 preservati',all((S/p.relative_to(B)).read_bytes()==p.read_bytes() for p in orig),str(len(orig)))
reg=(S/'YQArchItaliano_Command_Registry_372.txt').read_bytes();oldreg=(B/'YQArchItaliano_Command_Registry_372.txt').read_bytes()
test('Registro comandi byte-identico alla 3.73',reg==oldreg)
cmds=[x.decode().strip() for x in reg.splitlines() if x.startswith(b'YQ')]
test('646 nomi registro univoci',len(cmds)==646 and len(set(cmds))==646)
test('Versione reale 3.78',(S/'YQArchItaliano.version').read_text().strip()=='3.78')

# Syntax of every AutoLISP/MNL module.
issues=[];texts=[]
for f in S.rglob('*'):
 if f.suffix.lower() in ('.lsp','.mnl'):
  raw=f.read_bytes()
  try:t=raw.decode('utf8')
  except UnicodeDecodeError:t=raw.decode('cp1252')
  texts.append(t)
  try:issues.extend([(str(f),e) for e in validate(read_forms(t))])
  except Exception as e:issues.append((str(f),str(e)))
test('Tutti LSP/MNL e callback: struttura e arita IF/SETQ',not issues,repr(issues[:8]))
test('Nessun riferimento attivo alla release pubblica 3.73 nei LSP/MNL',not any('3.73' in t for t in texts))

# Development/runtime copies must be exact.
for tag in ('Library','Trees','Ribbon'):
 for ext in ('lsp','mnl') if tag=='Ribbon' else ('lsp','dcl'):
  f=f'{tag}_372.{ext}';test('Sorgente e runtime uguali: '+f,(D/'Sviluppo'/f).read_bytes()==(S/('YQArchItaliano_'+f)).read_bytes())
test('Bootstrap sorgente/runtime uguali',(D/'Sviluppo/Bootstrap.lsp').read_bytes()==(S/'YQArchItaliano_Bootstrap.lsp').read_bytes())

# Core behavior untouched apart from current-version text.
for f in ['YQArchItaliano_Bootstrap.lsp','YQArchItaliano_Menu.lsp','YQArchItaliano_Runtime.lsp','YQArchItaliano_Trees_372.lsp','YQArchItaliano_Trees_372.dcl','YQArchItaliano_Menu_372.mnu']:
 test('Logica non interessata preservata: '+f,norm_bytes((S/f).read_bytes())==(B/f).read_bytes())

# Catalog/insertion remains the already-tested 3.73 implementation.
lib=(S/'YQArchItaliano_Library_372.lsp').read_text('ascii');oldlib=(B/'YQArchItaliano_Library_372.lsp').read_text('ascii');dcl=(S/'YQArchItaliano_Library_372.dcl').read_text('ascii')
fn=lambda forms:{str(f[1]).upper():f for f in forms if isinstance(f,list) and len(f)>2 and str(f[0]).upper()=='DEFUN'}
bf=fn(read_forms(oldlib));nf=fn(read_forms(lib))
for name in ('UCS-MATRIX','SAVE','READ-STATE','BUILTINS','INDEX-PART','ADVANCED','BLOCK-SELECTED','QUERY-CHANGED','ACCEPT','INSERT'):
 test('Funzione catalogo preservata dalla 3.73: '+name,bf['YQL72-'+name]==nf['YQL72-'+name])
test('Doppio clic e un solo pulsante predefinito','key="blocks"; allow_accept=true; multiple_select=false;' in dcl and dcl.split('yql72_folder')[0].count('is_default=true')==1)
test('Riapertura facoltativa solo dopo commit','(setq running (and inserted (= "1" (yql72-get "opzione|reopen-success" "0"))))' in lib and '(yql72-get "opzione|repeat"' not in lib)
test('Punto seguito da creazione e verifica','PUNTO_ACQUISITO' in lib and 'VERIFICA_ENTITA' in lib and '(entget entity)' in lib)
test('Diagnostica ultimo inserimento disponibile','(defun c:YQIT_VERIFICA_INSERIMENTO' in lib)
keys=set(re.findall(r'key\s*=\s*"([^"\n]+)"',dcl));used=[]
for f in walk(read_forms(lib)):
 if f and str(f[0]).upper() in ('ACTION_TILE','GET_TILE','SET_TILE','MODE_TILE','START_IMAGE','DIMX_TILE','DIMY_TILE') and len(f)>1 and isinstance(f[1],String):used.append(str(f[1]))
test('Chiavi DCL riferite esistenti',set(used)<=keys,repr(set(used)-keys))

cat=json.loads((S/'YQArchItaliano_Catalogo_372.json').read_text());oldcat=json.loads((B/'YQArchItaliano_Catalogo_372.json').read_text())
test('Catalogo JSON identico alla 3.73',cat==oldcat)
test('195 schede in 17 categorie',len(cat)==195 and len({r['id'] for r in cat})==195 and len({r['category_it'] for r in cat})==17)
test('195 DWG accessibili con SHA originale',all(h((S/'blocks'/r['path']).read_bytes())==r['sha256'] for r in cat))
from collections import Counter
headers=Counter((S/'blocks'/r['path']).read_bytes()[:6].decode('ascii','replace') for r in cat)
test('Formati DWG: 147 legacy 2004 e 48 AutoCAD 2007',headers=={'AC1009':16,'AC1014':2,'AC1018':129,'AC1021':48},repr(dict(headers)))
test('Precheck DWG incompatibili preservato','(defun yql72-dwg-compatible-p' in lib and 'AC1021' in lib and '(yql72-dwg-compatible-p path)' in lib)
valid=[]
for r in cat:
 try:w,height,lines,fills=read_slide((S/'blocks'/r['preview']).read_bytes());valid.append(w>0 and height>0 and bool(lines or fills))
 except Exception:valid.append(False)
test('195 anteprime SLD presenti, leggibili e non vuote',len(valid)==195 and all(valid))

# Ribbon: exact routes/assets, only presentation changed.
parts=load_parts(S/'YQArchItaliano_Ribbon_372.cuix');old=load_parts(B/'YQArchItaliano_Ribbon_372.cuix')
errs=check_layout(parts);test('Contratto Ribbon 3.78: 10 pannelli, 60 visibili + 70 flyout',not errs,repr(errs))
root=E.fromstring(parts['RibbonRoot.cui']);mg=E.fromstring(parts['MenuGroup.cui']);om=E.fromstring(old['MenuGroup.cui'])
mac=lambda r:{m.get('UID'):m.findtext('Macro/Command') for m in r.iter('MenuMacro')}
test('Macro operative Ribbon identiche alla 3.73',mac(mg)==mac(om))
for p in root.iter('RibbonPanelSource'):
 if (p.get('UID') or '').startswith('YQIT367_PANEL_'):
  rows=[]
  for child in p:
   if child.tag=='RibbonPanelBreak':break
   if child.tag=='RibbonRow':rows.append(child)
  overflow=[x for x in p.findall('RibbonRow') if (x.get('UID') or '').startswith(OVERFLOW_UID_PREFIX)]
  main=rows[0].findall('RibbonCommandButton')
  test('Un comando principale etichettato: '+p.get('Text'),len(main)==1 and main[0].get('MenuMacroID')==PRIMARY_MACROS[p.get('UID')] and main[0].get('ButtonStyle')=='LargeWithText' and bool(main[0].get('Text')))
  test('Cinque secondari affiancati al primario + sette nel flyout: '+p.get('Text'),len(rows)==1 and len(list(rows[0].find('RibbonRowPanel').iter('RibbonCommandButton')))==5 and sum(len(x.findall('RibbonCommandButton')) for x in overflow)==7)
missing,edges=check_relationships(parts);test('Tutte 933 relazioni CUIx risolte',not missing and len(edges)==933)
imgs=[n for n in parts if n.endswith('.bmp')]
test('916 icone BMP identiche alla 3.73',len(imgs)==916 and all(parts[n]==old[n] for n in imgs))
test('916 icone BMP decodificabili',all(Image.open(io.BytesIO(parts[n])).size in ((16,16),(17,16),(32,32)) for n in imgs))
test('Parti CUIx non-UI identiche alla 3.73',all(parts[n]==old[n] for n in parts if n not in ('RibbonRoot.cui','MenuGroup.cui')))

loader=(S/'YQArchItaliano_Ribbon_372.lsp').read_text('ascii')
test('Gruppo proprio e protezione CUI principale','YQARCHITALIANO_RIBBON' in loader and '(= 0 (vla-get-Type group))' in loader)
test('Limite tentativi e contesto applicazione','(< *YQR72-RETRIES* 2)' in loader and 'YQIT-RIBBON-READY-CONTEXT' in loader)
test('Diagnostica Ribbon aggiornata 10+50+70','10 principali grandi con etichetta e 50 secondari in sottopannelli affiancati (3+2); altri 70 secondari nel flyout' in loader)

diag=(S/'YQArchItaliano_NativeCommands_372.lsp').read_text('cp1252')
test('Diagnostica completa coerente 10+50+70', '10 grandi con testo + 50 piccoli visibili + 70 piccoli nel flyout' in diag and '30 grandi + 100 piccoli' not in diag)

# Installer: 3.73 fix preserved and cleanup extended through 3.73.
script=(D/'Sviluppo/installer_378.ps1').read_bytes();script_text=script.decode('utf-8-sig')
test('Installer 3.78 preserva backup/journal/rollback',all(x in script_text for x in ('Backup','Journal','Restore-Journal')))
test('Installer evita doppio hash sui file invariati','$script:VerifiedUnchanged[$dst]=$true' in script_text and '$script:VerifiedUnchanged.ContainsKey($dst)' in script_text)
test('Installer ripulisce cache menu fino alla 3.75','363..377' in script_text and 'YQArchItaliano_Menu_' in script_text)
test('Installer senza collisione PowerShell V/v','$script:V[$dst]' not in script_text and 'foreach($v in 363..377)' not in script_text and 'foreach($menuVersion in 363..377)' in script_text)
test('BOM script installer conservato',script.startswith(b'\xef\xbb\xbfparam('))

# Support page new contact actions; no trackers/scripts.
support=(S/'YQArch_Sostegno_Italiano.html').read_text('utf-8')
test('Pagina Sostieni aggiornata alla 3.78','YQArch Italiano 3.78' in support)
test('CTA WhatsApp corretta','https://wa.me/393337240544' in support and 'Scrivimi su WhatsApp' in support)
test('Email suggerimenti e bug','mailto:andrea.giaqui@gmail.com' in support and 'segnalazioni di bug' in support)
test('Promozione sito e pagina YQArch','https://andreagiaquinto.it/' in support and 'https://andreagiaquinto.it/yqarch-italiano/' in support)
test('Pagina locale senza script/tracker','<script' not in support.lower() and 'google-analytics' not in support.lower())

# Documentation integrity.
guide=BeautifulSoup((S/'YQArch_Italiano_Guida.html').read_text(),'html.parser');ids=[x.get('id','').upper() for x in guide.find_all('article')]
test('Guida 3.78: 646 schede univoche, registro coperto',len(ids)==646 and len(set(ids))==646 and set(ids)==set(cmds))
test('Guida descrive il nuovo metodo Ribbon','1 solo comando principale grande con etichetta visibile' in guide.get_text() and 'flyout' in guide.get_text().lower())
test('Guida documenta WhatsApp e sito','WhatsApp' in guide.get_text() and 'andreagiaquinto.it' in guide.get_text())
body_children=[x for x in guide.body.children if getattr(x,'name',None)]
test('Guida: header prima dei contenuti e nessun riquadro release fuori griglia',bool(body_children) and body_children[0].name=='header' and all(not (x.name=='section' and x.get('id','').startswith('novita-')) for x in body_children[:1]))
test('Guida: aggiornamenti dentro contenitore principale',guide.find('main',class_='wrap') is not None and guide.find('section',id='novita-378') is not None and guide.find('section',id='novita-378').find_parent('main') is not None)
libs=['yq_blocks','yq_blockviewer']+[f'yq_blockviewer{i}' for i in range(1,10)]
test('11 schede librerie mantengono flusso commit/chiusura',all('YQIT_VERIFICA_INSERIMENTO' in guide.find(id=i).get_text() and 'Il catalogo si chiude' in guide.find(id=i).get_text() for i in libs))
ri=BeautifulSoup((S/'YQArchItaliano_Ribbon_Catalogo.html').read_text(),'html.parser')
test('Schema Ribbon: 130 icone, 10 pannelli, 10 primari, 70 flyout',len(ri.find_all('img'))==130 and len(ri.find_all('article'))==10 and len(ri.select('.primary .tool'))==10 and len(ri.select('.flytool'))==70 and 'Non è uno screenshot' in ri.get_text())
test('README non trasforma test statici in certificazione','non equivalgono a esecuzione reale' in (D/'README.txt').read_text())

# No accidental temp/build junk inside distribution tree.
allfiles=[x for x in D.rglob('*') if x.is_file()]
test('Nessun temporaneo distribuibile nel pacchetto',all(x.suffix.lower() not in ('.tmp','.part','.bak') for x in allfiles if '__pycache__' not in x.parts and x.suffix.lower()!='.pyc'))

a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
print('TOTAL',len(checks),'FAIL',sum(x['status']=='FAIL' for x in checks))
if any(x['status']=='FAIL' for x in checks):sys.exit(1)
