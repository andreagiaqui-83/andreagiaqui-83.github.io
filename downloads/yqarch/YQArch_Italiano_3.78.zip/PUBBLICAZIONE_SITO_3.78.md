# Pubblicazione YQArch Italiano 3.78

Autorizzata dall’utente dopo il collaudo della 3.77 del 3 ottobre 2026. Pubblicare esattamente EXE e ZIP verificati senza modificarli. Aggiornare landing YQArch, FAQ, JSON-LD, guida, rapporto, schema Ribbon, catalogo, note, compatibilità, SHA e manifest dei download. Conservare tutte le altre pagine, moduli e integrazioni del sito. Non cancellare gli archivi precedenti.
Distinguere collaudo nativo della 3.77 (AutoCAD 2027 italiano) e verifiche automatiche 3.78 con CUIx e componenti funzionali conservati. Non dichiarare certificati tutti i comandi o tutti gli ambienti.
Verificare hash dei file pubblicati, navigazione comune, SEO e layout desktop/mobile tramite le verifiche del sito.
