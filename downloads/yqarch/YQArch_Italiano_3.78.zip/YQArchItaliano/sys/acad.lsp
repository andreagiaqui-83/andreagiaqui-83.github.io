;;; YQArch Italiano 3.78 - ingresso idempotente per documento.
(if (findfile "YQArchItaliano_Bootstrap.lsp") (load "YQArchItaliano_Bootstrap.lsp"))
(princ)
