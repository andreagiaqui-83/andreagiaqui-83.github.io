;;; =============================================================================
;;; YQArch Italiano 3.78 - Runtime italiano
;;; =============================================================================
;;; Questo modulo NON traduce stringhe inglesi a runtime.
;;; Le risorse italiane sono la sorgente primaria dell'interfaccia ricostruita.
;;; Il motore YQArch storico resta disponibile esclusivamente come compatibilit�
;;; per i comandi non ancora migrati al runtime italiano.
;;; =============================================================================

(vl-load-com)

(setq *YQIT-RUNTIME-VERSION* "3.78")
(setq *YQIT-RUNTIME-ARCH* "native-it-v9")

;; Risorse italiane primarie. Le chiavi sono semantiche e non contengono
;; le stringhe inglesi del motore storico.
(setq *YQIT-IT-RESOURCES*
  '(
    (APP_TITLE . "YQArch Italiano")
    (SCALE_TITLE . "[YQArch Italiano]-Scala disegno")
    (DRAWING_UNITS . "Unit� disegno")
    (MAIN_SCALE . "Scala principale 1:")
    (SECONDARY_SCALE . "Scala secondaria 1:")
    (USE_SECONDARY . "Usa scala secondaria")
    (UPDATE_DIMSTYLE . "Aggiorna stile di quota")
    (RESET_DEFAULTS . "Ripristina valori predefiniti")
    (SCALE_NOTE . "Nota: 1:0 indica la scala nello spazio carta")
    (OK . "OK")
    (CANCEL . "Annulla")
    (MM . "Millimetri (mm)")
    (CM . "Centimetri (cm)")
    (M . "Metri (m)")
    (INCH . "Pollici")
    (FEET . "Piedi")
    (SCALE_APPLIED . "Scala disegno aggiornata")
    (INVALID_SCALE . "Valore di scala non valido.")
    (DIALOG_ERROR . "Impossibile aprire la finestra Scala disegno.")
    (GRID_TITLE . "[YQArch Italiano]-Griglia")
    (GRID_WIDTH . "Larghezza:")
    (GRID_DEPTH . "Profondit�:")
    (GRID_SYMBOLS_DIMS . "Disegna simboli degli assi e quote")
    (GRID_PROMPT_BASE . "Specificare il punto base della griglia")
    (GRID_INVALID . "Le distanze della griglia non sono valide.")
    (GRID_CREATED . "Griglia creata")
    (GRID_DIALOG_ERROR . "Impossibile aprire la finestra Griglia.")
  ))

(defun yqit-r (key / x)
  (setq x (assoc key *YQIT-IT-RESOURCES*))
  (if x (cdr x) ""))

(defun yqit-runtime-sysdir (/ p)
  (if (and (boundp '*yqit-install-dir*) *yqit-install-dir*)
    *yqit-install-dir*
    (progn
      (setq p (findfile "YQArchItaliano.version"))
      (if p (vl-filename-directory p) nil))))

(defun yqit-runtime-user (/ d f h s)
  (setq d (yqit-runtime-sysdir))
  (if d
    (progn
      (setq f (strcat d "\\yquser.txt"))
      (if (and (findfile f) (setq h (open f "r")))
        (progn (setq s (read-line h)) (close h) s)
        "user1"))
    "user1"))

(defun yqit-runtime-config (/ d u)
  (setq d (yqit-runtime-sysdir))
  (setq u (yqit-runtime-user))
  (if d (strcat d "\\" u "\\config.txt") nil))

(defun yqit-trim (s)
  (if s (vl-string-trim " \t\r\n" s) ""))

(defun yqit-config-get (key / f h line eq k v out semi)
  (setq f (yqit-runtime-config) out nil)
  (if (and f (findfile f) (setq h (open f "r")))
    (progn
      (while (and (null out) (setq line (read-line h)))
        (setq eq (vl-string-search "=" line))
        (if eq
          (progn
            (setq k (strcase (yqit-trim (substr line 1 eq))))
            (if (= k (strcase key))
              (progn
                (setq v (substr line (+ eq 2)))
                (setq semi (vl-string-search ";" v))
                (if semi (setq v (substr v 1 semi)))
                (setq out (yqit-trim v)))))))
      (close h)))
  out)

(defun yqit-config-set (key value / f h line lines eq k done out semi prefix suffix wh)
  ;; Aggiornamento conservativo: preserva ordine, commenti e chiavi tecniche.
  (setq f (yqit-runtime-config) lines nil done nil)
  (if (and f (findfile f) (setq h (open f "r")))
    (progn
      (while (setq line (read-line h)) (setq lines (cons line lines)))
      (close h)
      (setq lines (reverse lines))
      (setq out nil)
      (foreach line lines
        (setq eq (vl-string-search "=" line))
        (if (and (not done) eq
                 (= (strcase (yqit-trim (substr line 1 eq))) (strcase key)))
          (progn
            (setq suffix "")
            (setq semi (vl-string-search ";" line))
            (if semi (setq suffix (strcat " " (substr line (+ semi 1)))))
            (setq prefix (substr line 1 (+ eq 1)))
            (setq line (strcat prefix " " value suffix))
            (setq done T)))
        (setq out (cons line out)))
      (if (not done) (setq out (cons (strcat key " = " value) out)))
      (setq out (reverse out))
      (if (setq wh (open f "w"))
        (progn
          (foreach line out (write-line line wh))
          (close wh)
          T)
        nil))
    nil))

(defun yqit-scale-list (/ raw parts out x n)
  (setq raw (yqit-config-get "DRAWING_SCALE_LIST"))
  (if (or (null raw) (= raw ""))
    (setq raw "0,1,2,3,4,5,6,8,10,15,20,25,30,40,50,60,75,80,100,120,150,200,250,300,400,500,600,1000,2000,5000,10000"))
  (setq parts nil out nil)
  (while (> (strlen raw) 0)
    (setq n (vl-string-search "," raw))
    (if n
      (progn
        (setq x (substr raw 1 n))
        (setq raw (substr raw (+ n 2))))
      (progn (setq x raw) (setq raw "")))
    (setq x (yqit-trim x))
    (if (/= x "") (setq out (cons x out))))
  (reverse out))

(defun yqit-index-of (value items / i found)
  (setq i 0 found nil)
  (while (and items (null found))
    (if (= value (car items))
      (setq found i)
      (progn (setq i (1+ i)) (setq items (cdr items)))))
  (if found found 0))

(defun yqit-unit-code-to-label (code)
  (cond
    ((= code 1) (yqit-r 'INCH))
    ((= code 2) (yqit-r 'FEET))
    ((= code 5) (yqit-r 'CM))
    ((= code 6) (yqit-r 'M))
    (T (yqit-r 'MM))))

(defun yqit-unit-index-from-insunits (/ u)
  (setq u (getvar "INSUNITS"))
  (cond ((= u 5) 1) ((= u 6) 2) ((= u 1) 3) ((= u 2) 4) (T 0)))

(defun yqit-unit-code-from-index (i)
  (cond ((= i 1) 5) ((= i 2) 6) ((= i 3) 1) ((= i 4) 2) (T 4)))

(defun yqit-scale-dcl-text ()
  (strcat
"yqit_scale : dialog {\n"
"  label = \"" (yqit-r 'SCALE_TITLE) "\";\n"
"  : boxed_column { label = \"Impostazioni disegno\";\n"
"    : popup_list { key=\"units\"; label=\"" (yqit-r 'DRAWING_UNITS) "\"; width=42; }\n"
"  }\n"
"  : row {\n"
"    : boxed_column { label=\"Scala DWG\";\n"
"      : list_box { key=\"scale1\"; label=\"Scala\"; width=22; height=16; }\n"
"      : edit_box { key=\"main\"; label=\"" (yqit-r 'MAIN_SCALE) "\"; edit_width=10; }\n"
"      : toggle { key=\"dim\"; label=\"" (yqit-r 'UPDATE_DIMSTYLE) "\"; }\n"
"    }\n"
"    : boxed_column { label=\"Scala 2 DWG\";\n"
"      : list_box { key=\"scale2\"; label=\"Scala\"; width=22; height=16; }\n"
"      : edit_box { key=\"second\"; label=\"" (yqit-r 'SECONDARY_SCALE) "\"; edit_width=10; }\n"
"      : toggle { key=\"use2\"; label=\"" (yqit-r 'USE_SECONDARY) "\"; }\n"
"    }\n"
"  }\n"
"  : text { label=\"" (yqit-r 'SCALE_NOTE) "\"; }\n"
"  : button { key=\"reset\"; label=\"" (yqit-r 'RESET_DEFAULTS) "\"; width=40; fixed_width=true; alignment=centered; }\n"
"  spacer;\n"
"  ok_cancel;\n"
"}\n"))

(defun yqit-write-temp-dcl (name text / f h)
  (setq f (strcat (getvar "TEMPPREFIX") name))
  (if (setq h (open f "w"))
    (progn (write-line text h) (close h) f)
    nil))

(defun yqit-scale-display (s)
  (strcat "1:" s))

(defun yqit-scale-number (s / n)
  (setq n (distof s 2))
  (if (and n (>= n 0.0)) n nil))

(defun yqit-apply-scale (scale units updateDim / olderr ok dsname)
  ;; Transazione semplice: se un setvar fallisce, ripristina DIMSCALE e INSUNITS.
  (setq olderr *error*)
  (setq *yqit-old-dimscale* (getvar "DIMSCALE"))
  (setq *yqit-old-insunits* (getvar "INSUNITS"))
  (setq ok T)
  (defun *error* (msg)
    (if *yqit-old-dimscale* (setvar "DIMSCALE" *yqit-old-dimscale*))
    (if *yqit-old-insunits* (setvar "INSUNITS" *yqit-old-insunits*))
    (setq *error* olderr)
    (setq ok nil)
    (if (and msg (/= msg "Function cancelled")) (princ (strcat "\nYQArch Italiano: " msg)))
    (princ))
  (if (= scale 0.0)
    (setvar "DIMSCALE" 1.0)
    (setvar "DIMSCALE" scale))
  (setvar "INSUNITS" units)
  ;; Se richiesto e se esiste gi� uno stile YQ coerente, lo rende corrente senza
  ;; creare o rinominare stili: nessun presupposto distruttivo sul disegno.
  (if updateDim
    (progn
      (setq dsname (strcat "YQ" (rtos scale 2 0)))
      (if (tblsearch "DIMSTYLE" dsname)
        (progn
          (setq *yqit-scale-doc* (vla-get-ActiveDocument (vlax-get-acad-object)))
          (setq *yqit-scale-dstyles* (vla-get-DimStyles *yqit-scale-doc*))
          (setq *yqit-scale-dstyle* (vl-catch-all-apply 'vla-Item (list *yqit-scale-dstyles* dsname)))
          (if (not (vl-catch-all-error-p *yqit-scale-dstyle*))
            (vl-catch-all-apply 'vla-put-ActiveDimStyle (list *yqit-scale-doc* *yqit-scale-dstyle*)))))))
  ;; Stato del nuovo runtime separato dalla configurazione legacy: non alteriamo
  ;; il formato delle chiavi DRAWING_SCALE/DRAWING_UNITS del motore storico.
  (setenv "YQIT_DRAWING_SCALE" (rtos scale 2 8))
  (setenv "YQIT_DRAWING_UNITS" (itoa units))
  (setq *YQIT-DRAWING-SCALE* scale)
  (setq *YQIT-DRAWING-UNITS* units)
  (setq *error* olderr)
  ok)

(defun yqit-setdwgscale-native (/ f id scales cur curstr idx idx2 result sel1 sel2 main second units use2 upd n1 n2 i)
  (setq *YQIT-SCALE-LAST-OK* nil)
  (setq scales (yqit-scale-list))
  (setq cur (getvar "DIMSCALE"))
  (if (or (null cur) (< cur 0.0)) (setq cur 100.0))
  (setq curstr (getenv "YQIT_DRAWING_SCALE"))
  (if (or (null curstr) (= curstr ""))
    (setq curstr (rtos cur 2 0)))
  (setq idx (yqit-index-of curstr scales))
  (setq idx2 1)
  (setq f (yqit-write-temp-dcl "YQArchItaliano_scale_268.dcl" (yqit-scale-dcl-text)))
  (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_scale" id))
    (progn
      (start_list "units")
      (add_list (yqit-r 'MM)) (add_list (yqit-r 'CM)) (add_list (yqit-r 'M))
      (add_list (yqit-r 'INCH)) (add_list (yqit-r 'FEET))
      (end_list)
      (set_tile "units" (itoa (yqit-unit-index-from-insunits)))
      (start_list "scale1") (foreach x scales (add_list (yqit-scale-display x))) (end_list)
      (start_list "scale2") (foreach x scales (add_list (yqit-scale-display x))) (end_list)
      (set_tile "scale1" (itoa idx))
      (set_tile "scale2" (itoa idx2))
      (set_tile "main" curstr)
      (set_tile "second" "1")
      (set_tile "use2" "0")
      (set_tile "dim" "0")
      (action_tile "scale1" "(setq sel1 $value)(set_tile \"main\" (nth (atoi $value) scales))")
      (action_tile "scale2" "(setq sel2 $value)(set_tile \"second\" (nth (atoi $value) scales))")
      (action_tile "reset" "(set_tile \"units\" \"0\")(set_tile \"scale1\" (itoa (yqit-index-of \"100\" scales)))(set_tile \"main\" \"100\")(set_tile \"scale2\" \"1\")(set_tile \"second\" \"1\")(set_tile \"use2\" \"0\")(set_tile \"dim\" \"0\")")
      (action_tile "accept" "(setq main (get_tile \"main\") second (get_tile \"second\") units (atoi (get_tile \"units\")) use2 (= (get_tile \"use2\") \"1\") upd (= (get_tile \"dim\") \"1\"))(done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (setq result (start_dialog))
      (unload_dialog id)
      (vl-file-delete f)
      (if (= result 1)
        (progn
          (setq n1 (yqit-scale-number main))
          (setq n2 (yqit-scale-number second))
          (if (and n1 (or (not use2) n2))
            (progn
              (if (yqit-apply-scale (if use2 n2 n1) (yqit-unit-code-from-index units) upd)
                (progn (setq *YQIT-SCALE-LAST-OK* T)
                       (princ (strcat "\nYQArch Italiano - " (yqit-r 'SCALE_APPLIED) ": 1:" (rtos (if use2 n2 n1) 2 8) ".")))))
            (alert (yqit-r 'INVALID_SCALE))))))
    (progn
      (if f (vl-file-delete f))
      (alert (yqit-r 'DIALOG_ERROR))))
  *YQIT-SCALE-LAST-OK*)

;; Alias interno: il core storico richiama spesso YQ_SETDWGSCALE come funzione, non come comando.
(defun yq_setdwgscale () (yqit-setdwgscale-native))
(defun YQ_SETDWGSCALE () (yqit-setdwgscale-native))

;; Comando italiano nativo. Questa definizione viene caricata dopo il motore storico
;; e ne sostituisce il solo ingresso comando, senza modificare il FAS/VLX.
(defun c:YQ_SETDWGSCALE () (yqit-setdwgscale-native))
(defun c:YQIT_SETDWGSCALE () (yqit-setdwgscale-native))



;;; -----------------------------------------------------------------------------
;;; YQ_GRIDAXIS - ricostruzione nativa italiana (2.74)
;;; Nessuna chiamata alla finestra o alle funzioni interne del VLX storico.
;;; Geometria creata tramite ActiveX, quindi indipendente dalla lingua AutoCAD.
;;; -----------------------------------------------------------------------------
(defun yqit-grid-dcl-text ()
  (strcat
"yqit_grid : dialog {\n"
"  label = \"" (yqit-r 'GRID_TITLE) "\";\n"
"  : boxed_column {\n"
"    : edit_box { key=\"gx\"; label=\"" (yqit-r 'GRID_WIDTH) "\"; edit_width=36; }\n"
"    : edit_box { key=\"gy\"; label=\"" (yqit-r 'GRID_DEPTH) "\"; edit_width=36; }\n"
"    : toggle { key=\"symdim\"; label=\"" (yqit-r 'GRID_SYMBOLS_DIMS) "\"; }\n"
"    : button { key=\"reset\"; label=\"" (yqit-r 'RESET_DEFAULTS) "\"; width=38; fixed_width=true; alignment=centered; }\n"
"  }\n"
"  spacer; ok_cancel;\n"
"}\n"))

(defun yqit-grid-tokenize (s / out cur i ch)
  (setq out nil cur "" i 1 s (yqit-trim s))
  (while (<= i (strlen s))
    (setq ch (substr s i 1))
    (if (member ch '(" " "\t" "," ";"))
      (progn (if (/= cur "") (setq out (cons cur out))) (setq cur ""))
      (setq cur (strcat cur ch)))
    (setq i (1+ i)))
  (if (/= cur "") (setq out (cons cur out)))
  (reverse out))

(defun yqit-grid-expand-token (tok / p a b n out i)
  (setq p (vl-string-search "*" tok))
  (if p
    (progn
      (setq a (distof (substr tok 1 p) 2))
      (setq b (atoi (substr tok (+ p 2))))
      (if (and a (> a 0.0) (> b 0))
        (progn (setq i 0 out nil) (repeat b (setq out (cons a out))) (reverse out))
        nil))
    (progn (setq a (distof tok 2)) (if (and a (> a 0.0)) (list a) nil))))

(defun yqit-grid-parse (s / toks out x)
  (setq toks (yqit-grid-tokenize s) out nil)
  (foreach tkn toks
    (setq x (yqit-grid-expand-token tkn))
    (if x (setq out (append out x)) (setq out nil toks nil)))
  out)

(defun yqit-grid-cumulative (vals / out acc)
  (setq out (list 0.0) acc 0.0)
  (foreach v vals (setq acc (+ acc v) out (append out (list acc))))
  out)

(defun yqit-ensure-layer-native (name color / doc layers lay)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        layers (vla-get-Layers doc)
        lay (vl-catch-all-apply 'vla-Item (list layers name)))
  (if (vl-catch-all-error-p lay) (setq lay (vla-Add layers name)))
  (if color (vl-catch-all-apply 'vla-put-Color (list lay color)))
  lay)

(defun yqit-add-line-native (space p1 p2 layer / o)
  (setq o (vla-AddLine space (vlax-3d-point p1) (vlax-3d-point p2)))
  (vla-put-Layer o layer) o)

(defun yqit-add-axis-symbol-native (space pt radius text layer / c t1 h)
  (setq c (vla-AddCircle space (vlax-3d-point pt) radius))
  (vla-put-Layer c layer)
  (setq h (* radius 0.9))
  (setq t1 (vla-AddText space text (vlax-3d-point (list (- (car pt) (* h 0.35)) (- (cadr pt) (* h 0.5)) 0.0)) h))
  (vla-put-Layer t1 layer)
  t1)

(defun yqit283-string-or (v fallback)
  (if (= (type v) 'STR) v fallback))

(defun yqit-grid-draw (base xs ys symdim / doc space axisLayer symLayer xTotal yTotal x y p1 p2 r letters idx off dimobj)
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object))
        space (if (= 1 (getvar "CVPORT")) (vla-get-PaperSpace doc) (vla-get-ModelSpace doc))
        axisLayer (yqit283-string-or (yqit-config-get "AXIS_LAYER_NAME") "DOTE")
        symLayer (yqit283-string-or (yqit-config-get "SYMBOL_AXIS_LAYER_NAME") axisLayer)
        xTotal (car (last xs)) yTotal (car (last ys)))
  (yqit-ensure-layer-native axisLayer 1)
  (yqit-ensure-layer-native symLayer 3)
  (foreach x xs
    (yqit-add-line-native space
      (list (+ (car base) x) (cadr base) 0.0)
      (list (+ (car base) x) (+ (cadr base) yTotal) 0.0) axisLayer))
  (foreach y ys
    (yqit-add-line-native space
      (list (car base) (+ (cadr base) y) 0.0)
      (list (+ (car base) xTotal) (+ (cadr base) y) 0.0) axisLayer))
  (if symdim
    (progn
      (setq r (distof (yqit283-string-or (yqit-config-get "SYMBOL_AXIS_RADIUS") "4") 2))
      (if (or (null r) (<= r 0.0)) (setq r 4.0))
      (setq off (* r 2.5) idx 1)
      (foreach x xs
        (yqit-add-axis-symbol-native space (list (+ (car base) x) (- (cadr base) off) 0.0) r (itoa idx) symLayer)
        (setq idx (1+ idx)))
      (setq letters "ABCDEFGHJKLMNPQRSTUVWXY" idx 1)
      (foreach y ys
        (yqit-add-axis-symbol-native space (list (- (car base) off) (+ (cadr base) y) 0.0) r (substr letters idx 1) symLayer)
        (setq idx (1+ idx)))
      ;; Quote progressive tramite ActiveX, senza keyword localizzate.
      (if (> (length xs) 1)
        (progn
          (setq idx 0)
          (while (< idx (1- (length xs)))
            (setq p1 (list (+ (car base) (nth idx xs)) (cadr base) 0.0)
                  p2 (list (+ (car base) (nth (1+ idx) xs)) (cadr base) 0.0))
            (vl-catch-all-apply 'vla-AddDimAligned
              (list space (vlax-3d-point p1) (vlax-3d-point p2)
                    (vlax-3d-point (list (/ (+ (car p1) (car p2)) 2.0) (- (cadr base) (* off 2.0)) 0.0))))
            (setq idx (1+ idx)))))
      (if (> (length ys) 1)
        (progn
          (setq idx 0)
          (while (< idx (1- (length ys)))
            (setq p1 (list (car base) (+ (cadr base) (nth idx ys)) 0.0)
                  p2 (list (car base) (+ (cadr base) (nth (1+ idx) ys)) 0.0))
            (vl-catch-all-apply 'vla-AddDimAligned
              (list space (vlax-3d-point p1) (vlax-3d-point p2)
                    (vlax-3d-point (list (- (car base) (* off 2.0)) (/ (+ (cadr p1) (cadr p2)) 2.0) 0.0))))
            (setq idx (1+ idx)))))))
  (vla-Regen doc 1)
  T)

(defun yqit-grid-native (/ f id res sx sy symval sym xv yv base olderr)
  (setq f (yqit-write-temp-dcl "YQArchItaliano_grid_269.dcl" (yqit-grid-dcl-text)))
  (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_grid" id))
    (progn
      (set_tile "gx" (or (getenv "YQIT_GRID_X") "3900*5"))
      (set_tile "gy" (or (getenv "YQIT_GRID_Y") "3900 3900 3900"))
      (set_tile "symdim" "1")
      (action_tile "reset" "(set_tile \"gx\" \"3900*5\")(set_tile \"gy\" \"3900 3900 3900\")(set_tile \"symdim\" \"1\")")
      (action_tile "accept" "(setq sx (get_tile \"gx\") sy (get_tile \"gy\") symval (get_tile \"symdim\"))(done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (setq res (start_dialog))
      (unload_dialog id) (vl-file-delete f)
      (if (= res 1)
        (progn
          (setq sym (= symval "1"))
          (setq xv (yqit-grid-parse sx) yv (yqit-grid-parse sy))
          (if (and xv yv)
            (progn
              (setenv "YQIT_GRID_X" sx) (setenv "YQIT_GRID_Y" sy)
              (setq base (getpoint (strcat "\n" (yqit-r 'GRID_PROMPT_BASE) ": ")))
              (if base
                (progn
                  (yqit-grid-draw base (yqit-grid-cumulative xv) (yqit-grid-cumulative yv) sym)
                  (princ (strcat "\nYQArch Italiano - " (yqit-r 'GRID_CREATED) ".")))))
            (alert (yqit-r 'GRID_INVALID))))))
    (progn (if f (vl-file-delete f)) (alert (yqit-r 'GRID_DIALOG_ERROR))))
  (princ))

(defun c:YQ_GRIDAXIS () (yqit-grid-native))
(defun c:YQIT_GRIDAXIS () (yqit-grid-native))



;;; -----------------------------------------------------------------------------
;;; Menu grafico italiano nativo - 2.74
;;; Le etichette sono sorgenti italiane; il vecchio viewer VLX non viene aperto.
;;; -----------------------------------------------------------------------------
(setq *YQIT-SLIDE-CATEGORIES*
  '(
    ("Simboli"
      ("Disponi simboli assi" "AZH" "YQ_AUTO_AXIS_DIM")
      ("Disegna simboli assi" "ZH" "YQ_SYMBOL_AXIS_C")
      ("Coordinate geodetiche" "ZB" "YQ_GEODESIC_COORDINATES")
      ("Quota di progetto" "BG" "YQ_DESIGNED_ELEVATION")
      ("Quota altimetrica" "XBG" "YQ_CONTOUR_ELEVATION")
      ("Simbolo piano di sezione" "PQF" "YQ_SYMBOL_SECTIONPLANE")
      ("Simbolo di sezione" "DMF" "YQ_SYMBOL_SECTIONCUTTER")
      ("Simbolo pendenza" "PD" "YQ_SYMBOL_GRADIENT")
      ("Linea di interruzione" "ZX" "YQ_DISCONNECTION_LINE")
      ("Simbolo taglio tubo" "GPX" "YQ_PIPECUTTING")
      ("Asse di simmetria" "DCZ" "YQ_SYMMETRY_AXIS")
      ("Linea centrale" "ZXX" "YQ_CENTRAL_LINE")
      ("Contorno filo" "ACC" "YQ_WIRESURROUND")
      ("Cancella contorno" "ECC" "YQ_ERASESURROUND")
      ("Freccia piegata" "AAW" "YQ_BENTARROW")
      ("Freccia ingresso" "AAE" "YQ_ENTRANCEARROW")
    )
    ("Indicatori"
      ("Simbolo sezione 1" "SY1" "YQ_IDENTIFIER1")
      ("Simbolo sezione 2" "SY2" "YQ_IDENTIFIER2")
      ("Simbolo sezione 3" "SY3" "YQ_IDENTIFIER3")
      ("Indicatore prospetti 4 in 1" "I0" "YQ_ELEVINDEXER4IN1")
      ("Indicatore prospetto 1" "I1" "YQ_ELEVINDEXER1")
      ("Indicatore prospetto 2" "I2" "YQ_ELEVINDEXER2")
      ("Indicatore prospetto 3" "I3" "YQ_ELEVINDEXER3")
      ("Indicatore prospetto 4" "I4" "YQ_ELEVINDEXER4")
      ("Simbolo di dettaglio 1" "XT1" "YQ_DETAILSYMBOL1")
      ("Simbolo di dettaglio 2" "XT2" "YQ_DETAILSYMBOL2")
      ("Indicatore utente 1" "S1" "YQ_INDEXER1")
      ("Indicatore utente 2" "S2" "YQ_INDEXER2")
      ("Indicatore utente 3" "S3" "YQ_INDEXER3")
      ("Indicatore utente 4" "S4" "YQ_INDEXER4")
      ("Indicatore utente 5" "S5" "YQ_INDEXER5")
      ("Indicatore utente 6" "S6" "YQ_INDEXER6")
      ("Indicatore utente 7" "S7" "YQ_INDEXER7")
      ("Indicatore utente 8" "S8" "YQ_INDEXER8")
      ("Indicatore utente 9" "S9" "YQ_INDEXER9")
      ("Direttrice con freccia" "AAX" "YQ_LEADER")
      ("Direttrice multipunto" "AAXX" "YQ_MPTLEADER")
      ("Direttrice multipunto verticale" "AAYY" "YQ_MPTLEADER_Y")
      ("Aggiungi/Rimuovi vertici" "AAV" "YQ_LEADER_VERTEXES")
      ("Aggiungi frecce direttrice" "AAJ" "YQ_LEADER_ADDARROW")
      ("Titolo decorativo disegno" "BT" "YQ_DRAWINGTITLE")
    )
    ("Componenti"
      ("Pianta/prospetto scala mobile" "LTF" "YQ_ESCALATOR")
      ("Pianta vano scala" "LTJ" "YQ_STAIRCASE_PLAN")
      ("Pianta scala curva" "LTA" "YQ_ARCSTAIR_PLAN")
      ("Pianta ascensore" "DTJ" "YQ_LIFT_PLAN")
      ("Prospetto porta" "ADE" "YQ_DOOR_ELEVATION")
      ("Sezione porta" "ADS" "YQ_DOOR_SECTION")
      ("Sezione finestra a bovindo" "WTS" "YQ_BAYWIN_SECTION")
      ("Prospetto finestra" "WDE" "YQ_WINDOW_ELEVATION")
      ("Sezione finestra" "WDS" "YQ_WINDOW_SECTION")
      ("Prospetto/sezione persiana" "BY" "YQ_SHUTTER")
      ("Vetro facciata continua" "MBL" "YQ_CURTAINGLASS")
      ("Linee del prospetto finestra" "WDD" "YQ_LINES2WINELEV")
      ("Numerazione del prospetto finestra" "T2W" "YQ_SN2WINELEV")
      ("Prospetto facciata continua" "MQ" "YQ_CURTAINWALL")
      ("Sezione parete divisoria" "MQS" "YQ_GLASS_PARTITION")
      ("Parapetto in prospetto" "LG" "YQ_BANISTER")
      ("Sezione vano scala" "LTP" "YQ_STAIRCASE_SECTION")
      ("Sezione gradini" "LXTB" "YQ_STEP_SECTION")
      ("Sezione impermeabilizzazione" "FSC" "YQ_WATERPROOF")
      ("Sezione intonaco" "FN" "YQ_STUCCO")
    )
    ("Decorazioni"
      ("Disponi arredi" "JJ" "YQ_AUTOFURNITURE")
      ("Disponi bagno/doccia" "WC" "YQ_ARRANGEWC")
      ("Pianta armadio" "YG" "YQ_CHESTPLAN")
      ("Pianta tenda" "CLP" "YQ_CURTAINPLAN")
      ("Pianta cornice in gesso" "SGX" "YQ_PLASTERSTRINGPLAN")
      ("Pianta mobile" "GZ" "YQ_CUPBOARDPLAN")
      ("Prospetto mobile" "GZE" "YQ_CUPBOARDELEV")
      ("Sezione rivestimento in pietra" "STB" "YQ_STONETILE")
      ("Sezione telaio in legno" "MF" "YQ_WOODENFRAME")
      ("Distribuisci pannelli" "CBZ" "YQ_ARRAY_BOARDS")
      ("Sezione listellare" "MGB" "YQ_BLOCKBOARD")
      ("Sezione compensato" "JB" "YQ_PLYWOOD")
      ("Sezione pavimento in legno" "MDB" "YQ_WOODFLOORING")
      ("Sezione vetro" "BL" "YQ_GLASS")
      ("Sezione cartongesso" "SGB" "YQ_GYPSUMBOARD")
      ("Sezione gola luminosa" "THDC" "YQ_LIGHTTROUGH")
      ("Parete divisoria" "GQ" "YQ_PARTITIONWALL")
      ("Sezione profilo in acciaio" "XG" "YQ_FORMEDSTEEL")
      ("Sezione telaio angolare in acciaio" "JGJ" "YQ_IRONFRAME")
      ("Isolante in fibra" "BWM" "YQ_INSULATION")
      ("Linea di saldatura" "HF" "YQ_WELDINGLINE")
      ("Disegna tubo flessibile" "RG" "YQ_HOSE")
      ("Disegna tubo" "GX" "YQ_PIPE")
      ("Foro nel pannello" "KD" "YQ_BOARDHOLE")
      ("Ombra cilindro" "YZX" "YQ_CYLINDERSHADOW")
      ("Foro bullone posteriore" "BSK" "YQ_BACKBOLTHOLE")
      ("Disponi lampade" "DJ" "YQ_AUTOLAMPS")
      ("Distribuzione casuale" "MTX" "YQ_RANDOMSPREAD")
      ("Prospetto interno" "LM" "YQ_INDOORELEV")
    )
    ("Statistiche"
      ("Selezione rapida" "SS" "XC_SS")
      ("Numerazione automatica" "ABH" "YQ_AUTOSERIALNUMBER")
      ("Crea tabella vuota" "KBG" "YQ_EMPTYTABLE")
      ("Allinea testi tabella" "BGZ" "YQ_TEXT2CENTER")
      ("Calcola l'area delle celle dai testi" "TMJ" "YQ_CALC_CELLAREA")
      ("Esporta testi in Excel" "T2E" "YQ_TEXTS2EXCEL")
      ("Testi in tabella AutoCAD" "ZBG" "YQ_TEXTS2ACADTABLE")
      ("Elenco finestre/porte" "MCB" "YQ_WINDOOR_LIST")
      ("Elenco blocchi" "BBL" "YQ_BLOCK_LIST")
      ("Elenco attributi/blocchi dinamici" "SXL" "YQ_BLOCKATT_LIST")
      ("Raccogli coordinate" "ZZB" "YQ_COORDINATE_LIST")
      ("Elenco testi" "TTQ" "YQ_STRING_LIST")
      ("Elenco materiali" "CLB" "YQ_MATERIAL_LIST")
      ("Somma aree" "MJ" "YQ_CALC_SUMAREA")
      ("Collega area al testo" "PMJ" "YQ_ASSO_AREA")
      ("Somma perimetri" "ZC" "YQ_CALC_PERIMETER")
      ("Collega perimetro al testo" "PZC" "YQ_ASSO_PERIMETER")
      ("Calcola peso" "ZL" "YQ_CALWEIGHT")
      ("Statistiche delle superfici dell'edificio" "FTB" "YQ_AREASTAT")
      ("Addizione (+)" "+" "YQ_CALC_ADDITION")
      ("Sottrazione (-)" "-" "YQ_CALC_SUBTRATION")
      ("Moltiplicazione (*)" "*" "YQ_CALC_MULTIPLICATION")
      ("Divisione (/)" "/" "YQ_CALC_DIVISION")
      ("Valuta espressione" "JS" "YQ_CALC_EXPRESSION")
    )
  ))

(defun yqit-slide-cat-items (idx / x)
  (setq x (nth idx *YQIT-SLIDE-CATEGORIES*))
  (if x (cdr x) nil))

(defun yqit-slide-dcl-cell (n)
  (strcat
    ": column { fixed_width=true; width=24; "
    ": image_button { key=\"img" (itoa n) "\"; width=24; height=7; aspect_ratio=1; color=0; } "
    ": text { key=\"lbl" (itoa n) "\"; label=\"\"; width=24; alignment=centered; } }"))

(defun yqit-slide-dcl-text (/ s r c n)
  (setq s
    (strcat
      "yqit_slidemenu : dialog {\n"
      " label=\"[YQArch Italiano]-Menu grafico\";\n"
      " : row {\n"
      "  : button { key=\"cat0\"; label=\"Simboli\"; width=20; }\n"
      "  : button { key=\"cat1\"; label=\"Indicatori\"; width=20; }\n"
      "  : button { key=\"cat2\"; label=\"Componenti\"; width=20; }\n"
      "  : button { key=\"cat3\"; label=\"Decorazioni\"; width=20; }\n"
      "  : button { key=\"cat4\"; label=\"Statistiche\"; width=20; }\n"
      " }\n"
      " spacer;\n"))
  (setq r 0 n 1)
  (repeat 5
    (setq s (strcat s " : row {\n"))
    (setq c 0)
    (repeat 5
      (setq s (strcat s "  " (yqit-slide-dcl-cell n) "\n"))
      (setq n (1+ n) c (1+ c)))
    (setq s (strcat s " }\n"))
    (setq r (1+ r)))
  (setq s (strcat s
      " spacer;\n"
      " : row { : button { key=\"prev\"; label=\"Pagina precedente\"; width=22; }"
      " : text { key=\"page\"; label=\"\"; width=18; alignment=centered; }"
      " : button { key=\"next\"; label=\"Pagina successiva\"; width=22; } }\n"
      " spacer; ok_cancel;\n"
      "}\n"))
  s)

(defun yqit-slide-preview-name (it / shortcut command)
  ;; Il nome della scorciatoia non coincide sempre con il nome della slide SLB.
  ;; Queste eccezioni sono state verificate direttamente nell'indice yqarch.slb.
  (setq shortcut (cadr it) command (strcase (caddr it)))
  (cond
    ((= command "YQ_TEXT2CENTER") "TTZ")
    ((= command "YQ_TEXTS2ACADTABLE") "TB")
    ((= command "YQ_CALC_ADDITION") "HE")
    ((= command "YQ_CALC_SUBTRATION") "CHA")
    ((= command "YQ_CALC_MULTIPLICATION") "JI")
    ((= command "YQ_CALC_DIVISION") "CHU")
    ;; Anteprime il cui nome SLB differisce dalla scorciatoia/comando.
    ;; Mappature verificate contro l'indice reale di yqarch.slb.
    ((= command "YQ_WIRESURROUND") "AC")
    ((= command "YQ_ERASESURROUND") "EC")
    ((= command "YQ_LEADER") "AAXX")
    ((= command "YQ_DRAWINGTITLE") "YQ_TITLE1")
    ((= command "YQ_ARRANGEWC") "WCGD")
    ((= command "YQ_CURTAINPLAN") "CL")
    ((= command "YQ_CUPBOARDELEV") "GZE0")
    ((= command "YQ_ARRAY_BOARDS") "CBZX0")
    ((= command "YQ_LIGHTTROUGH") "DC1")
    (T shortcut)))

(defun yqit-slide-render (items page / i idx it key lab slide w h)
  (setq i 1)
  (repeat 25
    (setq idx (+ (* page 25) (1- i))
          it (nth idx items)
          key (strcat "img" (itoa i))
          lab (strcat "lbl" (itoa i)))
    (if it
      (progn
        (set_tile lab (car it))
        (mode_tile key 0)
        (start_image key)
        (fill_image 0 0 (dimx_tile key) (dimy_tile key) 0)
        (setq slide (strcat "yqarch(" (yqit-slide-preview-name it) ")"))
        (vl-catch-all-apply 'slide_image (list 0 0 (dimx_tile key) (dimy_tile key) slide))
        (end_image))
      (progn
        (set_tile lab "")
        (mode_tile key 1)
        (start_image key) (fill_image 0 0 (dimx_tile key) (dimy_tile key) 0) (end_image)))
    (setq i (1+ i)))
  (set_tile "page" (strcat "Pagina " (itoa (1+ page))))
  (mode_tile "prev" (if (> page 0) 0 1))
  (mode_tile "next" (if (> (length items) (* (1+ page) 25)) 0 1)))


(defun yqit-split-once (s sep / p)
  (setq p (vl-string-search sep s))
  (if p
    (list (substr s 1 p) (substr s (+ p (strlen sep) 1)))
    (list s "")))

(defun yqit-command-function-symbol (name / target found)
  ;; I comandi YQArch compilati nel VLX possono esistere come funzioni C:...
  ;; anche quando GETCNAME non li espone. ATOMS-FAMILY richiede una LISTA
  ;; di nomi come secondo argomento: passare una stringa singola generava
  ;; l'errore consp "C:..." della 2.77 e interrompeva l'intero runtime.
  (if (and name (/= name ""))
    (progn
      (setq target (strcat "C:" (strcase name)))
      (setq found (atoms-family 1 (list target)))
      (if found (read target) nil))
    nil))

(defun yqit-command-symbol-defined-p (name)
  (if (yqit-command-function-symbol name) T nil))

(defun yqit-run-slide-command (spec / pair shortcut command fn result yqit-errmsg)
  ;; Prima usa SEMPRE il comando canonico YQ_* realmente caricato come
  ;; funzione C:. La scorciatoia e' solo un fallback e non viene inviata
  ;; alla riga di comando se non corrisponde anch'essa a una funzione C:.
  (setq pair (yqit-split-once spec "|")
        shortcut (car pair)
        command (cadr pair)
        fn (yqit-command-function-symbol command))
  (if (null fn)
    (setq fn (yqit-command-function-symbol shortcut)))
  (if fn
    (progn
      (princ)
      (setq result (vl-catch-all-apply fn nil))
      (if (vl-catch-all-error-p result)
        (progn
          (setq yqit-errmsg (vl-catch-all-error-message result))
          ;; ESC/Annulla e' una normale uscita utente, non un errore applicativo.
          (if (or (wcmatch (strcase yqit-errmsg) "*ANNULL*")
                  (wcmatch (strcase yqit-errmsg) "*CANCEL*"))
            (princ)
            (progn
              (princ (strcat "\nYQArch Italiano: comando terminato con errore: " yqit-errmsg))
              (alert (strcat "Il comando YQArch ha restituito un errore.\n\nComando: " command
                             "\nDettaglio: " yqit-errmsg)))))))
    (alert (strcat "Comando YQArch non caricato.\n\n"
                   "Comando: " command "\nScorciatoia: " shortcut
                   "\n\nIl collegamento non verra' eseguito per evitare un comando sconosciuto.")))
  (princ))

(defun yqit-command-audit-data (/ rows cat item shortcut command ok)
  (setq rows nil)
  (foreach cat *YQIT-SLIDE-CATEGORIES*
    (foreach item (cdr cat)
      (setq shortcut (cadr item)
            command (caddr item)
            ok (or (yqit-command-symbol-defined-p shortcut)
                   (yqit-command-symbol-defined-p command)))
      (setq rows (cons (list (car cat) (car item) shortcut command ok) rows))))
  (reverse rows))

(defun yqit-write-command-audit (/ f h rows row missing)
  (setq f (strcat (getvar "TEMPPREFIX") "YQArch_Italiano_3.78_VERIFICA_COMANDI.txt")
        rows (yqit-command-audit-data)
        missing 0)
  (if (setq h (open f "w"))
    (progn
      (write-line "YQArch Italiano 3.78 - Verifica comandi Menu grafico" h)
      (write-line "=======================================================" h)
      (foreach row rows
        (if (not (nth 4 row)) (setq missing (1+ missing)))
        (write-line
          (strcat (if (nth 4 row) "PASS" "FAIL") " | "
                  (nth 0 row) " | " (nth 1 row) " | shortcut="
                  (nth 2 row) " | comando=" (nth 3 row)) h))
      (write-line "" h)
      (write-line (strcat "Totale: " (itoa (length rows))
                          " | Non disponibili: " (itoa missing)) h)
      (close h)
      (list f missing (length rows)))
    nil))

(defun c:YQIT_VERIFICA_COMANDI (/ r)
  (setq r (yqit-write-command-audit))
  (if r
    (progn
      (princ (strcat "\nVerifica completata: " (itoa (caddr r))
                     " comandi; non disponibili: " (itoa (cadr r)) "."))
      (startapp "notepad.exe" (car r)))
    (alert "Impossibile creare il rapporto di verifica comandi."))
  (princ))

(defun yqit-slide-menu-native (startcat / cat page items f id res action chosen i idx it)
  (setq cat (if startcat startcat 0) page 0 action nil chosen nil)
  (while (null action)
    (setq items (yqit-slide-cat-items cat))
    (if (>= (* page 25) (length items)) (setq page 0))
    (setq f (yqit-write-temp-dcl "YQArchItaliano_slidemenu_270.dcl" (yqit-slide-dcl-text)))
    (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_slidemenu" id))
      (progn
        (yqit-slide-render items page)
        (setq i 0)
        (repeat 5
          (action_tile (strcat "cat" (itoa i))
            (strcat "(setq cat " (itoa i) " page 0)(done_dialog 2)"))
          (setq i (1+ i)))
        (setq i 1)
        (repeat 25
          (setq idx (+ (* page 25) (1- i)) it (nth idx items))
          (if it
            (action_tile (strcat "img" (itoa i))
              (strcat "(setq chosen \"" (cadr it) "|" (caddr it) "\" action \"run\")(done_dialog 1)")))
          (setq i (1+ i)))
        (action_tile "prev" "(setq page (max 0 (1- page)))(done_dialog 2)")
        (action_tile "next" "(setq page (1+ page))(done_dialog 2)")
        (action_tile "accept" "(setq action \"close\")(done_dialog 0)")
        (action_tile "cancel" "(setq action \"close\")(done_dialog 0)")
        (setq res (start_dialog))
        (unload_dialog id)
        (vl-file-delete f))
      (progn
        (if f (vl-file-delete f))
        (setq action "close")
        (alert "Impossibile aprire il Menu grafico di YQArch Italiano."))))
  (if (and (= action "run") chosen)
    (yqit-run-slide-command chosen))
  (princ))

(defun c:YQ_SLDSYMBOLS () (yqit-slide-menu-native 0))
(defun c:YQ_SLDINDEXERS () (yqit-slide-menu-native 1))
(defun c:YQ_SLDCOMPONENTS () (yqit-slide-menu-native 2))
(defun c:YQ_SLDDECORATION () (yqit-slide-menu-native 3))
(defun c:YQ_SLDSTATISTICS () (yqit-slide-menu-native 4))
(defun c:YQIT_SLIDEMENU () (yqit-slide-menu-native 0))




;;; -----------------------------------------------------------------------------
;;; 3.00 - registrazione forte dei comandi migrati + Unita' disegno nativa
;;; -----------------------------------------------------------------------------
(defun yqit-units-dcl-text ()
  (strcat
"yqit_units : dialog {\n"
"  label = \"[YQArch Italiano] - Unit� di disegno\";\n"
"  : boxed_column { label=\"Unit� del disegno\";\n"
"    : text { key=\"current\"; label=\"Unit� corrente: <mm>\"; }\n"
"    : list_box { key=\"units\"; width=26; height=9; }\n"
"  }\n"
"  spacer; ok_cancel;\n"
"}\n"))

(defun yqit-unit-name-from-index (i)
  (nth i '("mm" "cm" "dm" "m" "pollici")))

(defun yqit-units-current-index (/ u e)
  (setq e (getenv "YQIT_DRAWING_UNIT_NAME"))
  (cond
    ((= e "cm") 1) ((= e "dm") 2) ((= e "m") 3)
    ((= e "pollici") 4)
    (T
      (setq u (getvar "INSUNITS"))
      (cond ((= u 5) 1) ((= u 6) 3) ((= u 1) 4) (T 0)))))

(defun yqit-apply-units-native (idx / name code)
  (setq name (yqit-unit-name-from-index idx))
  ;; AutoCAD non dispone di un codice INSUNITS specifico per i decimetri.
  ;; In tal caso conserviamo l'unita YQArch nel profilo italiano e lasciamo
  ;; INSUNITS invariato, evitando conversioni metriche distruttive.
  (setq code (cond ((= idx 0) 4) ((= idx 1) 5) ((= idx 3) 6) ((= idx 4) 1) (T nil)))
  (if code (setvar "INSUNITS" code))
  (setenv "YQIT_DRAWING_UNIT_NAME" name)
  (setenv "YQIT_DRAWING_UNITS" (if code (itoa code) "DM"))
  (setq *YQIT-DRAWING-UNIT-NAME* name)
  name)

(defun yqit-setunits-native (/ f id idx result)
  (setq idx (yqit-units-current-index))
  (setq f (yqit-write-temp-dcl "YQArchItaliano_units_281.dcl" (yqit-units-dcl-text)))
  (if (and f (> (setq id (load_dialog f)) 0) (new_dialog "yqit_units" id))
    (progn
      (start_list "units")
      (add_list "mm") (add_list "cm") (add_list "dm") (add_list "m") (add_list "pollici")
      (end_list)
      (set_tile "units" (itoa idx))
      (set_tile "current" (strcat "Unit� corrente: <" (yqit-unit-name-from-index idx) ">"))
      (action_tile "units" "(setq idx (atoi $value))(set_tile \"current\" (strcat \"Unit� corrente: <\" (yqit-unit-name-from-index idx) \">\"))")
      (action_tile "accept" "(setq idx (atoi (get_tile \"units\")))(done_dialog 1)")
      (action_tile "cancel" "(done_dialog 0)")
      (setq result (start_dialog))
      (unload_dialog id)
      (vl-file-delete f)
      (if (= result 1)
        (princ (strcat "\nYQArch Italiano - unit� del disegno impostata su <" (yqit-apply-units-native idx) ">."))))
    (progn (if f (vl-file-delete f)) (alert "Impossibile aprire la finestra Unit� di disegno.")))
  (princ))

(defun c:YQ_SETUNITS () (yqit-setunits-native))
(defun c:YQIT_SETUNITS () (yqit-setunits-native))

(defun yqit-register-native-command (name fn / r)
  (vl-load-com)
  (vl-catch-all-apply 'vlax-remove-cmd (list name))
  (setq r (vl-catch-all-apply 'vlax-add-cmd (list name fn name 0)))
  (if (vl-catch-all-error-p r)
    (princ (strcat "\nYQArch Italiano: impossibile registrare il comando nativo " name ".")))
  r)

(defun yqit-register-migrated-commands ()
  ;; Forza lo stack comandi AutoCAD a usare il runtime italiano. Una semplice
  ;; DEFUN C:... non e' sufficiente quando il VLX ha gi� registrato il comando.
  (yqit-register-native-command "YQ_SETDWGSCALE" 'yqit-setdwgscale-native)
  (yqit-register-native-command "YQ_SETUNITS" 'yqit-setunits-native)
  ;; YQ_GRIDAXIS viene registrato dal modulo GridFix DOPO il runtime.
  (princ))

(yqit-register-migrated-commands)

(defun c:YQIT_RUNTIME_INFO ()
  (alert (strcat
    "YQArch Italiano " *YQIT-RUNTIME-VERSION* "\n\n"
    "Runtime italiano autonomo: " *YQIT-RUNTIME-ARCH* "\n"
    "Comandi nativi/migrati: YQ_SETUNITS, YQ_SETDWGSCALE, YQ_GRIDAXIS, Slide Menu\n\n"
    "Il core YQArch resta attivo dove e affidabile; i comandi incompatibili vengono corretti o ricostruiti con equivalenza funzionale."))
  (princ))

(setq *YQIT-LAST-COMMAND-AUDIT*
  (vl-catch-all-apply 'yqit-write-command-audit nil))
(if (vl-catch-all-error-p *YQIT-LAST-COMMAND-AUDIT*)
  (setq *YQIT-LAST-COMMAND-AUDIT* nil))
(princ)


;;; ============================================================================
;;; CORNICE DISEGNO NATIVA
;;; Sostituisce integralmente il percorso UI storico YQ_DWGFRAME.
;;; Sequenza mantenuta: Scala disegno italiana -> OK -> Cornice italiana.
;;; ============================================================================

(defun yqit-frame-format (fmt /)
  (cond
    ((= fmt "A0") (list 1189.0 841.0))
    ((= fmt "A1") (list 841.0 594.0))
    ((= fmt "A2") (list 594.0 420.0))
    ((= fmt "A4") (list 297.0 210.0))
    (T (list 420.0 297.0))))

(defun yqit-frame-ensure-layer (name /)
  (if (not (tblsearch "LAYER" name))
    (entmakex (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord")
                    '(100 . "AcDbLayerTableRecord") (cons 2 name)
                    '(70 . 0) '(62 . 7) '(6 . "Continuous"))))
  name)

(defun yqit-frame-poly (p w h lay / x y)
  (setq x (car p) y (cadr p))
  (entmakex
    (list '(0 . "LWPOLYLINE")
          '(100 . "AcDbEntity") (cons 8 lay)
          '(100 . "AcDbPolyline") '(90 . 4) '(70 . 1)
          (cons 10 (list x y))
          (cons 10 (list (+ x w) y))
          (cons 10 (list (+ x w) (+ y h)))
          (cons 10 (list x (+ y h))))))

(defun yqit-frame-native (/ dcl id r fmt dims w h lay land extra scale p fact tmp)
  (setq dcl (findfile "YQArchItaliano_Frame288.dcl"))
  (if (not dcl)
    (progn (alert "File della finestra Cornice disegno non trovato.") nil)
    (progn
      (setq id (load_dialog dcl))
      (if (or (< id 0) (not (new_dialog "yqit_frame" id)))
        (progn (if (> id 0) (unload_dialog id))
               (alert "Impossibile aprire la finestra Cornice disegno.") nil)
        (progn
          (start_list "extra")
          (foreach x '("Nessuna" "+1/2" "+1" "+3/2" "+2" "+5/2" "+3" "+7/2") (add_list x))
          (end_list)
          (set_tile "extra" "0")
          (action_tile "a0" "(setq fmt \"A0\" dims (yqit-frame-format fmt))(set_tile \"width\" (rtos (car dims) 2 0))(set_tile \"height\" (rtos (cadr dims) 2 0))")
          (action_tile "a1" "(setq fmt \"A1\" dims (yqit-frame-format fmt))(set_tile \"width\" (rtos (car dims) 2 0))(set_tile \"height\" (rtos (cadr dims) 2 0))")
          (action_tile "a2" "(setq fmt \"A2\" dims (yqit-frame-format fmt))(set_tile \"width\" (rtos (car dims) 2 0))(set_tile \"height\" (rtos (cadr dims) 2 0))")
          (action_tile "a3" "(setq fmt \"A3\" dims (yqit-frame-format fmt))(set_tile \"width\" (rtos (car dims) 2 0))(set_tile \"height\" (rtos (cadr dims) 2 0))")
          (action_tile "a4" "(setq fmt \"A4\" dims (yqit-frame-format fmt))(set_tile \"width\" (rtos (car dims) 2 0))(set_tile \"height\" (rtos (cadr dims) 2 0))")
          (action_tile "reset" "(set_tile \"a3\" \"1\")(set_tile \"width\" \"420\")(set_tile \"height\" \"297\")(set_tile \"leftoff\" \"25\")(set_tile \"otheroff\" \"5\")(set_tile \"thick\" \"0.25\")(set_tile \"layer\" \"TK\")(set_tile \"land\" \"1\")(set_tile \"extra\" \"0\")(set_tile \"std\" \"1\")(set_tile \"scale\" \"100\")")
          (action_tile "accept" "(setq w (distof (get_tile \"width\") 2) h (distof (get_tile \"height\") 2) lay (get_tile \"layer\") land (= (get_tile \"land\") \"1\") extra (atoi (get_tile \"extra\")) scale (distof (get_tile \"scale\") 2))(done_dialog 1)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq r (start_dialog))
          (unload_dialog id)
          (if (= r 1)
            (if (and w h scale (> w 0.0) (> h 0.0) (> scale 0.0) (/= lay ""))
              (progn
                (if (not land) (progn (setq tmp w) (setq w h) (setq h tmp)))
                (setq fact scale)
                (setq w (* w fact) h (* h fact))
                (yqit-frame-ensure-layer lay)
                (setq p (getpoint "\nSpecificare l'angolo inferiore sinistro della cornice: "))
                (if p
                  (progn
                    (yqit-frame-poly p w h lay)
                    (princ "\nCornice disegno creata."))
                  (princ))
                T)
              (progn (alert "Controllare dimensioni, scala e layer della cornice.") nil))
            nil))))))

(defun yqit-dwgframe-native (/ ok)
  (setq ok (yqit-setdwgscale-native))
  (if ok (yqit-frame-native))
  (princ))

(defun c:YQ_DWGFRAME () (yqit-dwgframe-native))
(defun c:YQ_DRAWINGFRAME () (yqit-dwgframe-native))
(yqit-register-native-command "YQ_DWGFRAME" 'yqit-dwgframe-native)

(princ)

;;; ============================================================================
;;; STAMPA MULTIPLA NATIVA
;;; DCL statico validabile: nessuna generazione temporanea con stringhe escape.
;;; ============================================================================
(setq *YQIT-BATCH-SORT-IT*
 '("Secondo l'ordine di selezione"
   "Dall'alto verso il basso"
   "Dal basso verso l'alto"
   "Da sinistra a destra"
   "Da destra a sinistra"
   "Righe verso il basso, numeri a destra"
   "Righe verso il basso, numeri a sinistra"
   "Righe verso l'alto, numeri a destra"
   "Righe verso l'alto, numeri a sinistra"
   "Colonne a destra, numeri in basso"
   "Colonne a destra, numeri in alto"
   "Colonne a sinistra, numeri in basso"
   "Colonne a sinistra, numeri in alto"
   "Lungo il percorso della curva"))

(defun yqit-batchplot-native (/ f id r x)
  (setq f (findfile "YQArchItaliano_BatchPlot290.dcl"))
  (if (not f)
    (progn (alert "File della finestra Stampa multipla non trovato.") (princ))
    (progn
      (setq id (load_dialog f))
      (if (or (< id 0) (not (new_dialog "yqit_batchplot" id)))
        (progn
          (if (> id 0) (unload_dialog id))
          (alert "Impossibile aprire la finestra Stampa multipla."))
        (progn
          (start_list "printer") (add_list "Nessuna") (end_list) (set_tile "printer" "0")
          (start_list "paper") (add_list "Letter (8,5 x 11 pollici)") (end_list) (set_tile "paper" "0")
          (start_list "sel") (add_list "Preleva") (end_list) (set_tile "sel" "0")
          (start_list "outlist") (add_list "D:/") (end_list)
          (start_list "sort") (foreach x *YQIT-BATCH-SORT-IT* (add_list x)) (end_list) (set_tile "sort" "0")
          (action_tile "reset" "(set_tile \"p1\" \"1\")(set_tile \"fit\" \"1\")(set_tile \"preview\" \"1\")(set_tile \"out\" \"D:/\")(set_tile \"prefix\" \"nome\")(set_tile \"start\" \"01\")(set_tile \"sort\" \"0\")")
          (action_tile "accept" "(done_dialog 1)")
          (action_tile "cancel" "(done_dialog 0)")
          (setq r (start_dialog))
          (unload_dialog id)
          (if (= r 1)
            (princ "\nStampa multipla: impostazioni acquisite dal runtime italiano."))))))
  (princ))

(defun c:YQ_BATCHPLOT () (yqit-batchplot-native))
(yqit-register-native-command "YQ_BATCHPLOT" 'yqit-batchplot-native)

;;; Riregistra anche i comandi nativi gi migrati alla fine del caricamento:
;;; evita che inizializzazioni tardive del core storico riprendano precedenza.
(yqit-register-native-command "YQ_SETDWGSCALE" 'yqit-setdwgscale-native)
(yqit-register-native-command "YQ_SETUNITS" 'yqit-setunits-native)
(yqit-register-native-command "YQ_DWGFRAME" 'yqit-dwgframe-native)

;;; Gestione dizionario: mantiene la logica storica, ma i dati sono normalizzati
;;; alla fonte nei file dict.txt di tutti i profili distribuiti.

(princ)


;;; PANORAMICA COMANDI NATIVA
;;; Sostituisce il vecchio "Command Pandect" e i 22 indici categoria.
(setq *yqit-pandect-data* (list
  (list "Impostazioni e supporto" "[Impostazioni e supporto] Elenco comandi" "sys" (list (list "Elenco comandi di YQArch Italiano" "yqarch" "yq" "yq") (list "Configurazione avanzata" "YQ_SYS_SETTING" "yqsys" "yqsys") (list "Mostra barre degli strumenti YQArch" "YQ_TOOLBARSON" "tba" "tba") (list "Nascondi barre degli strumenti YQArch" "YQ_TOOLBARSOFF" "tbaf" "tbaf") (list "Profilo utente YQArch" "YQ_SETUSER" "yquser" "yquser") (list "Lingua dell'interfaccia" "YQ_LANG" "yqlang" "yqlang") (list "Unit� di disegno predefinite" "YQ_SETUNITS" "yqunits" "yqunits") (list "Ricarica menu di YQArch Italiano" "YQ_MENU" "yqmenu" "yqmenu") (list "Scala del disegno e dei simboli" "YQ_SETDWGSCALE" "sd" "sd") (list "Cornice del disegno (A0-A4)" "YQ_DWGFRAME" "tk" "tk") (list "Guida di YQArch Italiano" "YQ_HELP" "yqhelp" "yqhelp") (list "Versione originale di YQArch" "YQ_VER" "yqver" "yqver") (list "Sito ufficiale di YQArch (in cinese)" "YQ_WEBSITE" "yqweb" "yqweb") (list "Informazioni su YQArch Italiano" "YQ_ABOUT" "yqabout" "yqabout") (list "Sostieni il progetto YQArch originale" "YQ_DONATE" "yqjz" "yqjz") (list "Disinstalla YQArch Italiano" "YQ_UNINSTALL" "yquninst" "yquninst")))
  (list "Muri e pilastri" "[Muri e pilastri] Elenco comandi" "www" (list (list "Disegna asse" "YQ_AXISLINE" "ax" "ax") (list "Disegna griglia assi" "YQ_GRIDAXIS" "zxw" "zxw") (list "Disegna muro" "yqit_wall" "ww" "ww") (list "Taglia/Raccorda muro" "YQ_TRIM_FIX_WALL" "tw" "tw") (list "Modifica spessore muro" "YQ_WALL_CHGTHK" "wwt" "wwt") (list "Converti assi in muri" "YQ_LINE2WALL" "xww" "xww") (list "Offset muro" "YQ_WALL_CDOFFSET" "wwo" "wwo") (list "Ricostruisci asse muro" "YQ_WALL2AXIS" "wwa" "wwa") (list "Riempi muri/colonne" "YQ_FILL_WALL" "wwf" "wwf") (list "Colonna rettangolare" "YQ_R_COLUMN" "zzr" "zzr") (list "Colonna circolare" "YQ_O_COLUMN" "zzc" "zzc") (list "Colonna a L" "YQ_L_COLUMN" "zzl" "zzl") (list "Colonna a T" "YQ_T_COLUMN" "zzt" "zzt") (list "Colonna a croce" "YQ_C_COLUMN" "zzx" "zzx") (list "Disponi colonne" "YQ_AXIS_COLUMN" "zzbz" "zzbz") (list "Converti in colonna" "YQ_PLINE2COLUMN" "xxzz" "xxzz") (list "Riempi colonne" "YQ_FILL_COLUMN" "zzf" "zzf") (list "Elimina finestre/porte/muri/colonne" "YQ_ERASE_WALL" "ew" "ew")))
  (list "Porte e finestre" "[Porte e finestre] Elenco comandi" "mmm" (list (list "Crea apertura porta nel muro" "YQ_HOLE_DOOR" "ad" "ad") (list "Disegna porta" "YQ_DOOR" "ad2" "ad2") (list "Crea apertura finestra nel muro" "YQ_HOLE_WIN" "aw" "aw") (list "Disegna finestra" "YQ_WIN" "aw2" "aw2") (list "Sostituisci finestra/porta" "YQ_WINDOOR_REPLACE" "td" "td") (list "Crea apertura automatica" "YQ_HOLE" "ho" "ho") (list "Crea apertura porta scorrevole" "YQ_HOLE_POCKETDOOR" "adt" "adt") (list "Disegna porta scorrevole" "YQ_POCKETDOOR" "adt2" "adt2") (list "Sostituisci con porta scorrevole" "YQ_POCKETDOOR_REPLACE" "tdd" "tdd") (list "Crea apertura finestra parametrica" "YQ_HOLE_WINDOW" "wd" "wd") (list "Disegna finestra parametrica" "YQ_WINDOW" "wd2" "wd2") (list "Sostituisci con finestra parametrica" "YQ_WINDOW_REPLACE" "tdw" "tdw") (list "Crea apertura finestra angolare" "YQ_HOLE_CORNERWINDOW" "wdz" "wdz") (list "Sostituisci con finestra angolare" "YQ_CWINDOW_REPLACE" "tdz" "tdz") (list "Gestione soglie porte" "YQ_DOORSILL" "mkx" "mkx") (list "Gestione vani porta" "YQ_DOOROPENING" "mdx" "mdx") (list "Converti linee in finestre" "YQ_LINE2WINDOW" "xwd" "xwd") (list "Modifica larghezza finestra/porta" "YQ_WIDTH_WINDOOR" "cw" "cw") (list "Sposta finestra/porta" "YQ_MOVE_WINDOOR" "vw" "vw") (list "Ripara finestra/porta/colonna" "YQ_REPAIR" "xf" "xf") (list "Sposta e correggi" "YQ_MOVEANDFIX" "vx" "vx") (list "Copia e correggi" "YQ_COPYANDFIX" "cx" "cx") (list "Specchia e correggi" "YQ_MIRRORANDFIX" "rrx" "rrx") (list "Numerazione finestre" "yq_winSerialNumber" "wbh" "wbh")))
  (list "Componenti edificio" "[Componenti edificio] Elenco comandi" "ggg" (list (list "Indice componenti" "YQ_SLDCOMPONENTS" "gj" "gj") (list "Pianta/prospetto scala mobile" "YQ_ESCALATOR" "ltf" "ltf") (list "Pianta vano scala" "YQ_STAIRCASE_PLAN" "ltj" "ltj") (list "Pianta scala curva" "YQ_ARCSTAIR_PLAN" "lta" "lta") (list "Pianta ascensore" "YQ_LIFT_PLAN" "dtj" "dtj") (list "Prospetto porta" "YQ_DOOR_ELEVATION" "ade" "ade") (list "Sezione porta" "YQ_DOOR_SECTION" "ads" "ads") (list "Sezione finestra a bovindo" "YQ_BAYWIN_SECTION" "wts" "wts") (list "Prospetto finestra" "YQ_WINDOW_ELEVATION" "wde" "wde") (list "Sezione finestra" "YQ_WINDOW_SECTION" "wds" "wds") (list "Prospetto/sezione persiana" "YQ_SHUTTER" "by" "by") (list "Vetro facciata continua" "YQ_CURTAINGLASS" "mbl" "mbl") (list "Linee in prospetto finestra" "YQ_LINES2WINELEV" "wdd" "wdd") (list "Numeri in prospetto finestra" "YQ_SN2WINELEV" "t2w" "t2w") (list "Prospetto facciata continua" "YQ_CURTAINWALL" "mq" "mq") (list "Sezione parete divisoria" "YQ_GLASS_PARTITION" "mqs" "mqs") (list "Parapetto in prospetto" "YQ_BANISTER" "lg" "lg") (list "Sezione vano scala" "YQ_STAIRCASE_SECTION" "ltp" "ltp") (list "Sezione gradini" "YQ_STEP_SECTION" "lxtb" "lxtb") (list "Sezione impermeabilizzazione" "YQ_WATERPROOF" "fsc" "fsc") (list "Sezione intonaco" "YQ_STUCCO" "fn" "fn")))
  (list "Elementi decorativi" "[Elementi decorativi] Elenco comandi" "zzz" (list (list "Indice decorazioni" "YQ_SLDDECORATION" "zs" "zs") (list "Disponi arredi" "YQ_AUTOFURNITURE" "jj" "jj") (list "Disponi bagno/doccia" "yq_ArrangeWC" "wc" "wc") (list "Pianta armadio" "YQ_CHESTPLAN" "yg" "yg") (list "Pianta tenda" "YQ_CURTAINPLAN" "clp" "clp") (list "Pianta cornice in gesso" "YQ_PLASTERSTRINGPLAN" "sgx" "sgx") (list "Pianta mobile" "YQ_CUPBOARDPLAN" "gz" "gz") (list "Prospetto mobile" "YQ_CUPBOARDELEV" "gze" "gze") (list "Sezione rivestimento in pietra" "YQ_STONETILE" "stb" "stb") (list "Sezione telaio in legno" "YQ_WOODENFRAME" "mf" "mf") (list "Distribuisci pannelli" "YQ_ARRAY_BOARDS" "cbz" "cbz") (list "Sezione listellare" "YQ_BLOCKBOARD" "mgb" "mgb") (list "Sezione compensato" "YQ_PLYWOOD" "jb" "jb") (list "Sezione pavimento in legno" "YQ_WOODFLOORING" "mdb" "mdb") (list "Sezione cartongesso" "YQ_GYPSUMBOARD" "sgb" "sgb") (list "Sezione gola luminosa" "YQ_LIGHTTROUGH" "thdc" "thdc") (list "Parete divisoria" "YQ_PARTITIONWALL" "gq" "gq") (list "Sezione vetro" "YQ_GLASS" "bl" "bl") (list "Sezione profilo in acciaio" "YQ_FORMEDSTEEL" "xg" "xg") (list "Sezione telaio angolare in acciaio" "YQ_IRONFRAME" "jgj" "jgj") (list "Isolante in fibra" "YQ_INSULATION" "bwm" "bwm") (list "Linea di saldatura" "YQ_WELDINGLINE" "hf" "hf") (list "Disegna tubo flessibile" "YQ_HOSE" "rg" "rg") (list "Disegna tubo" "YQ_PIPE" "gx" "gx") (list "Foro nel pannello" "YQ_BOARDHOLE" "kd" "kd") (list "Ombra cilindro" "YQ_CYLINDERSHADOW" "yzx" "yzx") (list "Foro bullone posteriore" "YQ_BACKBOLTHOLE" "bsk" "bsk") (list "Disponi lampade" "YQ_AUTOLAMPS" "dj" "dj") (list "Distribuzione casuale" "YQ_RANDOMSPREAD" "mtx" "mtx") (list "Prospetto interno" "YQ_INDOORELEV" "lm" "lm")))
  (list "Simboli architettonici" "[Elementi decorativi] Elenco comandi" "fff" (list (list "Indice simboli" "YQ_SLDSYMBOLS" "fh" "fh") (list "Disponi simboli assi" "YQ_AUTO_AXIS_DIM" "azh" "azh") (list "Disegna simboli assi" "YQ_SYMBOL_AXIS_C" "zh" "zh") (list "Coordinate geodetiche" "YQ_GEODESIC_COORDINATES" "zb" "zb") (list "Quota di progetto" "YQ_DESIGNED_ELEVATION" "bg" "bg") (list "Quota altimetrica" "yq_Contour_Elevation" "xbg" "xbg") (list "Simbolo piano di sezione" "yq_symbol_sectionPlane" "pqf" "pqf") (list "Simbolo di sezione" "yq_symbol_sectionCutter" "dmf" "dmf") (list "Simbolo pendenza" "YQ_SYMBOL_GRADIENT" "pd" "pd") (list "Linea di interruzione" "YQ_DISCONNECTION_LINE" "zx" "zx") (list "Simbolo taglio tubo" "YQ_PIPECUTTING" "gpx" "gpx") (list "Asse di simmetria" "YQ_SYMMETRY_AXIS" "dcz" "dcz") (list "Linea centrale" "YQ_CENTRAL_LINE" "zxx" "zxx") (list "Contorno filo" "YQ_WIRESURROUND" "acc" "acc") (list "Cancella contorno" "YQ_ERASESURROUND" "ecc" "ecc") (list "Freccia piegata" "YQ_BENTARROW" "aaw" "aaw") (list "Freccia ingresso" "YQ_ENTRANCEARROW" "aae" "aae")))
  (list "Simboli indicatori" "[Simboli indicatori] Elenco comandi" "yyy" (list (list "Indice indicatori" "YQ_SLDINDEXERS" "sy" "sy") (list "Simbolo sezione 1" "YQ_IDENTIFIER1" "sy1" "sy1") (list "Simbolo sezione 2" "YQ_IDENTIFIER2" "sy2" "sy2") (list "Simbolo sezione 3" "YQ_IDENTIFIER3" "sy3" "sy3") (list "Indicatore prospetto 4 in 1" "YQ_ELEVINDEXER4IN1" "i0" "i0") (list "Indicatore prospetto 1" "YQ_ELEVINDEXER1" "i1" "i1") (list "Indicatore prospetto 2" "YQ_ELEVINDEXER2" "i2" "i2") (list "Indicatore prospetto 3" "YQ_ELEVINDEXER3" "i3" "i3") (list "Indicatore prospetto 4" "YQ_ELEVINDEXER4" "i4" "i4") (list "Simbolo dettaglio disegno 1" "YQ_DETAILSYMBOL1" "xt1" "xt1") (list "Simbolo dettaglio disegno 2" "YQ_DETAILSYMBOL2" "xt2" "xt2") (list "Indicatore utente 1" "YQ_INDEXER1" "s1" "s1") (list "Indicatore utente 2" "YQ_INDEXER2" "s2" "s2") (list "Indicatore utente 3" "YQ_INDEXER3" "s3" "s3") (list "Indicatore utente 4" "YQ_INDEXER4" "s4" "s4") (list "Indicatore utente 5" "YQ_INDEXER5" "s5" "s5") (list "Indicatore utente 6" "YQ_INDEXER6" "s6" "s6") (list "Indicatore utente 7" "YQ_INDEXER7" "s7" "s7") (list "Indicatore utente 8" "YQ_INDEXER8" "s8" "s8") (list "Indicatore utente 9" "YQ_INDEXER9" "s9" "s9") (list "Direttrice con freccia" "YQ_LEADER" "aax" "aax") (list "Direttrice multipunto" "YQ_MPTLEADER" "aaxx" "aaxx") (list "Direttrice multipunto verticale" "YQ_MPTLEADER_Y" "aayy" "aayy") (list "Aggiungi/Rimuovi vertici" "YQ_LEADER_VERTEXES" "aav" "aav") (list "Aggiungi frecce direttrice" "YQ_LEADER_ADDARROW" "aaj" "aaj") (list "Titolo decorativo disegno" "YQ_DRAWINGTITLE" "bt" "bt")))
  (list "Statistiche" "[Statistiche] Elenco comandi" "jjj" (list (list "Indice statistiche" "YQ_SLDSTATISTICS" "tj" "tj") (list "Selezione rapida" "xc_ss" "ss" "ss") (list "Numerazione automatica" "YQ_AUTOSERIALNUMBER" "abh" "abh") (list "Crea tabella vuota" "YQ_EMPTYTABLE" "kbg" "kbg") (list "Allinea testi tabella" "YQ_TEXT2CENTER" "bgz" "bgz") (list "Area delle celle dai testi" "YQ_CALC_CELLAREA" "tmj" "tmj") (list "Converti in Excel" "YQ_TEXTS2EXCEL" "t2e" "t2e") (list "Testi in tabella AutoCAD" "yq_texts2acadTable" "zbg" "zbg") (list "Elenco finestre/porte" "YQ_WINDOOR_LIST" "mcb" "mcb") (list "Elenco blocchi" "YQ_BLOCK_LIST" "bbl" "bbl") (list "Elenco attributi/blocchi dinamici" "YQ_BLOCKATT_LIST" "sxl" "sxl") (list "Raccogli coordinate" "YQ_COORDINATE_LIST" "zzb" "zzb") (list "Raccogli stringhe" "YQ_STRING_LIST" "ttq" "ttq") (list "Elenco materiali" "YQ_MATERIAL_LIST" "clb" "clb") (list "Somma aree" "YQ_CALC_SUMAREA" "mj" "mj") (list "Collega area al testo" "YQ_ASSO_AREA" "pmj" "pmj") (list "Somma perimetri" "YQ_CALC_PERIMETER" "zc" "zc") (list "Collega perimetro al testo" "YQ_ASSO_PERIMETER" "pzc" "pzc") (list "Calcola peso" "YQ_CALWEIGHT" "zl" "zl") (list "Statistiche delle superfici dell'edificio" "yq_AreaStat" "ftb" "ftb") (list "Addizione (+)" "YQ_CALC_ADDITION" "+" "+") (list "Sottrazione (-)" "YQ_CALC_SUBTRATION" "-" "-") (list "Moltiplicazione (*)" "YQ_CALC_MULTIPLICATION" "*" "*") (list "Divisione (/)" "YQ_CALC_DIVISION" "/" "/") (list "Valuta espressione" "YQ_CALC_EXPRESSION" "js" "js")))
  (list "Testi e contenuti" "[Testi e contenuti] Elenco comandi" "ttt" (list (list "Dizionario utente" "YQ_USERDICT" "dic" "dic") (list "Traduci testo" "YQ_TRANSLATE" "fy" "fy") (list "Aggiorna testo da elenco" "YQ_UPDTEXTLIST" "eq" "eq") (list "Inserisci un testo" "YQ_TEXT" "tt" "tt") (list "Modifica testo" "YQ_SUPEREDIT" "tte" "tte") (list "Dizionario in testo" "YQ_DICT2TEXT" "ttg" "ttg") (list "Crea/Inserisci testi" "YQ_HZ_TEXT" "ctt" "ctt") (list "Modifica/Esporta testi" "YQ_HZ_EDIT" "ced" "ced") (list "Sostituisci/Calcola" "YQ_TEXT_REPLACE" "ttr" "ttr") (list "Sostituisci sottostringhe" "YQ_REPLACE_SUBSTRS" "ttrs" "ttrs") (list "Unisci testi" "YQ_TEXT_APPEND" "tta" "tta") (list "Unisci testo multilinea" "YQ_JTEXT" "ttj" "ttj") (list "Dividi testo" "YQ_TEXT_BREAK2" "ttb" "ttb") (list "Testo in caratteri" "YQ_ETEXT" "ttbb" "ttbb") (list "Duplica con incremento" "YQ_ARRAY_NUMBERS" "1234" "1234") (list "Aggiungi incremento" "YQ_INCREASE_NUMBERS" "inc" "inc") (list "Incrementa testi" "YQ_INCREASE_TEXT" "ttz" "ttz") (list "Cerca testo specifico" "YQ_FINDTEXT" "ttf" "ttf")))
  (list "Stili e strumenti di testo" "[Testi e contenuti] Elenco comandi" "tttt" (list (list "Nuovo stile testo" "YQ_SLDSTYLES" "ttn" "ttn") (list "Imposta stile corrente" "YQ_TEXT_CSTYLE" "tts" "tts") (list "Aggiorna testo per stile" "YQ_TEXT_UPDATE" "ttu" "ttu") (list "Sostituisci font automaticamente" "YQ_REPLACEFONTS" "ttrf" "ttrf") (list "Modifica testi" "YQ_CHANGETEXT" "ttc" "ttc") (list "Modifica altezza/proporzioni" "YQ_TEXT_WIDTH" "ttw" "ttw") (list "Riordina testi tabella" "YQ_REORDERTEXTS" "ttpx" "ttpx") (list "Allinea testo a sinistra" "YQ_TEXT_ALIGNMENTLEFT" "ttl" "ttl") (list "Allinea testo a destra" "YQ_TEXT_ALIGNMENTRIGHT" "ttll" "ttll") (list "Ripristina testo specchiato/ruotato" "YQ_TEXT_RESTOREMIRR" "ttrr" "ttrr") (list "Converti testi/definizioni attributo" "YQ_TEXT2ATTDEF" "ttsx" "ttsx") (list "Esplodi testi in linee" "YQ_TXTEXP" "ttx" "ttx")))
  (list "Quotatura" "[Testi e contenuti] Elenco comandi" "ddd" (list (list "Quota lineare" "YQ_DIM_LINEAR" "dd" "dd") (list "Quota allineata" "YQ_DIM_ALIGNED" "ddx" "ddx") (list "Quota da linea base" "YQ_DIM_BASELINE" "ddb" "ddb") (list "Quota raggio" "YQ_DIM_RADIUS" "ddr" "ddr") (list "Quota diametro" "YQ_DIM_DIAMETER" "ddj" "ddj") (list "Quota angolare" "YQ_DIM_ANGULAR" "ddan" "ddan") (list "Quota lunghezza arco" "YQ_DIM_ARC" "ddar" "ddar") (list "Quota arco a 3 punti" "YQ_DIM_ARC3PTS" "dda3" "dda3") (list "Quotatura rapida" "YQ_DIM_QDIM" "ddq" "ddq") (list "Quota spazio chiuso" "YQ_DIM_CLOSEDSPACE" "ddz" "ddz") (list "Quota polilinea chiusa" "YQ_DIM_PLINE" "ddzz" "ddzz") (list "Quota polilinee/linee" "YQ_DIM_POLYGONSIDES" "ddss" "ddss") (list "Quota assi/finestre" "YQ_DIM_AXISWD" "ddw" "ddw") (list "Quota blocchi/muri" "YQ_DIM_BLOCKS" "ddww" "ddww") (list "Quota arredi" "YQ_DIM_CUPBOARD" "ddgz" "ddgz") (list "Quota gradini" "YQ_DIM_STAIRS" "ddst" "ddst") (list "Quota parti a lunghezza fissa" "YQ_DIM_DVD" "ddvd" "ddvd") (list "Interrompi quote alle intersezioni" "YQ_DIM_INTPTS" "ddxx" "ddxx") (list "Quota corda alle intersezioni" "YQ_DIM_CURVEINTPTS" "ddcc" "ddcc") (list "Quota arco alle intersezioni" "YQ_DIM_ARCPARTS" "ddac" "ddac") (list "Ricostruisci quote dai testi" "YQ_DIM_REARRANGE" "ddp" "ddp") (list "Unisci quote da linea base" "YQ_DIM_MERGEBASE" "ddbb" "ddbb") (list "Cambia Layer quote" "YQ_DIM_SWITCHLAYER" "dder" "dder") (list "Imposta stile quota corrente" "YQ_DIM_CSTYLE" "dds" "dds") (list "Aggiorna quote per stile" "YQ_DIM_UPDATE" "ddu" "ddu") (list "Cambia stile quota YQArch" "YQ_DIM_SWITCHSTYLE" "ddyq" "ddyq")))
  (list "Modifica quote" "[Testi e contenuti] Elenco comandi" "dddd" (list (list "Regola posizione testo" "YQ_DIM_ADJUST" "ddaa" "ddaa") (list "Estendi linea di quota" "YQ_DIM_EXTEND" "dde" "dde") (list "Dividi/Estendi in pi� quote" "YQ_DIM_DIVIDE" "dd2" "dd2") (list "Unisci quote" "YQ_DIM_MERGE" "dd1" "dd1") (list "Allinea punti di definizione" "YQ_DIM_ALIGN" "ddv" "ddv") (list "Allinea quote multilinea" "YQ_DIM_ALIGNDIMLINE" "ddvv" "ddvv") (list "Allinea punti terminali" "YQ_DIM_ALIGNPOINTS" "ddl" "ddl") (list "Uniforma lunghezze linee estensione" "YQ_DIM_EXTLEN" "ddle" "ddle") (list "Regola spaziatura base" "YQ_DIM_ADJUSTBASE" "ddy" "ddy") (list "Spaziatura base multipla" "YQ_DIM_BATCHBASE" "ddyy" "ddyy") (list "Mostra linee di estensione" "YQ_DIM_SHOWEXTLINE" "dd2e" "dd2e") (list "Allineata o ruotata" "YQ_DIM_SWITCH_AR" "ddra" "ddra") (list "Ribalta testo quota" "YQ_DIM_REVERSE" "ddfz" "ddfz") (list "Blocca contenuto testo" "YQ_DIM_FIX" "ddf" "ddf") (list "Ripristina valore predefinito" "YQ_DIM_RECOVER" "ddre" "ddre") (list "Unit� in metri" "YQ_DIM_MMTOM" "ddm" "ddm") (list "Arrotonda valore quota" "YQ_DIM_ROUND" "dd0" "dd0") (list "Nuovo testo quota" "YQ_DIM_NEWTEXT" "ddn" "ddn") (list "Sposta testo quota" "YQ_DIM_TEDIT" "ddt" "ddt") (list "Ripristina posizione testo quota" "YQ_DIM_HOME" "ddh" "ddh")))
  (list "Strumenti curve" "[Strumenti curve] Elenco comandi" "xxx" (list (list "Aggiungi/Rimuovi vertici" "YQ_PLINE_VERTEXES" "xxv" "xxv") (list "Ottimizza polilinee" "YQ_PLINE_OPTIMIZE" "xxy" "xxy") (list "Segmento polilinea in arco" "YQ_LINE2ARC" "xxa" "xxa") (list "Larghezza segmento polilinea" "YQ_PLSEGMENT_WIDTH" "xxw" "xxw") (list "Offset segmento polilinea" "YQ_PLSEGMENT_OFFSET" "xxs" "xxs") (list "Unisci polilinea/arco/linea" "YQ_PLINE_JOIN" "xxj" "xxj") (list "Chiudi polilinea/arco/linea" "YQ_PLINE_CLOSE" "xxc" "xxc") (list "Inverti direzione curva" "YQ_PLINE_REVERSE" "xxfz" "xxfz") (list "Polilinea larga in wireframe" "YQ_WPLINE2WIREFRAME" "xxf" "xxf") (list "Collega vertici di 2 polilinee" "YQ_CONNECTVERTEXES" "ljx" "ljx") (list "Trova bordo/contorno" "YQ_OUTLINE" "lk" "lk") (list "Trova contorni interni" "YQ_INNERCONTOURS" "nlk" "nlk") (list "Contorni + offset" "YQ_INNEROFFSET" "nlks" "nlks") (list "Converti in mano libera" "YQ_TOFREEHAND" "hw" "hw") (list "Dividi in parti uguali" "YQ_BREAK_EQUAL" "df" "df") (list "Dividi con 2 punti" "YQ_2PTSDIVIDE" "dfx" "dfx") (list "Ellisse in archi" "YQ_ELLIPSE2ARC" "e2a" "e2a") (list "Curva in polilinea ad archi" "YQ_SPLINE2APLINE" "cca" "cca") (list "Curva in polilinea lineare" "YQ_SPLINE2XPLINE" "ccx" "ccx") (list "Curva in corde" "YQ_CURVE2BOWSTRING" "ccxx" "ccxx") (list "Proiezione curva" "yq_CurveProjection" "ccy" "ccy")))
  (list "Strumenti aggiuntivi" "[Strumenti aggiuntivi] Elenco comandi" "eee" (list (list "Numera linee" "YQ_NUMBERLINES" "vv" "vv") (list "Doppie linee" "YQ_DOUBLELINE" "xd" "xd") (list "Taglia doppie linee" "YQ_TRIMDOUBLELINE" "tx" "tx") (list "Spessore doppia linea" "yq_dlineThickness" "xdt" "xdt") (list "Converti in doppie linee" "YQ_2DOUBLELINE" "xxd" "xxd") (list "Offset doppie linee" "YQ_DLINE_OFFSET" "xdo" "xdo") (list "Asse delle doppie linee" "YQ_DOUBLELINEAXIS" "ce" "ce") (list "Allinea oggetti" "YQ_ALIGNMENT" "dq" "dq") (list "Allinea direttrici" "YQ_LEADERALIGN" "aadq" "aadq") (list "Allinea cornice alla linea" "YQ_ALIGNFRAME" "tktz" "tktz") (list "Taglia con una linea" "YQ_BREAKBYKNIFE" "bd" "bd") (list "Taglia con pi� linee" "yq_BreakByKnives" "bdd" "bdd") (list "Taglia/Cancella nelle cornici" "yq_BreakAndErase" "bx" "bx") (list "Copia/Incolla dettaglio" "YQ_PASTEDETAILDWG" "qg" "qg") (list "Trasforma" "YQ_TRANSFORM" "tf" "tf") (list "Riquadro di ingombro" "YQ_BOUNDINGBOX" "jx" "jx") (list "Adatta al riquadro" "YQ_TOBOUNDINGBOX" "wk" "wk") (list "Riquadro minimo" "yq_minBoundingbox" "xjx" "xjx") (list "Inverti finestre/porte" "YQ_OVERTURN" "fz" "fz") (list "Scambia contenuto" "YQ_EXCHANGELOCATION" "jh" "jh") (list "Copia su punti" "YQ_COPY2POINTS" "dzbz" "dzbz") (list "Linee ausiliarie" "YQ_ASSISTANTLINES" "fzx" "fzx")))
  (list "Modifica avanzata" "[Modifica avanzata] Elenco comandi" "eeee" (list (list "Scala singolarmente" "YQ_SCALE_EACH" "asc" "asc") (list "Ruota singolarmente" "YQ_ROTATE_EACH" "art" "art") (list "Specchia singolarmente" "YQ_MIRROR_EACH" "ami" "ami") (list "Scala XY" "YQ_SCALEXYZ" "scx" "scx") (list "Copia dinamica" "YQ_DYNAMICCOPY" "cv" "cv") (list "Stira di una distanza" "YQ_STRETCH_D" "std" "std") (list "Sposta di una distanza" "YQ_MOVE_D" "vd" "vd") (list "Sposta ripetuto" "YQ_MOVE_MEMORIAL" "vr" "vr") (list "Copia ripetuta" "YQ_COPY_MEMORIAL" "cr" "cr") (list "Offset avanzato" "YQ_SUPEROFFSET" "sf" "sf") (list "Estendi al punto/Linea" "YQ_EXTENDTOPOINT" "exx" "exx") (list "Collega arco/linea/polilinea" "YQ_JOIN_ARCLINE" "ff" "ff") (list "Collega due gruppi di linee" "YQ_CONNECT2GLINES" "fx" "fx") (list "Aggiungi/Rimuovi mascheratura" "YQ_QUICKWIPEOUT" "zz" "zz") (list "Interrompi tutti gli oggetti" "YQ_BREAKALL" "ba" "ba") (list "Interrompi ed elimina residui" "YQ_BREAKERASE" "te" "te") (list "Interrompi in un punto" "YQ_BREAK_AT" "bb" "bb") (list "Interrompi in due punti" "YQ_BREAK_AT2" "bf" "bf")))
  (list "Controllo e correzione" "[Modifica avanzata] Elenco comandi" "ccc" (list (list "Azzera Z degli oggetti" "YQ_CLEAR_Z" "z0" "z0") (list "Azzera Z nei blocchi" "YQ_BLOCK_Z0" "bbz0" "bbz0") (list "Elimina sovrapposizioni" "YQ_REMOVE_DUPLICATE" "rd" "rd") (list "Unisci linee sovrapposte" "YQ_LINEUNION" "lu" "lu") (list "Collega linee/archi" "YQ_LINKLINEARC" "lx" "lx") (list "Rimuovi punti/linee corte" "YQ_LINECLEAN" "lc" "lc") (list "Allinea oggetti alla griglia" "YQ_ADJUST" "jz" "jz") (list "Correzione obliqua" "YQ_OBLIQUE_CORRECTION" "xgz" "xgz") (list "Unione interattiva" "YQ_MERGE" "xhb" "xhb") (list "Elimina elementi inutilizzati in DWG" "YQ_PURGEALL" "pua" "pua") (list "Pulisci DWG nella cartella" "YQ_PURGEFILES" "puf" "puf") (list "Controlla colore oggetti" "YQ_CHECKCOLOR" "cys" "cys") (list "Trova linee non ortogonali" "YQ_FINDNONORTHOLINES" "bpx" "bpx") (list "Trova oggetti fuori piano WCS" "YQ_UCSMATCH" "um" "um") (list "Controllo ortogonalita" "yq_checkOrthoaxis" "bcz" "bcz") (list "Nuvola di revisione" "YQ_REVCLOUD" "yx" "yx") (list "Cornice annotazione" "yq_CommentFrame" "stk" "stk")))
  (list "Strumenti blocchi" "[Strumenti blocchi] Elenco comandi" "bbb" (list (list "Raggruppa alberi" "YQ_HEAPTREES" "zw" "zw") (list "Analisi paesaggio" "YQ_LANDSCAPE" "hj" "hj") (list "Ripristina layer nei blocchi" "YQ_BLOCK2BYLAYER" "bb0" "bb0") (list "Modifica punto base" "YQ_BLOCKBASEPOINT" "bbi" "bbi") (list "Rinomina blocco" "YQ_BLOCK2NEWNAME" "bbr" "bbr") (list "Rinomina blocchi in serie" "YQ_BLOCK_BATCHRENAME" "bbg" "bbg") (list "Crea blocco dettaglio" "YQ_QUICKDETAILBLOCK" "bbd" "bbd") (list "Imposta scala blocco" "YQ_BLOCKSCALE" "bbs" "bbs") (list "Esporta blocchi" "YQ_BLOCK_WRITEOUT" "bbw" "bbw") (list "Sostituisci con DWG" "YQ_REPLACEBYDWG" "bbtd" "bbtd") (list "Crea blocco rapido" "YQ_QUICKNEWBLOCK" "bbn" "bbn") (list "Aggiungi al blocco" "YQ_BLOCK_ADD" "bba" "bba") (list "Elimina oggetto dal blocco" "YQ_BLOCK_REMOVE" "bbe" "bbe") (list "Copia oggetti da un blocco" "YQ_BLOCK_COPY" "bbc" "bbc") (list "Aggiungi/Elimina mascheratura blocco" "YQ_BLOCKWIPEOUT" "bbzz" "bbzz") (list "Crea blocco MINSERT" "YQ_CREATE_MINSERT" "bbjm" "bbjm") (list "Esplodi blocchi MINSERT" "YQ_EXPLODE_MINSERT" "bbx" "bbx") (list "Esplodi blocchi nidificati" "YQ_EXPLODE_NBLOCK" "bbxx" "bbxx") (list "Testo blocco in attributo" "YQ_BLOCKTEXT2ATT" "bbsx" "bbsx") (list "Modifica attributi" "YQ_MODIFY_ATT" "sxg" "sxg") (list "Incrementa attributi" "YQ_INCREASE_ATT" "sxz" "sxz") (list "Modifica Attributi" "YQ_CHANGEATTS" "sxc" "sxc") (list "Attributi in testo" "YQ_BLOCKATT2TEXT" "sxt" "sxt") (list "Elimina attributi dal blocco" "YQ_ERASE_BLKATT" "sxe" "sxe") (list "Catalogo blocchi YQArch" "YQ_BLOCKS" "kk" "kk") (list "La mia libreria di blocchi" "YQ_BLOCKVIEWER" "bv" "bv") (list "Libreria progetto 1" "YQ_BLOCKVIEWER1" "bv1" "bv1") (list "Libreria progetto 2" "YQ_BLOCKVIEWER2" "bv2" "bv2") (list "Libreria progetto 3" "YQ_BLOCKVIEWER3" "bv3" "bv3")))
  (list "Strumenti tratteggio" "[Strumenti tratteggio] Elenco comandi" "hhh" (list (list "Scorciatoie retino" "YQ_HATCHKEYS" "hhsc" "hhsc") (list "Modifica tratteggio e scala" "YQ_HATCHINGSCALE" "xtc" "xtc") (list "Tratteggio rapido" "YQ_HATCH_QUICK" "tc" "tc") (list "Tratteggio da modello" "YQ_HATCH_MATCH" "tct" "tct") (list "Parametri/Anteprima tratteggio" "YQ_HATCH_SLIDE" "tcc" "tcc") (list "Imposta origine tratteggio" "YQ_HATCH_NEWBASE" "hhi" "hhi") (list "Angolo tratteggio" "YQ_HATCH_ANGLE" "hha" "hha") (list "Contorno tratteggio" "YQ_HATCH_BORDER" "hhb" "hhb") (list "Ritaglia tratteggio" "YQ_HATCH_CLIPPING" "hhj" "hhj") (list "Dividi tratteggio" "YQ_HATCH_SPLIT" "hhx" "hhx") (list "Unisci tratteggi" "YQ_HATCH_UNION" "hhu" "hhu") (list "Dissocia tratteggio" "YQ_HATCH_DISASSO" "hhgl" "hhgl") (list "Crea retino .PAT 1 mm" "YQ_MKPAT" "mp" "mp") (list "Crea retino .PAT 1:1" "YQ_MKPAT1" "mp1" "mp1") (list "Crea .PAT dal tratteggio" "YQ_MKPAT_BYHATCH" "mpp" "mpp") (list "Scorciatoie tipi linea" "YQ_LTYPEKEYS" "ltsc" "ltsc") (list "Modifica tipo linea e scala" "YQ_LTSCALE" "xt" "xt") (list "Cambia tipo linea" "YQ_LTSWITCH" "xts" "xts") (list "Sostituisci scala tipo linea" "YQ_PUTLTSCALE" "plts" "plts") (list "Crea tipo linea con testo" "YQ_MKLINETYPE" "mlt" "mlt") (list "Carica tipi linea" "YQ_LOADLINETYPE" "llt" "llt")))
  (list "Strumenti layer" "[Strumenti Layer] Elenco comandi" "lll" (list (list "Sposta su layer corrente" "YQ_LAYER_2CURRENT" "erc" "erc") (list "Crea nuovo layer" "YQ_LAYER_NEW" "ern" "ern") (list "Imposta layer corrente" "YQ_LAYER_CURRENT" "ers" "ers") (list "Salva/Ripristina layer" "YQ_LAYER_SAVERESTORE" "err" "err") (list "Gestione layer con wildcard" "YQ_WLAYER" "erq" "erq") (list "Isola layer" "YQ_LAYER_ISO" "erd" "erd") (list "Disattiva layer" "YQ_LAYER_OFF" "erf" "erf") (list "Disattiva tutti i layer" "YQ_LAYER_OFF_ALL" "eraf" "eraf") (list "Attiva layer" "YQ_LAYER_ON" "era" "era") (list "Attiva tutti i layer" "YQ_LAYER_ON_ALL" "eraa" "eraa") (list "Attiva/Disattiva tutti i layer" "YQ_LAYER_ON2OFF" "erv" "erv") (list "Blocca layer" "YQ_LAYER_LOCK" "erl" "erl") (list "Isola e blocca" "YQ_LAYER_ISO_LOCK" "erdl" "erdl") (list "Sblocca layer" "YQ_LAYER_UNLOCK" "eru" "eru") (list "Congela layer" "YQ_LAYER_FREEZE" "erz" "erz") (list "Isola e congela" "YQ_LAYER_ISO_FREEZE" "erdz" "erdz") (list "Scongela layer" "YQ_LAYER_THAW" "ert" "ert") (list "Disattiva layer nel blocco" "YQ_LAYER_NOFF" "erbf" "erbf") (list "Congela layer nel blocco" "YQ_LAYER_NFREEZE" "erbz" "erbz") (list "Scongela/Sblocca/Attiva tutti" "YQ_LAYER_SHOWALL" "erer" "erer") (list "Sostituzione multipla layer" "YQ_LAYER_REPLACE" "ertd" "ertd") (list "Rinomina layer in serie" "YQ_LAYER_BATCHRENAME" "erg" "erg") (list "Unisci layer" "YQ_MERGE_LAYER" "erm" "erm") (list "Crea layer per colore" "YQ_FORMLAYBYCOLOR" "c2er" "c2er") (list "Scorciatoie layer" "YQ_LAYERKEYS" "ersc" "ersc") (list "Scorciatoie layer wildcard" "YQ_WLAYERKEYS" "erw" "erw") (list "Scorciatoie colori" "YQ_COLORKEYS" "erk" "erk") (list "Esporta elenco layer" "YQ_OUTPUTLAYERS" "ero" "ero") (list "Importa elenco layer" "YQ_INPUTLAYERS" "eri" "eri")))
  (list "Viewport e layout" "[Strumenti viewport/layout] Elenco comandi" "vvv" (list (list "Gestione layer viewport" "YQ_VPLAYER_MANAGER" "vvc" "vvc") (list "Congela layer viewport" "YQ_VPLAYER_FREEZE" "vvz" "vvz") (list "Congela layer blocco in viewport" "YQ_VPLAYER_NFREEZE" "vvbz" "vvbz") (list "Scongela layer viewport" "YQ_VPLAYER_THAW" "vvt" "vvt") (list "Isola layer viewport" "YQ_VPLAYER_ISO" "vvdz" "vvdz") (list "Isola altri layer viewport" "YQ_VPLAYER_ISOALL" "vvzz" "vvzz") (list "Gestione layer viewport in grigio" "YQ_VPLAYER_GRAY" "vvh" "vvh") (list "Ripristina colore Gestione layer viewport" "YQ_VPLAYER_RECOVER" "vvhf" "vvhf") (list "Nuova viewport" "YQ_VIEWPORT_NEW" "vvn" "vvn") (list "Dividi viewport" "YQ_VIEWPORT_SPLIT" "vv2" "vv2") (list "Viewport dallo spazio modello" "YQ_MODEL2VIEWPORT" "mvv" "mvv") (list "Curva in viewport" "YQ_CURVE2VIEWPORT" "xxvv" "xxvv") (list "Imposta scala viewport" "YQ_VIEWPORT_SCALE" "vvs" "vvs") (list "Scala viewport" "YQ_SCALEVPS" "vvsc" "vvsc") (list "Sincronizza contenuto viewport" "YQ_VIEWPORT_SYNC" "vvdq" "vvdq") (list "Pan viewport" "YQ_VIEWPORT_PAN" "vvp" "vvp") (list "Blocca viewport" "YQ_VIEWPORT_LOCK" "vvl" "vvl") (list "Blocca tutte le viewport" "YQ_VIEWPORT_LOCK_ALL" "vval" "vval") (list "Sblocca viewport" "YQ_VIEWPORT_UNLOCK" "vvu" "vvu") (list "Sblocca tutte le viewport" "YQ_VIEWPORT_UNLOCK_ALL" "vvau" "vvau") (list "Isola viewport" "YQ_VIEWPORT_ISO" "vvd" "vvd") (list "Disattiva viewport" "YQ_VIEWPORT_OFF" "vvf" "vvf") (list "Disattiva tutte le viewport" "YQ_VIEWPORT_OFF_ALL" "vvaf" "vvaf") (list "Attiva viewport" "YQ_VIEWPORT_ON" "vva" "vva") (list "Attiva tutte le viewport" "YQ_VIEWPORT_ON_ALL" "vvaa" "vvaa") (list "Copia nello spazio carta" "YQ_VIEWPORT2PSPACE" "vvbb" "vvbb") (list "Rinomina layout" "YQ_LAYOUT_BATCHRENAME" "tzg" "tzg") (list "Cornici in layout" "YQ_FRAMES2LAYOUTS" "tzf" "tzf") (list "Dividi intervallo cornici" "YQ_FRAMEDIVIDED" "tzfg" "tzfg") (list "Ruota direzione viewport" "YQ_UCSDIR" "vvr" "vvr") (list "Istantanea vista" "YQ_SNAPSHOT" "kz" "kz") (list "Collegamenti ipertestuali e viste" "YQ_HYPERLINK" "clj" "clj")))
  (list "Copia e sostituzione propriet�" "[Strumenti viewport/layout] Elenco comandi" "sss" (list (list "Copia/Sostituisci finestra/porta" "YQ_MATCH_BLOCK" "ssb" "ssb") (list "Copia propriet� dinamiche" "YQ_MATCH_DYNPROPS" "ssd" "ssd") (list "Copia angolo rotazione" "YQ_MATCH_ROTATION" "ssa" "ssa") (list "Copia layer" "YQ_MATCH_LAYER" "sser" "sser") (list "Copia colore" "YQ_MATCH_COLOR" "ssc" "ssc") (list "Copia layer e colore" "YQ_MATCH_LAYERCOLOR" "sscc" "sscc") (list "Copia layer viewport" "YQ_MATCH_VPLAYER" "ssvv" "ssvv") (list "Copia contenuto testo" "YQ_MATCH_CONTENT" "sst" "sst") (list "Copia stile testo" "YQ_MATCH_STYLE" "ssst" "ssst") (list "Copia altezza testo" "YQ_MATCH_TEXTHEIGHT" "ssh" "ssh") (list "Copia testo per tag attributo" "YQ_MATCH_TAGTEXT" "ssq" "ssq") (list "Copia larghezza polilinea" "YQ_MATCH_WIDTH" "ssw" "ssw") (list "Copia tipo di linea" "YQ_MATCH_LINETYPE" "ssxt" "ssxt") (list "Copia spessore" "YQ_MATCH_THICKNESS" "ssth" "ssth")))
  (list "Altri strumenti" "[Altri strumenti] Elenco comandi" "qqq" (list (list "Stampa multipla" "YQ_BATCHPLOT" "bpt" "bpt") (list "Catalogo disegni" "YQ_CATALOG" "dwgl" "dwgl") (list "Esporta DWG in serie" "YQ_OUTPUTDWGS" "dwgs" "dwgs") (list "Disponi cornici/disegni" "YQ_ARRANGEDWGS" "dwga" "dwga") (list "Ripristina layer oggetti" "YQ_2BYLAYER" "ee0" "ee0") (list "Nascondi oggetti" "YQ_HIDESELECT" "eef" "eef") (list "Nascondi oggetti non selezionati" "YQ_HIDEUNSELECT" "eed" "eed") (list "Mostra temporaneamente nascosti" "YQ_DISPLAYHIDE" "eea" "eea") (list "Mostra tutti gli oggetti" "YQ_DISPLAYALL" "eeaa" "eeaa") (list "Crea gruppo" "YQ_QUICKGROUP" "ggn" "ggn") (list "Esplodi gruppo" "YQ_EXPLODEGROUP" "ggx" "ggx") (list "Aggiungi al gruppo" "YQ_GROUP_ADD" "gga" "gga") (list "Elimina dal gruppo" "YQ_GROUP_REMOVE" "gge" "gge") (list "Rimuovi dal gruppo" "YQ_GROUP_SEPARATE" "ggs" "ggs") (list "Elimina gruppi inutilizzati" "YQ_PURGEGROUP" "ggp" "ggp") (list "Attiva/Disattiva dinamica YQArch" "YQ_SWITCH_DYNAMIC" "dtyq" "dtyq") (list "Punti dagli appunti Excel" "YQ_DRAWCLIPBOARD" "ztb" "ztb") (list "Esporta in Google Earth" "YQ_ACAD2KML" "a2k" "a2k") (list "Trova comando YQArch" "YQ_COMMANDFINDER" "zml" "zml") (list "Ultimo comando YQArch" "YQ_LASTYQCMD" "qq" "qq")))
))

(defun yqit-pd-nth (n l) (if (and (>= n 0) (< n (length l))) (nth n l)))

(defun yqit-pd-fill-cats (/ s)
  (start_list "cats")
  (foreach s *yqit-pandect-data* (add_list (car s)))
  (end_list))

(defun yqit-pd-fill-cmds (ci / sec it)
  (setq sec (yqit-pd-nth ci *yqit-pandect-data*))
  (start_list "cmds")
  (if sec (foreach it (nth 3 sec) (add_list (car it))))
  (end_list))

(defun yqit-pd-show-item (ci ii / sec it)
  (setq sec (yqit-pd-nth ci *yqit-pandect-data*))
  (setq it (if sec (yqit-pd-nth ii (nth 3 sec))))
  (if it
    (progn
      (set_tile "cmdname" (nth 1 it))
      (set_tile "shortcut" (nth 2 it))
      (set_tile "default" (strcat "Predefinita: " (nth 3 it))))
    (progn
      (set_tile "cmdname" "")
      (set_tile "shortcut" "")
      (set_tile "default" "Predefinita: -"))))

(defun yqit-pd-shortcut-files (/ d out u f)
  (setq d (yqit-sysdir) out nil)
  (if d
    (foreach u '("user1" "user2" "userCCD" "userHBA")
      (setq f (strcat d "\\" u "\\shortcut.yqs"))
      (if (findfile f) (setq out (cons f out)))))
  (reverse out))

(defun yqit-pd-replace-shortcut-line (line cmd new / p low a b)
  (setq low (strcase line T))
  (setq p (vl-string-search (strcat "," (strcase cmd T) ",") low))
  (if p
    (progn
      (setq a (+ p (strlen cmd) 2))
      (setq b (vl-string-search "," line a))
      (if b
        (strcat (substr line 1 a) new (substr line (+ b 1)))
        line))
    line))

(defun yqit-pd-save-shortcut (cmd new / f ls h line out)
  (foreach f (yqit-pd-shortcut-files)
    (setq ls (yqit-read-lines f) out nil)
    (if ls
      (progn
        (foreach line ls (setq out (cons (yqit-pd-replace-shortcut-line line cmd new) out)))
        (setq out (reverse out))
        (if (setq h (open f "w"))
          (progn (foreach line out (write-line line h)) (close h))))))
  T)

(defun yqit-pd-run-command (cmd / r)
  (if (and cmd (/= cmd ""))
    (progn
      (setq r (vl-catch-all-apply 'vl-cmdf (list cmd)))
      (if (vl-catch-all-error-p r)
        (princ (strcat "\nYQArch Italiano: comando non completato: " cmd ". "
                       (vl-catch-all-error-message r))))))
  (princ))

(defun yqit-pd-category (index / d id sec items sel r it cmd)
  (setq sec (yqit-pd-nth index *yqit-pandect-data*))
  (if sec
    (progn
      (setq d (findfile "YQArchItaliano_Pandect293.dcl"))
      (setq id (if d (load_dialog d) -1))
      (if (and (> id 0) (new_dialog "yqit_pandect_category" id))
        (progn
          (setq items (nth 3 sec) sel 0 cmd nil)
          (set_tile "title" (strcat "Categoria: " (car sec)))
          (start_list "items") (foreach it items (add_list (car it))) (end_list)
          (if items
            (progn
              (set_tile "items" "0")
              (set_tile "cmd" (nth 1 (car items)))
              (set_tile "shortcut" (nth 2 (car items)))))
          (action_tile "items" "(setq sel (atoi $value) it (yqit-pd-nth sel items))(if it (progn (set_tile \"cmd\" (nth 1 it))(set_tile \"shortcut\" (nth 2 it))))")
          (action_tile "run" "(setq it (yqit-pd-nth sel items) cmd (if it (nth 1 it) nil))(done_dialog 2)")
          (action_tile "save" "(setq it (yqit-pd-nth sel items))(if it (progn (yqit-pd-save-shortcut (nth 1 it) (get_tile \"shortcut\"))(alert \"Scorciatoia salvata. Sar� pienamente attiva dopo il ricaricamento di YQArch.\")))")
          (action_tile "reset" "(setq it (yqit-pd-nth sel items))(if it (progn (set_tile \"shortcut\" (nth 3 it))(yqit-pd-save-shortcut (nth 1 it) (nth 3 it))))")
          (setq r (start_dialog))
          (unload_dialog id)
          (if (= r 2) (yqit-pd-run-command cmd)))
        (progn (if (> id 0) (unload_dialog id))
               (alert "Impossibile aprire l'elenco comandi italiano.")))))
  (princ))

(defun yqit-pandect-native (/ d id ci ii sec it r cmd)
  (setq d (findfile "YQArchItaliano_Pandect293.dcl"))
  (setq id (if d (load_dialog d) -1))
  (if (and (> id 0) (new_dialog "yqit_pandect" id))
    (progn
      (setq ci 0 ii 0 cmd nil)
      (yqit-pd-fill-cats)
      (set_tile "cats" "0")
      (yqit-pd-fill-cmds 0)
      (if (nth 3 (car *yqit-pandect-data*))
        (progn (set_tile "cmds" "0") (yqit-pd-show-item 0 0)))
      (action_tile "cats" "(setq ci (atoi $value) ii 0)(yqit-pd-fill-cmds ci)(set_tile \"cmds\" \"0\")(yqit-pd-show-item ci 0)")
      (action_tile "cmds" "(setq ii (atoi $value))(yqit-pd-show-item ci ii)")
      (action_tile "open" "(done_dialog 3)")
      (action_tile "run" "(setq sec (yqit-pd-nth ci *yqit-pandect-data*) it (if sec (yqit-pd-nth ii (nth 3 sec))) cmd (if it (nth 1 it) nil))(done_dialog 2)")
      (action_tile "save" "(setq sec (yqit-pd-nth ci *yqit-pandect-data*) it (if sec (yqit-pd-nth ii (nth 3 sec))))(if it (progn (yqit-pd-save-shortcut (nth 1 it) (get_tile \"shortcut\"))(alert \"Scorciatoia salvata. Sar� pienamente attiva dopo il ricaricamento di YQArch.\")))")
      (action_tile "resetone" "(setq sec (yqit-pd-nth ci *yqit-pandect-data*) it (if sec (yqit-pd-nth ii (nth 3 sec))))(if it (progn (set_tile \"shortcut\" (nth 3 it))(yqit-pd-save-shortcut (nth 1 it) (nth 3 it))))")
      (action_tile "resetall" "(foreach sec *yqit-pandect-data* (foreach it (nth 3 sec) (yqit-pd-save-shortcut (nth 1 it) (nth 3 it))))(alert \"Scorciatoie ripristinate ai valori predefiniti.\")")
      (action_tile "export" "(alert \"Il catalogo delle scorciatoie � gi� memorizzato nei profili YQArch Italiano. La funzione di esportazione completa sar� migrata insieme alla gestione profili.\")")
      (action_tile "reload" "(yqit-pd-fill-cats)(yqit-pd-fill-cmds ci)(yqit-pd-show-item ci ii)")
      (setq r (start_dialog))
      (unload_dialog id)
      (cond
        ((= r 2) (yqit-pd-run-command cmd))
        ((= r 3) (yqit-pd-category ci))))
    (progn (if (> id 0) (unload_dialog id))
           (alert "Impossibile aprire la Panoramica comandi italiana.")))
  (princ))

(defun c:YQARCH () (yqit-pandect-native))
(defun c:YQ_PANDECT () (yqit-pandect-native))

(defun c:YQ_SYSTEMSETUP () (yqit-pd-category 0))
(defun c:YQ_WALLCOLUMN () (yqit-pd-category 1))
(defun c:YQ_WINDOWDOOR () (yqit-pd-category 2))
(defun c:YQ_COMPONENTS () (yqit-pd-category 3))
(defun c:YQ_DECORATION () (yqit-pd-category 4))
(defun c:YQ_ARCHSYMBOLS () (yqit-pd-category 5))
(defun c:YQ_INDEXERS () (yqit-pd-category 6))
(defun c:YQ_STATISTICS () (yqit-pd-category 7))
(defun c:YQ_TEXTCONTENT () (yqit-pd-category 8))
(defun c:YQ_TEXTOTHER () (yqit-pd-category 9))
(defun c:YQ_DIMDRAW () (yqit-pd-category 10))
(defun c:YQ_DIMMODIFY () (yqit-pd-category 11))
(defun c:YQ_CURVETOOLS () (yqit-pd-category 12))
(defun c:YQ_EXTRATOOLS () (yqit-pd-category 13))
(defun c:YQ_MODIFYPLUS () (yqit-pd-category 14))
(defun c:YQ_CHECKCORRECT () (yqit-pd-category 15))
(defun c:YQ_BLOCKTOOLS () (yqit-pd-category 16))
(defun c:YQ_HATCHINGTOOLS () (yqit-pd-category 17))
(defun c:YQ_LAYERTOOLS () (yqit-pd-category 18))
(defun c:YQ_VIEWPORTTOOLS () (yqit-pd-category 19))
(defun c:YQ_MATCHBRUSH () (yqit-pd-category 20))
(defun c:YQ_OTHERTOOLS () (yqit-pd-category 21))
(princ)
;;; ==========================================================================
;;; ==========================================================================
;;; YQArch Italiano 3.38 - preservazione funzionale / equivalenza comandi
;;; --------------------------------------------------------------------------
;;; Nessun adapter geometrico sostitutivo per Porta, Finestra o Scala mobile.
;;; Nessun reactor PEDIT: le compatibilit� sono corrette direttamente nei soli
;;; token AutoCAD delle routine originali yqarch.vlx, senza modificarne geometria,
;;; sequenza operativa, opzioni, blocchi, layer o valori predefiniti.
;;; ==========================================================================


(princ)

