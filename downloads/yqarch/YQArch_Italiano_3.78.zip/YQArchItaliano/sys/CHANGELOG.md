# YQArch Italiano 3.78

- Release di pubblicazione dopo il collaudo della 3.77 su AutoCAD 2027 italiano del 3 ottobre 2026.
- Ribbon CUIx identico alla 3.77: una riga principale con grande e sottopannello di 5 piccoli affiancati (3+2), più 7 accessi nel flyout per pannello. 10 pannelli e 130 accessi totali conservati.
- Diagnostica completa corretta: 10 grandi + 50 piccoli visibili + 70 nel flyout; 23 categorie e 547 voci storiche.
- Core, catalogo, anteprime, inserimento diretto, impostazioni e pagina Sostieni preservati. Installer completo con backup, rollback e pulizia cache fino alla 3.77.
- Guida con 646 schede e documenti aggiornati; verifiche statiche e simulate distinte dal collaudo nativo della 3.77.

---
## Cronologia precedente (testi storici, non nuova certificazione)

# YQArch Italiano 3.73

- Corretto il crash dell'installer 3.72 durante **Aggiornamento profili** in presenza di più profili AutoCAD: eliminata la collisione PowerShell tra `$script:V` e `$v`.
- La cache dei file già verificati usa ora `$script:VerifiedUnchanged`; il ciclo delle versioni menu usa `$menuVersion`; la verifica finale usa `.ContainsKey()`.
- Aggiunti test anti-regressione specifici per installazioni multi-profilo e mantenuto il rollback journal/backup.
- Conservati integralmente il popolazione Ribbon consolidata (10 pannelli, 130 accessi promossi), gli identificatori UI stabili e il flusso di inserimento blocchi a un solo passaggio.
- Conservato il controllo preventivo dei formati DWG introdotto nel candidato precedente: 147/195 blocchi leggibili da AutoCAD 2004–2006; 48 AC1021 richiedono AutoCAD 2007 o successivo.
- Guida mantenuta a 646 schede; documentazione e numero di versione aggiornati alla 3.73.
- I nomi tecnici interni `_372` del runtime consolidato restano intenzionalmente stabili per evitare regressioni; la versione pubblica/installata è 3.73.

Verifiche automatiche della 3.73: 71 controlli statici/risorse e 184 test di logica/API simulate superati prima del packaging. Successivamente la 3.73 è stata collaudata realmente su AutoCAD 2026 italiano con esito positivo per installazione/aggiornamento, Ribbon e inserimento blocchi.

# Changelog YQArch Italiano

## 3.59
- Chiusura delle 89 UI residue: 148/148 interfacce grafiche rilevate certificate integralmente italiane.
- Stile comune DCL/VV uniformato e ripristino delle keyword tecniche `fixed_width/fixed_height`.
- 152 patch UI FAS4 a lunghezza invariata; SLB invariato.
- Classe C residua: 0.

## 3.56
- Chiusura globale della revisione linguistica del core storico con ulteriori patch FAS4 conservative a lunghezza invariata.
- Rifinitura del menu **Impostazioni e supporto** e sincronizzazione terminologica delle relative voci.
- Correzione dei caratteri accentati nelle DCL native e controllo sistematico delle codifiche.
- Guida italiana ampliata a 646/646 schede con procedure passo-passo, livelli di documentazione e ricerca.
- Mantenuti congelati SLB e moduli moderni gia collaudati.
- Rafforzati i test su LSP, DCL, pannelli, registro comandi, struttura FAS4 e packaging.

## 3.53
- Stabilizzazione dei pannelli Q5/Q7 e correzione dell'invocazione XC_SS.
- Normalizzazione del menu Impostazioni e supporto e separazione del sostegno al progetto originale da quello all'edizione italiana.
- Prima guida completa con 646 schede.
- Ulteriore revisione di Sezione porta, isolamento, retini e quote.

## 3.52
- Revisione massiva dei prompt e delle stringhe visibili del core.
- Loader esterno reso piu deterministico e silenzioso.
- Pulizia delle voci legacy dei pannelli/scorciatoie.

## 3.51
- Revisione massiva del core visibile: 284 stringhe FAS4 inglesi localizzate e 74 controparti cinesi neutralizzate in italiano, senza riallocare il FAS.
- Corretto `YQ_BANISTER`: rimosse tutte le variabili locali/formali `t` in conflitto con la costante AutoLISP `T`.
- Audit globale T/NIL, sintassi LSP/DCL, registro 646 comandi, packaging e riferimenti release-specifici.

## 3.49
- Onda 1: modernizzate UI Scala curva e Scala mobile; nuova anteprima Parapetto; core funzionale invariato.

# 3.48 - 2026-09-10

- Consolidamento grafico delle interfacce native.
- Porta scorrevole: lista preset non sovrapposta.
- Anteprime scale più tecniche e leggibili.
- Revisione terminologica e correzione refusi DCL esterni.
- Matrice di modernizzazione aggiornata con evidenza runtime 3.47.
- Core storico stabile preservato.

# 3.48 - 2026-09-10

- Avvio della revisione completa come edizione italiana moderna.
- Nuove anteprime professionali e dinamiche per scale e porta scorrevole.
- Glossario tecnico e matrice di modernizzazione dei 646 comandi.
- Cinque prompt storici yqpanel tradotti alla fonte.
- Core VLX stabile preservato.

# 3.48 - 2026-09-10

- Ripristino core reale 3.42; lint AutoLISP rigoroso; moduli nativi isolati; diagnostica 646 comandi.

# 3.42 - 2026-09-09

- Sezione scala: eliminato il posizionamento `VL-CMDF + PAUSE` della 3.41.
- Nuovo posizionamento interno: `prompt italiano originale + GETPOINT(QO$, stringa vuota)` + helper originale `YQ_MOVE(QJ,QO$,target)`.
- Generatore geometrico, DCL, varianti, resource stream e anteprime invariati.
- Pianta vano scala e gli altri percorsi migliorati restano congelati.

# 3.41 - 2026-09-09

- Sezione scala: sostituita la sequenza finale di 6 `ads-cmd` con una singola `VL-CMDF` atomica, preservando gruppo QJ, `_non`, punto base QO$ e `PAUSE` originali.
- Generatore geometrico e tutte le opzioni della Sezione scala restano originali.
- Pianta vano scala congelata sulla 3.40 dopo il superamento del precedente punto critico nel test reale.
- Nessuna modifica alle anteprime, a Finestra, Porta scorrevole, Scala mobile o Scala curva.

# 3.40 - 2026-09-09

- Pianta vano scala: corretti 5 override OSNAP locali `non` e 1 risposta `y` nel call-graph originale (`_non` / `_y`).
- Pianta vano scala: ricostruite `STAIRPLAN` e `STAIRPLANE` con etichette native italiane e senza sovrapposizioni inglesi/cinesi.
- Finestra, Porta scorrevole, Scala mobile e Scala curva congelate rispetto alla 3.39.
- Confermata la policy: equivalenza funzionale completa e stabilità AutoCAD 2027 hanno priorità sulla conservazione del codice legacy.

# 3.33 - 2026-09-08

- Corretto il numero release visualizzato dal bootstrap installer (patch binaria stessa lunghezza, senza ricompilare il launcher).
- Sezione scala: comando originale preservato; compatibilità PEDIT localizzata tramite PEDITACCEPT temporaneo e ripristino automatico.
- Sezione scala: anteprima originale resa leggibile cambiando soltanto lo sfondo del tile DCL VIEW.
- Simbolo pendenza: ulteriori stringhe puramente visive localizzate nativamente nel FAS a lunghezza invariata; keyword tecniche non modificate.
- Corretto il refuso visibile `mousa` -> `mouse` nei prompt di rotazione del core.
- Rafforzato il gate: diff binario VLX ammesso solo nelle posizioni dichiarate, controllo keyword tecniche e controllo versione bootstrap.
- Ribadita policy: nessuna modifica della logica funzionale originale YQArch come soluzione finale.

# YQArch Italiano 3.06

- Localizzazione nativa mirata della scala rettilinea nel secondo stream FAS4 di `yqarch.vlx`.
- Tradotti alla fonte i prompt `Plan of a staircase`, `Landing width`, `Tread width` e `Current Step Altezza`.
- Lunghezza dello stream FAS4, chiave di cifratura, offset e bytecode preservati.
- DCL italiano della scala preservato; nessuna riscrittura della logica geometrica.
- Numerazione automatica, YQ_WALL, Porta, Griglia assi, Cornice, Stampa multipla, Dizionario e Menu grafico congelati funzionalmente.

# YQArch Italiano 3.04

- Preparazione della release pubblica aggiornata.
- Preservato il motore originale funzionante della Numerazione automatica.
- Tradotti prompt residui dell'Indicatore (secondo/terzo punto, commento, angolo polare).
- Tradotto il messaggio finale “numeri progressivi creati”.
- Ripulito il commento predefinito con “Marmo”.
- Migliorata la documentazione di compatibilità Windows/AutoCAD e dei problemi noti.
- Nessuna modifica agli offset o ai simboli eseguibili del core FAS4.

# YQArch Italiano 3.04

- Audit strutturale della localizzazione nel core FAS4 incorporato in `yqarch.vlx`.
- Traduzione nativa alla sorgente binaria di stringhe UI/prompt riconosciute, con patch a lunghezza fissa per non modificare offset e flusso eseguibile.
- Completate le stringhe residue di Scala curva e Indicatore utente, oltre a numerose stringhe condivise di quote, scale, pannelli e comandi.
- Ridotto il banner storico YQArch all'avvio intervenendo direttamente sulle risorse del core.
- Numerazione automatica mantiene integralmente il motore originale YQArch, già verificato funzionante nella 3.00.
- Corrette stringhe residue nei DCL incorporati (ordinali, incremento/decremento, cifre).
- Aggiornato l'audit di regressione e localizzazione.

# Changelog

## 3.00
- Corretto il flusso di Numerazione automatica: la selezione degli oggetti è ora immediata.
- Mantenuta la Porta nativa italiana introdotta nella 2.97.
- Pulizia di file obsoleti/non referenziati.
- Revisione terminologica e grammaticale di stringhe visibili.
- Aggiunta documentazione per GitHub, compatibilità, problemi noti e attribuzioni.
- Audit statico dei prompt AutoLISP/DCL.
- Conservati i moduli già stabilizzati senza riscritture funzionali.

## 2.97
- Migrazione nativa di Numerazione automatica e Porta.

## 2.96
- Ripristinati i due metodi di sostegno alla versione italiana.


## 3.78
- Ribbon vincolata a due sole righe visibili per pannello: 1 grande + 5 piccoli; 7 accessi nel flyout.
- Rimossa la terza riga visibile che alterava l'altezza percepita della Ribbon.
- Guida HTML riordinata e riallineata.
