# Riscontro reale utente sulla 3.75

Data: 03/10/2026.

- La Ribbon 3.75 si carica in AutoCAD 2027 italiano, ma la presenza di 1 comando grande + 2 righe da 3 piccoli per pannello mantiene la scheda troppo alta/densa rispetto alla Ribbon standard di AutoCAD.
- Regola richiesta: l’altezza standard di AutoCAD è un vincolo ferreo. La correzione 3.76 usa 1 grande + una sola riga da 5 piccoli; i 7 promoted rimanenti vanno nel flyout.
- L’utente ha inoltre segnalato un’impaginazione non corretta della Guida: la 3.76 sposta intestazione e note di versione dentro una struttura unica e allineata.
- Nessuna richiesta di modifica al core, al catalogo blocchi o alla pagina Sostieni.
